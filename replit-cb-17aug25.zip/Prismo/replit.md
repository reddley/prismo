# Overview

Prismo is an AI-powered competitive intelligence platform designed to aggregate, analyze, and present real-time insights from multiple data sources, primarily RSS feeds from major tech publications. It leverages AI for sentiment analysis and content categorization, delivering live dashboards with briefings, notifications, and trend analysis. The platform aims to provide comprehensive market intelligence monitoring, processing a high volume of daily insights, and offering advanced stock market tracking and real-time fuzzy search capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend
- **Framework**: React 18 with TypeScript and Vite.
- **UI Library**: shadcn/ui (built on Radix UI) with Tailwind CSS for styling, supporting dark/light modes.
- **State Management**: TanStack Query for server state and caching.
- **Routing**: Wouter.
- **Charts**: Recharts.
- **UI/UX Decisions**: Eliminated all animate-pulse effects for a clean, static loading state experience. Dynamic report resizing with subtle visual indicators and smooth transitions. Full keyboard navigation with visible focus rings. Advanced placement system with instant modal dismissal, hover previews, and precise grid positioning.

## Backend
- **Runtime**: Node.js with Express.js.
- **Language**: TypeScript with ES modules.
- **API Pattern**: RESTful endpoints with JSON.
- **File Uploads**: Multer.
- **Scheduling**: Node-cron for automation.
- **Session Management**: Express sessions with PostgreSQL storage.
- **Rate Limiting**: Comprehensive tenant-aware token bucket system with load shedding and backpressure controls.

## Data Storage
- **Database**: PostgreSQL with Neon serverless hosting.
- **ORM**: Drizzle ORM with schema-first TypeScript definitions.
- **Connection Pooling**: Transaction-mode pooling with optimized connections.
- **Performance**: Optimized indexes achieving sub-100ms query times, 5x dashboard performance improvement.
- **Schema Design**: Dedicated tables for users, data sources, insights, monitors, briefings, and notifications.
- **Knowledge Graph**: Complete entity-relationship model with 8 core tables (entities, edges, events, embeddings) supporting vector search and fuzzy text matching. Includes entity canonicalization and deduplication system.

## Unified Service Architecture & AI Integration
- **Architecture**: Consolidated service layer with dependency injection container and standardized error handling policies.
- **Services**: Four unified intelligent services managing AI operations, data processing, user intelligence, and cost optimization.
- **AI Provider**: OpenAI (GPT-4o-mini) with intelligent model routing and cost optimization.
- **Cost Strategy**: Rule-based pre-filtering handles a majority of operations at zero cost, AI reserved for uncertain cases with daily budget limits.
- **Capabilities**: Hybrid sentiment analysis, content summarization, entity extraction, user behavior learning, and intelligent alerting.

## Data Processing Pipeline
- **RSS Parsing**: Custom parser with error handling and retry logic.
- **Scheduling**: Automated feed fetching (every 15 minutes) and daily briefings.
- **Content Analysis**: Real-time AI processing for sentiment and categorization.
- **Monitoring**: Keyword-based content monitoring with configurable alerts.

## Stock Market Integration
- **Real-Time Search**: Polygon.io API integration with fuzzy company name matching.
- **Rate Limiting Protection**: Intelligent debouncing with minimum API call intervals.
- **Comprehensive Fallback**: 40+ curated global companies.
- **Smart Caching**: TTL for live quotes and search results.
- **Watchlist Management**: Persistent user watchlists with real-time quote updates.
- **International Coverage**: Support for major US, Asian, and European companies.

## Zero-Downtime Migration System
- **Migration Pattern**: "Add → Backfill → Swap" approach for schema changes without downtime.
- **Safe Operations**: Uses `CREATE INDEX CONCURRENTLY`, `NOT VALID` constraints, and batch processing.
- **Tracking**: Dedicated migration_history and migration_steps tables for progress monitoring.
- **Rollback Support**: Step-by-step rollback capabilities.
- **Non-Blocking**: No table locks or service interruptions during migrations.

## Authentication & Security
- **Role-Based Access Control**: Admin/User privilege levels.
- **Input Validation**: Zod schemas.
- **Error Handling**: Centralized error handling.

# External Dependencies

## Core Infrastructure
- **Database**: Neon PostgreSQL.
- **File Storage**: Local filesystem for uploaded logos.
- **Session Store**: connect-pg-simple.

## AI Services
- **OpenAI API**: For content analysis, sentiment detection, and briefing generation.

## Financial Data Services
- **Polygon.io API**: Real-time stock quotes, company search, and market data.

## UI Components
- **Design System**: shadcn/ui.
- **Icons**: Lucide React.
- **Charts**: Recharts.
- **Forms**: React Hook Form with Zod validation.