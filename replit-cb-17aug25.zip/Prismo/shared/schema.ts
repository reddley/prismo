import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb, boolean, real, numeric, date, vector } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  name: text("name"), // User's full name
  title: text("title"), // User's job title/role description
  profileImageUrl: text("profile_image_url"), // Profile picture
  password: text("password").notNull(), // Argon2id hashed
  logoUrl: text("logo_url"),
  theme: text("theme").default("dark"),
  role: text("role", { enum: ["admin", "user"] }).notNull().default("user"),
  teamId: varchar("team_id"), // For future team functionality
  emailVerified: boolean("email_verified").default(false),
  emailVerificationToken: text("email_verification_token"),
  emailVerificationExpires: timestamp("email_verification_expires"),
  passwordResetToken: text("password_reset_token"),
  passwordResetExpires: timestamp("password_reset_expires"),
  lastLoginAt: timestamp("last_login_at"),
  loginAttempts: integer("login_attempts").default(0),
  lockoutUntil: timestamp("lockout_until"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Teams table for future multi-tenant support
export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  logoUrl: text("logo_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User-Team relationship table for future expansion
export const userTeams = pgTable("user_teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  role: text("role", { enum: ["owner", "admin", "member"] }).notNull().default("member"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dataSources = pgTable("data_sources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'rss', 'api', 'reddit', 'twitter', 'news', 'custom'
  url: text("url").notNull(),
  category: text("category"), // 'technology', 'finance', 'general', 'social', 'patents'
  description: text("description"),
  fetchFrequency: integer("fetch_frequency").default(15), // minutes
  isActive: boolean("is_active").default(true),
  lastFetched: timestamp("last_fetched"),
  createdAt: timestamp("created_at").defaultNow(),
  // Workflow automation fields
  headers: jsonb("headers"), // Custom headers for API calls
  authType: text("auth_type"), // 'none', 'bearer', 'api_key', 'basic'
  authCredentials: text("auth_credentials"), // encrypted auth info
  customMapping: jsonb("custom_mapping"), // field mapping for custom APIs
});

export const insights = pgTable("insights", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  summary: text("summary"),
  category: text("category"),
  source: text("source"),
  sourceUrl: text("source_url"),
  sentiment: text("sentiment"), // 'positive', 'negative', 'neutral'
  confidence: integer("confidence"), // 0-100
  priority: text("priority"), // 'low', 'medium', 'high', 'critical'
  tags: text("tags").array(),
  metadata: jsonb("metadata"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const monitors = pgTable("monitors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  keywords: text("keywords").array(),
  isActive: boolean("is_active").default(true),
  sourceCount: integer("source_count").default(0),
  status: text("status").default("active"), // 'active', 'paused', 'limited'
  createdAt: timestamp("created_at").defaultNow(),
});

export const briefings = pgTable("briefings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  keyPoints: text("key_points").array(),
  date: timestamp("date").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // 'info', 'warning', 'error', 'success'
  priority: text("priority").default("medium"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Entity tables for companies, people, and organizations (used in Decks)
export const companies = pgTable("companies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  industry: text("industry"),
  founded: text("founded"), // Year or date founded
  headquarters: text("headquarters"),
  website: text("website"),
  logoUrl: text("logo_url"),
  marketCap: text("market_cap"),
  employees: text("employees"),
  revenue: text("revenue"),
  status: text("status").default("active"), // 'active', 'acquired', 'defunct', 'public', 'private'
  tags: text("tags").array(),
  keyPeople: jsonb("key_people"), // Array of key executives
  socialMedia: jsonb("social_media"), // Twitter, LinkedIn, etc.
  mentionCount: integer("mention_count").default(0),
  lastMentioned: timestamp("last_mentioned"),
  priority: text("priority").default("normal"), // ignore, normal, high, critical
  isAutoCreated: boolean("is_auto_created").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const people = pgTable("people", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  title: text("title"),
  company: text("company"),
  description: text("description"),
  industry: text("industry"),
  location: text("location"),
  profileImageUrl: text("profile_image_url"),
  linkedinUrl: text("linkedin_url"),
  twitterUrl: text("twitter_url"),
  website: text("website"),
  expertise: text("expertise").array(),
  tags: text("tags").array(),
  influence: text("influence").default("medium"), // 'low', 'medium', 'high', 'expert'
  mentionCount: integer("mention_count").default(0),
  lastMentioned: timestamp("last_mentioned"),
  priority: text("priority").default("normal"), // ignore, normal, high, critical
  isAutoCreated: boolean("is_auto_created").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const organizations = pgTable("organizations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'agency', 'nonprofit', 'government', 'association', 'think_tank'
  description: text("description"),
  industry: text("industry"),
  founded: text("founded"),
  headquarters: text("headquarters"),
  website: text("website"),
  logoUrl: text("logo_url"),
  budget: text("budget"),
  employees: text("employees"),
  tags: text("tags").array(),
  keyPeople: jsonb("key_people"),
  socialMedia: jsonb("social_media"),
  mentionCount: integer("mention_count").default(0),
  lastMentioned: timestamp("last_mentioned"),
  priority: text("priority").default("normal"), // ignore, normal, high, critical
  isAutoCreated: boolean("is_auto_created").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Entity mentions - links insights to specific entities
export const entityMentions = pgTable("entity_mentions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  insightId: varchar("insight_id").notNull().references(() => insights.id, { onDelete: "cascade" }),
  entityType: text("entity_type").notNull(), // company, person, organization
  entityId: varchar("entity_id").notNull(),
  mentionType: text("mention_type").default("reference"), // reference, quote, analysis, announcement
  confidence: real("confidence").default(0.8), // AI confidence in the mention
  context: text("context"), // Surrounding text for context
  createdAt: timestamp("created_at").defaultNow(),
});

// Entity relationships - tracks connections between entities
export const entityRelationships = pgTable("entity_relationships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromEntityType: text("from_entity_type").notNull(),
  fromEntityId: varchar("from_entity_id").notNull(),
  toEntityType: text("to_entity_type").notNull(),
  toEntityId: varchar("to_entity_id").notNull(),
  relationshipType: text("relationship_type").notNull(), // works_at, partner_with, acquired_by, competitor_of, etc.
  strength: real("strength").default(0.5), // Relationship strength 0-1
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Boards for visualizing entity connections
export const boards = pgTable("boards", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  layout: jsonb("layout"), // Visual layout data for the board
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Board entities - which entities are on which boards
export const boardEntities = pgTable("board_entities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  boardId: varchar("board_id").notNull().references(() => boards.id, { onDelete: "cascade" }),
  entityType: text("entity_type").notNull(),
  entityId: varchar("entity_id").notNull(),
  position: jsonb("position"), // x, y coordinates on the board
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Deck mentions table for entity-insight relationships
export const deckMentions = pgTable("deck_mentions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityType: text("entity_type").notNull(), // 'company', 'person', 'organization'
  entityId: varchar("entity_id").notNull(),
  insightId: varchar("insight_id").references(() => insights.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  content: text("content"),
  source: text("source"),
  sourceUrl: text("source_url"),
  sentiment: text("sentiment"), // 'positive', 'negative', 'neutral'
  relevance: integer("relevance").default(50), // 0-100 relevance score
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// System settings for global application control
export const systemSettings = pgTable("system_settings", {
  id: varchar("id").primaryKey().default("main"),
  dataIngestionEnabled: boolean("data_ingestion_enabled").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User preference tracking for intelligent alerts
export const userPreferences = pgTable("user_preferences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  preferenceType: text("preference_type").notNull(), // entity_type, topic, sentiment_preference, etc.
  preferenceValue: text("preference_value").notNull(),
  weight: real("weight").default(1.0), // How strong this preference is
  source: text("source").default("implicit"), // implicit, explicit, learned
  confidence: real("confidence").default(0.5),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Email verification queue for batch processing
export const emailVerificationQueue = pgTable("email_verification_queue", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  email: text("email").notNull(),
  token: text("token").notNull(),
  attemptCount: integer("attempt_count").default(0),
  lastAttemptAt: timestamp("last_attempt_at"),
  expiresAt: timestamp("expires_at").notNull(),
  status: text("status", { enum: ["pending", "sent", "delivered", "failed", "expired"] }).default("pending"),
  errorMessage: text("error_message"),
  priority: text("priority", { enum: ["high", "normal", "low"] }).default("normal"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Rate limiting tracking per IP and email
export const rateLimitAttempts = pgTable("rate_limit_attempts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  identifier: text("identifier").notNull(), // IP address or email
  identifierType: text("identifier_type", { enum: ["ip", "email"] }).notNull(),
  attemptType: text("attempt_type", { enum: ["signup", "login", "password_reset", "email_verification"] }).notNull(),
  attemptCount: integer("attempt_count").default(1),
  lastAttemptAt: timestamp("last_attempt_at").defaultNow(),
  resetAt: timestamp("reset_at").notNull(),
  blocked: boolean("blocked").default(false),
  blockReason: text("block_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Security audit log
export const securityAuditLog = pgTable("security_audit_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }),
  action: text("action").notNull(), // signup, login, logout, password_change, email_verify, etc.
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  success: boolean("success").notNull(),
  failureReason: text("failure_reason"),
  sessionId: text("session_id"),
  metadata: jsonb("metadata"),
  riskScore: integer("risk_score").default(0), // 0-100 risk assessment
  blocked: boolean("blocked").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Session security enhancements
export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }),
  data: jsonb("data").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  lastAccessedAt: timestamp("last_accessed_at").defaultNow(),
  invalidated: boolean("invalidated").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Stock market watchlist for tracking followed stocks
export const stockWatchlist = pgTable("stock_watchlist", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  isActive: boolean("is_active").default(true),
  addedAt: timestamp("added_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// === KNOWLEDGE GRAPH CORE DATA MODEL ===

// Core entity table - represents any real-world entity (person, company, concept, etc.)
export const entities = pgTable("entities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // person, company, organization, concept, location, product, etc.
  name: text("name").notNull(),
  canonicalName: text("canonical_name").notNull(),
  description: text("description"),
  status: text("status", { enum: ["active", "inactive", "merged", "deprecated"] }).default("active"),
  confidence: real("confidence").default(1.0), // 0.0-1.0 confidence in entity existence/accuracy
  source: text("source").default("manual"), // manual, extracted, imported, inferred
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Entity identifiers - various ways to identify the same entity (handles aliases, IDs, etc.)
export const entityIdentifiers = pgTable("entity_identifiers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityId: varchar("entity_id").notNull().references(() => entities.id, { onDelete: "cascade" }),
  scheme: text("scheme").notNull(), // domain, cik, wikipedia, patent, ticker, lei, duns, permid
  value: text("value").notNull(),
  originalValue: text("original_value").notNull(), // Original unprocessed value
  isPrimary: boolean("is_primary").default(false), // Primary identifier for this scheme
  confidence: real("confidence").default(1.0), // Confidence this identifier belongs to this entity
  source: text("source").default("manual"), // Where this identifier was discovered
  createdAt: timestamp("created_at").defaultNow(),
});

// Entity attributes - flexible key-value properties for entities
export const entityAttributes = pgTable("entity_attributes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityId: varchar("entity_id").notNull().references(() => entities.id, { onDelete: "cascade" }),
  key: text("key").notNull(), // industry, founded_year, headquarters, revenue, employee_count, etc.
  value: text("value").notNull(),
  dataType: text("data_type", { enum: ["text", "number", "date", "boolean", "json", "url"] }).default("text"),
  confidence: real("confidence").default(1.0), // Confidence in this attribute value
  source: text("source").default("manual"), // Source of this attribute
  sourceUrl: text("source_url"), // URL where this was extracted from
  validFrom: timestamp("valid_from").defaultNow(), // When this attribute became valid
  validTo: timestamp("valid_to"), // When this attribute expires/becomes invalid
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Entity embeddings - vector representations for semantic search
export const entityEmbeddings = pgTable("entity_embeddings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityId: varchar("entity_id").notNull().references(() => entities.id, { onDelete: "cascade" }),
  model: text("model").notNull(), // embedding model used (text-embedding-3-small, etc.)
  embedding: vector("embedding", { dimensions: 1536 }), // 1536-dimensional vector for OpenAI text-embedding-3-small
  sourceText: text("source_text"), // Text that was embedded
  createdAt: timestamp("created_at").defaultNow(),
});

// Edges - relationships between entities
export const edges = pgTable("edges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromEntityId: varchar("from_entity_id").notNull().references(() => entities.id, { onDelete: "cascade" }),
  toEntityId: varchar("to_entity_id").notNull().references(() => entities.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // works_at, owns, competes_with, acquired_by, located_in, etc.
  strength: real("strength").default(0.5), // 0.0-1.0 strength of relationship
  direction: text("direction", { enum: ["directed", "undirected"] }).default("directed"),
  status: text("status", { enum: ["active", "inactive", "historical"] }).default("active"),
  confidence: real("confidence").default(1.0), // Confidence in this relationship
  validFrom: timestamp("valid_from").defaultNow(),
  validTo: timestamp("valid_to"), // When relationship ends/ended
  properties: jsonb("properties"), // Additional relationship-specific data
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Edge evidence - supporting evidence for relationships
export const edgeEvidence = pgTable("edge_evidence", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  edgeId: varchar("edge_id").notNull().references(() => edges.id, { onDelete: "cascade" }),
  evidenceType: text("evidence_type").notNull(), // article, press_release, filing, linkedin, website, etc.
  sourceUrl: text("source_url"),
  sourceTitle: text("source_title"),
  sourceText: text("source_text"),
  extractedText: text("extracted_text"), // Specific text that supports the relationship
  confidence: real("confidence").default(1.0), // How well this evidence supports the relationship
  publishedAt: timestamp("published_at"),
  discoveredAt: timestamp("discovered_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Events - time-based occurrences involving entities
export const events = pgTable("events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // funding_round, acquisition, product_launch, executive_change, etc.
  title: text("title").notNull(),
  description: text("description"),
  summary: text("summary"),
  impact: text("impact", { enum: ["low", "medium", "high", "critical"] }).default("medium"),
  status: text("status", { enum: ["confirmed", "rumored", "planned", "cancelled"] }).default("confirmed"),
  confidence: real("confidence").default(1.0),
  occurredAt: timestamp("occurred_at"),
  announcedAt: timestamp("announced_at"),
  sourceUrl: text("source_url"),
  sourceTitle: text("source_title"),
  metadata: jsonb("metadata"), // Event-specific structured data
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Event participants - which entities are involved in events
export const eventParticipants = pgTable("event_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  entityId: varchar("entity_id").notNull().references(() => entities.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // acquirer, target, investor, founder, participant, subject, etc.
  importance: text("importance", { enum: ["primary", "secondary", "mentioned"] }).default("primary"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertDataSourceSchema = createInsertSchema(dataSources).omit({
  id: true,
  createdAt: true,
  lastFetched: true,
});

export const insertInsightSchema = createInsertSchema(insights).omit({
  id: true,
  createdAt: true,
});

export const insertMonitorSchema = createInsertSchema(monitors).omit({
  id: true,
  createdAt: true,
});

export const insertBriefingSchema = createInsertSchema(briefings).omit({
  id: true,
  createdAt: true,
  date: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserTeamSchema = createInsertSchema(userTeams).omit({
  id: true,
  createdAt: true,
});

// Entity insert schemas (used in Decks)
export const insertCompanySchema = createInsertSchema(companies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  mentionCount: true,
  lastMentioned: true,
});

export const insertPersonSchema = createInsertSchema(people).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  mentionCount: true,
  lastMentioned: true,
});

export const insertOrganizationSchema = createInsertSchema(organizations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  mentionCount: true,
  lastMentioned: true,
});

export const insertEntityMentionSchema = createInsertSchema(entityMentions).omit({
  id: true,
  createdAt: true,
});

export const insertEntityRelationshipSchema = createInsertSchema(entityRelationships).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBoardSchema = createInsertSchema(boards).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBoardEntitySchema = createInsertSchema(boardEntities).omit({
  id: true,
  createdAt: true,
});

export const insertDeckMentionSchema = createInsertSchema(deckMentions).omit({
  id: true,
  createdAt: true,
});

export const insertSystemSettingsSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertUserPreferenceSchema = createInsertSchema(userPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmailVerificationQueueSchema = createInsertSchema(emailVerificationQueue).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRateLimitAttemptsSchema = createInsertSchema(rateLimitAttempts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSecurityAuditLogSchema = createInsertSchema(securityAuditLog).omit({
  id: true,
  createdAt: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  createdAt: true,
});

export const insertStockWatchlistSchema = createInsertSchema(stockWatchlist).omit({
  id: true,
  createdAt: true,
  addedAt: true,
});

// Type exports
export type UserPreference = typeof userPreferences.$inferSelect;
export type InsertUserPreference = typeof userPreferences.$inferInsert;

export type EmailVerificationQueue = typeof emailVerificationQueue.$inferSelect;
export type InsertEmailVerificationQueue = z.infer<typeof insertEmailVerificationQueueSchema>;

export type RateLimitAttempts = typeof rateLimitAttempts.$inferSelect;
export type InsertRateLimitAttempts = z.infer<typeof insertRateLimitAttemptsSchema>;

export type SecurityAuditLog = typeof securityAuditLog.$inferSelect;
export type InsertSecurityAuditLog = z.infer<typeof insertSecurityAuditLogSchema>;

export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;

export type StockWatchlistItem = typeof stockWatchlist.$inferSelect;
export type InsertStockWatchlistItem = z.infer<typeof insertStockWatchlistSchema>;



// Define relations
export const usersRelations = relations(users, ({ one, many }) => ({
  team: one(teams, {
    fields: [users.teamId],
    references: [teams.id],
  }),
  userTeams: many(userTeams),
}));

export const teamsRelations = relations(teams, ({ many }) => ({
  users: many(users),
  userTeams: many(userTeams),
}));

export const userTeamsRelations = relations(userTeams, ({ one }) => ({
  user: one(users, {
    fields: [userTeams.userId],
    references: [users.id],
  }),
  team: one(teams, {
    fields: [userTeams.teamId],
    references: [teams.id],
  }),
}));

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Feature flags table for dynamic configuration
export const featureFlags = pgTable("feature_flags", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description").notNull(),
  type: varchar("type").notNull().$type<'boolean' | 'string' | 'number' | 'json'>(),
  defaultValue: jsonb("default_value").notNull(),
  currentValue: jsonb("current_value").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  category: varchar("category").notNull().$type<'ai_processing' | 'data_ingestion' | 'ui_features' | 'system_controls' | 'experimental' | 'performance' | 'security'>(),
  riskLevel: varchar("risk_level").notNull().$type<'low' | 'medium' | 'high' | 'critical'>(),
  rolloutPercentage: integer("rollout_percentage").default(100),
  targetUsers: jsonb("target_users").$type<string[]>(),
  environment: jsonb("environment").notNull().$type<('development' | 'staging' | 'production')[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  lastModifiedBy: varchar("last_modified_by").notNull(),
});

export type FeatureFlag = typeof featureFlags.$inferSelect;
export type InsertFeatureFlag = typeof featureFlags.$inferInsert;
export type Team = typeof teams.$inferSelect;
export type InsertTeam = typeof teams.$inferInsert;
export type UserTeam = typeof userTeams.$inferSelect;
export type InsertUserTeam = typeof userTeams.$inferInsert;

export type SystemSettings = typeof systemSettings.$inferSelect;
export type InsertSystemSettings = z.infer<typeof insertSystemSettingsSchema>;

export type InsertDataSource = z.infer<typeof insertDataSourceSchema>;
export type DataSource = typeof dataSources.$inferSelect;

export type InsertInsight = z.infer<typeof insertInsightSchema>;
export type Insight = typeof insights.$inferSelect;

export type InsertMonitor = z.infer<typeof insertMonitorSchema>;
export type Monitor = typeof monitors.$inferSelect;

export type InsertBriefing = z.infer<typeof insertBriefingSchema>;
export type Briefing = typeof briefings.$inferSelect;

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// Entity types (used in Decks)
export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

export type InsertPerson = z.infer<typeof insertPersonSchema>;
export type Person = typeof people.$inferSelect;

export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;
export type Organization = typeof organizations.$inferSelect;

// New entity system types
export type EntityMention = typeof entityMentions.$inferSelect;
export type InsertEntityMention = z.infer<typeof insertEntityMentionSchema>;

export type EntityRelationship = typeof entityRelationships.$inferSelect;
export type InsertEntityRelationship = z.infer<typeof insertEntityRelationshipSchema>;

export type Board = typeof boards.$inferSelect;
export type InsertBoard = z.infer<typeof insertBoardSchema>;

export type BoardEntity = typeof boardEntities.$inferSelect;
export type InsertBoardEntity = z.infer<typeof insertBoardEntitySchema>;

export type InsertDeckMention = z.infer<typeof insertDeckMentionSchema>;
export type DeckMention = typeof deckMentions.$inferSelect;

// Intelligent Alerts system types
export type UserSpec = typeof userSpecs.$inferSelect;
export type InsertUserSpec = z.infer<typeof insertUserSpecSchema>;

export type UserInteraction = typeof userInteractions.$inferSelect;
export type InsertUserInteraction = z.infer<typeof insertUserInteractionSchema>;

export type IntelligentAlert = typeof intelligentAlerts.$inferSelect;
export type InsertIntelligentAlert = z.infer<typeof insertIntelligentAlertSchema>;

export type AlertPattern = typeof alertPatterns.$inferSelect;
export type InsertAlertPattern = z.infer<typeof insertAlertPatternSchema>;

export type UserBehavior = typeof userBehaviors.$inferSelect;
export type InsertUserBehavior = z.infer<typeof insertUserBehaviorSchema>;

export type SavedInsight = typeof savedInsights.$inferSelect;
export type InsertSavedInsight = z.infer<typeof insertSavedInsightSchema>;

// Intelligent Alerts System Tables

// User Specs (🔍 binoculars icon) - intelligent preference profiles learned from behavior
export const userSpecs = pgTable("user_specs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  specType: text("spec_type").notNull(), // 'industry_focus', 'company_tracking', 'technology_interest', 'market_segment', 'competitive_intelligence'
  specKey: text("spec_key").notNull(), // "artificial intelligence", "apple", "fintech", etc.
  displayName: text("display_name").notNull(), // user-friendly name for profile tags: "AI & Machine Learning", "Apple Inc.", "Financial Technology"
  strength: real("strength").notNull().default(0.5), // 0.0 to 1.0 - how strong this preference is
  confidence: real("confidence").notNull().default(0.5), // 0.0 to 1.0 - how confident we are in this spec
  learnedFrom: text("learned_from").notNull().default("interaction"), // 'interaction', 'explicit', 'behavior_pattern'
  interactionCount: integer("interaction_count").notNull().default(0), // number of times user interacted with related content
  lastActivated: timestamp("last_activated"), // when this spec last triggered an alert
  lastReinforced: timestamp("last_reinforced").defaultNow(), // when user last interacted with related content
  keywords: text("keywords").array(), // associated keywords for matching
  metadata: jsonb("metadata"), // additional context about this spec
  isActive: boolean("is_active").notNull().default(true),
  showInProfile: boolean("show_in_profile").notNull().default(true), // whether to show as tag in user profile
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User Interactions - track behavior to learn specs automatically
export const userInteractions = pgTable("user_interactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  interactionType: text("interaction_type").notNull(), // 'view', 'read', 'save', 'share', 'feedback_positive', 'feedback_negative', 'dwell_time'
  targetType: text("target_type").notNull(), // 'insight', 'alert', 'entity', 'deck'
  targetId: varchar("target_id").notNull(), // ID of the item interacted with
  dwellTime: integer("dwell_time"), // time spent in seconds (for view interactions)
  extractedKeywords: text("extracted_keywords").array(), // keywords extracted from the content user interacted with
  extractedEntities: text("extracted_entities").array(), // entities extracted from the content
  category: text("category"), // category of the content interacted with
  priority: text("priority"), // priority level of the content interacted with
  metadata: jsonb("metadata"), // additional context about the interaction
  timestamp: timestamp("timestamp").defaultNow(),
});

// Intelligent Alerts - synthesized actionable intelligence
export const intelligentAlerts = pgTable("intelligent_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(), // Analyst-quality title
  insight: text("insight").notNull(), // The synthesized intelligence - "connect the dots" analysis
  actionability: text("actionability").notNull(), // What action the user should consider
  priority: text("priority").notNull(), // 'medium', 'high', 'critical' - no low priority alerts
  confidence: real("confidence").notNull(), // AI confidence in the synthesis 0-1
  relevanceScore: real("relevance_score").notNull(), // How well this matches user preferences 0-1
  triggerEntities: jsonb("trigger_entities"), // Entities that triggered this alert
  relatedInsights: text("related_insights").array(), // Insight IDs that contributed to this synthesis
  trendAnalysis: jsonb("trend_analysis"), // Pattern/trend data that contributed
  marketContext: text("market_context"), // Broader market/industry context
  isRead: boolean("is_read").default(false),
  isArchived: boolean("is_archived").default(false),
  userFeedback: text("user_feedback"), // 'valuable', 'somewhat_useful', 'not_relevant'
  createdAt: timestamp("created_at").defaultNow(),
});

// Alert synthesis patterns - tracks what combinations create valuable alerts  
export const alertPatterns = pgTable("alert_patterns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patternType: text("pattern_type").notNull(), // 'entity_correlation', 'trend_shift', 'competitive_move', 'market_signal'
  triggerConditions: jsonb("trigger_conditions").notNull(), // What conditions must be met
  synthesisRules: jsonb("synthesis_rules").notNull(), // How to combine data into insights
  successRate: real("success_rate").default(0.0), // Historical success rate of this pattern
  userValue: real("user_value").default(0.0), // Average user feedback value
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User behavior tracking for learning preferences
export const userBehaviors = pgTable("user_behaviors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  actionType: text("action_type").notNull(), // 'save_insight', 'click_entity', 'read_full_content', 'share', 'archive'
  targetType: text("target_type").notNull(), // 'insight', 'entity', 'alert', 'briefing'
  targetId: varchar("target_id").notNull(),
  sessionId: varchar("session_id"), // For grouping related behaviors
  metadata: jsonb("metadata"), // Additional context about the behavior
  timestamp: timestamp("timestamp").defaultNow(),
});

// Saved insights - user-curated collection for learning preferences
export const savedInsights = pgTable("saved_insights", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  insightId: varchar("insight_id").notNull().references(() => insights.id, { onDelete: "cascade" }),
  tags: text("tags").array(), // User-added tags
  notes: text("notes"), // User notes about why this was saved
  folder: text("folder"), // Organization folder
  savedAt: timestamp("saved_at").defaultNow(),
});

// Cost tracking tables for persistent accounting
export const costEntries = pgTable("cost_entries", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  modelName: varchar("model_name", { length: 50 }).notNull(),
  operation: varchar("operation", { length: 50 }).notNull(), // sentiment, summarization, entity_extraction, etc.
  inputTokens: integer("input_tokens").notNull().default(0),
  outputTokens: integer("output_tokens").notNull().default(0),
  cost: numeric("cost", { precision: 10, scale: 8 }).notNull(), // High precision for micro-costs
  priority: varchar("priority", { length: 20 }).notNull(),
  success: boolean("success").default(true).notNull(),
  metadata: jsonb("metadata"), // Additional context like content type, source, etc.
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const costSummaries = pgTable("cost_summaries", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  date: date("date").notNull().unique(), // YYYY-MM-DD format
  totalCost: numeric("total_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  totalCalls: integer("total_calls").notNull().default(0),
  ruleBasedOperations: integer("rule_based_operations").notNull().default(0),
  costSavings: numeric("cost_savings", { precision: 10, scale: 2 }).notNull().default("0"),
  topModels: jsonb("top_models"), // JSON array of {model, calls, cost}
  topOperations: jsonb("top_operations"), // JSON array of {operation, calls, cost}
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCostEntrySchema = createInsertSchema(costEntries).omit({
  id: true,
  createdAt: true,
});

export const insertCostSummarySchema = createInsertSchema(costSummaries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCostEntry = z.infer<typeof insertCostEntrySchema>;
export type CostEntry = typeof costEntries.$inferSelect;

export type InsertCostSummary = z.infer<typeof insertCostSummarySchema>;
export type CostSummary = typeof costSummaries.$inferSelect;

// Intelligent Alerts insert schemas
export const insertUserSpecSchema = createInsertSchema(userSpecs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastReinforced: true,
});

export const insertUserInteractionSchema = createInsertSchema(userInteractions).omit({
  id: true,
  timestamp: true,
});

export const insertIntelligentAlertSchema = createInsertSchema(intelligentAlerts).omit({
  id: true,
  createdAt: true,
});

export const insertAlertPatternSchema = createInsertSchema(alertPatterns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserBehaviorSchema = createInsertSchema(userBehaviors).omit({
  id: true,
  timestamp: true,
});

export const insertSavedInsightSchema = createInsertSchema(savedInsights).omit({
  id: true,
  savedAt: true,
});

// Knowledge Graph insert schemas
export const insertEntitySchema = createInsertSchema(entities).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEntityIdentifierSchema = createInsertSchema(entityIdentifiers).omit({
  id: true,
  createdAt: true,
});

export const insertEntityAttributeSchema = createInsertSchema(entityAttributes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEntityEmbeddingSchema = createInsertSchema(entityEmbeddings).omit({
  id: true,
  createdAt: true,
});

export const insertEdgeSchema = createInsertSchema(edges).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEdgeEvidenceSchema = createInsertSchema(edgeEvidence).omit({
  id: true,
  createdAt: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEventParticipantSchema = createInsertSchema(eventParticipants).omit({
  id: true,
  createdAt: true,
});

// Knowledge Graph types
export type Entity = typeof entities.$inferSelect;
export type InsertEntity = z.infer<typeof insertEntitySchema>;

export type EntityIdentifier = typeof entityIdentifiers.$inferSelect;
export type InsertEntityIdentifier = z.infer<typeof insertEntityIdentifierSchema>;

export type EntityAttribute = typeof entityAttributes.$inferSelect;
export type InsertEntityAttribute = z.infer<typeof insertEntityAttributeSchema>;

export type EntityEmbedding = typeof entityEmbeddings.$inferSelect;
export type InsertEntityEmbedding = z.infer<typeof insertEntityEmbeddingSchema>;

export type Edge = typeof edges.$inferSelect;
export type InsertEdge = z.infer<typeof insertEdgeSchema>;

export type EdgeEvidence = typeof edgeEvidence.$inferSelect;
export type InsertEdgeEvidence = z.infer<typeof insertEdgeEvidenceSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type EventParticipant = typeof eventParticipants.$inferSelect;
export type InsertEventParticipant = z.infer<typeof insertEventParticipantSchema>;

// Home 2.0: Report Templates and Installed Reports for customizable dashboard
export const reportTemplates = pgTable("report_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  version: integer("version").default(1),
  inputsSchema: jsonb("inputs_schema").notNull(),
  previewImg: text("preview_img"),
  tags: text("tags").array(),
  isFeatured: boolean("is_featured").default(false),
  popularityScore: real("popularity_score").default(0.0),
  // New visualization fields
  visualizationConfig: jsonb("visualization_config"), // Recharts configuration for previews
  sampleData: jsonb("sample_data"), // Sample data for previews (≤25 rows)
  chartTypes: text("chart_types").array(), // Available chart types: ['line', 'bar', 'pie', 'area', 'scatter']
  defaultChartType: text("default_chart_type").default("line"), // Default chart for previews
  animationConfig: jsonb("animation_config"), // Animation settings for charts
  accessibilityConfig: jsonb("accessibility_config"), // A11y settings and descriptions
  createdAt: timestamp("created_at").defaultNow(),
});

// Custom report blueprints created by users
export const reportBlueprints = pgTable("report_blueprints", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  category: text("category").notNull(),
  tags: text("tags").array(),
  useCase: text("use_case"),
  isPublic: boolean("is_public").default(false), // Whether other users can see this blueprint
  isActive: boolean("is_active").default(true),
  installCount: integer("install_count").default(0),
  currentVersionId: varchar("current_version_id"), // Points to the latest version
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Versions of custom report blueprints
export const reportBlueprintVersions = pgTable("report_blueprint_versions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  blueprintId: varchar("blueprint_id").notNull().references(() => reportBlueprints.id, { onDelete: "cascade" }),
  version: text("version").notNull(), // semver format: 1.0.0
  changelog: text("changelog"),
  builderConfigJson: jsonb("builder_config_json").notNull(), // DSL v1 configuration
  configSchema: jsonb("config_schema"), // JSON schema for user configuration
  previewData: jsonb("preview_data"), // Sample data for preview
  isStable: boolean("is_stable").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const installedReports = pgTable("installed_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  templateId: varchar("template_id").notNull().references(() => reportTemplates.id, { onDelete: "cascade" }),
  configJson: jsonb("config_json").default({}),
  layoutJson: jsonb("layout_json").default({}),
  state: text("state", { enum: ["active", "inactive", "archived"] }).default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Home 2.0 Relations
export const reportTemplatesRelations = relations(reportTemplates, ({ many }) => ({
  installedReports: many(installedReports),
}));

export const installedReportsRelations = relations(installedReports, ({ one }) => ({
  user: one(users, {
    fields: [installedReports.userId],
    references: [users.id],
  }),
  template: one(reportTemplates, {
    fields: [installedReports.templateId],
    references: [reportTemplates.id],
  }),
}));

// Home 2.0 Insert Schemas
export const insertReportTemplateSchema = createInsertSchema(reportTemplates).omit({
  id: true,
  createdAt: true,
});

export const insertInstalledReportSchema = createInsertSchema(installedReports).omit({
  id: true,
  createdAt: true,
});

export const insertReportBlueprintSchema = createInsertSchema(reportBlueprints).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  installCount: true,
  currentVersionId: true,
});

export const insertReportBlueprintVersionSchema = createInsertSchema(reportBlueprintVersions).omit({
  id: true,
  createdAt: true,
});

// Home 2.0 Types
export type ReportTemplate = typeof reportTemplates.$inferSelect;
export type InsertReportTemplate = z.infer<typeof insertReportTemplateSchema>;
export type InstalledReport = typeof installedReports.$inferSelect;
export type InsertInstalledReport = z.infer<typeof insertInstalledReportSchema>;
export type ReportBlueprint = typeof reportBlueprints.$inferSelect;
export type InsertReportBlueprint = z.infer<typeof insertReportBlueprintSchema>;
export type ReportBlueprintVersion = typeof reportBlueprintVersions.$inferSelect;
export type InsertReportBlueprintVersion = z.infer<typeof insertReportBlueprintVersionSchema>;
