// Feature flags and kill-switches framework for safe production experimentation
import { z } from "zod";

// Feature flag types
export type FeatureFlagType = 'boolean' | 'string' | 'number' | 'json';

export interface FeatureFlag {
  id: string;
  name: string;
  description: string;
  type: FeatureFlagType;
  defaultValue: any;
  currentValue: any;
  enabled: boolean;
  category: FeatureFlagCategory;
  riskLevel: RiskLevel;
  createdAt: Date;
  updatedAt: Date;
  lastModifiedBy: string;
  rolloutPercentage?: number; // For gradual rollouts
  targetUsers?: string[]; // Specific user targeting
  environment: Environment[];
}

export type FeatureFlagCategory = 
  | 'ai_processing'
  | 'data_ingestion' 
  | 'ui_features'
  | 'system_controls'
  | 'experimental'
  | 'performance'
  | 'security';

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';
export type Environment = 'development' | 'staging' | 'production';

// Predefined feature flags for core system functionality
export const CORE_FEATURE_FLAGS = {
  // System-wide kill switches
  READ_ONLY_MODE: {
    id: 'read_only_mode',
    name: 'Read-Only Mode',
    description: 'Enable read-only mode to prevent all write operations',
    type: 'boolean' as const,
    defaultValue: false,
    category: 'system_controls' as const,
    riskLevel: 'critical' as const
  },
  
  PAUSE_DATA_INGESTION: {
    id: 'pause_data_ingestion',
    name: 'Pause Data Ingestion',
    description: 'Temporarily stop all RSS feed processing and data ingestion',
    type: 'boolean' as const,
    defaultValue: false,
    category: 'data_ingestion' as const,
    riskLevel: 'high' as const
  },

  // AI processing controls
  ENABLE_AI_PROCESSING: {
    id: 'enable_ai_processing',
    name: 'AI Processing',
    description: 'Enable AI-powered content analysis and processing',
    type: 'boolean' as const,
    defaultValue: true,
    category: 'ai_processing' as const,
    riskLevel: 'medium' as const
  },

  BULK_AI_CALLS: {
    id: 'bulk_ai_calls',
    name: 'Bulk AI Calls',
    description: 'Allow batch processing of multiple insights with AI',
    type: 'boolean' as const,
    defaultValue: false,
    category: 'ai_processing' as const,
    riskLevel: 'high' as const
  },

  AI_COST_LIMIT_DAILY: {
    id: 'ai_cost_limit_daily',
    name: 'Daily AI Cost Limit',
    description: 'Maximum daily spend on AI processing (USD)',
    type: 'number' as const,
    defaultValue: 10.0,
    category: 'ai_processing' as const,
    riskLevel: 'medium' as const
  },

  // Performance and experimental features
  REAL_TIME_STREAMING: {
    id: 'real_time_streaming',
    name: 'Real-time Streaming',
    description: 'Enable live WebSocket streaming of insights',
    type: 'boolean' as const,
    defaultValue: false,
    category: 'experimental' as const,
    riskLevel: 'medium' as const
  },

  ENHANCED_MONITORING: {
    id: 'enhanced_monitoring',
    name: 'Enhanced Monitoring',
    description: 'Enable detailed performance and cost monitoring',
    type: 'boolean' as const,
    defaultValue: true,
    category: 'performance' as const,
    riskLevel: 'low' as const
  },

  // UI and UX features
  NEW_DASHBOARD_UI: {
    id: 'new_dashboard_ui',
    name: 'New Dashboard UI',
    description: 'Enable the redesigned dashboard interface',
    type: 'boolean' as const,
    defaultValue: false,
    category: 'ui_features' as const,
    riskLevel: 'low' as const
  },

  // Data processing controls
  RSS_FETCH_INTERVAL: {
    id: 'rss_fetch_interval',
    name: 'RSS Fetch Interval',
    description: 'Minutes between RSS feed fetches',
    type: 'number' as const,
    defaultValue: 15,
    category: 'data_ingestion' as const,
    riskLevel: 'low' as const
  },

  MAX_INSIGHTS_PER_BATCH: {
    id: 'max_insights_per_batch',
    name: 'Max Insights Per Batch',
    description: 'Maximum number of insights to process in a single batch',
    type: 'number' as const,
    defaultValue: 50,
    category: 'data_ingestion' as const,
    riskLevel: 'medium' as const
  }
} as const;

// Validation schemas
export const featureFlagValueSchema = z.union([
  z.boolean(),
  z.string(),
  z.number(),
  z.record(z.unknown()) // For JSON values
]);

export const createFeatureFlagSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  description: z.string().min(1),
  type: z.enum(['boolean', 'string', 'number', 'json']),
  defaultValue: featureFlagValueSchema,
  currentValue: featureFlagValueSchema,
  enabled: z.boolean(),
  category: z.enum(['ai_processing', 'data_ingestion', 'ui_features', 'system_controls', 'experimental', 'performance', 'security']),
  riskLevel: z.enum(['low', 'medium', 'high', 'critical']),
  rolloutPercentage: z.number().min(0).max(100).optional(),
  targetUsers: z.array(z.string()).optional(),
  environment: z.array(z.enum(['development', 'staging', 'production']))
});

export const updateFeatureFlagSchema = createFeatureFlagSchema.partial().extend({
  id: z.string().min(1),
  lastModifiedBy: z.string().min(1)
});

export type CreateFeatureFlag = z.infer<typeof createFeatureFlagSchema>;
export type UpdateFeatureFlag = z.infer<typeof updateFeatureFlagSchema>;

// Helper types for type-safe flag access
export type CoreFeatureFlagId = keyof typeof CORE_FEATURE_FLAGS;
export type FeatureFlagValue<T extends FeatureFlagType> = 
  T extends 'boolean' ? boolean :
  T extends 'string' ? string :
  T extends 'number' ? number :
  T extends 'json' ? any : 
  unknown;