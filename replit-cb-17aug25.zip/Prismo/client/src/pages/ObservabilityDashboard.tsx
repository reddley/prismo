import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { AlertTriangle, Activity, Clock, Users, TrendingUp, CheckCircle, XCircle, AlertCircle, HelpCircle } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, BarChart, Bar } from 'recharts';
import { useState } from 'react';
import { BatchIngestionMetrics } from '@/components/BatchIngestionMetrics';

interface MetricsData {
  metrics: {
    timestamp: number;
    red: {
      requests: { total: number; rate: number; last1min: number; last5min: number; last15min: number };
      errors: { total: number; rate: number; last1min: number; last5min: number; last15min: number; errorRate: number };
      duration: { p50: number; p95: number; p99: number; avg: number; max: number };
    };
    use: {
      utilization: { cpu: number; memory: number; dbConnections: number; activeRequests: number };
      saturation: { queueLength: number; waitTime: number; throttledRequests: number };
      errors: { systemErrors: number; dbErrors: number; apiErrors: number };
    };
    business: { activeUsers: number; insightsProcessed: number; aiCalls: number; costToday: number };
  };
  health: {
    status: 'healthy' | 'degraded' | 'unhealthy';
    slos: {
      availability: { target: number; current: number; passing: boolean };
      latency: { target: number; current: number; passing: boolean };
      errorRate: { target: number; current: number; passing: boolean };
    };
    alerts: string[];
  };
  tracing: {
    totalTraces: number;
    avgDuration: number;
    errorRate: number;
    slowestOperations: Array<{ operation: string; avgDuration: number }>;
  };
}

interface AlertsData {
  alerts: Array<{
    id: string;
    severity: 'critical' | 'warning' | 'info';
    message: string;
    description: string;
    timestamp: number;
    resolved?: boolean;
  }>;
  stats: {
    totalAlerts: number;
    activeAlerts: number;
    criticalAlerts: number;
    avgResolutionTime: number;
  };
}

interface CacheStats {
  l1Hits: number;
  l1Misses: number;
  l2Hits: number;
  l2Misses: number;
  totalRequests: number;
  hitRatio: number;
  l1CacheEnabled: boolean;
  l2CacheEnabled: boolean;
  timestamp: number;
}

export default function ObservabilityDashboard() {
  const [selectedTimeRange, setSelectedTimeRange] = useState('metrics');

  const { data: metricsData, isLoading: metricsLoading } = useQuery<MetricsData>({
    queryKey: ['/api/observability/metrics'],
    refetchInterval: 5000 // Refresh every 5 seconds
  });

  const { data: alertsData, isLoading: alertsLoading } = useQuery<AlertsData>({
    queryKey: ['/api/observability/alerts'],
    refetchInterval: 10000 // Refresh every 10 seconds
  });

  const { data: cacheData, isLoading: cacheLoading } = useQuery<CacheStats>({
    queryKey: ['/api/cache/stats'],
    refetchInterval: 5000 // Refresh every 5 seconds
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-600 bg-green-50 border-green-200';
      case 'degraded': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'unhealthy': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'warning': return 'secondary';
      case 'info': return 'outline';
      default: return 'outline';
    }
  };

  const formatDuration = (ms: number) => {
    if (ms < 1000) return `${Math.round(ms)}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  if (metricsLoading) {
    return <div className="flex items-center justify-center p-8">Loading observability data...</div>;
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Observability Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Monitor system health, performance, and alerts in real-time
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <Badge 
              className={getStatusColor(metricsData?.health.status || 'unknown')}
              data-testid="system-status"
            >
              {metricsData?.health.status?.toUpperCase() || 'UNKNOWN'}
            </Badge>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent className="max-w-sm p-0" side="bottom">
                  <div className="max-h-[60vh] overflow-y-auto p-4">
                    <div className="space-y-3">
                      <div className="text-sm font-medium">System Status Levels</div>
                      
                      <div className="space-y-2 text-xs">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-3 h-3 text-green-600" />
                          <span className="font-medium text-green-700">HEALTHY:</span>
                          <span>All 3 SLOs passing (Availability ≥99.9%, Latency ≤500ms, Errors ≤1%)</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <AlertCircle className="w-3 h-3 text-yellow-600" />
                          <span className="font-medium text-yellow-700">DEGRADED:</span>
                          <span>2 out of 3 SLOs passing - system experiencing minor issues</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <XCircle className="w-3 h-3 text-red-600" />
                          <span className="font-medium text-red-700">UNHEALTHY:</span>
                          <span>Less than 2 SLOs passing - immediate attention required</span>
                        </div>
                      </div>
                      
                      <div className="border-t pt-2 mt-2">
                        <div className="text-xs text-muted-foreground">
                          <strong>SLO Targets:</strong> Availability 99.9%+, P95 Latency &lt;500ms, Error Rate &lt;1%
                        </div>
                      </div>
                    </div>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => window.location.reload()}
            data-testid="button-refresh"
          >
            Refresh
          </Button>
        </div>
      </div>

      {/* System Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card data-testid="card-availability" className="relative">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-1">
              Availability
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity ml-1" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-sm p-0" side="top">
                    <div className="max-h-[60vh] overflow-y-auto p-4">
                      <div className="space-y-3">
                        <div className="text-sm font-medium">System Availability</div>
                        
                        <div className="text-xs space-y-2">
                          <p><strong>What it measures:</strong> Percentage of time the system is operational and responding to requests without errors.</p>
                          
                          <p><strong>How it's calculated:</strong> (Successful requests / Total requests) × 100 over the monitoring period.</p>
                          
                          <p><strong>Why it matters:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>Direct impact on user experience and business operations</li>
                            <li>Industry standard SLO for web services</li>
                            <li>Key indicator for system reliability and infrastructure health</li>
                          </ul>
                          
                          <p><strong>Target thresholds:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>99.9%+: Excellent (≤8.8 hours downtime/year)</li>
                            <li>99.5%+: Good (≤1.8 days downtime/year)</li>
                            <li>&lt;99%: Poor (≥3.7 days downtime/year)</li>
                          </ul>
                          
                          <p><strong>Troubleshooting steps:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>Check error rates and failed requests</li>
                            <li>Review server health and resource utilization</li>
                            <li>Analyze recent deployments or configuration changes</li>
                            <li>Verify database connectivity and performance</li>
                          </ul>
                        </div>
                        
                        <div className="border-t pt-2">
                          <div className="text-xs text-muted-foreground">
                            Target: 99.9%+ for optimal user experience
                          </div>
                        </div>
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </CardTitle>
            {metricsData?.health.slos.availability.passing ? 
              <CheckCircle className="h-4 w-4 text-green-600" /> : 
              <XCircle className="h-4 w-4 text-red-600" />
            }
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metricsData?.health.slos.availability.current.toFixed(2) || '0'}%
            </div>
            <p className="text-xs text-muted-foreground">
              Target: {metricsData?.health.slos.availability.target || 99.9}%
            </p>
          </CardContent>
        </Card>

        <Card data-testid="card-latency" className="relative">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-1">
              P95 Latency
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity ml-1" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-sm p-0" side="top">
                    <div className="max-h-[60vh] overflow-y-auto p-4">
                      <div className="space-y-3">
                        <div className="text-sm font-medium">Response Time SLO</div>
                        
                        <div className="text-xs space-y-2">
                          <p><strong>P95 Latency:</strong> 95% of requests complete faster than this time. This excludes the slowest 5% of requests to focus on typical user experience.</p>
                          
                          <p><strong>Why P95 matters:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>Better indicator than average (excludes outliers)</li>
                            <li>Reflects real user experience for most requests</li>
                            <li>Industry standard for latency SLOs</li>
                          </ul>
                          
                          <p><strong>Current breakdown:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>Current: {formatDuration(metricsData?.health.slos.latency.current || 0)}</li>
                            <li>Target: &lt;{formatDuration(metricsData?.health.slos.latency.target || 500)}</li>
                            <li>Status: {metricsData?.health.slos.latency.passing ? '✅ Passing' : '❌ Failing'}</li>
                          </ul>
                          
                          <p><strong>Performance thresholds:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>&lt;100ms: Excellent (instantaneous)</li>
                            <li>100-500ms: Good (barely noticeable)</li>
                            <li>500ms-1s: Acceptable (slight delay)</li>
                            <li>&gt;1s: Poor (user frustration)</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </CardTitle>
            {metricsData?.health.slos.latency.passing ? 
              <CheckCircle className="h-4 w-4 text-green-600" /> : 
              <XCircle className="h-4 w-4 text-red-600" />
            }
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatDuration(metricsData?.health.slos.latency.current || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Target: &lt;{formatDuration(metricsData?.health.slos.latency.target || 500)}
            </p>
          </CardContent>
        </Card>

        <Card data-testid="card-error-rate" className="relative">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-1">
              Error Rate
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity ml-1" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-sm p-0" side="top">
                    <div className="max-h-[60vh] overflow-y-auto p-4">
                      <div className="space-y-3">
                        <div className="text-sm font-medium">Error Rate SLO</div>
                        
                        <div className="text-xs space-y-2">
                          <p><strong>Calculation:</strong> (HTTP 4xx + 5xx responses / Total requests) × 100</p>
                          
                          <p><strong>Error types:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li><strong>4xx Client Errors:</strong> Bad requests, authentication failures, not found</li>
                            <li><strong>5xx Server Errors:</strong> Internal server errors, database failures, timeouts</li>
                          </ul>
                          
                          <p><strong>Current status:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>Current rate: {metricsData?.health.slos.errorRate.current.toFixed(2) || '0'}%</li>
                            <li>Target: &lt;{metricsData?.health.slos.errorRate.target || 1}%</li>
                            <li>Status: {metricsData?.health.slos.errorRate.passing ? '✅ Passing' : '❌ Failing'}</li>
                          </ul>
                          
                          <p><strong>Acceptable thresholds:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>&lt;0.1%: Excellent reliability</li>
                            <li>0.1-1%: Good (industry standard)</li>
                            <li>1-5%: Acceptable for some systems</li>
                            <li>&gt;5%: Poor reliability, investigation needed</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </CardTitle>
            {metricsData?.health.slos.errorRate.passing ? 
              <CheckCircle className="h-4 w-4 text-green-600" /> : 
              <XCircle className="h-4 w-4 text-red-600" />
            }
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metricsData?.health.slos.errorRate.current.toFixed(2) || '0'}%
            </div>
            <p className="text-xs text-muted-foreground">
              Target: &lt;{metricsData?.health.slos.errorRate.target || 1}%
            </p>
          </CardContent>
        </Card>

        <Card data-testid="card-alerts" className="relative">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-1">
              Active Alerts
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity ml-1" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-sm p-0" side="top">
                    <div className="max-h-[60vh] overflow-y-auto p-4">
                      <div className="space-y-3">
                        <div className="text-sm font-medium">Alert Management</div>
                        
                        <div className="text-xs space-y-2">
                          <p><strong>Alert status overview:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>Active alerts: {alertsData?.stats.activeAlerts || 0}</li>
                            <li>Critical alerts: {alertsData?.stats.criticalAlerts || 0}</li>
                            <li>Total alerts: {alertsData?.stats.totalAlerts || 0}</li>
                            <li>Avg resolution: {formatDuration(alertsData?.stats.avgResolutionTime || 0)}</li>
                          </ul>
                          
                          <p><strong>Alert severity levels:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li><strong>Critical:</strong> Immediate action required, system impact</li>
                            <li><strong>Warning:</strong> Monitor closely, potential issues</li>
                            <li><strong>Info:</strong> Informational, no immediate action needed</li>
                          </ul>
                          
                          <p><strong>Alert triggers:</strong></p>
                          <ul className="list-disc list-inside ml-2 space-y-1">
                            <li>SLO violations (availability, latency, errors)</li>
                            <li>Resource utilization thresholds</li>
                            <li>System health indicators</li>
                            <li>Performance anomalies</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {alertsData?.stats.activeAlerts || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              {alertsData?.stats.criticalAlerts || 0} critical
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard Tabs */}
      <Tabs defaultValue="metrics" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="metrics" data-testid="tab-metrics">RED Metrics</TabsTrigger>
          <TabsTrigger value="alerts" data-testid="tab-alerts">Alerts & Events</TabsTrigger>
          <TabsTrigger value="cache" data-testid="tab-cache">Cache Performance</TabsTrigger>
          <TabsTrigger value="batch-ingestion" data-testid="tab-batch-ingestion">Batch Ingestion</TabsTrigger>
        </TabsList>

        {/* RED Metrics Tab */}
        <TabsContent value="metrics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Request Rate Card */}
            <Card data-testid="card-request-rate" className="relative">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-1">
                  Request Rate
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity ml-1" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-sm p-0" side="top">
                        <div className="max-h-[60vh] overflow-y-auto p-4">
                          <div className="space-y-3">
                            <div className="text-sm font-medium">Request Rate Monitoring</div>
                            
                            <div className="text-xs space-y-2">
                              <p><strong>What it measures:</strong> Number of HTTP requests processed per second across all endpoints.</p>
                              
                              <p><strong>Why it matters:</strong></p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>Indicates system load and user activity</li>
                                <li>Helps identify traffic spikes or drops</li>
                                <li>Critical for capacity planning</li>
                              </ul>
                              
                              <p><strong>Breakdowns available:</strong></p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>Last 1min: {metricsData?.metrics.red.requests.last1min || 0}</li>
                                <li>Last 5min: {metricsData?.metrics.red.requests.last5min || 0}</li>
                                <li>Last 15min: {metricsData?.metrics.red.requests.last15min || 0}</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metricsData?.metrics.red.requests.rate.toFixed(1) || '0'}/s
                </div>
                <p className="text-xs text-muted-foreground">
                  {metricsData?.metrics.red.requests.total || 0} total requests
                </p>
              </CardContent>
            </Card>

            {/* Error Rate Card */}
            <Card data-testid="card-error-rate-detailed" className="relative">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-1">
                  Error Rate
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity ml-1" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-sm p-0" side="top">
                        <div className="max-h-[60vh] overflow-y-auto p-4">
                          <div className="space-y-3">
                            <div className="text-sm font-medium">Error Rate Analysis</div>
                            
                            <div className="text-xs space-y-2">
                              <p><strong>Calculation:</strong> (Failed requests / Total requests) × 100</p>
                              
                              <p><strong>Error classifications:</strong></p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>4xx: Client errors (bad requests, auth failures)</li>
                                <li>5xx: Server errors (system failures, timeouts)</li>
                              </ul>
                              
                              <p><strong>Target thresholds:</strong></p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>&lt;1%: Excellent</li>
                                <li>1-5%: Acceptable</li>
                                <li>&gt;5%: Requires attention</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </CardTitle>
                <AlertTriangle className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metricsData?.metrics.red.errors.errorRate.toFixed(2) || '0'}%
                </div>
                <p className="text-xs text-muted-foreground">
                  {metricsData?.metrics.red.errors.total || 0} total errors
                </p>
              </CardContent>
            </Card>

            {/* Response Duration Card */}
            <Card data-testid="card-response-duration" className="relative">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-1">
                  P95 Response Time
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity ml-1" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-sm p-0" side="top">
                        <div className="max-h-[60vh] overflow-y-auto p-4">
                          <div className="space-y-3">
                            <div className="text-sm font-medium">Response Time Percentiles</div>
                            
                            <div className="text-xs space-y-2">
                              <p><strong>P95 Duration:</strong> 95% of requests complete faster than this time</p>
                              
                              <p><strong>Full breakdown:</strong></p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>P50 (median): {formatDuration(metricsData?.metrics.red.duration.p50 || 0)}</li>
                                <li>P95: {formatDuration(metricsData?.metrics.red.duration.p95 || 0)}</li>
                                <li>P99: {formatDuration(metricsData?.metrics.red.duration.p99 || 0)}</li>
                                <li>Max: {formatDuration(metricsData?.metrics.red.duration.max || 0)}</li>
                              </ul>
                              
                              <p><strong>Performance targets:</strong></p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>P95 &lt;500ms: Excellent user experience</li>
                                <li>P95 500ms-1s: Acceptable</li>
                                <li>P95 &gt;1s: User experience degradation</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatDuration(metricsData?.metrics.red.duration.p95 || 0)}
                </div>
                <p className="text-xs text-muted-foreground">
                  Avg: {formatDuration(metricsData?.metrics.red.duration.avg || 0)}
                </p>
              </CardContent>
            </Card>

            {/* Business Metrics Card */}
            <Card data-testid="card-business-metrics" className="relative">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-1">
                  Active Users
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity ml-1" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-sm p-0" side="top">
                        <div className="max-h-[60vh] overflow-y-auto p-4">
                          <div className="space-y-3">
                            <div className="text-sm font-medium">Business Intelligence Metrics</div>
                            
                            <div className="text-xs space-y-2">
                              <p><strong>Key business indicators:</strong></p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>Active users: {metricsData?.metrics.business.activeUsers || 0}</li>
                                <li>Insights processed: {metricsData?.metrics.business.insightsProcessed || 0}</li>
                                <li>AI calls made: {metricsData?.metrics.business.aiCalls || 0}</li>
                                <li>Daily AI cost: ${metricsData?.metrics.business.costToday.toFixed(2) || '0.00'}</li>
                              </ul>
                              
                              <p><strong>Cost optimization:</strong></p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>Rule-based processing prioritized to minimize AI costs</li>
                                <li>AI calls reserved for critical insights only</li>
                                <li>Daily budget limits enforced automatically</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metricsData?.metrics.business.activeUsers || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  ${metricsData?.metrics.business.costToday.toFixed(2) || '0.00'} AI cost today
                </p>
              </CardContent>
            </Card>
          </div>

          {/* System Resources Section */}
          <Card className="relative">
            <CardHeader>
              <CardTitle className="flex items-center gap-1">
                System Resources
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-sm p-0" side="top">
                      <div className="max-h-[60vh] overflow-y-auto p-4">
                        <div className="space-y-3">
                          <div className="text-sm font-medium">System Resource Monitoring</div>
                          
                          <div className="text-xs space-y-2">
                            <p><strong>Resource utilization tracking:</strong></p>
                            <ul className="list-disc list-inside ml-2 space-y-1">
                              <li><strong>CPU:</strong> Processor usage percentage</li>
                              <li><strong>Memory:</strong> RAM consumption</li>
                              <li><strong>DB Connections:</strong> Active database connections</li>
                              <li><strong>Active Requests:</strong> Concurrent HTTP requests</li>
                            </ul>
                            
                            <p><strong>Utilization thresholds:</strong></p>
                            <ul className="list-disc list-inside ml-2 space-y-1">
                              <li>&lt;70%: Healthy</li>
                              <li>70-90%: Monitor closely</li>
                              <li>&gt;90%: Scale up needed</li>
                            </ul>
                            
                            <p><strong>Saturation indicators:</strong></p>
                            <ul className="list-disc list-inside ml-2 space-y-1">
                              <li>Queue length and wait times</li>
                              <li>Throttled requests count</li>
                              <li>Resource contention signals</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <div className="text-sm text-muted-foreground">CPU Usage</div>
                  <div className="text-lg font-semibold">{metricsData?.metrics.use.utilization.cpu || 0}%</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-muted-foreground">Memory</div>
                  <div className="text-lg font-semibold">{metricsData?.metrics.use.utilization.memory || 0}%</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-muted-foreground">DB Connections</div>
                  <div className="text-lg font-semibold">{metricsData?.metrics.use.utilization.dbConnections || 0}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-muted-foreground">Active Requests</div>
                  <div className="text-lg font-semibold">{metricsData?.metrics.use.utilization.activeRequests || 0}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Alerts Tab */}
        <TabsContent value="alerts" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card data-testid="card-total-alerts">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Alerts</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{alertsData?.stats.totalAlerts || 0}</div>
                <p className="text-xs text-muted-foreground">All time</p>
              </CardContent>
            </Card>
            <Card data-testid="card-active-alerts-detailed">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
                <AlertCircle className="h-4 w-4 text-orange-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{alertsData?.stats.activeAlerts || 0}</div>
                <p className="text-xs text-muted-foreground">Currently unresolved</p>
              </CardContent>
            </Card>
            <Card data-testid="card-critical-alerts">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Critical Alerts</CardTitle>
                <XCircle className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{alertsData?.stats.criticalAlerts || 0}</div>
                <p className="text-xs text-muted-foreground">Needs immediate attention</p>
              </CardContent>
            </Card>
            <Card data-testid="card-avg-resolution">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg Resolution</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatDuration(alertsData?.stats.avgResolutionTime || 0)}</div>
                <p className="text-xs text-muted-foreground">Time to resolve</p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Alerts */}
          <Card data-testid="card-recent-alerts">
            <CardHeader>
              <CardTitle>Recent Alerts</CardTitle>
              <CardDescription>Latest system alerts and events</CardDescription>
            </CardHeader>
            <CardContent>
              {alertsData?.alerts && alertsData.alerts.length > 0 ? (
                <div className="space-y-3">
                  {alertsData.alerts.slice(0, 5).map((alert) => (
                    <div key={alert.id} className="flex items-start space-x-3 p-3 rounded-lg border">
                      <div className="flex-shrink-0">
                        {alert.severity === 'critical' && <XCircle className="h-4 w-4 text-red-500" />}
                        {alert.severity === 'warning' && <AlertTriangle className="h-4 w-4 text-yellow-500" />}
                        {alert.severity === 'info' && <AlertCircle className="h-4 w-4 text-blue-500" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <div className="text-sm font-medium">{alert.message}</div>
                          <Badge variant={getSeverityColor(alert.severity) as any}>
                            {alert.severity}
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {alert.description}
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {formatTimestamp(alert.timestamp)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  No recent alerts found
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cache Performance Tab */}
        <TabsContent value="cache" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card data-testid="card-cache-hit-rate" className="relative">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Overall Hit Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {cacheData?.hitRatio?.toFixed(1) || '0'}%
                </div>
                <p className="text-xs text-muted-foreground">
                  {(cacheData?.l1Hits || 0) + (cacheData?.l2Hits || 0)} / {((cacheData?.l1Hits || 0) + (cacheData?.l1Misses || 0) + (cacheData?.l2Hits || 0) + (cacheData?.l2Misses || 0))} requests
                </p>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="absolute top-3 right-3 w-4 h-4 text-muted-foreground hover:text-foreground cursor-help opacity-60 hover:opacity-100 transition-opacity" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-sm p-0" side="top">
                      <div className="max-h-[60vh] overflow-y-auto p-4">
                        <div className="space-y-3">
                          <div className="text-sm font-medium">Cache Performance Analysis</div>
                          
                          <div className="text-xs space-y-2">
                            <p><strong>Hit rate calculation:</strong> (Cache hits / Total requests) × 100</p>
                            
                            <p><strong>Cache architecture:</strong></p>
                            <ul className="list-disc list-inside ml-2 space-y-1">
                              <li>L1: In-memory cache (fastest access)</li>
                              <li>L2: Redis distributed cache (network latency)</li>
                              <li>Fallback: Database query (slowest)</li>
                            </ul>
                            
                            <p><strong>Performance targets:</strong></p>
                            <ul className="list-disc list-inside ml-2 space-y-1">
                              <li>&gt;90%: Excellent performance</li>
                              <li>70-90%: Good performance</li>
                              <li>&lt;70%: Cache optimization needed</li>
                            </ul>
                            
                            <p><strong>Current status:</strong></p>
                            <ul className="list-disc list-inside ml-2 space-y-1">
                              <li>L1 enabled: {cacheData?.l1CacheEnabled ? 'Yes' : 'No'}</li>
                              <li>L2 enabled: {cacheData?.l2CacheEnabled ? 'Yes' : 'No'}</li>
                              <li>Total hits: {((cacheData?.l1Hits || 0) + (cacheData?.l2Hits || 0))}</li>
                              <li>Total requests: {((cacheData?.l1Hits || 0) + (cacheData?.l1Misses || 0) + (cacheData?.l2Hits || 0) + (cacheData?.l2Misses || 0))}</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </CardContent>
            </Card>

            <Card data-testid="card-l1-cache">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">L1 Cache</CardTitle>
                <div className={`h-2 w-2 rounded-full ${cacheData?.l1CacheEnabled ? 'bg-green-500' : 'bg-gray-400'}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Math.round(((cacheData?.l1Hits || 0) / Math.max((cacheData?.l1Hits || 0) + (cacheData?.l1Misses || 0), 1)) * 100) || 0}%
                </div>
                <p className="text-xs text-muted-foreground">
                  {cacheData?.l1Hits || 0} hits, {cacheData?.l1Misses || 0} misses
                </p>
              </CardContent>
            </Card>

            <Card data-testid="card-l2-cache">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">L2 Cache</CardTitle>
                <div className={`h-2 w-2 rounded-full ${cacheData?.l2CacheEnabled ? 'bg-green-500' : 'bg-gray-400'}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Math.round(((cacheData?.l2Hits || 0) / Math.max((cacheData?.l2Hits || 0) + (cacheData?.l2Misses || 0), 1)) * 100) || 0}%
                </div>
                <p className="text-xs text-muted-foreground">
                  {cacheData?.l2Hits || 0} hits, {cacheData?.l2Misses || 0} misses
                </p>
              </CardContent>
            </Card>

            <Card data-testid="card-cache-efficiency">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Cache Efficiency</CardTitle>
                <Activity className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {cacheData?.hitRatio?.toFixed(1) || '0'}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Performance gain
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Cache Performance Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Cache Layer Performance</CardTitle>
                <CardDescription>Detailed breakdown by cache layer</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm">
                      <span>L1 Cache (Memory)</span>
                      <span>{Math.round(((cacheData?.l1Hits || 0) / Math.max((cacheData?.l1Hits || 0) + (cacheData?.l1Misses || 0), 1)) * 100) || 0}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${Math.round(((cacheData?.l1Hits || 0) / Math.max((cacheData?.l1Hits || 0) + (cacheData?.l1Misses || 0), 1)) * 100) || 0}%` }}
                      />
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {cacheData?.l1Hits || 0} hits, {cacheData?.l1Misses || 0} misses
                    </div>
                  </div>
                  
                  {cacheData?.l2CacheEnabled && (
                    <div>
                      <div className="flex justify-between text-sm">
                        <span>L2 Cache (Redis)</span>
                        <span>{Math.round(((cacheData?.l2Hits || 0) / Math.max((cacheData?.l2Hits || 0) + (cacheData?.l2Misses || 0), 1)) * 100) || 0}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                        <div
                          className="bg-green-600 h-2 rounded-full"
                          style={{ width: `${Math.round(((cacheData?.l2Hits || 0) / Math.max((cacheData?.l2Hits || 0) + (cacheData?.l2Misses || 0), 1)) * 100) || 0}%` }}
                        />
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {cacheData?.l2Hits || 0} hits, {cacheData?.l2Misses || 0} misses
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cache Statistics</CardTitle>
                <CardDescription>Current cache status and metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span>L1 Cache Status:</span>
                    <span className={cacheData?.l1CacheEnabled ? 'text-green-600' : 'text-gray-500'}>
                      {cacheData?.l1CacheEnabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>L2 Cache Status:</span>
                    <span className={cacheData?.l2CacheEnabled ? 'text-green-600' : 'text-gray-500'}>
                      {cacheData?.l2CacheEnabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Memory Usage:</span>
                    <span>N/A</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Updated:</span>
                    <span>{cacheData?.timestamp ? formatTimestamp(cacheData.timestamp) : 'N/A'}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Batch Ingestion Tab */}
        <TabsContent value="batch-ingestion" className="space-y-6">
          <BatchIngestionMetrics />
        </TabsContent>
      </Tabs>
    </div>
  );
}