import { useState, useRef, useEffect } from "react";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { LogoUpload } from "@/components/ui/logo-upload";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useTheme } from "@/hooks/use-theme";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/hooks/use-user";
import { Shield, Lock, Copy, Eye, EyeOff, Key, Plus, Trash2, Upload } from "lucide-react";

interface ApiKey {
  id: string;
  name: string;
  value: string;
  lastUsed?: string;
}

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const { user, isAdmin } = useUser();
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([
    { id: '1', name: 'Anthropic API Key', value: 'sk-ant-api03-...', lastUsed: '2 hours ago' },
    { id: '2', name: 'OpenAI API Key', value: 'sk-proj-...', lastUsed: '1 day ago' },
    { id: '3', name: 'News API Key', value: '4a8b9c2d...', lastUsed: 'Never' },
  ]);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyValue, setNewKeyValue] = useState('');

  const handleThemeChange = (checked: boolean) => {
    const newTheme = checked ? "dark" : "light";
    setTheme(newTheme);
    
    // Save theme to server
    fetch('/api/settings/theme', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ theme: newTheme }),
    }).catch(error => {
      console.error('Failed to save theme:', error);
    });
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    
    try {
      // Save any pending settings changes here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      
      toast({
        title: "Settings saved",
        description: "Your settings have been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const toggleKeyVisibility = (keyId: string) => {
    const newVisible = new Set(visibleKeys);
    if (newVisible.has(keyId)) {
      newVisible.delete(keyId);
    } else {
      newVisible.add(keyId);
    }
    setVisibleKeys(newVisible);
  };

  const copyToClipboard = async (value: string, keyName: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast({
        title: "Copied to clipboard",
        description: `${keyName} has been copied to your clipboard.`,
      });
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Could not copy to clipboard. Please try again.",
        variant: "destructive",
      });
    }
  };

  const addNewKey = () => {
    if (!newKeyName.trim() || !newKeyValue.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both a name and value for the API key.",
        variant: "destructive",
      });
      return;
    }

    const newKey: ApiKey = {
      id: Date.now().toString(),
      name: newKeyName.trim(),
      value: newKeyValue.trim(),
      lastUsed: 'Never',
    };

    setApiKeys([...apiKeys, newKey]);
    setNewKeyName('');
    setNewKeyValue('');
    
    toast({
      title: "API key added",
      description: `${newKey.name} has been added to your vault.`,
    });
  };

  const deleteKey = (keyId: string) => {
    const keyToDelete = apiKeys.find(k => k.id === keyId);
    setApiKeys(apiKeys.filter(k => k.id !== keyId));
    
    toast({
      title: "API key removed",
      description: `${keyToDelete?.name} has been removed from your vault.`,
    });
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden" data-testid="settings-page">
      <Header title="System Settings" />
      
      <main className="flex-1 overflow-y-auto custom-scrollbar p-6">
        <div className="max-w-2xl mx-auto space-y-6">
          
          {/* System Preferences */}
          <Card data-testid="card-system-preferences">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                System Preferences
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure application appearance and behavior
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Dark Mode</Label>
                  <div className="text-[0.8rem] text-muted-foreground">
                    Toggle between light and dark themes
                  </div>
                </div>
                <Switch
                  checked={theme === "dark"}
                  onCheckedChange={handleThemeChange}
                  data-testid="switch-dark-mode"
                />
              </div>
            </CardContent>
          </Card>

          {/* Branding Settings - Admin Only */}
          {isAdmin && (
            <Card data-testid="card-branding-settings">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-4 w-4" />
                  Branding Settings
                  <Badge variant="default" className="flex items-center gap-1">
                    <Shield className="h-3 w-3" />
                    Admin Only
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Customize your team's branding and appearance
                </p>
              </CardHeader>
              <CardContent>
                <LogoUpload onLogoChange={setLogoUrl} data-testid="logo-upload-component" />
              </CardContent>
            </Card>
          )}

          {/* API Keys Management */}
          <Card data-testid="card-api-keys">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-4 w-4" />
                API Keys Management
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage your API keys for external services
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Existing Keys */}
              <div className="space-y-3">
                {apiKeys.map((apiKey) => (
                  <div key={apiKey.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-sm">{apiKey.name}</p>
                        <Badge variant="outline" className="text-xs">
                          Last used: {apiKey.lastUsed}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <code className="text-xs bg-muted px-2 py-1 rounded font-mono">
                          {visibleKeys.has(apiKey.id) ? apiKey.value : '••••••••••••••••'}
                        </code>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleKeyVisibility(apiKey.id)}
                          data-testid={`button-toggle-visibility-${apiKey.id}`}
                        >
                          {visibleKeys.has(apiKey.id) ? 
                            <EyeOff className="h-3 w-3" /> : 
                            <Eye className="h-3 w-3" />
                          }
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(apiKey.value, apiKey.name)}
                          data-testid={`button-copy-${apiKey.id}`}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteKey(apiKey.id)}
                      className="text-destructive hover:text-destructive"
                      data-testid={`button-delete-${apiKey.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>

              {/* Add New Key */}
              <div className="border-t pt-4">
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <Label htmlFor="new-key-name">API Key Name</Label>
                    <Input
                      id="new-key-name"
                      placeholder="e.g., OpenAI API Key"
                      value={newKeyName}
                      onChange={(e) => setNewKeyName(e.target.value)}
                      data-testid="input-new-key-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="new-key-value">API Key Value</Label>
                    <Input
                      id="new-key-value"
                      type="password"
                      placeholder="Enter your API key"
                      value={newKeyValue}
                      onChange={(e) => setNewKeyValue(e.target.value)}
                      data-testid="input-new-key-value"
                    />
                  </div>
                  <Button
                    onClick={addNewKey}
                    variant="outline"
                    className="w-fit"
                    data-testid="button-add-new-key"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add API Key
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Security Settings */}
          <Card data-testid="card-security-settings">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-4 w-4" />
                Security & Privacy
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage your account security preferences
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  Your data is encrypted and stored securely. API keys are never shared with third parties.
                </AlertDescription>
              </Alert>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium">Account Role</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={isAdmin ? "default" : "secondary"} className="flex items-center gap-1">
                      {isAdmin && <Shield className="h-3 w-3" />}
                      {user?.role || 'user'}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium">Member Since</Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    }) : 'N/A'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end pt-4">
            <Button
              onClick={handleSaveSettings}
              disabled={saving}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              data-testid="button-save-settings"
            >
              {saving ? "Saving..." : "Save Settings"}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}