import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, MapPin, Globe, Building2, Search, Plus, ExternalLink, Linkedin, Twitter, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import type { Person } from "@shared/schema";

export default function People() {
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: people = [], isLoading } = useQuery<Person[]>({
    queryKey: ['/api/people'],
  });

  const filteredPeople = people.filter((person: Person) =>
    person.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    person.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    person.company?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getInfluenceColor = (influence: string) => {
    switch (influence) {
      case 'expert': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-foreground">People</h1>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="">
              <CardHeader>
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-20 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <main className="flex-1 overflow-y-auto p-6">
        <div className="max-w-7xl mx-auto space-y-6" data-testid="people-page">
          {/* Header */}
          <div className="flex items-center justify-between">
            <Button data-testid="button-add-person">
              <Plus className="w-4 h-4 mr-2" />
              Add Person
            </Button>
          </div>

          {/* Search and Filters */}
          <div className="flex items-center space-x-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search people..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-people"
              />
            </div>
            <Badge variant="secondary" className="px-3 py-1">
              {filteredPeople.length} people
            </Badge>
          </div>

          {/* People Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPeople.map((person: Person) => (
              <Link key={person.id} href={`/people/${person.id}`}>
                <Card 
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  data-testid={`card-person-${person.id}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={person.profileImageUrl || ''} alt={person.name} />
                          <AvatarFallback>
                            {person.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <CardTitle className="text-lg">{person.name}</CardTitle>
                          <CardDescription>{person.title}</CardDescription>
                        </div>
                      </div>
                      
                      {/* Mentions in top right corner */}
                      <div className="flex items-center text-sm text-muted-foreground">
                        <TrendingUp className="w-4 h-4 mr-1" />
                        {person.mentionCount || 0}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Person Info - Always show company, location, and industry */}
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Building2 className="w-4 h-4 mr-2" />
                        {person.company || 'Company not specified'}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4 mr-2" />
                        {person.location || 'Location not specified'}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Globe className="w-4 h-4 mr-2" />
                        {person.industry || 'Industry not specified'}
                      </div>
                    </div>

                    {/* Short Description (12 words or less) */}
                    {person.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {person.description.split(' ').slice(0, 12).join(' ')}{person.description.split(' ').length > 12 ? '...' : ''}
                      </p>
                    )}

                    {/* Tags - Always show expertise tags */}
                    <div className="flex flex-wrap gap-1">
                      {person.expertise && person.expertise.length > 0 ? (
                        <>
                          {person.expertise.slice(0, 3).map((skill, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                          {person.expertise.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{person.expertise.length - 3} more
                            </Badge>
                          )}
                        </>
                      ) : (
                        <>
                          {person.influence && (
                            <Badge variant="outline" className="text-xs">
                              {person.influence} influence
                            </Badge>
                          )}
                          <Badge variant="outline" className="text-xs opacity-60">
                            leadership
                          </Badge>
                          <Badge variant="outline" className="text-xs opacity-60">
                            industry expert
                          </Badge>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* Empty State */}
          {filteredPeople.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No people found</h3>
              <p className="text-muted-foreground mb-4">
                {searchQuery ? `No people match "${searchQuery}"` : "Start by adding your first person"}
              </p>
              <Button data-testid="button-add-first-person">
                <Plus className="w-4 h-4 mr-2" />
                Add Person
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}