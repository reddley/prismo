import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Search,
  Filter,
  Download,
  Calendar as CalendarIcon,
  Clock,
  TrendingUp,
  ExternalLink,
  BookmarkPlus,
  MoreHorizontal,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import type { Insight } from "@shared/schema";

interface SearchFilters {
  query: string;
  sentiment: string[];
  priority: string[];
  category: string[];
  source: string[];
  dateRange: {
    from: Date | null;
    to: Date | null;
  };
  sortBy: string;
  sortOrder: 'asc' | 'desc';
}

const defaultFilters: SearchFilters = {
  query: '',
  sentiment: [],
  priority: [],
  category: [],
  source: [],
  dateRange: { from: null, to: null },
  sortBy: 'createdAt',
  sortOrder: 'desc'
};

export default function SearchPage() {
  const [filters, setFilters] = useState<SearchFilters>(defaultFilters);
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [savedSearches, setSavedSearches] = useState<string[]>([]);

  // Fetch insights with search parameters
  const { data: insights = [], isLoading, error } = useQuery({
    queryKey: ['/api/insights/search', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      if (filters.query) params.append('query', filters.query);
      if (filters.sentiment.length > 0) params.append('sentiment', filters.sentiment.join(','));
      if (filters.priority.length > 0) params.append('priority', filters.priority.join(','));
      if (filters.category.length > 0) params.append('category', filters.category.join(','));
      if (filters.source.length > 0) params.append('source', filters.source.join(','));
      if (filters.dateRange.from) params.append('dateFrom', filters.dateRange.from.toISOString());
      if (filters.dateRange.to) params.append('dateTo', filters.dateRange.to.toISOString());
      params.append('sortBy', filters.sortBy);
      params.append('sortOrder', filters.sortOrder);
      
      const response = await fetch(`/api/insights/search?${params.toString()}`);
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      return response.json();
    },
    enabled: true,
  }) as { data: Insight[], isLoading: boolean, error: any };

  // Fetch available filter options
  const { data: filterOptions = {} } = useQuery({
    queryKey: ['/api/insights/filter-options'],
  }) as { data: { categories?: string[], sources?: string[] } };

  const updateFilter = (key: keyof SearchFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const addArrayFilter = (key: keyof SearchFilters, value: string) => {
    const currentArray = filters[key] as string[];
    if (!currentArray.includes(value)) {
      updateFilter(key, [...currentArray, value]);
    }
  };

  const removeArrayFilter = (key: keyof SearchFilters, value: string) => {
    const currentArray = filters[key] as string[];
    updateFilter(key, currentArray.filter(item => item !== value));
  };

  const clearFilters = () => {
    setFilters(defaultFilters);
  };

  const saveCurrentSearch = () => {
    const searchName = `Search - ${format(new Date(), 'MMM dd, HH:mm')}`;
    setSavedSearches(prev => [searchName, ...prev]);
  };

  const exportResults = () => {
    // Export functionality - would integrate with backend
    console.log('Exporting results...', insights.length);
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment?.toLowerCase()) {
      case 'positive': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'negative': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      case 'neutral': return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      case 'high': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'low': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const activeFilterCount = [
    ...filters.sentiment,
    ...filters.priority, 
    ...filters.category,
    ...filters.source,
    filters.dateRange.from ? 1 : 0,
    filters.dateRange.to ? 1 : 0
  ].length;

  return (
    <div className="flex-1 flex flex-col overflow-hidden" data-testid="search-page">
      <Header 
        title="Search Insights" 
        subtitle="Advanced search and filtering across all intelligence data"
      />
      
      <main className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Header */}
        <div className="mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Main Search Input */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search insights, keywords, companies, trends..."
                value={filters.query}
                onChange={(e) => updateFilter('query', e.target.value)}
                className="pl-10 h-12 text-lg"
                data-testid="input-search-query"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button
                variant={isFiltersOpen ? "default" : "outline"}
                onClick={() => setIsFiltersOpen(!isFiltersOpen)}
                className="h-12"
                data-testid="button-toggle-filters"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
                {activeFilterCount > 0 && (
                  <Badge variant="secondary" className="ml-2 h-5 w-5 p-0 flex items-center justify-center text-xs">
                    {activeFilterCount}
                  </Badge>
                )}
              </Button>

              <Button 
                variant="outline" 
                onClick={saveCurrentSearch}
                className="h-12"
                data-testid="button-save-search"
              >
                <BookmarkPlus className="h-4 w-4" />
              </Button>

              <Button 
                variant="outline" 
                onClick={exportResults}
                className="h-12"
                disabled={insights.length === 0}
                data-testid="button-export-results"
              >
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Active Filters Display */}
          {activeFilterCount > 0 && (
            <div className="mt-4 flex flex-wrap gap-2 items-center">
              <span className="text-sm text-muted-foreground">Active filters:</span>
              
              {filters.sentiment.map(item => (
                <Badge key={item} variant="secondary" className="gap-1" data-testid={`filter-sentiment-${item}`}>
                  Sentiment: {item}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => removeArrayFilter('sentiment', item)}
                  />
                </Badge>
              ))}
              
              {filters.priority.map(item => (
                <Badge key={item} variant="secondary" className="gap-1" data-testid={`filter-priority-${item}`}>
                  Priority: {item}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => removeArrayFilter('priority', item)}
                  />
                </Badge>
              ))}
              
              {filters.category.map(item => (
                <Badge key={item} variant="secondary" className="gap-1" data-testid={`filter-category-${item}`}>
                  Category: {item}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => removeArrayFilter('category', item)}
                  />
                </Badge>
              ))}

              {filters.source.map(item => (
                <Badge key={item} variant="secondary" className="gap-1" data-testid={`filter-source-${item}`}>
                  Source: {item}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => removeArrayFilter('source', item)}
                  />
                </Badge>
              ))}

              {(filters.dateRange.from || filters.dateRange.to) && (
                <Badge variant="secondary" className="gap-1" data-testid="filter-date-range">
                  Date Range
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => updateFilter('dateRange', { from: null, to: null })}
                  />
                </Badge>
              )}

              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearFilters}
                className="h-6 text-xs"
                data-testid="button-clear-filters"
              >
                Clear all
              </Button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          {isFiltersOpen && (
            <Card className="lg:col-span-1 h-fit" data-testid="filters-panel">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Advanced Filters</span>
                  <Button variant="ghost" size="sm" onClick={clearFilters} data-testid="button-clear-all-filters">
                    Clear All
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Sort Options */}
                <div className="space-y-2">
                  <Label>Sort By</Label>
                  <Select value={filters.sortBy} onValueChange={(value) => updateFilter('sortBy', value)}>
                    <SelectTrigger data-testid="select-sort-by">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="createdAt">Date Created</SelectItem>
                      <SelectItem value="publishedAt">Date Published</SelectItem>
                      <SelectItem value="title">Title</SelectItem>
                      <SelectItem value="priority">Priority</SelectItem>
                      <SelectItem value="sentiment">Sentiment</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select value={filters.sortOrder} onValueChange={(value: 'asc' | 'desc') => updateFilter('sortOrder', value)}>
                    <SelectTrigger data-testid="select-sort-order">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="desc">Newest First</SelectItem>
                      <SelectItem value="asc">Oldest First</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                {/* Sentiment Filter */}
                <div className="space-y-3">
                  <Label>Sentiment</Label>
                  <div className="space-y-2">
                    {['Positive', 'Negative', 'Neutral'].map((sentiment) => (
                      <div key={sentiment} className="flex items-center space-x-2">
                        <Checkbox
                          id={`sentiment-${sentiment}`}
                          checked={filters.sentiment.includes(sentiment.toLowerCase())}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              addArrayFilter('sentiment', sentiment.toLowerCase());
                            } else {
                              removeArrayFilter('sentiment', sentiment.toLowerCase());
                            }
                          }}
                          data-testid={`checkbox-sentiment-${sentiment.toLowerCase()}`}
                        />
                        <Label htmlFor={`sentiment-${sentiment}`} className="text-sm font-normal">
                          {sentiment}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Priority Filter */}
                <div className="space-y-3">
                  <Label>Priority</Label>
                  <div className="space-y-2">
                    {['Critical', 'High', 'Medium', 'Low'].map((priority) => (
                      <div key={priority} className="flex items-center space-x-2">
                        <Checkbox
                          id={`priority-${priority}`}
                          checked={filters.priority.includes(priority.toLowerCase())}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              addArrayFilter('priority', priority.toLowerCase());
                            } else {
                              removeArrayFilter('priority', priority.toLowerCase());
                            }
                          }}
                          data-testid={`checkbox-priority-${priority.toLowerCase()}`}
                        />
                        <Label htmlFor={`priority-${priority}`} className="text-sm font-normal">
                          {priority}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Category Filter */}
                <div className="space-y-3">
                  <Label>Category</Label>
                  <div className="space-y-2">
                    {filterOptions?.categories?.map((category: string) => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category}`}
                          checked={filters.category.includes(category)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              addArrayFilter('category', category);
                            } else {
                              removeArrayFilter('category', category);
                            }
                          }}
                          data-testid={`checkbox-category-${category}`}
                        />
                        <Label htmlFor={`category-${category}`} className="text-sm font-normal">
                          {category}
                        </Label>
                      </div>
                    )) || ['Technology', 'Finance', 'Business', 'AI/ML', 'Startups'].map((category) => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category}`}
                          checked={filters.category.includes(category)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              addArrayFilter('category', category);
                            } else {
                              removeArrayFilter('category', category);
                            }
                          }}
                          data-testid={`checkbox-category-${category.toLowerCase()}`}
                        />
                        <Label htmlFor={`category-${category}`} className="text-sm font-normal">
                          {category}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Date Range Filter */}
                <div className="space-y-3">
                  <Label>Date Range</Label>
                  <div className="space-y-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                          data-testid="button-date-from"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {filters.dateRange.from ? (
                            format(filters.dateRange.from, "PPP")
                          ) : (
                            <span>From date</span>
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={filters.dateRange.from || undefined}
                          onSelect={(date) => updateFilter('dateRange', { ...filters.dateRange, from: date || null })}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>

                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                          data-testid="button-date-to"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {filters.dateRange.to ? (
                            format(filters.dateRange.to, "PPP")
                          ) : (
                            <span>To date</span>
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={filters.dateRange.to || undefined}
                          onSelect={(date) => updateFilter('dateRange', { ...filters.dateRange, to: date || null })}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Results Area */}
          <div className={cn(
            "space-y-6",
            isFiltersOpen ? "lg:col-span-3" : "lg:col-span-4"
          )}>
            {/* Results Header */}
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold" data-testid="text-results-count">
                  {isLoading ? 'Searching...' : `${insights.length} insights found`}
                </h2>
                <p className="text-sm text-muted-foreground">
                  {filters.query && `Results for "${filters.query}"`}
                </p>
              </div>
            </div>

            {/* Results List */}
            <div className="space-y-4">
              {isLoading && (
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Card key={i} className="p-6">
                      <div className="">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-3"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {!isLoading && insights.length === 0 && (
                <Card className="p-8 text-center" data-testid="no-results-message">
                  <div className="space-y-3">
                    <Search className="h-12 w-12 text-muted-foreground mx-auto" />
                    <h3 className="text-lg font-medium">No insights found</h3>
                    <p className="text-sm text-muted-foreground">
                      Try adjusting your search terms or filters to find what you're looking for.
                    </p>
                  </div>
                </Card>
              )}

              {!isLoading && insights.map((insight: Insight) => (
                <Card key={insight.id} className="p-6 hover:shadow-md transition-shadow" data-testid={`insight-card-${insight.id}`}>
                  <div className="space-y-4">
                    {/* Header */}
                    <div className="flex justify-between items-start gap-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg leading-tight mb-2" data-testid={`insight-title-${insight.id}`}>
                          {insight.title}
                        </h3>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {insight.sentiment && (
                            <Badge className={getSentimentColor(insight.sentiment)} data-testid={`badge-sentiment-${insight.id}`}>
                              {insight.sentiment}
                            </Badge>
                          )}
                          {insight.priority && (
                            <Badge className={getPriorityColor(insight.priority)} data-testid={`badge-priority-${insight.id}`}>
                              {insight.priority}
                            </Badge>
                          )}
                          {insight.category && (
                            <Badge variant="outline" data-testid={`badge-category-${insight.id}`}>
                              {insight.category}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {insight.sourceUrl && (
                          <Button variant="ghost" size="sm" asChild data-testid={`button-external-link-${insight.id}`}>
                            <a href={insight.sourceUrl} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </Button>
                        )}
                        <Button variant="ghost" size="sm" data-testid={`button-more-actions-${insight.id}`}>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="text-sm text-muted-foreground leading-relaxed" data-testid={`insight-summary-${insight.id}`}>
                      {insight.summary || insight.content?.substring(0, 200) + '...'}
                    </div>

                    {/* Footer */}
                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <div className="flex items-center gap-4">
                        {insight.source && (
                          <span className="flex items-center gap-1" data-testid={`insight-source-${insight.id}`}>
                            <TrendingUp className="h-3 w-3" />
                            {insight.source}
                          </span>
                        )}
                        {insight.publishedAt && (
                          <span className="flex items-center gap-1" data-testid={`insight-date-${insight.id}`}>
                            <Clock className="h-3 w-3" />
                            {format(new Date(insight.publishedAt), 'MMM dd, yyyy')}
                          </span>
                        )}
                      </div>
                      {insight.confidence && (
                        <span className="text-xs" data-testid={`insight-confidence-${insight.id}`}>
                          {insight.confidence}% confidence
                        </span>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
        </div>
      </main>
    </div>
  );
}