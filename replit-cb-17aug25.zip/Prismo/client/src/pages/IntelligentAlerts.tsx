import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Brain, 
  TrendingUp, 
  Target, 
  CheckCircle, 
  Archive, 
  Lightbulb, 
  Zap, 
  Clock,
  AlertTriangle,
  Star,
  Eye,
  ThumbsUp,
  ThumbsDown,
  Binoculars,
  Tag,
  Activity
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { Header } from "@/components/layout/header";

interface IntelligentAlert {
  id: string;
  title: string;
  insight: string;
  actionability: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  relevanceScore: number;
  triggerEntities: Array<{ type: string; id: string }>;
  relatedInsights: string[];
  trendAnalysis: {
    patternType: string;
    strength: number;
    dataPoints: number;
  };
  marketContext: string;
  isRead: boolean;
  isArchived: boolean;
  userFeedback?: string;
  createdAt: string;
}

interface ProfileTag {
  id: string;
  displayName: string;
  specType: string;
  strength: number;
}

export default function IntelligentAlerts() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("alerts");
  const [selectedAlert, setSelectedAlert] = useState<IntelligentAlert | null>(null);
  const [feedback, setFeedback] = useState("");
  const [includeRead, setIncludeRead] = useState(false);

  // Fetch alerts
  const { data: alerts = [], isLoading: alertsLoading, refetch: refetchAlerts } = useQuery<IntelligentAlert[]>({
    queryKey: ['/api/alerts', { includeRead }],
    queryFn: () => fetch(`/api/alerts?userId=default-user&includeRead=${includeRead}`).then(res => res.json()),
  });

  // Fetch user profile tags (learned specs)
  const { data: profileTags = [], isLoading: tagsLoading } = useQuery<ProfileTag[]>({
    queryKey: ['/api/user/profile-tags'],
    queryFn: () => fetch('/api/user/profile-tags?userId=default-user').then(res => res.json()),
  });

  // Fetch recent auto alerts
  const { data: recentAutoAlerts = [], isLoading: autoAlertsLoading } = useQuery<Array<{
    id: string;
    title: string;
    createdAt: string;
    priority: string;
  }>>({
    queryKey: ['/api/alerts/recent-auto'],
    queryFn: () => fetch('/api/alerts/recent-auto?userId=default-user&hours=24').then(res => res.json()),
  });

  // Mark as read mutation
  const markReadMutation = useMutation({
    mutationFn: ({ alertId, feedback }: { alertId: string; feedback?: string }) =>
      apiRequest(`/api/alerts/${alertId}/read`, 'PATCH', { userId: 'default-user', feedback }),
    onSuccess: () => {
      toast({
        title: "Alert Updated",
        description: "Alert marked as read.",
      });
      refetchAlerts();
      setSelectedAlert(null);
      setFeedback("");
    },
  });

  // Archive alert mutation
  const archiveAlertMutation = useMutation({
    mutationFn: (alertId: string) =>
      apiRequest(`/api/alerts/${alertId}/archive`, 'PATCH', { userId: 'default-user' }),
    onSuccess: () => {
      toast({
        title: "Alert Archived",
        description: "Alert has been archived.",
      });
      refetchAlerts();
      setSelectedAlert(null);
    },
  });

  const priorityConfig = {
    critical: { icon: AlertTriangle, color: "text-red-600 dark:text-red-400", bg: "bg-red-50 dark:bg-red-900/20" },
    high: { icon: TrendingUp, color: "text-orange-600 dark:text-orange-400", bg: "bg-orange-50 dark:bg-orange-900/20" },
    medium: { icon: Target, color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-50 dark:bg-blue-900/20" },
    low: { icon: Lightbulb, color: "text-gray-600 dark:text-gray-400", bg: "bg-gray-50 dark:bg-gray-900/20" }
  };

  const getSpecTypeIcon = (specType: string) => {
    switch (specType) {
      case 'industry_focus': return Target;
      case 'technology_interest': return Zap;
      case 'company_tracking': return Brain;
      default: return Tag;
    }
  };

  const getSpecTypeColor = (specType: string) => {
    switch (specType) {
      case 'industry_focus': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300';
      case 'technology_interest': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300';
      case 'company_tracking': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300';
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden" data-testid="alerts-page">
      <Header 
        title="Alerts" 
        subtitle="Automatic alerts generated when high-priority insights match your learned preferences"
      />
      
      <main className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="container mx-auto px-6 py-6 space-y-6">
          {/* Learning Status Indicator */}
          <div className="flex justify-end">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-2 h-2 bg-green-500 rounded-full "></div>
              <span className="text-sm font-medium text-green-700 dark:text-green-300">Learning Active</span>
            </div>
          </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="alerts" className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            Recent Alerts
            {alerts.length > 0 && (
              <Badge variant="secondary" className="ml-1">
                {alerts.filter(a => !a.isRead).length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="specs" className="flex items-center gap-2">
            <Binoculars className="h-4 w-4" />
            Your Specs
            {Array.isArray(profileTags) && profileTags.length > 0 && (
              <Badge variant="secondary" className="ml-1">
                {profileTags.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="activity" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Auto Activity
          </TabsTrigger>
        </TabsList>

        <TabsContent value="alerts" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button 
                variant={includeRead ? "default" : "outline"} 
                size="sm"
                onClick={() => setIncludeRead(!includeRead)}
              >
                {includeRead ? "Show Unread Only" : "Show All"}
              </Button>
            </div>
          </div>
          
          {alertsLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : !Array.isArray(alerts) || alerts.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Binoculars className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Alerts Yet</h3>
                <p className="text-muted-foreground text-center max-w-md">
                  The system is learning your preferences from your reading behavior. 
                  As you interact with insights, we'll automatically generate alerts that match your interests.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {(Array.isArray(alerts) ? alerts : []).filter(alert => includeRead || !alert.isRead).map((alert) => {
                const config = priorityConfig[alert.priority];
                const PriorityIcon = config.icon;
                
                return (
                  <Card key={alert.id} className={cn(
                    "transition-all duration-200 hover:shadow-lg cursor-pointer border-l-4",
                    alert.isRead ? "opacity-70" : "",
                    config.bg.replace('bg-', 'border-l-').replace('-50', '-500').replace('-900/20', '-500')
                  )} onClick={() => setSelectedAlert(alert)}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4 flex-1">
                          <div className={cn("p-3 rounded-lg", config.bg)}>
                            <PriorityIcon className={cn("h-5 w-5", config.color)} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-lg font-semibold">{alert.title}</h3>
                              {!alert.isRead && (
                                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                              )}
                            </div>
                            <p className="text-muted-foreground mb-4 leading-relaxed">{alert.insight}</p>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <Badge variant="outline" className={config.color}>
                                {alert.priority} Priority
                              </Badge>
                              <span>{alert.confidence}% Confidence</span>
                              <span>{new Date(alert.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={(e) => {
                              e.stopPropagation();
                              markReadMutation.mutate({ alertId: alert.id });
                            }}
                          >
                            {alert.isRead ? <Archive className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="specs" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Your Learned Specs
              </CardTitle>
              <CardDescription>
                The system automatically learns your interests by analyzing your reading behavior and interactions with insights.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {tagsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : !Array.isArray(profileTags) || profileTags.length === 0 ? (
                <div className="text-center py-12">
                  <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Specs Learned Yet</h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Start reading insights and the system will automatically learn your preferences. 
                    The more you interact, the better alerts you'll receive.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {(Array.isArray(profileTags) ? profileTags : []).map((tag) => {
                      const SpecIcon = getSpecTypeIcon(tag.specType);
                      return (
                        <Badge 
                          key={tag.id}
                          variant="secondary" 
                          className={cn("px-3 py-1 flex items-center gap-2", getSpecTypeColor(tag.specType))}
                        >
                          <SpecIcon className="h-3 w-3" />
                          {tag.displayName}
                          <span className="text-xs opacity-75">
                            {Math.round(tag.strength * 100)}%
                          </span>
                        </Badge>
                      );
                    })}
                  </div>
                  <Separator />
                  <div className="text-sm text-muted-foreground">
                    <p className="mb-2">
                      <strong>How it works:</strong> As you read, save, and interact with insights, 
                      the system identifies patterns in your interests and automatically creates "specs" - 
                      learned preferences that trigger relevant alerts.
                    </p>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>🎯 <strong>Industry Focus</strong>: Sectors and markets you engage with</li>
                      <li>⚡ <strong>Technology Interest</strong>: Tech trends and innovations you follow</li>
                      <li>🧠 <strong>Company Tracking</strong>: Organizations you monitor</li>
                    </ul>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Automatic Alert Activity
              </CardTitle>
              <CardDescription>
                Recent automatic alerts generated in the last 24 hours
              </CardDescription>
            </CardHeader>
            <CardContent>
              {autoAlertsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : !Array.isArray(recentAutoAlerts) || recentAutoAlerts.length === 0 ? (
                <div className="text-center py-12">
                  <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Automatic Alerts Today</h3>
                  <p className="text-muted-foreground">
                    The system is monitoring for high-priority insights that match your specs. 
                    Alerts will appear here automatically when relevant content is found.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {(Array.isArray(recentAutoAlerts) ? recentAutoAlerts : []).map((alert) => (
                    <div key={alert.id} className="flex items-center justify-between p-2.5 bg-muted/50 rounded-md">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-2 h-2 rounded-full",
                          alert.priority === 'critical' ? 'bg-red-500' :
                          alert.priority === 'high' ? 'bg-orange-500' :
                          alert.priority === 'medium' ? 'bg-blue-500' : 'bg-gray-500'
                        )} />
                        <div>
                          <div className="font-medium text-sm">{alert.title}</div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(alert.createdAt).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {alert.priority}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
        </div>
      </main>

      {/* Alert Detail Modal/Panel */}
      {selectedAlert && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="max-w-2xl w-full max-h-[85vh] overflow-y-auto">
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="pr-8">{selectedAlert.title}</CardTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline" className={priorityConfig[selectedAlert.priority].color}>
                      {selectedAlert.priority}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {new Date(selectedAlert.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setSelectedAlert(null)}
                >
                  ×
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Insight Analysis</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {selectedAlert.insight}
                </p>
              </div>
              
              <Separator />
              
              <div>
                <h4 className="font-semibold mb-2">Recommended Actions</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {selectedAlert.actionability}
                </p>
              </div>

              <Separator />

              <div>
                <h4 className="font-semibold mb-2">Market Context</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {selectedAlert.marketContext}
                </p>
              </div>

              {!selectedAlert.isRead && (
                <div className="space-y-3">
                  <Separator />
                  <div>
                    <h4 className="font-semibold mb-2">Feedback (Optional)</h4>
                    <Textarea 
                      placeholder="Was this alert helpful? Any suggestions for improvement?"
                      value={feedback}
                      onChange={(e) => setFeedback(e.target.value)}
                      className="text-sm"
                    />
                  </div>
                  <div className="flex justify-between gap-2">
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => markReadMutation.mutate({ 
                          alertId: selectedAlert.id, 
                          feedback: feedback + " [Positive feedback]" 
                        })}
                      >
                        <ThumbsUp className="h-3 w-3 mr-1" />
                        Helpful
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => markReadMutation.mutate({ 
                          alertId: selectedAlert.id, 
                          feedback: feedback + " [Negative feedback]" 
                        })}
                      >
                        <ThumbsDown className="h-3 w-3 mr-1" />
                        Not Helpful
                      </Button>
                    </div>
                    <Button 
                      onClick={() => markReadMutation.mutate({ 
                        alertId: selectedAlert.id, 
                        feedback: feedback || undefined 
                      })}
                      disabled={markReadMutation.isPending}
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Mark as Read
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}