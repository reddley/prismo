import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Building2, MapPin, Globe, Users, Calendar, TrendingUp, Search, Plus, ExternalLink } from "lucide-react";
import { Link } from "wouter";
import type { Company } from "@shared/schema";

export default function Companies() {
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: companies = [], isLoading } = useQuery<Company[]>({
    queryKey: ['/api/companies'],
  });

  const filteredCompanies = companies.filter((company: Company) =>
    company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    company.industry?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-foreground">Companies</h1>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="">
              <CardHeader>
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-20 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <main className="flex-1 overflow-y-auto p-6">
        <div className="max-w-7xl mx-auto space-y-6" data-testid="companies-page">
          {/* Header */}
          <div className="flex items-center justify-between">
            <Button data-testid="button-add-company">
              <Plus className="w-4 h-4 mr-2" />
              Add Company
            </Button>
          </div>

          {/* Search and Filters */}
          <div className="flex items-center space-x-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search companies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-companies"
              />
            </div>
            <Badge variant="secondary" className="px-3 py-1">
              {filteredCompanies.length} companies
            </Badge>
          </div>

          {/* Companies Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCompanies.map((company: Company) => (
              <Link key={company.id} href={`/companies/${company.id}`}>
                <Card 
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  data-testid={`card-company-${company.id}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={company.logoUrl || ''} alt={company.name} />
                          <AvatarFallback>
                            <Building2 className="w-6 h-6" />
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <CardTitle className="text-lg">{company.name}</CardTitle>
                          <CardDescription>{company.industry}</CardDescription>
                        </div>
                      </div>
                      
                      {/* Mentions in top right corner */}
                      <div className="flex items-center text-sm text-muted-foreground">
                        <TrendingUp className="w-4 h-4 mr-1" />
                        {company.mentionCount || 0}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Company Info - Always show headquarters and founded */}
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4 mr-2" />
                        {company.headquarters || 'Location not specified'}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="w-4 h-4 mr-2" />
                        {company.founded ? `Founded ${company.founded}` : 'Founded year not specified'}
                      </div>
                      {company.employees && (
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Users className="w-4 h-4 mr-2" />
                          {company.employees} employees
                        </div>
                      )}
                    </div>

                    {/* Description */}
                    {company.description && (
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {company.description}
                      </p>
                    )}

                    {/* Tags - Always show keyword tags */}
                    <div className="flex flex-wrap gap-1">
                      {company.tags && company.tags.length > 0 ? (
                        <>
                          {company.tags.slice(0, 3).map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {company.tags.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{company.tags.length - 3} more
                            </Badge>
                          )}
                        </>
                      ) : (
                        <>
                          {company.industry && (
                            <Badge variant="outline" className="text-xs">
                              {company.industry.toLowerCase()}
                            </Badge>
                          )}
                          <Badge variant="outline" className="text-xs opacity-60">
                            technology
                          </Badge>
                          <Badge variant="outline" className="text-xs opacity-60">
                            business
                          </Badge>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* Empty State */}
          {filteredCompanies.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <Building2 className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No companies found</h3>
              <p className="text-muted-foreground mb-4">
                {searchQuery ? `No companies match "${searchQuery}"` : "Start by adding your first company"}
              </p>
              <Button data-testid="button-add-first-company">
                <Plus className="w-4 h-4 mr-2" />
                Add Company
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}