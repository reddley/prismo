import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Building2, MapPin, Calendar, Users, Globe, TrendingUp, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";
import { CompanyEditDialog } from "@/components/EntityEditDialog";

interface Company {
  id: string;
  name: string;
  description?: string;
  industry?: string;
  founded?: string;
  headquarters?: string;
  website?: string;
  logoUrl?: string;
  marketCap?: string;
  employees?: string;
  revenue?: string;
  status: string;
  tags?: string[];
  keyPeople?: any;
  socialMedia?: any;
  mentionCount: number;
  lastMentioned?: string;
  priority: string;
  // Enhanced profile data
  profileData?: {
    detailedDescription?: string;
    funding?: string;
    investors?: string[];
    competitors?: string[];
    products?: string[];
    newsLinks?: Array<{ title: string; url: string; date: string }>;
    financialData?: any;
  };
}

export function CompanyProfile() {
  const { id } = useParams<{ id: string }>();

  const { data: company, isLoading } = useQuery<Company>({
    queryKey: ['/api/companies', id],
  });

  const { data: mentions = [], isLoading: loadingMentions } = useQuery<any[]>({
    queryKey: ['/api/companies', id, 'mentions'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className=" space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="h-32 bg-muted rounded"></div>
          <div className="h-24 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  if (!company) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Company Not Found</h1>
          <Link href="/companies">
            <Button>Back to Companies</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="flex-1 overflow-y-auto">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <Link href="/companies">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Companies
              </Button>
            </Link>
          </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Profile Card */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-start gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={company.logoUrl || ''} alt={company.name} />
                  <AvatarFallback>
                    <Building2 className="w-8 h-8" />
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <CardTitle className="text-2xl mb-2">{company.name}</CardTitle>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      {company.industry && (
                        <Badge variant="secondary">{company.industry}</Badge>
                      )}
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-4 h-4" />
                        {company.mentionCount} mentions
                      </div>
                    </div>
                    <CompanyEditDialog company={company} />
                  </div>
                  
                  {/* Quick Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      {company.headquarters || 'Location not specified'}
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      {company.founded ? `Founded ${company.founded}` : 'Founded year not specified'}
                    </div>
                    {company.employees && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Users className="w-4 h-4" />
                        {company.employees} employees
                      </div>
                    )}
                    {company.website && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Globe className="w-4 h-4" />
                        <a 
                          href={company.website} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="hover:text-primary flex items-center gap-1"
                        >
                          Website
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Description */}
              <div>
                <h3 className="font-semibold mb-2">About</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {company.profileData?.detailedDescription || company.description || 'No description available.'}
                </p>
              </div>

              {/* Tags */}
              {company.tags && company.tags.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Keywords</h3>
                  <div className="flex flex-wrap gap-2">
                    {company.tags.map((tag, index) => (
                      <Badge key={index} variant="outline">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Financial Info */}
              {(company.marketCap || company.revenue || company.profileData?.funding) && (
                <div>
                  <h3 className="font-semibold mb-2">Financial Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    {company.marketCap && (
                      <div>
                        <span className="text-muted-foreground">Market Cap:</span>
                        <div className="font-medium">{company.marketCap}</div>
                      </div>
                    )}
                    {company.revenue && (
                      <div>
                        <span className="text-muted-foreground">Revenue:</span>
                        <div className="font-medium">{company.revenue}</div>
                      </div>
                    )}
                    {company.profileData?.funding && (
                      <div>
                        <span className="text-muted-foreground">Funding:</span>
                        <div className="font-medium">{company.profileData.funding}</div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Mentions */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Mentions</CardTitle>
            </CardHeader>
            <CardContent>
              {loadingMentions ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="">
                      <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : mentions.length > 0 ? (
                <div className="space-y-4">
                  {mentions.slice(0, 5).map((mention: any, index: number) => (
                    <div key={index} className="border-b pb-3 last:border-b-0">
                      <h4 className="font-medium text-sm mb-1">{mention.title}</h4>
                      <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                        {mention.summary || mention.content}
                      </p>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>{mention.source}</span>
                        <span>{new Date(mention.publishedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No recent mentions found
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Additional Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Additional Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <span className="text-sm text-muted-foreground">Status:</span>
                <div className="font-medium capitalize">{company.status}</div>
              </div>
              
              <div>
                <span className="text-sm text-muted-foreground">Priority Level:</span>
                <div className="font-medium capitalize">{company.priority}</div>
              </div>

              {company.lastMentioned && (
                <div>
                  <span className="text-sm text-muted-foreground">Last Mentioned:</span>
                  <div className="font-medium">
                    {new Date(company.lastMentioned).toLocaleDateString()}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Competitors */}
          {company.profileData?.competitors && company.profileData.competitors.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Competitors</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {company.profileData.competitors.map((competitor: string, index: number) => (
                    <div key={index} className="text-sm p-2 bg-muted rounded">
                      {competitor}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Products/Services */}
          {company.profileData?.products && company.profileData.products.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Products & Services</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {company.profileData.products.map((product: string, index: number) => (
                    <Badge key={index} variant="outline" className="mr-2 mb-2">
                      {product}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
        </div>
      </div>
    </div>
  );
}