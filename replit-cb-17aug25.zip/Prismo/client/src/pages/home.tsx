import { Header } from "@/components/layout/header";
import { DashboardGrid } from "@/components/dashboard/DashboardGrid";

export default function Home() {
  return (
    <div className="flex-1 flex flex-col overflow-hidden" data-testid="home-page">
      <Header 
        title="Home 2.0" 
        subtitle="Your personalized dashboard"
      />
      
      <main className="flex-1 overflow-y-auto custom-scrollbar">
        <DashboardGrid />
      </main>
    </div>
  );
}