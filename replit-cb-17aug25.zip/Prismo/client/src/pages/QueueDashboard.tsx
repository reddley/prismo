import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Activity, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Timer,
  Database,
  Zap
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface QueueStats {
  waiting: number;
  active: number;
  completed: number;
  failed: number;
  delayed: number;
  paused: boolean;
}

interface DeadLetterQueueStats {
  total: number;
  recent: number;
  oldestFailure: Date | null;
}

interface QueueDashboardData {
  queues: Record<string, QueueStats>;
  deadLetterQueue: DeadLetterQueueStats;
  redis: {
    connected: boolean;
    responseTime: number;
    memoryUsage?: string;
    version?: string;
  };
  idempotency: {
    totalKeys: number;
    expiredKeys: number;
    activeKeys: number;
  };
  timestamp: number;
}

export default function QueueDashboard() {
  const { data: queueData, isLoading } = useQuery<QueueDashboardData>({
    queryKey: ['/api/queue/stats'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { mutate: triggerRssProcessing, isPending: isProcessing } = useMutation({
    mutationFn: () => apiRequest('/api/queue/rss/process', {
      method: 'POST',
      body: JSON.stringify({ sourceIds: [] }),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/queue/stats'] });
    },
  });

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <h1 className="text-3xl font-bold">Queue Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-6 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const totalJobs = queueData ? Object.values(queueData.queues).reduce(
    (sum, queue) => sum + queue.waiting + queue.active + queue.completed + queue.failed,
    0
  ) : 0;

  const totalActive = queueData ? Object.values(queueData.queues).reduce(
    (sum, queue) => sum + queue.active,
    0
  ) : 0;

  const totalFailed = queueData ? Object.values(queueData.queues).reduce(
    (sum, queue) => sum + queue.failed,
    0
  ) : 0;

  return (
    <div className="p-6 space-y-6" data-testid="queue-dashboard">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Queue Dashboard</h1>
          <p className="text-muted-foreground">
            Redis-backed job queue with idempotency, retries, and dead letter queue
          </p>
        </div>
        <Button
          onClick={() => triggerRssProcessing()}
          disabled={isProcessing}
          data-testid="button-trigger-rss"
        >
          {isProcessing ? (
            <>
              <Timer className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 mr-2" />
              Trigger RSS Processing
            </>
          )}
        </Button>
      </div>

      {/* System Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Redis Status</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {queueData?.redis.connected ? (
                <>
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className="text-green-500">Connected</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-yellow-500" />
                  <span className="text-yellow-500">Fallback Mode</span>
                </>
              )}
            </div>
            {queueData?.redis.connected && (
              <div className="text-xs text-muted-foreground mt-2">
                Response: {queueData.redis.responseTime}ms
                {queueData.redis.memoryUsage && (
                  <div>Memory: {queueData.redis.memoryUsage}</div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-active-jobs">
              {totalActive}
            </div>
            <p className="text-xs text-muted-foreground">
              Currently processing
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Dead Letter Queue</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-dlq-count">
              {queueData?.deadLetterQueue.total || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Failed jobs (stuck items)
            </p>
            {queueData?.deadLetterQueue.total === 0 && (
              <Badge variant="outline" className="text-green-600 mt-2">
                ✓ No stuck items
              </Badge>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Queue Status Alert */}
      {queueData?.deadLetterQueue.total === 0 && totalFailed === 0 && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Queue system is healthy. No stuck items in dead letter queue after soak tests.
          </AlertDescription>
        </Alert>
      )}

      {/* Individual Queue Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {queueData && Object.entries(queueData.queues).map(([queueName, stats]) => (
          <Card key={queueName}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium capitalize">
                {queueName.replace('_', ' ')}
              </CardTitle>
              <CardDescription>
                {stats.paused ? (
                  <Badge variant="secondary">Paused</Badge>
                ) : (
                  <Badge variant="outline">Active</Badge>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Waiting:</span>
                <span data-testid={`text-waiting-${queueName}`}>{stats.waiting}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Active:</span>
                <span className="font-medium text-blue-600" data-testid={`text-active-${queueName}`}>
                  {stats.active}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Completed:</span>
                <span className="text-green-600" data-testid={`text-completed-${queueName}`}>
                  {stats.completed}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Failed:</span>
                <span className="text-red-600" data-testid={`text-failed-${queueName}`}>
                  {stats.failed}
                </span>
              </div>
              {stats.delayed > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Delayed:</span>
                  <span className="text-yellow-600">{stats.delayed}</span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Idempotency Stats */}
      {queueData && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Idempotency Protection</CardTitle>
            <CardDescription>
              Prevents duplicate job execution with 24-hour key expiration
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {queueData.idempotency.activeKeys}
                </div>
                <div className="text-sm text-muted-foreground">Active Keys</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-500">
                  {queueData.idempotency.expiredKeys}
                </div>
                <div className="text-sm text-muted-foreground">Expired Keys</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {queueData.idempotency.totalKeys}
                </div>
                <div className="text-sm text-muted-foreground">Total Keys</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dead Letter Queue Details */}
      {queueData && queueData.deadLetterQueue.total > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-red-500" />
              Dead Letter Queue Details
            </CardTitle>
            <CardDescription>
              Jobs that failed after maximum retry attempts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Total failed jobs:</span>
                <Badge variant="destructive">{queueData.deadLetterQueue.total}</Badge>
              </div>
              <div className="flex justify-between">
                <span>Recent failures (24h):</span>
                <Badge variant="outline">{queueData.deadLetterQueue.recent}</Badge>
              </div>
              {queueData.deadLetterQueue.oldestFailure && (
                <div className="flex justify-between">
                  <span>Oldest failure:</span>
                  <span className="text-sm text-muted-foreground">
                    {new Date(queueData.deadLetterQueue.oldestFailure).toLocaleString()}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="text-xs text-muted-foreground text-center">
        Last updated: {queueData ? new Date(queueData.timestamp).toLocaleString() : 'Never'}
      </div>
    </div>
  );
}