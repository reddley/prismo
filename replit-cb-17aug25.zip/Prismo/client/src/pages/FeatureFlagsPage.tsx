import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Shield, Zap, Settings, Beaker, Activity, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface FeatureFlag {
  id: string;
  name: string;
  description: string;
  type: 'boolean' | 'string' | 'number' | 'json';
  currentValue: any;
  defaultValue: any;
  enabled: boolean;
  category: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  rolloutPercentage?: number;
  environment: string[];
  updatedAt: string;
  lastModifiedBy: string;
}

const categoryIcons = {
  ai_processing: Zap,
  data_ingestion: Activity,
  ui_features: Eye,
  system_controls: Shield,
  experimental: Beaker,
  performance: Activity,
  security: Shield
};

const riskColors = {
  low: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  medium: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
  high: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
  critical: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
};

export default function FeatureFlagsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showKillSwitchDialog, setShowKillSwitchDialog] = useState(false);

  const { data: flags = [], isLoading } = useQuery<FeatureFlag[]>({
    queryKey: ['/api/feature-flags'],
  });

  const updateFlagMutation = useMutation({
    mutationFn: async ({ flagId, updates }: { flagId: string; updates: any }) => {
      return apiRequest(`/api/feature-flags/${flagId}`, {
        method: 'PATCH',
        body: JSON.stringify(updates)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/feature-flags'] });
      toast({
        title: "Success",
        description: "Feature flag updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update feature flag",
        variant: "destructive",
      });
    }
  });

  const emergencyKillSwitchMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('/api/feature-flags/emergency-kill-switch', {
        method: 'POST'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/feature-flags'] });
      toast({
        title: "Emergency Kill Switch Activated",
        description: "All high-risk features have been disabled",
        variant: "destructive",
      });
      setShowKillSwitchDialog(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to activate emergency kill switch",
        variant: "destructive",
      });
    }
  });

  const handleToggleFlag = async (flag: FeatureFlag) => {
    if (flag.type === 'boolean') {
      updateFlagMutation.mutate({
        flagId: flag.id,
        updates: {
          currentValue: !flag.currentValue,
          lastModifiedBy: 'user'
        }
      });
    }
  };

  const handleUpdateValue = async (flag: FeatureFlag, newValue: any) => {
    updateFlagMutation.mutate({
      flagId: flag.id,
      updates: {
        currentValue: newValue,
        lastModifiedBy: 'user'
      }
    });
  };

  const filteredFlags = flags.filter(flag => 
    selectedCategory === 'all' || flag.category === selectedCategory
  );

  const systemControlFlags = flags.filter(flag => flag.category === 'system_controls');
  const criticalFlags = flags.filter(flag => flag.riskLevel === 'critical');

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6" data-testid="feature-flags-page">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold" data-testid="page-title">Feature Flags & Kill Switches</h1>
          <p className="text-muted-foreground mt-2">
            Manage feature toggles and emergency controls for safe production experimentation
          </p>
        </div>
        
        <Button
          variant="destructive"
          onClick={() => setShowKillSwitchDialog(true)}
          className="flex items-center gap-2"
          data-testid="button-emergency-kill-switch"
        >
          <AlertTriangle className="h-4 w-4" />
          Emergency Kill Switch
        </Button>
      </div>

      {/* Critical System Controls */}
      <Card className="border-red-200 dark:border-red-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-300">
            <Shield className="h-5 w-5" />
            Critical System Controls
          </CardTitle>
          <CardDescription>
            System-wide kill switches for emergency situations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {systemControlFlags.map((flag) => {
              const IconComponent = categoryIcons[flag.category as keyof typeof categoryIcons] || Settings;
              return (
                <Card key={flag.id} className="p-4" data-testid={`flag-card-${flag.id}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <IconComponent className="h-4 w-4" />
                      <div>
                        <h4 className="font-medium" data-testid={`flag-name-${flag.id}`}>{flag.name}</h4>
                        <p className="text-sm text-muted-foreground">{flag.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={riskColors[flag.riskLevel]} data-testid={`flag-risk-${flag.id}`}>
                        {flag.riskLevel}
                      </Badge>
                      <Switch
                        checked={flag.currentValue}
                        onCheckedChange={() => handleToggleFlag(flag)}
                        data-testid={`flag-toggle-${flag.id}`}
                      />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Feature Flags Management */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <TabsList className="grid w-full grid-cols-8">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="ai_processing">AI</TabsTrigger>
          <TabsTrigger value="data_ingestion">Data</TabsTrigger>
          <TabsTrigger value="ui_features">UI</TabsTrigger>
          <TabsTrigger value="experimental">Experimental</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="system_controls">System</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedCategory} className="space-y-4">
          <div className="grid gap-4">
            {filteredFlags.map((flag) => {
              const IconComponent = categoryIcons[flag.category as keyof typeof categoryIcons] || Settings;
              return (
                <Card key={flag.id} data-testid={`flag-detail-card-${flag.id}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <IconComponent className="h-5 w-5" />
                        <div>
                          <CardTitle className="text-lg" data-testid={`flag-detail-name-${flag.id}`}>
                            {flag.name}
                          </CardTitle>
                          <CardDescription>{flag.description}</CardDescription>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={riskColors[flag.riskLevel]}>
                          {flag.riskLevel}
                        </Badge>
                        <Badge variant="outline">{flag.category}</Badge>
                        <Switch
                          checked={flag.enabled}
                          onCheckedChange={(enabled) => 
                            updateFlagMutation.mutate({
                              flagId: flag.id,
                              updates: { enabled, lastModifiedBy: 'user' }
                            })
                          }
                          data-testid={`flag-detail-enabled-${flag.id}`}
                        />
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div>
                        <Label>Current Value</Label>
                        {flag.type === 'boolean' ? (
                          <Switch
                            checked={flag.currentValue}
                            onCheckedChange={() => handleToggleFlag(flag)}
                            className="mt-2"
                            data-testid={`flag-value-toggle-${flag.id}`}
                          />
                        ) : flag.type === 'number' ? (
                          <Input
                            type="number"
                            value={flag.currentValue}
                            onChange={(e) => handleUpdateValue(flag, parseFloat(e.target.value))}
                            className="mt-2"
                            data-testid={`flag-value-input-${flag.id}`}
                          />
                        ) : (
                          <Input
                            value={flag.currentValue}
                            onChange={(e) => handleUpdateValue(flag, e.target.value)}
                            className="mt-2"
                            data-testid={`flag-value-input-${flag.id}`}
                          />
                        )}
                      </div>
                      
                      {flag.rolloutPercentage !== undefined && (
                        <div>
                          <Label>Rollout Percentage</Label>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            value={flag.rolloutPercentage}
                            onChange={(e) => 
                              updateFlagMutation.mutate({
                                flagId: flag.id,
                                updates: { 
                                  rolloutPercentage: parseInt(e.target.value),
                                  lastModifiedBy: 'user'
                                }
                              })
                            }
                            className="mt-2"
                            data-testid={`flag-rollout-input-${flag.id}`}
                          />
                        </div>
                      )}

                      <div>
                        <Label>Environment</Label>
                        <div className="mt-2 flex gap-1">
                          {flag.environment.map(env => (
                            <Badge key={env} variant="secondary">{env}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="text-sm text-muted-foreground">
                      Last modified by {flag.lastModifiedBy} at {new Date(flag.updatedAt).toLocaleString()}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Emergency Kill Switch Dialog */}
      {showKillSwitchDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-300">
                <AlertTriangle className="h-5 w-5" />
                Emergency Kill Switch
              </CardTitle>
              <CardDescription>
                This will immediately disable all high-risk and critical features. 
                Use only in emergency situations.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded border border-red-200 dark:border-red-800">
                <h4 className="font-medium text-red-800 dark:text-red-200 mb-2">
                  Features that will be disabled:
                </h4>
                <ul className="text-sm text-red-700 dark:text-red-300 space-y-1">
                  {criticalFlags.map(flag => (
                    <li key={flag.id}>• {flag.name}</li>
                  ))}
                </ul>
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowKillSwitchDialog(false)}
                  className="flex-1"
                  data-testid="button-cancel-kill-switch"
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => emergencyKillSwitchMutation.mutate()}
                  disabled={emergencyKillSwitchMutation.isPending}
                  className="flex-1"
                  data-testid="button-confirm-kill-switch"
                >
                  {emergencyKillSwitchMutation.isPending ? 'Activating...' : 'Activate Kill Switch'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}