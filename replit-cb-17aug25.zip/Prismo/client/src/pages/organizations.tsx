import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Landmark, MapPin, Globe, Calendar, DollarSign, Users, Search, Plus, ExternalLink, TrendingUp } from "lucide-react";
import type { Organization } from "@shared/schema";

export default function Organizations() {
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: organizations = [], isLoading } = useQuery<Organization[]>({
    queryKey: ['/api/organizations'],
  });

  const filteredOrganizations = organizations.filter((org: Organization) =>
    org.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    org.type?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    org.industry?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'government': return 'bg-blue-500';
      case 'agency': return 'bg-purple-500';
      case 'nonprofit': return 'bg-green-500';
      case 'association': return 'bg-orange-500';
      case 'think_tank': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-foreground">Organizations</h1>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="">
              <CardHeader>
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-20 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <main className="flex-1 overflow-y-auto p-6">
        <div className="max-w-7xl mx-auto space-y-6" data-testid="organizations-page">
          {/* Header */}
          <div className="flex items-center justify-between">
            <Button data-testid="button-add-organization">
              <Plus className="w-4 h-4 mr-2" />
              Add Organization
            </Button>
          </div>

          {/* Search and Filters */}
          <div className="flex items-center space-x-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search organizations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-organizations"
              />
            </div>
            <Badge variant="secondary" className="px-3 py-1">
              {filteredOrganizations.length} organizations
            </Badge>
          </div>

          {/* Organizations Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredOrganizations.map((org: Organization) => (
          <Card 
            key={org.id} 
            className="hover:shadow-lg transition-shadow cursor-pointer"
            data-testid={`card-organization-${org.id}`}
          >
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={org.logoUrl || ''} alt={org.name} />
                    <AvatarFallback>
                      <Landmark className="w-6 h-6" />
                    </AvatarFallback>
                  </Avatar>
                  {/* Type indicator */}
                  <div 
                    className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-background ${getTypeColor(org.type)}`}
                    title={org.type}
                  />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg">{org.name}</CardTitle>
                  <CardDescription className="capitalize">
                    {org.type.replace('_', ' ')} • {org.industry}
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Organization Info */}
              <div className="space-y-2">
                {org.headquarters && (
                  <div className="flex items-center text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-2" />
                    {org.headquarters}
                  </div>
                )}
                {org.founded && (
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-2" />
                    Founded {org.founded}
                  </div>
                )}
                {org.budget && (
                  <div className="flex items-center text-sm text-muted-foreground">
                    <DollarSign className="w-4 h-4 mr-2" />
                    {org.budget} budget
                  </div>
                )}
                {org.employees && (
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Users className="w-4 h-4 mr-2" />
                    {org.employees} employees
                  </div>
                )}
              </div>

              {/* Description */}
              {org.description && (
                <p className="text-sm text-muted-foreground line-clamp-3">
                  {org.description}
                </p>
              )}

              {/* Tags */}
              {org.tags && org.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {org.tags.slice(0, 3).map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {org.tags.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{org.tags.length - 3} more
                    </Badge>
                  )}
                </div>
              )}

              {/* Stats */}
              <div className="flex items-center justify-between pt-2 border-t">
                <div className="flex items-center text-sm text-muted-foreground">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  {org.mentionCount || 0} mentions
                </div>
                {org.website && (
                  <Button variant="ghost" size="sm" asChild>
                    <a href={org.website} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </Button>
                )}
              </div>
            </CardContent>
            </Card>
            ))}
          </div>

          {/* Empty State */}
          {filteredOrganizations.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <Landmark className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No organizations found</h3>
              <p className="text-muted-foreground mb-4">
                {searchQuery ? `No organizations match "${searchQuery}"` : "Start by adding your first organization"}
              </p>
              <Button data-testid="button-add-first-organization">
                <Plus className="w-4 h-4 mr-2" />
                Add Organization
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}