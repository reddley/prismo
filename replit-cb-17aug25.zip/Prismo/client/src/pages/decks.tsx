import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, User, Users, Search, Filter, TrendingUp, Clock, ExternalLink, Edit } from "lucide-react";
import { Link } from "wouter";

export default function Decks() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  // Fetch all entity types
  const { data: companies = [], isLoading: loadingCompanies } = useQuery<any[]>({
    queryKey: ['/api/companies'],
  });

  const { data: people = [], isLoading: loadingPeople } = useQuery<any[]>({
    queryKey: ['/api/people'],
  });

  const { data: organizations = [], isLoading: loadingOrgs } = useQuery<any[]>({
    queryKey: ['/api/organizations'],
  });

  const isLoading = loadingCompanies || loadingPeople || loadingOrgs;

  // Combine all entities
  const allEntities = [
    ...companies.map((c: any) => ({ ...c, type: 'company' })),
    ...people.map((p: any) => ({ ...p, type: 'person' })),
    ...organizations.map((o: any) => ({ ...o, type: 'organization' }))
  ];

  // Filter entities based on search and tab
  const filteredEntities = allEntities.filter((entity) => {
    const matchesSearch = entity.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         entity.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === "all") return matchesSearch;
    return matchesSearch && entity.type === activeTab;
  });

  // Sort by priority and last mentioned
  const sortedEntities = filteredEntities.sort((a, b) => {
    const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
    const aPriority = priorityOrder[a.priority as keyof typeof priorityOrder];
    const bPriority = priorityOrder[b.priority as keyof typeof priorityOrder];
    
    if (aPriority !== bPriority) {
      return bPriority - aPriority;
    }
    
    return new Date(b.lastMentioned || b.createdAt).getTime() - new Date(a.lastMentioned || a.createdAt).getTime();
  });

  const getEntityIcon = (type: string) => {
    switch (type) {
      case 'company': return <Building2 className="h-4 w-4" />;
      case 'person': return <User className="h-4 w-4" />;
      case 'organization': return <Users className="h-4 w-4" />;
      default: return <Building2 className="h-4 w-4" />;
    }
  };

  const getEntityImage = (entity: any) => {
    switch (entity.type) {
      case 'company': return entity.logoUrl;
      case 'person': return entity.profilePictureUrl;
      case 'organization': return entity.logoUrl;
      default: return undefined;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getEntityLink = (entity: any) => {
    switch (entity.type) {
      case 'company': return `/companies/${entity.id}`;
      case 'person': return `/people/${entity.id}`;
      case 'organization': return `/organizations/${entity.id}`;
      default: return `/companies/${entity.id}`;
    }
  };

  const formatLastMentioned = (date: string) => {
    const now = new Date();
    const mentionDate = new Date(date);
    const diffInHours = Math.floor((now.getTime() - mentionDate.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d ago`;
    return mentionDate.toLocaleDateString();
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden" data-testid="decks-page">
      <Header 
        title="Intelligence Decks" 
        subtitle="AI-powered entity discovery and relationship mapping"
      />
      
      <main className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6">
        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search entities by name or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="search-entities"
            />
          </div>
          <Button variant="outline" size="sm" className="whitespace-nowrap">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>

        {/* Entity Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all" data-testid="tab-all">
              All ({allEntities.length})
            </TabsTrigger>
            <TabsTrigger value="company" data-testid="tab-companies">
              <Building2 className="h-4 w-4 mr-1" />
              Companies ({(companies as any[]).length})
            </TabsTrigger>
            <TabsTrigger value="person" data-testid="tab-people">
              <User className="h-4 w-4 mr-1" />
              People ({(people as any[]).length})
            </TabsTrigger>
            <TabsTrigger value="organization" data-testid="tab-organizations">
              <Users className="h-4 w-4 mr-1" />
              Organizations ({(organizations as any[]).length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="space-y-4">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-muted rounded-full" />
                        <div className="flex-1 space-y-2">
                          <div className="h-5 bg-muted rounded w-3/4" />
                          <div className="h-4 bg-muted rounded w-full" />
                          <div className="h-3 bg-muted rounded w-1/2" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : sortedEntities.length === 0 ? (
              <div className="text-center py-12">
                <Users className="h-16 w-16 mx-auto text-muted-foreground mb-6" />
                {searchQuery ? (
                  <>
                    <h3 className="text-lg font-medium mb-2">No entities found</h3>
                    <p className="text-muted-foreground mb-4">
                      Try adjusting your search criteria or browse all entities
                    </p>
                    <Button onClick={() => setSearchQuery("")} variant="outline">
                      Clear Search
                    </Button>
                  </>
                ) : (
                  <>
                    <h3 className="text-lg font-medium mb-2">No decks created yet</h3>
                    <p className="text-muted-foreground mb-4">
                      High-priority insights will automatically create entity profiles
                    </p>
                    <Link href="/sources">
                      <Button>
                        <TrendingUp className="h-4 w-4 mr-2" />
                        Configure Data Sources
                      </Button>
                    </Link>
                  </>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {sortedEntities.map((entity) => (
                    <Card 
                      key={`${entity.type}-${entity.id}`}
                      className="group hover:shadow-md transition-all duration-200 border-l-4 border-l-transparent hover:border-l-primary relative"
                      data-testid={`entity-card-${entity.type}-${entity.id}`}
                    >
                      <CardContent className="p-4">
                        {/* Card Header with Avatar, Name, and Mentions */}
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3 flex-1">
                            {/* Clickable Entity Avatar */}
                            <Link href={getEntityLink(entity)}>
                              <div className="relative cursor-pointer">
                                <Avatar className="h-10 w-10 hover:ring-2 hover:ring-primary/20 transition-all">
                                  <AvatarImage 
                                    src={getEntityImage(entity)} 
                                    alt={entity.name}
                                    className="object-cover aspect-square"
                                  />
                                  <AvatarFallback>
                                    {getEntityIcon(entity.type)}
                                  </AvatarFallback>
                                </Avatar>
                                {/* Priority Indicator */}
                                <div 
                                  className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-background ${getPriorityColor(entity.priority)}`}
                                  title={`${entity.priority} priority`}
                                />
                              </div>
                            </Link>

                            {/* Clickable Entity Name and Type */}
                            <div className="flex-1 min-w-0">
                              <Link href={getEntityLink(entity)}>
                                <h3 className="font-semibold text-sm hover:text-primary transition-colors truncate cursor-pointer mb-1">
                                  {entity.name}
                                </h3>
                              </Link>
                              <div className="flex items-center gap-2">
                                <Badge variant="secondary" className="capitalize text-xs">
                                  {entity.type}
                                </Badge>
                                {entity.industry && (
                                  <Badge variant="outline" className="text-xs">
                                    {entity.industry}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Top Right Corner: Edit Icon and Mentions */}
                          <div className="flex items-center gap-2 flex-shrink-0">
                            {/* Mentions Count with Trending Icon */}
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <TrendingUp className="h-3 w-3" />
                              {entity.mentionCount || 0}
                            </div>
                            {/* Edit Icon */}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                console.log('Edit entity:', entity.id, entity.type);
                              }}
                              data-testid={`edit-${entity.type}-${entity.id}`}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        
                        {/* Description */}
                        <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                          {entity.description || `${entity.type} discovered from intelligence analysis`}
                        </p>

                        {/* Bottom Metadata */}
                        {entity.lastMentioned && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {formatLastMentioned(entity.lastMentioned)}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}