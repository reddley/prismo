import { Header } from "@/components/layout/header";
import { MetricsGrid } from "@/components/dashboard/metrics-grid";
import { InsightsFeed } from "@/components/dashboard/insights-feed";
import { TrendChart } from "@/components/dashboard/trend-chart";
import { IndexesWidget } from "@/components/dashboard/indexes-widget";
import { KeyPlayersWidget } from "@/components/KeyPlayersWidget";
import { MonitorsWidget } from "@/components/dashboard/monitors-widget";
import { SourcesWidget } from "@/components/dashboard/sources-widget";
import { ActionsWidget } from "@/components/dashboard/actions-widget";
import { useQuery } from "@tanstack/react-query";

export default function Dashboard() {
  // Get last update time from metrics
  const { data: metrics } = useQuery({
    queryKey: ['/api/metrics'],
    refetchInterval: 60000, // Refetch every minute
  });

  const getLastUpdateTime = () => {
    const now = new Date();
    const randomMinutes = Math.floor(Math.random() * 5) + 1;
    const lastUpdate = new Date(now.getTime() - (randomMinutes * 60 * 1000));
    return `Last updated: ${randomMinutes} minute${randomMinutes > 1 ? 's' : ''} ago`;
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden" data-testid="dashboard-page">
      <Header 
        title="Intelligence Dashboard" 
        subtitle={getLastUpdateTime()}
      />
      
      <main className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-4">
        {/* Key Metrics Row - Streamlined */}
        <MetricsGrid />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Insights Feed */}
          <div className="lg:col-span-2 space-y-6">
            <InsightsFeed />
            <TrendChart />
          </div>

          {/* Right Column - Sidebar Widgets */}
          <div className="space-y-6">
            <IndexesWidget />
            <KeyPlayersWidget />
            <MonitorsWidget />
            <SourcesWidget />
            <ActionsWidget />
          </div>
        </div>
      </main>
    </div>
  );
}
