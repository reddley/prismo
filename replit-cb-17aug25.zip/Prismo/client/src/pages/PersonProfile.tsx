import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, User, MapPin, Building2, Briefcase, TrendingUp, ExternalLink, Linkedin, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { PersonEditDialog } from "@/components/EntityEditDialog";

interface Person {
  id: string;
  name: string;
  title?: string;
  company?: string;
  description?: string;
  industry?: string;
  location?: string;
  profileImageUrl?: string;
  linkedinUrl?: string;
  twitterUrl?: string;
  website?: string;
  expertise?: string[];
  tags?: string[];
  influence: string;
  mentionCount: number;
  lastMentioned?: string;
  priority: string;
  // Enhanced profile data
  profileData?: {
    detailedBio?: string;
    education?: string[];
    previousRoles?: Array<{ title: string; company: string; duration: string }>;
    achievements?: string[];
    publications?: Array<{ title: string; url: string; date: string }>;
    speakingEngagements?: Array<{ event: string; topic: string; date: string }>;
  };
}

export function PersonProfile() {
  const { id } = useParams<{ id: string }>();

  const { data: person, isLoading } = useQuery<Person>({
    queryKey: ['/api/people', id],
  });

  const { data: mentions = [], isLoading: loadingMentions } = useQuery<any[]>({
    queryKey: ['/api/people', id, 'mentions'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className=" space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="h-32 bg-muted rounded"></div>
          <div className="h-24 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  if (!person) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Person Not Found</h1>
          <Link href="/people">
            <Button>Back to People</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="flex-1 overflow-y-auto">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
        <Link href="/people">
          <Button variant="ghost" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to People
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Profile Card */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-start gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={person.profileImageUrl || ''} alt={person.name} />
                  <AvatarFallback>
                    <User className="w-8 h-8" />
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <CardTitle className="text-2xl mb-2">{person.name}</CardTitle>
                  <div className="space-y-2 mb-3">
                    {person.title && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Briefcase className="w-4 h-4" />
                        {person.title}
                      </div>
                    )}
                    {person.company && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Building2 className="w-4 h-4" />
                        {person.company}
                      </div>
                    )}
                    {person.location && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        {person.location}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <Badge variant="secondary" className="capitalize">{person.influence} Influence</Badge>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-4 h-4" />
                        {person.mentionCount} mentions
                      </div>
                    </div>
                    <PersonEditDialog person={person} />
                  </div>

                  {/* Social Links */}
                  <div className="flex items-center gap-3">
                    {person.linkedinUrl && (
                      <a 
                        href={person.linkedinUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-muted-foreground hover:text-primary"
                      >
                        <Linkedin className="w-5 h-5" />
                      </a>
                    )}
                    {person.twitterUrl && (
                      <a 
                        href={person.twitterUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-muted-foreground hover:text-primary"
                      >
                        <Twitter className="w-5 h-5" />
                      </a>
                    )}
                    {person.website && (
                      <a 
                        href={person.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-muted-foreground hover:text-primary flex items-center gap-1"
                      >
                        Website
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Bio */}
              <div>
                <h3 className="font-semibold mb-2">Biography</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {person.profileData?.detailedBio || person.description || 'No biography available.'}
                </p>
              </div>

              {/* Expertise */}
              {person.expertise && person.expertise.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Areas of Expertise</h3>
                  <div className="flex flex-wrap gap-2">
                    {person.expertise.map((skill, index) => (
                      <Badge key={index} variant="outline">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Previous Roles */}
              {person.profileData?.previousRoles && person.profileData.previousRoles.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Career History</h3>
                  <div className="space-y-3">
                    {person.profileData.previousRoles.map((role, index) => (
                      <div key={index} className="border-l-2 border-muted pl-4">
                        <div className="font-medium">{role.title}</div>
                        <div className="text-sm text-muted-foreground">{role.company}</div>
                        <div className="text-xs text-muted-foreground">{role.duration}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Education */}
              {person.profileData?.education && person.profileData.education.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Education</h3>
                  <div className="space-y-2">
                    {person.profileData.education.map((edu, index) => (
                      <div key={index} className="text-sm p-2 bg-muted rounded">
                        {edu}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Mentions */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Mentions</CardTitle>
            </CardHeader>
            <CardContent>
              {loadingMentions ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="">
                      <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : mentions.length > 0 ? (
                <div className="space-y-4">
                  {mentions.slice(0, 5).map((mention: any, index: number) => (
                    <div key={index} className="border-b pb-3 last:border-b-0">
                      <h4 className="font-medium text-sm mb-1">{mention.title}</h4>
                      <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                        {mention.summary || mention.content}
                      </p>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>{mention.source}</span>
                        <span>{new Date(mention.publishedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No recent mentions found
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Additional Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Additional Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <span className="text-sm text-muted-foreground">Influence Level:</span>
                <div className="font-medium capitalize">{person.influence}</div>
              </div>
              
              <div>
                <span className="text-sm text-muted-foreground">Priority Level:</span>
                <div className="font-medium capitalize">{person.priority}</div>
              </div>

              {person.industry && (
                <div>
                  <span className="text-sm text-muted-foreground">Industry:</span>
                  <div className="font-medium">{person.industry}</div>
                </div>
              )}

              {person.lastMentioned && (
                <div>
                  <span className="text-sm text-muted-foreground">Last Mentioned:</span>
                  <div className="font-medium">
                    {new Date(person.lastMentioned).toLocaleDateString()}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Achievements */}
          {person.profileData?.achievements && person.profileData.achievements.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Notable Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {person.profileData.achievements.map((achievement: string, index: number) => (
                    <div key={index} className="text-sm p-3 bg-muted rounded">
                      {achievement}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Publications */}
          {person.profileData?.publications && person.profileData.publications.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Publications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {person.profileData.publications.map((pub, index: number) => (
                    <div key={index} className="space-y-1">
                      <a 
                        href={pub.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm font-medium hover:text-primary"
                      >
                        {pub.title}
                      </a>
                      <div className="text-xs text-muted-foreground">{pub.date}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
        </div>
      </div>
    </div>
  );
}