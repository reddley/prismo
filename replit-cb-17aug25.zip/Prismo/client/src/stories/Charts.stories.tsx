import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import {
  LineChart,
  AreaChart,
  BarChart,
  PieChart,
  DonutChart,
  ScatterChart,
  BubbleChart,
  HeatmapChart,
  ColorPicker,
  ChartConfig,
  ColorTheme
} from '@/components/charts';

// Sample data for demonstrations
const timeSeriesData = [
  { date: '2024-01', sales: 4000, profit: 2400, expenses: 1600 },
  { date: '2024-02', sales: 3000, profit: 1398, expenses: 1602 },
  { date: '2024-03', sales: 2000, profit: 9800, expenses: 800 },
  { date: '2024-04', sales: 2780, profit: 3908, expenses: 1200 },
  { date: '2024-05', sales: 1890, profit: 4800, expenses: 1890 },
  { date: '2024-06', sales: 2390, profit: 3800, expenses: 2100 },
];

const categoryData = [
  { category: 'Technology', value: 45, count: 120 },
  { category: 'Healthcare', value: 32, count: 89 },
  { category: 'Finance', value: 23, count: 67 },
  { category: 'Education', value: 18, count: 45 },
  { category: 'Retail', value: 12, count: 34 },
];

const scatterData = [
  { x: 100, y: 200, z: 50, category: 'A' },
  { x: 120, y: 100, z: 60, category: 'A' },
  { x: 170, y: 300, z: 80, category: 'B' },
  { x: 140, y: 250, z: 70, category: 'B' },
  { x: 150, y: 400, z: 90, category: 'C' },
  { x: 110, y: 280, z: 55, category: 'C' },
];

const heatmapData = [
  { day: 'Mon', hour: '9AM', value: 45 },
  { day: 'Mon', hour: '12PM', value: 78 },
  { day: 'Mon', hour: '3PM', value: 23 },
  { day: 'Tue', hour: '9AM', value: 67 },
  { day: 'Tue', hour: '12PM', value: 89 },
  { day: 'Tue', hour: '3PM', value: 34 },
  { day: 'Wed', hour: '9AM', value: 56 },
  { day: 'Wed', hour: '12PM', value: 91 },
  { day: 'Wed', hour: '3PM', value: 45 },
];

const chartConfig: ChartConfig = {
  sales: { label: 'Sales Revenue', color: 'hsl(var(--chart-1))' },
  profit: { label: 'Net Profit', color: 'hsl(var(--chart-2))' },
  expenses: { label: 'Operating Expenses', color: 'hsl(var(--chart-3))' },
  value: { label: 'Market Value', color: 'hsl(var(--chart-1))' },
  count: { label: 'Total Count', color: 'hsl(var(--chart-2))' },
};

const meta: Meta = {
  title: 'Charts/Unified Charts Layer',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component: 'Comprehensive chart components built on Recharts with unified props, theming, and accessibility features.',
      },
    },
  },
  tags: ['autodocs'],
};

export default meta;

// Line Chart Stories
export const LineChartDefault: StoryObj = {
  name: 'Line Chart - Default',
  render: () => (
    <div className="h-96 w-full">
      <LineChart
        data={timeSeriesData}
        xKey="date"
        yKeys={['sales', 'profit']}
        config={chartConfig}
        aria-label="Sales and profit trends over time"
      />
    </div>
  ),
};

export const LineChartMultiSeries: StoryObj = {
  name: 'Line Chart - Multi Series',
  render: () => (
    <div className="h-96 w-full">
      <LineChart
        data={timeSeriesData}
        xKey="date"
        yKeys={['sales', 'profit', 'expenses']}
        config={chartConfig}
        dot={true}
        strokeWidth={3}
        valueFormatter={(value) => `$${value.toLocaleString()}`}
        aria-label="Financial metrics comparison over time"
      />
    </div>
  ),
};

// Area Chart Stories
export const AreaChartDefault: StoryObj = {
  name: 'Area Chart - Default',
  render: () => (
    <div className="h-96 w-full">
      <AreaChart
        data={timeSeriesData}
        xKey="date"
        yKeys={['sales']}
        config={chartConfig}
        fillOpacity={0.8}
        aria-label="Sales revenue area chart"
      />
    </div>
  ),
};

export const AreaChartStacked: StoryObj = {
  name: 'Area Chart - Stacked',
  render: () => (
    <div className="h-96 w-full">
      <AreaChart
        data={timeSeriesData}
        xKey="date"
        yKeys={['profit', 'expenses']}
        config={chartConfig}
        stackId="financial"
        valueFormatter={(value) => `$${value.toLocaleString()}`}
        aria-label="Stacked financial metrics"
      />
    </div>
  ),
};

// Bar Chart Stories
export const BarChartVertical: StoryObj = {
  name: 'Bar Chart - Vertical',
  render: () => (
    <div className="h-96 w-full">
      <BarChart
        data={categoryData}
        xKey="category"
        yKeys={['value']}
        config={chartConfig}
        layout="vertical"
        valueFormatter={(value) => `${value}%`}
        aria-label="Category values bar chart"
      />
    </div>
  ),
};

export const BarChartHorizontal: StoryObj = {
  name: 'Bar Chart - Horizontal',
  render: () => (
    <div className="h-96 w-full">
      <BarChart
        data={categoryData}
        xKey="category"
        yKeys={['value', 'count']}
        config={chartConfig}
        layout="horizontal"
        aria-label="Category comparison horizontal bar chart"
      />
    </div>
  ),
};

// Pie Chart Stories
export const PieChartDefault: StoryObj = {
  name: 'Pie Chart - Default',
  render: () => (
    <div className="h-96 w-full">
      <PieChart
        data={categoryData}
        dataKey="value"
        nameKey="category"
        config={chartConfig}
        valueFormatter={(value) => `${value}%`}
        aria-label="Category distribution pie chart"
      />
    </div>
  ),
};

export const DonutChartDefault: StoryObj = {
  name: 'Donut Chart - Default',
  render: () => (
    <div className="h-96 w-full">
      <DonutChart
        data={categoryData}
        dataKey="value"
        nameKey="category"
        config={chartConfig}
        showLabels={true}
        valueFormatter={(value) => `${value}%`}
        aria-label="Category distribution donut chart"
      />
    </div>
  ),
};

// Scatter Chart Stories
export const ScatterChartDefault: StoryObj = {
  name: 'Scatter Chart - Default',
  render: () => (
    <div className="h-96 w-full">
      <ScatterChart
        data={scatterData}
        xKey="x"
        yKey="y"
        seriesKey="category"
        config={chartConfig}
        valueFormatter={(value) => value.toString()}
        aria-label="X vs Y scatter plot by category"
      />
    </div>
  ),
};

export const BubbleChartDefault: StoryObj = {
  name: 'Bubble Chart - Default',
  render: () => (
    <div className="h-96 w-full">
      <BubbleChart
        data={scatterData}
        xKey="x"
        yKey="y"
        zKey="z"
        seriesKey="category"
        config={chartConfig}
        minSize={64}
        maxSize={200}
        aria-label="X vs Y bubble chart with Z as size"
      />
    </div>
  ),
};

// Heatmap Chart Stories
export const HeatmapChartDefault: StoryObj = {
  name: 'Heatmap Chart - Default',
  render: () => (
    <div className="h-96 w-full">
      <HeatmapChart
        data={heatmapData}
        xKey="hour"
        yKey="day"
        valueKey="value"
        valueFormatter={(value) => value.toString()}
        cellSize={40}
        cellGap={2}
        showLabels={true}
        aria-label="Activity heatmap by day and hour"
      />
    </div>
  ),
};

// Color Picker Story
export const ColorPickerExample: StoryObj = {
  name: 'Color Picker - Interactive',
  render: () => {
    const [theme, setTheme] = useState<ColorTheme>({
      background: 'hsl(var(--background))',
      foreground: 'hsl(var(--foreground))',
      borders: 'hsl(var(--border))',
      elements: [
        'hsl(var(--chart-1))',
        'hsl(var(--chart-2))',
        'hsl(var(--chart-3))',
      ],
      labels: 'hsl(var(--muted-foreground))',
    });

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold">Custom Chart Theming</h3>
          <ColorPicker theme={theme} onThemeChange={setTheme} />
        </div>
        
        <div className="h-80 w-full">
          <LineChart
            data={timeSeriesData}
            xKey="date"
            yKeys={['sales', 'profit', 'expenses']}
            config={chartConfig}
            colors={theme.elements}
            aria-label="Themed line chart example"
          />
        </div>
      </div>
    );
  },
};

// Accessibility Features Story
export const AccessibilityFeatures: StoryObj = {
  name: 'Accessibility Features',
  render: () => (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-semibold mb-4">Keyboard Navigation & ARIA Labels</h3>
        <p className="text-sm text-muted-foreground mb-4">
          All charts include proper ARIA labels, roles, and keyboard navigation support.
          Tooltips are focusable and screen reader accessible.
        </p>
        
        <div className="h-64 w-full">
          <PieChart
            data={categoryData}
            dataKey="value"
            nameKey="category"
            config={chartConfig}
            aria-label="Accessible pie chart showing market distribution"
            aria-describedby="chart-description"
          />
        </div>
        <p id="chart-description" className="text-xs text-muted-foreground mt-2">
          This chart shows the distribution of market values across different technology categories.
        </p>
      </div>
    </div>
  ),
};

// Theme Adaptation Story
export const ThemeAdaptation: StoryObj = {
  name: 'Light/Dark Theme Adaptation',
  render: () => {
    return (
      <div className="space-y-6">
        <p className="text-sm text-muted-foreground">
          Charts automatically adapt to light/dark themes using CSS custom properties.
          Toggle your theme to see the adaptation in action.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-64">
            <h4 className="text-sm font-medium mb-2">Line Chart</h4>
            <LineChart
              data={timeSeriesData.slice(0, 4)}
              xKey="date"
              yKeys={['sales']}
              config={chartConfig}
              showGrid={true}
            />
          </div>
          
          <div className="h-64">
            <h4 className="text-sm font-medium mb-2">Bar Chart</h4>
            <BarChart
              data={categoryData.slice(0, 3)}
              xKey="category"
              yKeys={['value']}
              config={chartConfig}
              layout="vertical"
            />
          </div>
        </div>
      </div>
    );
  },
};

// Performance Story
export const PerformanceExample: StoryObj = {
  name: 'Performance & Large Datasets',
  render: () => {
    // Generate larger dataset for performance testing
    const largeData = Array.from({ length: 100 }, (_, i) => ({
      index: i,
      value1: Math.random() * 100,
      value2: Math.random() * 100,
      value3: Math.random() * 100,
    }));

    return (
      <div className="space-y-6">
        <p className="text-sm text-muted-foreground">
          Charts handle large datasets efficiently with Recharts optimization.
          This example shows 100 data points with multiple series.
        </p>
        
        <div className="h-80 w-full">
          <LineChart
            data={largeData}
            xKey="index"
            yKeys={['value1', 'value2', 'value3']}
            config={{
              value1: { label: 'Series 1', color: 'hsl(var(--chart-1))' },
              value2: { label: 'Series 2', color: 'hsl(var(--chart-2))' },
              value3: { label: 'Series 3', color: 'hsl(var(--chart-3))' },
            }}
            dot={false}
            strokeWidth={1}
            aria-label="Performance test with large dataset"
          />
        </div>
      </div>
    );
  },
};