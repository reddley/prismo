import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Separator } from '@/components/ui/separator';
import { Palette } from 'lucide-react';

export interface ColorTheme {
  background: string;
  foreground: string;
  borders: string;
  elements: string[];
  labels: string;
}

export interface ColorPickerProps {
  theme: ColorTheme;
  onThemeChange: (theme: ColorTheme) => void;
  className?: string;
}

const defaultColors = [
  '#3b82f6', // blue
  '#ef4444', // red  
  '#10b981', // green
  '#f59e0b', // yellow
  '#8b5cf6', // purple
  '#f97316', // orange
  '#06b6d4', // cyan
  '#84cc16', // lime
  '#ec4899', // pink
  '#6b7280', // gray
];

const presetThemes: Record<string, ColorTheme> = {
  default: {
    background: 'hsl(var(--background))',
    foreground: 'hsl(var(--foreground))',
    borders: 'hsl(var(--border))',
    elements: [
      'hsl(var(--chart-1))',
      'hsl(var(--chart-2))',
      'hsl(var(--chart-3))',
      'hsl(var(--chart-4))',
      'hsl(var(--chart-5))',
    ],
    labels: 'hsl(var(--muted-foreground))',
  },
  vibrant: {
    background: '#ffffff',
    foreground: '#1a1a1a',
    borders: '#e5e5e5',
    elements: ['#ff6b6b', '#4ecdc4', '#45b7d1', '#f9ca24', '#6c5ce7'],
    labels: '#666666',
  },
  minimal: {
    background: '#fafafa',
    foreground: '#333333',
    borders: '#e0e0e0',
    elements: ['#2563eb', '#7c3aed', '#dc2626', '#059669', '#ea580c'],
    labels: '#737373',
  },
  dark: {
    background: '#1a1a1a',
    foreground: '#ffffff',
    borders: '#333333',
    elements: ['#60a5fa', '#a78bfa', '#fb7185', '#34d399', '#fbbf24'],
    labels: '#a3a3a3',
  },
};

export function ColorPicker({ theme, onThemeChange, className }: ColorPickerProps) {
  const [activeSection, setActiveSection] = useState<'elements' | 'background' | 'text'>('elements');

  const handlePresetSelect = (presetName: string) => {
    onThemeChange(presetThemes[presetName]);
  };

  const handleElementColorChange = (index: number, color: string) => {
    const newElements = [...theme.elements];
    newElements[index] = color;
    onThemeChange({ ...theme, elements: newElements });
  };

  const addElement = () => {
    const newElements = [...theme.elements, defaultColors[theme.elements.length % defaultColors.length]];
    onThemeChange({ ...theme, elements: newElements });
  };

  const removeElement = (index: number) => {
    if (theme.elements.length > 1) {
      const newElements = theme.elements.filter((_, i) => i !== index);
      onThemeChange({ ...theme, elements: newElements });
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className={`gap-2 ${className}`} data-testid="button-color-picker">
          <Palette className="h-4 w-4" />
          Customize Colors
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-3">Chart Color Theme</h4>
            
            {/* Preset Themes */}
            <div className="space-y-2">
              <Label className="text-sm">Presets</Label>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(presetThemes).map(([name, preset]) => (
                  <Button
                    key={name}
                    variant="outline"
                    size="sm"
                    onClick={() => handlePresetSelect(name)}
                    className="justify-start gap-2"
                    data-testid={`preset-${name}`}
                  >
                    <div className="flex gap-1">
                      {preset.elements.slice(0, 3).map((color, i) => (
                        <div
                          key={i}
                          className="w-3 h-3 rounded-full border"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                    <span className="capitalize">{name}</span>
                  </Button>
                ))}
              </div>
            </div>

            <Separator className="my-4" />

            {/* Section Tabs */}
            <div className="flex gap-1 mb-3">
              {[
                { key: 'elements', label: 'Data Colors' },
                { key: 'background', label: 'Background' },
                { key: 'text', label: 'Text & Borders' },
              ].map(({ key, label }) => (
                <Button
                  key={key}
                  variant={activeSection === key ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveSection(key as any)}
                  data-testid={`section-${key}`}
                >
                  {label}
                </Button>
              ))}
            </div>

            {/* Data Colors Section */}
            {activeSection === 'elements' && (
              <div className="space-y-3">
                <Label className="text-sm">Data Series Colors</Label>
                {theme.elements.map((color, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div
                      className="w-6 h-6 rounded border cursor-pointer"
                      style={{ backgroundColor: color }}
                      onClick={() => {
                        const input = document.createElement('input');
                        input.type = 'color';
                        input.value = color.startsWith('#') ? color : '#3b82f6';
                        input.onchange = (e) => handleElementColorChange(index, (e.target as HTMLInputElement).value);
                        input.click();
                      }}
                    />
                    <Input
                      value={color}
                      onChange={(e) => handleElementColorChange(index, e.target.value)}
                      className="flex-1 text-xs"
                      placeholder="#3b82f6"
                      data-testid={`color-input-${index}`}
                    />
                    {theme.elements.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeElement(index)}
                        className="h-6 w-6 p-0"
                        data-testid={`remove-color-${index}`}
                      >
                        ×
                      </Button>
                    )}
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={addElement}
                  className="w-full"
                  data-testid="add-color"
                >
                  Add Color
                </Button>
              </div>
            )}

            {/* Background Section */}
            {activeSection === 'background' && (
              <div className="space-y-3">
                <div>
                  <Label className="text-sm">Background</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <div
                      className="w-6 h-6 rounded border cursor-pointer"
                      style={{ backgroundColor: theme.background }}
                      onClick={() => {
                        const input = document.createElement('input');
                        input.type = 'color';
                        input.value = theme.background.startsWith('#') ? theme.background : '#ffffff';
                        input.onchange = (e) => onThemeChange({ ...theme, background: (e.target as HTMLInputElement).value });
                        input.click();
                      }}
                    />
                    <Input
                      value={theme.background}
                      onChange={(e) => onThemeChange({ ...theme, background: e.target.value })}
                      className="flex-1 text-xs"
                      data-testid="background-input"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Text & Borders Section */}
            {activeSection === 'text' && (
              <div className="space-y-3">
                <div>
                  <Label className="text-sm">Text Color</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <div
                      className="w-6 h-6 rounded border cursor-pointer"
                      style={{ backgroundColor: theme.foreground }}
                      onClick={() => {
                        const input = document.createElement('input');
                        input.type = 'color';
                        input.value = theme.foreground.startsWith('#') ? theme.foreground : '#000000';
                        input.onchange = (e) => onThemeChange({ ...theme, foreground: (e.target as HTMLInputElement).value });
                        input.click();
                      }}
                    />
                    <Input
                      value={theme.foreground}
                      onChange={(e) => onThemeChange({ ...theme, foreground: e.target.value })}
                      className="flex-1 text-xs"
                      data-testid="foreground-input"
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm">Border Color</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <div
                      className="w-6 h-6 rounded border cursor-pointer"
                      style={{ backgroundColor: theme.borders }}
                      onClick={() => {
                        const input = document.createElement('input');
                        input.type = 'color';
                        input.value = theme.borders.startsWith('#') ? theme.borders : '#e5e5e5';
                        input.onchange = (e) => onThemeChange({ ...theme, borders: (e.target as HTMLInputElement).value });
                        input.click();
                      }}
                    />
                    <Input
                      value={theme.borders}
                      onChange={(e) => onThemeChange({ ...theme, borders: e.target.value })}
                      className="flex-1 text-xs"
                      data-testid="borders-input"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-sm">Label Color</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <div
                      className="w-6 h-6 rounded border cursor-pointer"
                      style={{ backgroundColor: theme.labels }}
                      onClick={() => {
                        const input = document.createElement('input');
                        input.type = 'color';
                        input.value = theme.labels.startsWith('#') ? theme.labels : '#666666';
                        input.onchange = (e) => onThemeChange({ ...theme, labels: (e.target as HTMLInputElement).value });
                        input.click();
                      }}
                    />
                    <Input
                      value={theme.labels}
                      onChange={(e) => onThemeChange({ ...theme, labels: e.target.value })}
                      className="flex-1 text-xs"
                      data-testid="labels-input"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}