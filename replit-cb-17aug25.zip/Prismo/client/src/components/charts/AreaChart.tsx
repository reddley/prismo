import { AreaChart as RechartsAreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { ChartBase, ChartConfig } from './ChartBase';
import { ChartTooltip } from './ChartTooltip';
import { useTheme } from 'next-themes';

export interface AreaChartProps {
  data: any[];
  xKey: string;
  yKeys: string[];
  seriesKey?: string;
  valueFormatter?: (value: any) => string;
  tooltipFormatter?: (value: any, name: string) => [string, string];
  className?: string;
  config?: ChartConfig;
  showGrid?: boolean;
  showLegend?: boolean;
  showTooltip?: boolean;
  stackId?: string;
  fillOpacity?: number;
  strokeWidth?: number;
  curve?: 'linear' | 'monotone' | 'step';
  colors?: string[];
  'aria-label'?: string;
  'aria-describedby'?: string;
}

const defaultColors = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export function AreaChart({
  data,
  xKey,
  yKeys,
  valueFormatter,
  tooltipFormatter,
  className = "h-[200px]",
  config,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  stackId,
  fillOpacity = 0.6,
  strokeWidth = 2,
  curve = 'monotone',
  colors = defaultColors,
  'aria-label': ariaLabel,
  'aria-describedby': ariaDescribedBy,
  ...props
}: AreaChartProps) {
  const { theme } = useTheme();

  const getColor = (key: string, index: number) => {
    if (config?.[key]?.color) {
      return config[key].color;
    }
    if (config?.[key]?.theme) {
      return theme === 'dark' ? config[key].theme!.dark : config[key].theme!.light;
    }
    return colors[index % colors.length];
  };

  return (
    <ChartBase 
      data={data} 
      className={className}
      config={config}
      aria-label={ariaLabel || `Area chart showing ${yKeys.join(', ')} over ${xKey}`}
      aria-describedby={ariaDescribedBy}
    >
      <RechartsAreaChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <defs>
          {yKeys.map((key, index) => {
            const color = getColor(key, index);
            return (
              <linearGradient key={key} id={`gradient-${key}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={fillOpacity} />
                <stop offset="95%" stopColor={color} stopOpacity={fillOpacity * 0.1} />
              </linearGradient>
            );
          })}
        </defs>
        {showGrid && (
          <CartesianGrid 
            strokeDasharray="3 3" 
            className="stroke-muted"
            stroke="hsl(var(--muted-foreground))"
            opacity={0.2}
          />
        )}
        <XAxis 
          dataKey={xKey}
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12 }}
          className="fill-muted-foreground"
          stroke="hsl(var(--muted-foreground))"
        />
        <YAxis 
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12 }}
          className="fill-muted-foreground"
          stroke="hsl(var(--muted-foreground))"
          tickFormatter={valueFormatter}
        />
        {showTooltip && (
          <Tooltip 
            content={
              <ChartTooltip 
                valueFormatter={valueFormatter}
                labelFormatter={(label) => `${xKey}: ${label}`}
              />
            }
            cursor={{ strokeDasharray: '5 5', stroke: 'hsl(var(--muted-foreground))' }}
          />
        )}
        {showLegend && (
          <Legend 
            wrapperStyle={{ fontSize: '12px' }}
            iconType="rect"
          />
        )}
        {yKeys.map((key, index) => {
          const color = getColor(key, index);
          return (
            <Area
              key={key}
              type={curve}
              dataKey={key}
              stackId={stackId}
              stroke={color}
              fill={`url(#gradient-${key})`}
              strokeWidth={strokeWidth}
              name={config?.[key]?.label || key}
              connectNulls={false}
              aria-label={`${config?.[key]?.label || key} data series`}
            />
          );
        })}
      </RechartsAreaChart>
    </ChartBase>
  );
}