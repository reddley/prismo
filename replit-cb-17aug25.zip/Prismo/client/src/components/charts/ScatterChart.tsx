import { ScatterChart as RechartsScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ZAxis } from 'recharts';
import { ChartBase, ChartConfig } from './ChartBase';
import { ChartTooltip } from './ChartTooltip';
import { useTheme } from 'next-themes';

export interface ScatterChartProps {
  data: any[];
  xKey: string;
  yKey: string;
  zKey?: string; // For bubble chart
  seriesKey?: string;
  valueFormatter?: (value: any) => string;
  tooltipFormatter?: (value: any, name: string) => [string, string];
  className?: string;
  config?: ChartConfig;
  showGrid?: boolean;
  showLegend?: boolean;
  showTooltip?: boolean;
  shape?: 'circle' | 'square' | 'triangle' | 'diamond';
  minSize?: number;
  maxSize?: number;
  colors?: string[];
  'aria-label'?: string;
  'aria-describedby'?: string;
}

const defaultColors = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export function ScatterChart({
  data,
  xKey,
  yKey,
  zKey,
  seriesKey,
  valueFormatter,
  tooltipFormatter,
  className = "h-[200px]",
  config,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  shape = 'circle',
  minSize = 64,
  maxSize = 144,
  colors = defaultColors,
  'aria-label': ariaLabel,
  'aria-describedby': ariaDescribedBy,
  ...props
}: ScatterChartProps) {
  const { theme } = useTheme();

  // Group data by series if seriesKey is provided
  const groupedData = seriesKey ? 
    data.reduce((acc, item) => {
      const series = item[seriesKey];
      if (!acc[series]) acc[series] = [];
      acc[series].push(item);
      return acc;
    }, {} as Record<string, any[]>) : 
    { default: data };

  const getColor = (key: string, index: number) => {
    if (config?.[key]?.color) {
      return config[key].color;
    }
    if (config?.[key]?.theme) {
      return theme === 'dark' ? config[key].theme!.dark : config[key].theme!.light;
    }
    return colors[index % colors.length];
  };

  return (
    <ChartBase 
      data={data} 
      className={className}
      config={config}
      aria-label={ariaLabel || `Scatter chart showing ${yKey} vs ${xKey}${zKey ? ` with ${zKey} as size` : ''}`}
      aria-describedby={ariaDescribedBy}
    >
      <RechartsScatterChart margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
        {showGrid && (
          <CartesianGrid 
            strokeDasharray="3 3" 
            className="stroke-muted"
            stroke="hsl(var(--muted-foreground))"
            opacity={0.2}
          />
        )}
        <XAxis 
          type="number"
          dataKey={xKey}
          name={xKey}
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12 }}
          className="fill-muted-foreground"
          stroke="hsl(var(--muted-foreground))"
          tickFormatter={valueFormatter}
        />
        <YAxis 
          type="number"
          dataKey={yKey}
          name={yKey}
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12 }}
          className="fill-muted-foreground"
          stroke="hsl(var(--muted-foreground))"
          tickFormatter={valueFormatter}
        />
        {zKey && (
          <ZAxis 
            type="number"
            dataKey={zKey}
            range={[minSize, maxSize]}
            name={zKey}
          />
        )}
        {showTooltip && (
          <Tooltip 
            content={
              <ChartTooltip 
                valueFormatter={valueFormatter}
                labelFormatter={(label) => label}
              />
            }
            cursor={{ strokeDasharray: '5 5', stroke: 'hsl(var(--muted-foreground))' }}
          />
        )}
        {showLegend && seriesKey && (
          <Legend 
            wrapperStyle={{ fontSize: '12px' }}
            iconType="circle"
          />
        )}
        {Object.entries(groupedData).map(([seriesName, seriesData], index) => (
          <Scatter
            key={seriesName}
            name={seriesName === 'default' ? undefined : (config?.[seriesName]?.label || seriesName)}
            data={seriesData}
            fill={getColor(seriesName, index)}
            shape={shape}
            aria-label={`${seriesName === 'default' ? 'Data' : seriesName} scatter series`}
          />
        ))}
      </RechartsScatterChart>
    </ChartBase>
  );
}

// Bubble chart is a scatter chart with Z-axis (size)
export interface BubbleChartProps extends ScatterChartProps {
  zKey: string; // Required for bubble chart
}

export function BubbleChart(props: BubbleChartProps) {
  return <ScatterChart {...props} />;
}