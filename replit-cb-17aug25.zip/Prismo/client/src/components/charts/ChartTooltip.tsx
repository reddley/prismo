import { TooltipProps } from 'recharts';
import { Card, CardContent } from '@/components/ui/card';

interface ChartTooltipProps extends Partial<TooltipProps<any, any>> {
  valueFormatter?: (value: any) => string;
  labelFormatter?: (label: any) => string;
  hideLabel?: boolean;
  hideIndicator?: boolean;
}

export function ChartTooltip({
  active,
  payload,
  label,
  valueFormatter,
  labelFormatter,
  hideLabel = false,
  hideIndicator = false,
  ...props
}: ChartTooltipProps) {
  if (!active || !payload?.length) {
    return null;
  }

  return (
    <Card className="border shadow-lg">
      <CardContent className="p-3 space-y-1">
        {!hideLabel && label && (
          <div className="text-sm font-medium text-foreground">
            {labelFormatter ? labelFormatter(label) : label}
          </div>
        )}
        <div className="space-y-1">
          {payload.map((entry, index) => (
            <div key={index} className="flex items-center gap-2 text-sm">
              {!hideIndicator && (
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: entry.color }}
                />
              )}
              <span className="text-muted-foreground">{entry.name}:</span>
              <span className="font-medium text-foreground">
                {valueFormatter ? valueFormatter(entry.value) : entry.value}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export function CustomTooltip(props: ChartTooltipProps) {
  return <ChartTooltip {...props} />;
}