import { ReactNode } from 'react';
import { ResponsiveContainer } from 'recharts';
import { cn } from '@/lib/utils';

export interface ChartConfig {
  [key: string]: {
    label: string;
    color?: string;
    theme?: {
      light: string;
      dark: string;
    };
  };
}

export interface BaseChartProps {
  data: any[];
  className?: string;
  config?: ChartConfig;
  children: ReactNode;
  'aria-label'?: string;
  'aria-describedby'?: string;
}

export function ChartBase({ 
  data, 
  className, 
  children, 
  'aria-label': ariaLabel,
  'aria-describedby': ariaDescribedBy,
  ...props 
}: BaseChartProps) {
  if (!data || data.length === 0) {
    return (
      <div 
        className={cn("flex items-center justify-center h-[200px] text-muted-foreground", className)}
        role="img"
        aria-label={ariaLabel || "Chart with no data"}
      >
        No data available
      </div>
    );
  }

  return (
    <div 
      className={cn("w-full", className)}
      role="img"
      aria-label={ariaLabel}
      aria-describedby={ariaDescribedBy}
    >
      <ResponsiveContainer width="100%" height="100%">
        {children}
      </ResponsiveContainer>
    </div>
  );
}