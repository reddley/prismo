import { useMemo } from 'react';
import { ChartBase, ChartConfig } from './ChartBase';
import { ChartTooltip } from './ChartTooltip';
import { useTheme } from 'next-themes';

export interface HeatmapChartProps {
  data: any[];
  xKey: string;
  yKey: string;
  valueKey: string;
  valueFormatter?: (value: any) => string;
  tooltipFormatter?: (value: any, name: string) => [string, string];
  className?: string;
  config?: ChartConfig;
  showTooltip?: boolean;
  colorScale?: [string, string]; // [min color, max color]
  cellSize?: number;
  cellGap?: number;
  showLabels?: boolean;
  'aria-label'?: string;
  'aria-describedby'?: string;
}

export function HeatmapChart({
  data,
  xKey,
  yKey,
  valueKey,
  valueFormatter,
  tooltipFormatter,
  className = "h-[300px]",
  config,
  showTooltip = true,
  colorScale = ['hsl(var(--muted))', 'hsl(var(--primary))'],
  cellSize = 20,
  cellGap = 2,
  showLabels = false,
  'aria-label': ariaLabel,
  'aria-describedby': ariaDescribedBy,
  ...props
}: HeatmapChartProps) {
  const { theme } = useTheme();

  // Process data into heatmap matrix
  const { matrix, xLabels, yLabels, minValue, maxValue } = useMemo(() => {
    const xSet = new Set(data.map(d => d[xKey]));
    const ySet = new Set(data.map(d => d[yKey]));
    const xLabels = Array.from(xSet).sort();
    const yLabels = Array.from(ySet).sort();
    
    const matrix: { x: string; y: string; value: number; originalData: any }[][] = [];
    const values = data.map(d => d[valueKey]).filter(v => typeof v === 'number');
    const minValue = Math.min(...values);
    const maxValue = Math.max(...values);
    
    yLabels.forEach(yLabel => {
      const row: { x: string; y: string; value: number; originalData: any }[] = [];
      xLabels.forEach(xLabel => {
        const dataPoint = data.find(d => d[xKey] === xLabel && d[yKey] === yLabel);
        row.push({
          x: xLabel,
          y: yLabel,
          value: dataPoint ? dataPoint[valueKey] : 0,
          originalData: dataPoint
        });
      });
      matrix.push(row);
    });
    
    return { matrix, xLabels, yLabels, minValue, maxValue };
  }, [data, xKey, yKey, valueKey]);

  // Calculate color intensity based on value
  const getColor = (value: number) => {
    if (maxValue === minValue) return colorScale[0];
    const intensity = (value - minValue) / (maxValue - minValue);
    
    // Simple linear interpolation between two colors
    const [minColor, maxColor] = colorScale;
    if (intensity === 0) return minColor;
    if (intensity === 1) return maxColor;
    
    // For HSL interpolation, we'll use CSS custom properties
    return `color-mix(in hsl, ${maxColor} ${intensity * 100}%, ${minColor})`;
  };

  const handleCellClick = (cell: any) => {
    // Could add click handlers for interactivity
  };

  const svgWidth = xLabels.length * (cellSize + cellGap) + 60;
  const svgHeight = yLabels.length * (cellSize + cellGap) + 60;

  if (!data || data.length === 0) {
    return (
      <div 
        className="flex items-center justify-center h-[200px] text-muted-foreground"
        role="img"
        aria-label={ariaLabel || "Heatmap with no data"}
      >
        No data available
      </div>
    );
  }

  return (
    <div 
      className={`w-full ${className}`}
      role="img"
      aria-label={ariaLabel || `Heatmap showing ${valueKey} by ${xKey} and ${yKey}`}
      aria-describedby={ariaDescribedBy}
    >
      <div className="relative overflow-auto">
        <svg 
          width={svgWidth} 
          height={svgHeight}
          className="min-w-full"
        >
          {/* X-axis labels */}
          {xLabels.map((label, i) => (
            <text
              key={`x-${label}`}
              x={50 + i * (cellSize + cellGap) + cellSize / 2}
              y={40}
              textAnchor="middle"
              className="fill-muted-foreground text-xs"
              transform={`rotate(-45, ${50 + i * (cellSize + cellGap) + cellSize / 2}, 40)`}
            >
              {label}
            </text>
          ))}
          
          {/* Y-axis labels */}
          {yLabels.map((label, i) => (
            <text
              key={`y-${label}`}
              x={40}
              y={50 + i * (cellSize + cellGap) + cellSize / 2 + 4}
              textAnchor="end"
              className="fill-muted-foreground text-xs"
            >
              {label}
            </text>
          ))}
          
          {/* Heatmap cells */}
          {matrix.map((row, rowIndex) =>
            row.map((cell, colIndex) => (
              <g key={`${cell.x}-${cell.y}`}>
                <rect
                  x={50 + colIndex * (cellSize + cellGap)}
                  y={50 + rowIndex * (cellSize + cellGap)}
                  width={cellSize}
                  height={cellSize}
                  fill={getColor(cell.value)}
                  stroke="hsl(var(--background))"
                  strokeWidth={1}
                  className="cursor-pointer transition-opacity hover:opacity-80"
                  onClick={() => handleCellClick(cell)}
                  aria-label={`${cell.x}, ${cell.y}: ${valueFormatter ? valueFormatter(cell.value) : cell.value}`}
                  role="button"
                  tabIndex={0}
                />
                {showLabels && (
                  <text
                    x={50 + colIndex * (cellSize + cellGap) + cellSize / 2}
                    y={50 + rowIndex * (cellSize + cellGap) + cellSize / 2 + 3}
                    textAnchor="middle"
                    className="fill-foreground text-xs pointer-events-none"
                    fontSize={cellSize > 30 ? '10' : '8'}
                  >
                    {valueFormatter ? valueFormatter(cell.value) : cell.value}
                  </text>
                )}
              </g>
            ))
          )}
        </svg>
        
        {/* Legend */}
        <div className="mt-4 flex items-center justify-center gap-2">
          <span className="text-xs text-muted-foreground">
            {valueFormatter ? valueFormatter(minValue) : minValue}
          </span>
          <div className="flex h-4 w-32 rounded">
            <div 
              className="h-full w-full rounded"
              style={{
                background: `linear-gradient(to right, ${colorScale[0]}, ${colorScale[1]})`
              }}
            />
          </div>
          <span className="text-xs text-muted-foreground">
            {valueFormatter ? valueFormatter(maxValue) : maxValue}
          </span>
        </div>
      </div>
    </div>
  );
}