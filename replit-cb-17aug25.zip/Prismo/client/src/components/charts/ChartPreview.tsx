import { useState, useEffect, useRef } from 'react';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  AreaChart, 
  Area, 
  ScatterChart, 
  Scatter,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, ChartLine, BarChart3, PieChart as PieIcon, TrendingUp, Zap } from 'lucide-react';

interface ChartPreviewProps {
  slug: string;
  isVisible: boolean;
  onClose: () => void;
  position?: { x: number; y: number };
}

interface ChartData {
  chartType: string;
  data: any[];
  config?: any;
  animations?: any;
  accessibility?: any;
}

const CHART_COLORS = [
  '#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1', 
  '#d084d0', '#ffb347', '#87ceeb', '#dda0dd', '#98fb98'
];

const ChartTypeIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'line': return <ChartLine className="h-4 w-4" />;
    case 'bar': return <BarChart3 className="h-4 w-4" />;
    case 'pie': return <PieIcon className="h-4 w-4" />;
    case 'area': return <TrendingUp className="h-4 w-4" />;
    case 'scatter': return <Zap className="h-4 w-4" />;
    default: return <ChartLine className="h-4 w-4" />;
  }
};

export function ChartPreview({ slug, isVisible, onClose, position }: ChartPreviewProps) {
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedChartType, setSelectedChartType] = useState<string>('line');
  const containerRef = useRef<HTMLDivElement>(null);

  // Fetch preview data on mount
  useEffect(() => {
    if (!isVisible || !slug) return;

    const fetchPreview = async () => {
      setLoading(true);
      setError(null);
      
      try {
        // Try to fetch cached preview first
        const response = await fetch(`/api/report-templates/${slug}/preview`);
        
        if (response.ok) {
          const previewData = await response.json();
          
          if (previewData.sampleData && previewData.sampleData.length > 0) {
            setChartData({
              chartType: previewData.defaultChartType || 'line',
              data: previewData.sampleData.slice(0, 25),
              config: previewData.visualizationConfig,
              animations: previewData.animationConfig,
              accessibility: previewData.accessibilityConfig
            });
            setSelectedChartType(previewData.defaultChartType || 'line');
          } else {
            // Fallback to sample render
            await fetchSampleRender(previewData.defaultChartType || 'line');
          }
        } else {
          throw new Error('Failed to fetch preview');
        }
      } catch (err) {
        // Fallback to sample render
        await fetchSampleRender('line');
      } finally {
        setLoading(false);
      }
    };

    const fetchSampleRender = async (chartType: string) => {
      try {
        const response = await fetch(`/api/report-templates/${slug}/render-sample`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ chartType })
        });
        
        if (response.ok) {
          const sampleData = await response.json();
          setChartData(sampleData);
          setSelectedChartType(chartType);
        } else {
          throw new Error('Failed to render sample data');
        }
      } catch (err) {
        setError('Failed to load chart preview');
        console.error('Preview error:', err);
      }
    };

    fetchPreview();
  }, [isVisible, slug]);

  // Handle chart type change
  const handleChartTypeChange = async (newType: string) => {
    if (!slug || newType === selectedChartType) return;
    
    setSelectedChartType(newType);
    setLoading(true);
    
    try {
      const response = await fetch(`/api/report-templates/${slug}/render-sample`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chartType: newType })
      });
      
      if (response.ok) {
        const sampleData = await response.json();
        setChartData(sampleData);
      }
    } catch (err) {
      console.error('Failed to change chart type:', err);
    } finally {
      setLoading(false);
    }
  };

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isVisible) {
        onClose();
      }
    };

    if (isVisible) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [isVisible, onClose]);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    if (isVisible) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isVisible, onClose]);

  if (!isVisible) return null;

  const renderChart = () => {
    if (!chartData?.data) return null;

    const commonProps = {
      width: 320,
      height: 200,
      data: chartData.data,
      margin: { top: 5, right: 30, left: 20, bottom: 5 }
    };

    switch (selectedChartType) {
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <LineChart {...commonProps}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke={CHART_COLORS[0]} 
                strokeWidth={2}
                dot={{ fill: CHART_COLORS[0], strokeWidth: 2 }}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        );
        
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart {...commonProps}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill={CHART_COLORS[0]} />
              {chartData.data[0]?.target && (
                <Bar dataKey="target" fill={CHART_COLORS[1]} />
              )}
            </BarChart>
          </ResponsiveContainer>
        );
        
      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={chartData.data}
                cx="50%"
                cy="50%"
                outerRadius={60}
                fill="#8884d8"
                dataKey="value"
                label
              >
                {chartData.data.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        );
        
      case 'area':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart {...commonProps}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Area 
                type="monotone" 
                dataKey="value" 
                stroke={CHART_COLORS[0]} 
                fill={CHART_COLORS[0]} 
                fillOpacity={0.3}
              />
            </AreaChart>
          </ResponsiveContainer>
        );
        
      case 'scatter':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <ScatterChart {...commonProps}>
              <CartesianGrid />
              <XAxis dataKey="x" />
              <YAxis dataKey="y" />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter dataKey="z" fill={CHART_COLORS[0]} />
            </ScatterChart>
          </ResponsiveContainer>
        );
        
      default:
        return <div className="text-center py-8 text-muted-foreground">Unsupported chart type</div>;
    }
  };

  const positionStyle = position ? {
    position: 'fixed' as const,
    top: Math.max(10, Math.min(position.y - 150, window.innerHeight - 350)),
    left: Math.max(10, Math.min(position.x + 20, window.innerWidth - 380)),
    zIndex: 1000
  } : {
    position: 'fixed' as const,
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    zIndex: 1000
  };

  return (
    <Card 
      ref={containerRef}
      className="w-[360px] shadow-lg border bg-background/95 backdrop-blur-sm"
      style={positionStyle}
      data-testid={`preview-chart-${slug}`}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <ChartTypeIcon type={selectedChartType} />
            <h3 className="font-medium text-sm">Chart Preview</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-6 w-6 p-0"
            data-testid="button-close-preview"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Chart Type Selector */}
        <div className="flex gap-1 mb-3">
          {['line', 'bar', 'pie', 'area', 'scatter'].map((type) => (
            <Button
              key={type}
              variant={selectedChartType === type ? "default" : "outline"}
              size="sm"
              className="h-7 px-2"
              onClick={() => handleChartTypeChange(type)}
              disabled={loading}
              data-testid={`button-chart-type-${type}`}
            >
              <ChartTypeIcon type={type} />
            </Button>
          ))}
        </div>
        
        {loading ? (
          <div className="h-[200px] flex items-center justify-center">
            <div className="text-sm text-muted-foreground">Loading chart...</div>
          </div>
        ) : error ? (
          <div className="h-[200px] flex items-center justify-center">
            <div className="text-sm text-red-600">{error}</div>
          </div>
        ) : (
          <div className="chart-container">
            {renderChart()}
          </div>
        )}
        
        {chartData?.accessibility?.description && (
          <div className="mt-2 text-xs text-muted-foreground border-t pt-2">
            {chartData.accessibility.description}
          </div>
        )}
      </CardContent>
    </Card>
  );
}