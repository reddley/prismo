import { useMemo } from 'react';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  AreaChart, 
  Area,
  XAxis, 
  YAxis, 
  ResponsiveContainer 
} from 'recharts';

interface StaticChartPreviewProps {
  category: string;
  name: string;
  tags?: string[];
  className?: string;
}

// Rules-based chart type determination
function determineChartType(category: string, name: string, tags: string[] = []): string {
  const nameUpper = name.toUpperCase();
  const categoryUpper = category.toUpperCase();
  const allTags = tags.join(' ').toUpperCase();
  
  // Financial and revenue data - prefer bar charts
  if (categoryUpper.includes('FINANCE') || 
      nameUpper.includes('FINANCIAL') || 
      nameUpper.includes('REVENUE') || 
      nameUpper.includes('PROFIT') || 
      nameUpper.includes('BUDGET') ||
      allTags.includes('FINANCE') ||
      allTags.includes('REVENUE')) {
    return 'bar';
  }
  
  // Market share, composition, breakdown - prefer pie charts
  if (nameUpper.includes('SHARE') || 
      nameUpper.includes('BREAKDOWN') || 
      nameUpper.includes('COMPOSITION') || 
      nameUpper.includes('DISTRIBUTION') ||
      nameUpper.includes('PORTFOLIO') ||
      allTags.includes('SHARE') ||
      allTags.includes('PORTFOLIO')) {
    return 'pie';
  }
  
  // Trends, growth, time series - prefer area charts
  if (nameUpper.includes('TREND') || 
      nameUpper.includes('GROWTH') || 
      nameUpper.includes('OVER TIME') || 
      nameUpper.includes('TIMELINE') ||
      nameUpper.includes('HISTORICAL') ||
      allTags.includes('GROWTH') ||
      allTags.includes('TREND')) {
    return 'area';
  }
  
  // Analytics and Intelligence - prefer line charts
  if (categoryUpper.includes('ANALYTICS') || 
      categoryUpper.includes('INTELLIGENCE') ||
      nameUpper.includes('ANALYSIS') ||
      nameUpper.includes('INSIGHTS') ||
      allTags.includes('ANALYTICS') ||
      allTags.includes('INTELLIGENCE')) {
    return 'line';
  }
  
  // Default to line chart for clean appearance
  return 'line';
}

// Generate sample data based on chart type and context
function generateSampleData(chartType: string, category: string): any[] {
  switch (chartType) {
    case 'bar':
      return [
        { name: 'Q1', value: 85000, target: 80000 },
        { name: 'Q2', value: 92000, target: 85000 },
        { name: 'Q3', value: 78000, target: 90000 },
        { name: 'Q4', value: 105000, target: 95000 }
      ];
    case 'pie':
      return [
        { name: 'Product A', value: 45, color: '#8884d8' },
        { name: 'Product B', value: 30, color: '#82ca9d' },
        { name: 'Product C', value: 15, color: '#ffc658' },
        { name: 'Other', value: 10, color: '#ff7c7c' }
      ];
    case 'area':
      return [
        { month: 'Jan', growth: 12, market: 8 },
        { month: 'Feb', growth: 15, market: 10 },
        { month: 'Mar', growth: 18, market: 12 },
        { month: 'Apr', growth: 22, market: 15 },
        { month: 'May', growth: 25, market: 18 },
        { month: 'Jun', growth: 28, market: 20 }
      ];
    case 'line':
    default:
      return [
        { date: 'Week 1', insights: 24, alerts: 8 },
        { date: 'Week 2', insights: 35, alerts: 12 },
        { date: 'Week 3', insights: 28, alerts: 6 },
        { date: 'Week 4', insights: 42, alerts: 15 },
        { date: 'Week 5', insights: 38, alerts: 9 }
      ];
  }
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1'];

export function StaticChartPreview({ category, name, tags = [], className = '' }: StaticChartPreviewProps) {
  const { chartType, data } = useMemo(() => {
    const type = determineChartType(category, name, tags);
    const sampleData = generateSampleData(type, category);
    return { chartType: type, data: sampleData };
  }, [category, name, tags]);

  const renderChart = () => {
    switch (chartType) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <Bar dataKey="value" fill="#8884d8" radius={2} />
              <Bar dataKey="target" fill="#82ca9d" radius={2} opacity={0.6} />
            </BarChart>
          </ResponsiveContainer>
        );
      
      case 'pie':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <Pie
                data={data}
                dataKey="value"
                cx="50%"
                cy="50%"
                outerRadius={30}
                innerRadius={15}
              >
                {data.map((entry: any, index: number) => (
                  <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        );
      
      case 'area':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <defs>
                <linearGradient id="colorGrowth" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#8884d8" stopOpacity={0.1} />
                </linearGradient>
              </defs>
              <Area 
                type="monotone" 
                dataKey="growth" 
                stroke="#8884d8" 
                fillOpacity={1} 
                fill="url(#colorGrowth)" 
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        );
      
      case 'line':
      default:
        return (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <Line 
                type="monotone" 
                dataKey="insights" 
                stroke="#8884d8" 
                strokeWidth={2} 
                dot={false}
                activeDot={{ r: 3 }}
              />
              <Line 
                type="monotone" 
                dataKey="alerts" 
                stroke="#82ca9d" 
                strokeWidth={2} 
                dot={false}
                activeDot={{ r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        );
    }
  };

  return (
    <div className={`w-16 h-12 bg-muted/30 rounded border ${className}`}>
      {renderChart()}
    </div>
  );
}