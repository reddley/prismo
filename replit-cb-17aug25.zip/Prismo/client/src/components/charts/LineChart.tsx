import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ChartBase, ChartConfig } from './ChartBase';
import { ChartTooltip } from './ChartTooltip';
import { useTheme } from 'next-themes';

export interface LineChartProps {
  data: any[];
  xKey: string;
  yKeys: string[];
  seriesKey?: string;
  valueFormatter?: (value: any) => string;
  tooltipFormatter?: (value: any, name: string) => [string, string];
  className?: string;
  config?: ChartConfig;
  showGrid?: boolean;
  showLegend?: boolean;
  showTooltip?: boolean;
  strokeWidth?: number;
  dot?: boolean;
  curve?: 'linear' | 'monotone' | 'step';
  colors?: string[];
  'aria-label'?: string;
  'aria-describedby'?: string;
}

const defaultColors = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export function LineChart({
  data,
  xKey,
  yKeys,
  valueFormatter,
  tooltipFormatter,
  className = "h-[200px]",
  config,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  strokeWidth = 2,
  dot = false,
  curve = 'monotone',
  colors = defaultColors,
  'aria-label': ariaLabel,
  'aria-describedby': ariaDescribedBy,
  ...props
}: LineChartProps) {
  const { theme } = useTheme();

  const getColor = (key: string, index: number) => {
    if (config?.[key]?.color) {
      return config[key].color;
    }
    if (config?.[key]?.theme) {
      return theme === 'dark' ? config[key].theme!.dark : config[key].theme!.light;
    }
    return colors[index % colors.length];
  };

  return (
    <ChartBase 
      data={data} 
      className={className}
      config={config}
      aria-label={ariaLabel || `Line chart showing ${yKeys.join(', ')} over ${xKey}`}
      aria-describedby={ariaDescribedBy}
    >
      <RechartsLineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        {showGrid && (
          <CartesianGrid 
            strokeDasharray="3 3" 
            className="stroke-muted"
            stroke="hsl(var(--muted-foreground))"
            opacity={0.2}
          />
        )}
        <XAxis 
          dataKey={xKey}
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12 }}
          className="fill-muted-foreground"
          stroke="hsl(var(--muted-foreground))"
        />
        <YAxis 
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12 }}
          className="fill-muted-foreground"
          stroke="hsl(var(--muted-foreground))"
          tickFormatter={valueFormatter}
        />
        {showTooltip && (
          <Tooltip 
            content={
              <ChartTooltip 
                valueFormatter={valueFormatter}
                labelFormatter={(label) => `${xKey}: ${label}`}
              />
            }
            cursor={{ strokeDasharray: '5 5', stroke: 'hsl(var(--muted-foreground))' }}
          />
        )}
        {showLegend && (
          <Legend 
            wrapperStyle={{ fontSize: '12px' }}
            iconType="line"
          />
        )}
        {yKeys.map((key, index) => (
          <Line
            key={key}
            type={curve}
            dataKey={key}
            stroke={getColor(key, index)}
            strokeWidth={strokeWidth}
            dot={dot}
            name={config?.[key]?.label || key}
            connectNulls={false}
            aria-label={`${config?.[key]?.label || key} data series`}
          />
        ))}
      </RechartsLineChart>
    </ChartBase>
  );
}