import { PieChart as RechartsPieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ChartBase, ChartConfig } from './ChartBase';
import { ChartTooltip } from './ChartTooltip';
import { useTheme } from 'next-themes';

export interface PieChartProps {
  data: any[];
  dataKey: string;
  nameKey: string;
  valueFormatter?: (value: any) => string;
  tooltipFormatter?: (value: any, name: string) => [string, string];
  className?: string;
  config?: ChartConfig;
  showLegend?: boolean;
  showTooltip?: boolean;
  showLabels?: boolean;
  innerRadius?: number;
  outerRadius?: number;
  paddingAngle?: number;
  startAngle?: number;
  endAngle?: number;
  colors?: string[];
  labelFormatter?: (entry: any) => string;
  'aria-label'?: string;
  'aria-describedby'?: string;
}

const defaultColors = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export function PieChart({
  data,
  dataKey,
  nameKey,
  valueFormatter,
  tooltipFormatter,
  className = "h-[200px]",
  config,
  showLegend = true,
  showTooltip = true,
  showLabels = false,
  innerRadius = 0,
  outerRadius = 80,
  paddingAngle = 0,
  startAngle = 90,
  endAngle = 450,
  colors = defaultColors,
  labelFormatter,
  'aria-label': ariaLabel,
  'aria-describedby': ariaDescribedBy,
  ...props
}: PieChartProps) {
  const { theme } = useTheme();

  const getColor = (entry: any, index: number) => {
    const key = entry[nameKey];
    if (config?.[key]?.color) {
      return config[key].color;
    }
    if (config?.[key]?.theme) {
      return theme === 'dark' ? config[key].theme!.dark : config[key].theme!.light;
    }
    return colors[index % colors.length];
  };

  const renderCustomLabel = (entry: any) => {
    if (!showLabels) return null;
    if (labelFormatter) return labelFormatter(entry);
    
    const percent = ((entry.value / data.reduce((sum, item) => sum + item[dataKey], 0)) * 100).toFixed(1);
    return `${entry[nameKey]}: ${percent}%`;
  };

  return (
    <ChartBase 
      data={data} 
      className={className}
      config={config}
      aria-label={ariaLabel || `Pie chart showing distribution of ${nameKey}`}
      aria-describedby={ariaDescribedBy}
    >
      <RechartsPieChart margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={showLabels ? renderCustomLabel : false}
          outerRadius={outerRadius}
          innerRadius={innerRadius}
          fill="#8884d8"
          dataKey={dataKey}
          paddingAngle={paddingAngle}
          startAngle={startAngle}
          endAngle={endAngle}
          stroke="hsl(var(--background))"
          strokeWidth={2}
        >
          {data.map((entry, index) => (
            <Cell 
              key={`cell-${index}`} 
              fill={getColor(entry, index)}
              aria-label={`${entry[nameKey]}: ${valueFormatter ? valueFormatter(entry[dataKey]) : entry[dataKey]}`}
            />
          ))}
        </Pie>
        {showTooltip && (
          <Tooltip 
            content={
              <ChartTooltip 
                valueFormatter={valueFormatter}
                labelFormatter={(label) => label}
                hideIndicator={false}
              />
            }
          />
        )}
        {showLegend && (
          <Legend 
            wrapperStyle={{ fontSize: '12px' }}
            iconType="circle"
            formatter={(value, entry) => config?.[value]?.label || value}
          />
        )}
      </RechartsPieChart>
    </ChartBase>
  );
}

// Donut chart is just a pie chart with inner radius
export interface DonutChartProps extends Omit<PieChartProps, 'innerRadius'> {
  innerRadius?: number;
}

export function DonutChart({
  innerRadius = 60,
  ...props
}: DonutChartProps) {
  return <PieChart {...props} innerRadius={innerRadius} />;
}