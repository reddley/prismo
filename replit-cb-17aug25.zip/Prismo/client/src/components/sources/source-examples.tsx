import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, ExternalLink, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SourceExample {
  name: string;
  category: string;
  url: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Advanced';
  requiresAuth: boolean;
  setup?: string[];
}

const sourceExamples: SourceExample[] = [
  // RSS Examples
  {
    name: "TechCrunch Startups",
    category: "technology",
    url: "https://techcrunch.com/category/startups/feed/",
    description: "Latest startup news and funding rounds",
    difficulty: 'Easy',
    requiresAuth: false,
    setup: ["Just paste the URL - no authentication needed!"]
  },
  {
    name: "Ars Technica Technology",
    category: "technology", 
    url: "http://feeds.arstechnica.com/arstechnica/technology",
    description: "In-depth technology analysis and breaking news",
    difficulty: 'Easy',
    requiresAuth: false,
  },
  {
    name: "MIT Technology Review",
    category: "technology",
    url: "https://www.technologyreview.com/feed/",
    description: "Cutting-edge tech research and innovation",
    difficulty: 'Easy',
    requiresAuth: false,
  },
  
  // Financial RSS
  {
    name: "MarketWatch Breaking",
    category: "finance",
    url: "https://feeds.marketwatch.com/marketwatch/topstories/",
    description: "Real-time market news and financial updates",
    difficulty: 'Easy',
    requiresAuth: false,
  },
  {
    name: "Financial Times Tech",
    category: "finance",
    url: "https://www.ft.com/technology?format=rss",
    description: "Enterprise and financial technology news",
    difficulty: 'Easy',
    requiresAuth: false,
  },
  
  // API Examples
  {
    name: "NewsAPI Headlines",
    category: "general",
    url: "https://newsapi.org/v2/top-headlines?sources=techcrunch,the-verge&apiKey=YOUR_API_KEY",
    description: "Aggregated news from multiple tech sources",
    difficulty: 'Medium',
    requiresAuth: true,
    setup: [
      "1. Sign up at newsapi.org (free tier: 100 requests/day)",
      "2. Get your API key from the dashboard",
      "3. Replace YOUR_API_KEY in the URL above"
    ]
  },
  {
    name: "Guardian Technology",
    category: "technology",
    url: "https://content.guardianapis.com/technology?api-key=YOUR_API_KEY&format=json",
    description: "Technology news from The Guardian",
    difficulty: 'Medium',
    requiresAuth: true,
    setup: [
      "1. Register at open-platform.theguardian.com",
      "2. Generate your free API key",
      "3. Replace YOUR_API_KEY in the URL"
    ]
  },
  
  // Social Media Examples  
  {
    name: "Reddit r/technology",
    category: "social",
    url: "https://www.reddit.com/r/technology.json",
    description: "Top technology discussions from Reddit",
    difficulty: 'Easy',
    requiresAuth: false,
    setup: ["Reddit's JSON feeds are public - just add .json to any subreddit URL"]
  },
  
  // Advanced Examples
  {
    name: "Crunchbase Companies",
    category: "business", 
    url: "https://api.crunchbase.com/api/v4/entities/organizations?user_key=YOUR_API_KEY",
    description: "Company funding rounds and startup data",
    difficulty: 'Advanced',
    requiresAuth: true,
    setup: [
      "1. Sign up for Crunchbase Pro (paid subscription required)",
      "2. Get API access from your account settings",
      "3. Configure authentication headers"
    ]
  }
];

interface SourceExamplesProps {
  onUseExample: (example: SourceExample) => void;
}

export function SourceExamples({ onUseExample }: SourceExamplesProps) {
  const { toast } = useToast();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "URL copied to clipboard",
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'Advanced': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const groupedExamples = sourceExamples.reduce((acc, example) => {
    if (!acc[example.category]) {
      acc[example.category] = [];
    }
    acc[example.category].push(example);
    return acc;
  }, {} as Record<string, SourceExample[]>);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Ready-to-Use Examples</h3>
        <p className="text-muted-foreground">
          Copy these proven configurations to get started quickly
        </p>
      </div>

      {Object.entries(groupedExamples).map(([category, examples]) => (
        <div key={category}>
          <h4 className="font-medium mb-3 capitalize text-sm text-muted-foreground uppercase tracking-wide">
            {category} Sources
          </h4>
          <div className="grid gap-3">
            {examples.map((example, idx) => (
              <Card key={idx} className="hover:shadow-sm transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-sm truncate">{example.name}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-1">
                        {example.description}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1 flex-shrink-0 ml-2">
                      <Badge className={getDifficultyColor(example.difficulty)} variant="secondary">
                        {example.difficulty}
                      </Badge>
                      {example.requiresAuth && (
                        <Badge variant="outline" className="text-xs">
                          Auth
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div className="bg-muted/50 p-2 rounded font-mono text-xs break-all">
                      {example.url}
                    </div>
                    
                    {example.setup && (
                      <div className="text-xs space-y-1">
                        <p className="font-medium text-sm">Setup Instructions:</p>
                        <ul className="space-y-1 text-muted-foreground">
                          {example.setup.map((step, stepIdx) => (
                            <li key={stepIdx} className="flex items-start space-x-2">
                              <CheckCircle className="h-3 w-3 mt-0.5 text-green-600 flex-shrink-0" />
                              <span className="text-xs">{step}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="flex items-center gap-2 flex-wrap">
                      <Button
                        size="sm"
                        onClick={() => onUseExample(example)}
                        data-testid={`button-use-example-${idx}`}
                      >
                        Use This Source
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(example.url)}
                        data-testid={`button-copy-url-${idx}`}
                      >
                        <Copy className="h-3 w-3 mr-1" />
                        Copy
                      </Button>
                      {!example.url.includes('YOUR_API_KEY') && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(example.url, '_blank')}
                          data-testid={`button-test-url-${idx}`}
                        >
                          <ExternalLink className="h-3 w-3 mr-1" />
                          Test
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ))}
      
      <div className="text-center pt-4 border-t">
        <p className="text-sm text-muted-foreground">
          Want to add a custom source? Choose "Custom API" from the templates above to build your own integration.
        </p>
      </div>
    </div>
  );
}