import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  ChartLine, 
  Search, 
  Database, 
  FileText, 
  Settings,
  Eye,
  LogOut,
  User,
  Menu,
  ChevronLeft,
  Building2,
  Users,
  Landmark,
  Brain,
  Activity
} from "lucide-react";
import prismoLogoColor from "@assets/logo-color_1755181188529.png";
import prismoLogoBlack from "@assets/logo-blk_1755209989143.png";

import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useUser } from "@/hooks/use-user";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { SystemSettings } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

function UserProfile({ isExpanded }: { isExpanded: boolean }) {
  const { user } = useUser();
  
  if (!isExpanded) {
    return (
      <div className="p-4 border-t border-sidebar-border" data-testid="sidebar-user-profile">
        <div className="flex flex-col items-center">
          <Link 
            href="/profile"
            className="transition-transform hover:scale-105"
            data-testid="link-profile-picture"
          >
            <Avatar className="w-8 h-8 cursor-pointer">
              <AvatarImage 
                src={user?.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150"} 
                alt="User profile"
              />
              <AvatarFallback>
                <User className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="p-4 border-t border-sidebar-border" data-testid="sidebar-user-profile">
      <div className="flex items-center space-x-3">
        <Link 
          href="/profile"
          className="transition-transform hover:scale-105"
          data-testid="link-profile-picture"
        >
          <Avatar className="w-10 h-10 cursor-pointer">
            <AvatarImage 
              src={user?.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150"} 
              alt="User profile"
            />
            <AvatarFallback>
              <User className="w-5 h-5" />
            </AvatarFallback>
          </Avatar>
        </Link>
        <div className="flex-1">
          <p className="text-sm font-medium text-sidebar-foreground" data-testid="text-username">
            {user?.name || user?.username || "User"}
          </p>
          <p className="text-xs text-sidebar-foreground/60" data-testid="text-user-role">
            {user?.title || "User"}
          </p>
        </div>
        <Button 
          variant="ghost" 
          size="sm"
          className="text-sidebar-foreground/60 hover:text-sidebar-foreground"
          data-testid="button-logout"
        >
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

interface SidebarProps {
  logoUrl?: string | null;
  className?: string;
}

export function Sidebar({ logoUrl, className }: SidebarProps) {
  const [location] = useLocation();
  const [isExpanded, setIsExpanded] = useState(false);
  const queryClient = useQueryClient();

  // System settings query for data ingestion toggle
  const { data: systemSettings } = useQuery<SystemSettings>({
    queryKey: ['/api/system/settings'],
  });

  // Mutation to toggle data ingestion
  const toggleDataIngestionMutation = useMutation({
    mutationFn: async () => {
      const currentState = systemSettings?.dataIngestionEnabled || false;
      const response = await fetch('/api/system/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ dataIngestionEnabled: !currentState })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/system/settings'] });
    },
  });

  const navigation = [
    { name: "Home", href: "/", icon: ChartLine, current: location === "/" },
    { name: "Search", href: "/search", icon: Search, current: location === "/search" },
    { name: "Alerts", href: "/alerts", icon: Brain, current: location === "/alerts" },
    { name: "Decks", href: "/decks", icon: FileText, current: location === "/decks" },
    { name: "Companies", href: "/companies", icon: Building2, current: location === "/companies", nested: true },
    { name: "People", href: "/people", icon: Users, current: location === "/people", nested: true },
    { name: "Organizations", href: "/organizations", icon: Landmark, current: location === "/organizations", nested: true },
    { name: "Data Sources", href: "/sources", icon: Database, current: location === "/sources" },
    { name: "Briefings", href: "/briefings", icon: FileText, current: location === "/briefings" },
  ];

  return (
    <div 
      className={cn(
        "bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 ease-in-out",
        isExpanded ? "w-64" : "w-16",
        className
      )}
    >
      {/* Logo and Brand */}
      <div data-testid="sidebar-header">
        <div className={cn("flex items-center", isExpanded ? "p-6 space-x-3" : "p-4 justify-center")}>
          <div className="w-8 h-8 flex items-center justify-center flex-shrink-0">
            {logoUrl ? (
              <img 
                src={logoUrl} 
                alt="Custom team logo" 
                className="w-full h-full object-contain rounded-lg"
                data-testid="img-custom-logo"
              />
            ) : (
              <button
                onClick={() => toggleDataIngestionMutation.mutate()}
                className="group w-8 h-8 flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95 cursor-pointer"
                data-testid="button-toggle-data-ingestion"
                disabled={toggleDataIngestionMutation.isPending}
                title={`Data ingestion: ${systemSettings?.dataIngestionEnabled ? 'Active (Click to pause)' : 'Paused (Click to activate)'}`}
              >
                <img 
                  src={systemSettings?.dataIngestionEnabled ? prismoLogoColor : prismoLogoBlack} 
                  alt={`Prismo logo - ${systemSettings?.dataIngestionEnabled ? 'Active' : 'Inactive'}`}
                  className={`w-8 h-8 object-contain transition-all duration-500 ${
                    toggleDataIngestionMutation.isPending ? 'opacity-50' : 
                    systemSettings?.dataIngestionEnabled ? 'filter-none' : 'opacity-80'
                  } group-hover:brightness-110`}
                  data-testid="img-prismo-logo"
                />
                {toggleDataIngestionMutation.isPending && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-2 h-2 bg-primary rounded-full animate-ping" />
                  </div>
                )}
              </button>
            )}
          </div>
          {isExpanded && (
            <div>
              <h1 className="font-bold text-sidebar-foreground font-mono tracking-wider text-[24px] ml-[-4px] mr-[-4px]" data-testid="text-app-name">Prismo</h1>
            </div>
          )}
        </div>
        
        {/* Toggle Button */}
        <div className={cn(isExpanded ? "px-6 pb-4" : "px-4 pb-4")}>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className={cn(
              "mt-4 text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-colors",
              isExpanded ? "w-full justify-start" : "w-8 h-8 p-0 justify-center"
            )}
            data-testid="button-toggle-sidebar"
          >
            {isExpanded ? (
              <ChevronLeft className="w-4 h-4" />
            ) : (
              <Menu className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-2" data-testid="sidebar-navigation">
        {navigation.map((item) => (
          <Link 
            key={item.name} 
            href={item.href}
            data-testid={`link-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
            className={cn(
              "flex items-center rounded-lg text-sm font-medium transition-colors",
              isExpanded ? "px-3 py-2" : "p-2 justify-center",
              item.nested && isExpanded ? "ml-1" : "",
              item.current
                ? "bg-sidebar-primary/20 text-sidebar-primary"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            )}
            title={!isExpanded ? item.name : undefined}
            style={item.nested && isExpanded ? { paddingLeft: '20px' } : {}}
          >
            <div className={cn("flex items-center", isExpanded ? "space-x-3" : "")}>
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {isExpanded && <span>{item.name}</span>}
            </div>
          </Link>
        ))}
      </nav>
      {/* User Profile */}
      <UserProfile isExpanded={isExpanded} />
    </div>
  );
}
