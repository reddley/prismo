import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Settings, DollarSign, TrendingDown, Activity, Clock, Target } from "lucide-react";
import { CommandMenu } from "@/components/CommandMenu";

import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from '@/components/ui/dialog';

interface HeaderProps {
  title?: string;
  subtitle?: string;
}

interface CostStats {
  dailyAiCalls: number;
  dailyAiCost: number;
  ruleBasedOperations: number;
  remainingBudget: number;
  remainingCalls: number;
  costSavings: number;
}

function CostDashboard() {
  const { data: costStats } = useQuery<CostStats>({
    queryKey: ['/api/cost-stats'],
    refetchInterval: 30000,
  });

  if (!costStats) {
    return (
      <div className="p-6 space-y-4">
        <div className="text-center text-muted-foreground">Loading cost data...</div>
      </div>
    );
  }

  const efficiencyPercent = costStats.ruleBasedOperations > 0 
    ? Math.round((costStats.ruleBasedOperations / (costStats.ruleBasedOperations + costStats.dailyAiCalls)) * 100)
    : 0;

  const budgetUsedPercent = Math.round(((5.0 - costStats.remainingBudget) / 5.0) * 100);

  return (
    <div className="p-6 space-y-6 w-[500px] max-h-[600px] overflow-y-auto">
      <div className="space-y-2">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <DollarSign className="w-5 h-5" />
          Daily Cost Optimization
        </h3>
        <p className="text-sm text-muted-foreground">
          Real-time monitoring of AI usage and cost savings
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-700">
          <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
            <TrendingDown className="w-4 h-4" />
            <span className="text-sm font-medium">Daily Spent</span>
          </div>
          <div className="mt-1">
            <span className="text-2xl font-bold text-green-800 dark:text-green-300">
              ${costStats.dailyAiCost.toFixed(4)}
            </span>
            <span className="text-sm text-green-600 dark:text-green-500 ml-2">
              of $5.00
            </span>
          </div>
        </div>

        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-700">
          <div className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
            <Target className="w-4 h-4" />
            <span className="text-sm font-medium">Efficiency</span>
          </div>
          <div className="mt-1">
            <span className="text-2xl font-bold text-blue-800 dark:text-blue-300">
              {efficiencyPercent}%
            </span>
            <span className="text-sm text-blue-600 dark:text-blue-500 ml-2">
              rule-based
            </span>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h4 className="font-medium flex items-center gap-2">
          <Activity className="w-4 h-4" />
          Today's Usage
        </h4>
        
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm">AI API Calls</span>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{costStats.dailyAiCalls}</Badge>
              <span className="text-xs text-muted-foreground">
                {costStats.remainingCalls} remaining
              </span>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-sm">Rule-based Operations</span>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-700">
                {costStats.ruleBasedOperations}
              </Badge>
              <span className="text-xs text-green-600 dark:text-green-500">
                $0 cost
              </span>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-sm">Budget Remaining</span>
            <div className="flex items-center gap-2">
              <Badge variant={costStats.remainingBudget > 2 ? "default" : "destructive"}>
                ${costStats.remainingBudget.toFixed(2)}
              </Badge>
              <span className="text-xs text-muted-foreground">
                {budgetUsedPercent}% used
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <h4 className="font-medium text-sm">Budget Usage</h4>
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
          <div 
            className={`h-2 rounded-full transition-all duration-300 ${
              budgetUsedPercent < 50 ? 'bg-green-500' :
              budgetUsedPercent < 80 ? 'bg-yellow-500' : 'bg-red-500'
            }`}
            style={{ width: `${Math.min(budgetUsedPercent, 100)}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>$0</span>
          <span>$5.00 daily limit</span>
        </div>
      </div>

      <div className="bg-muted/50 p-4 rounded-lg border">
        <div className="flex items-center gap-2 text-muted-foreground mb-2">
          <Clock className="w-4 h-4" />
          <span className="text-sm font-medium">Optimization Status</span>
        </div>
        
        <div className="space-y-2 text-sm">
          {costStats.remainingBudget > 4 && (
            <div className="text-green-600 dark:text-green-400">
              ✓ Excellent cost efficiency - minimal AI usage
            </div>
          )}
          {costStats.remainingBudget <= 4 && costStats.remainingBudget > 2 && (
            <div className="text-yellow-600 dark:text-yellow-400">
              ⚠ Moderate AI usage - monitoring closely
            </div>
          )}
          {costStats.remainingBudget <= 2 && (
            <div className="text-red-600 dark:text-red-400">
              ⚠ High AI usage - switching to rule-based processing
            </div>
          )}
          
          <div className="text-muted-foreground">
            Rule-based systems handling {efficiencyPercent}% of operations for free
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex gap-2">
          <Link href="/settings">
            <Button variant="outline" size="sm" className="flex-1">
              Adjust Limits
            </Button>
          </Link>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => window.location.reload()}
            className="flex-1"
          >
            Refresh Data
          </Button>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={() => {
              const today = new Date().toISOString().split('T')[0];
              window.open(`/api/cost-export?startDate=${today}&endDate=${today}`, '_blank');
            }}
            className="text-xs px-3 py-1"
          >
            Export Today
          </Button>
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={() => {
              window.open('/api/cost-export', '_blank');
            }}
            className="text-xs px-3 py-1"
          >
            Export All
          </Button>
        </div>
      </div>
    </div>
  );
}

export function Header({ title = "Intelligence Dashboard", subtitle }: HeaderProps) {
  const [commandMenuOpen, setCommandMenuOpen] = useState(false);
  
  const { data: costStats } = useQuery<CostStats>({
    queryKey: ['/api/cost-stats'],
    refetchInterval: 30000,
  });

  // Keyboard shortcut for Command Menu (Cmd/Ctrl + K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandMenuOpen(true);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const getBudgetStatus = () => {
    if (!costStats) return { color: 'bg-gray-500', label: 'Loading...' };
    if (costStats.remainingBudget > 4) return { color: 'bg-green-500', label: `$${costStats.dailyAiCost.toFixed(3)}` };
    if (costStats.remainingBudget > 2) return { color: 'bg-yellow-500', label: `$${costStats.dailyAiCost.toFixed(3)}` };
    return { color: 'bg-red-500', label: `$${costStats.dailyAiCost.toFixed(3)}` };
  };

  const budgetStatus = getBudgetStatus();

  return (
    <header className="bg-card border-b border-border px-4 py-3" data-testid="header-main">
      <div className="flex items-center justify-between">
        {/* Search Bar - Left aligned (clickable to open Command Menu) */}
        <div className="relative">
          <div
            onClick={() => setCommandMenuOpen(true)}
            className="w-96 pl-10 pr-4 py-2 h-10 bg-background/50 border border-border/50 rounded-md cursor-pointer hover:border-primary/50 hover:bg-background transition-all duration-200 flex items-center"
            data-testid="search-trigger"
          >
            <span className="text-muted-foreground text-sm">
              Search reports, navigation, and more...
            </span>
            <div className="ml-auto text-xs text-muted-foreground">
              <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
                ⌘K
              </kbd>
            </div>
          </div>
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground pointer-events-none" />
        </div>

        {/* Action Icons - Compact right side */}
        <div className="flex items-center space-x-2">
          {/* Cost Monitor */}
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-foreground"
                data-testid="button-cost-dashboard"
              >
                <div className="flex items-center justify-center relative">
                  <DollarSign className="w-4 h-4" />
                  <div className={`absolute -top-1 -right-1 w-2 h-2 rounded-full ${budgetStatus.color}`} />
                </div>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Cost Optimization Dashboard</DialogTitle>
                <DialogDescription>
                  Real-time monitoring of AI usage and cost savings
                </DialogDescription>
              </DialogHeader>
              <CostDashboard />
            </DialogContent>
          </Dialog>

          {/* Observability */}
          <Link href="/observability">
            <Button 
              variant="ghost" 
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-foreground"
              data-testid="button-observability"
            >
              <Activity className="w-4 h-4" />
            </Button>
          </Link>

          {/* Settings */}
          <Link href="/settings">
            <Button 
              variant="ghost" 
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-foreground"
              data-testid="button-settings"
            >
              <Settings className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Command Menu */}
      <CommandMenu 
        open={commandMenuOpen} 
        onOpenChange={setCommandMenuOpen} 
      />
    </header>
  );
}
