import { useState, useRef } from "react";
import { Button } from "./button";
import { Card, CardContent } from "./card";
import { Upload, X, Eye } from "lucide-react";

interface LogoUploadProps {
  onLogoChange: (logoUrl: string | null) => void;
  currentLogo?: string | null;
}

export function LogoUpload({ onLogoChange, currentLogo }: LogoUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentLogo || null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    // Validate file size (2MB)
    if (file.size > 2 * 1024 * 1024) {
      alert('File size must be less than 2MB');
      return;
    }

    setUploading(true);

    try {
      // Create preview
      const preview = URL.createObjectURL(file);
      setPreviewUrl(preview);

      // Upload to server
      const formData = new FormData();
      formData.append('logo', file);

      const response = await fetch('/api/settings/logo', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      onLogoChange(result.logoUrl);
      
    } catch (error) {
      console.error('Logo upload failed:', error);
      alert('Failed to upload logo. Please try again.');
      setPreviewUrl(currentLogo || null);
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveLogo = () => {
    setPreviewUrl(null);
    onLogoChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-4" data-testid="logo-upload-container">
      <div className="space-y-2">
        <label className="block text-sm font-medium text-foreground">Custom Logo</label>
        
        {previewUrl ? (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <img 
                  src={previewUrl} 
                  alt="Logo preview" 
                  className="w-12 h-12 object-contain rounded-lg border border-border bg-muted"
                  data-testid="logo-preview-image"
                />
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground" data-testid="logo-preview-name">
                    company-logo.png
                  </p>
                  <p className="text-xs text-muted-foreground">Logo uploaded successfully</p>
                </div>
                <div className="flex space-x-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleBrowseClick}
                    data-testid="button-change-logo"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleRemoveLogo}
                    className="text-destructive hover:text-destructive"
                    data-testid="button-remove-logo"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card 
            className="border-2 border-dashed border-muted-foreground/25 hover:border-muted-foreground/50 transition-colors cursor-pointer"
            onClick={handleBrowseClick}
            data-testid="logo-upload-dropzone"
          >
            <CardContent className="p-6 text-center">
              <div className="space-y-3">
                <div className="mx-auto w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                  <Upload className="w-6 h-6 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">
                    Drop your logo here or{" "}
                    <span className="text-primary font-medium">browse files</span>
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    PNG, JPG up to 2MB
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
          data-testid="input-file-logo"
        />
      </div>
      
      {uploading && (
        <div className="text-center py-2">
          <p className="text-sm text-muted-foreground">Uploading logo...</p>
        </div>
      )}
    </div>
  );
}
