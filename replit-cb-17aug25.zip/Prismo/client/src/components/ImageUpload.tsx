import { useState, useRef } from "react";
import { Upload, X, Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ImageUploadProps {
  currentImageUrl?: string;
  onImageChange: (imageUrl: string) => void;
  entityType: "company" | "person" | "organization";
  entityId?: string;
  maxSizePixels?: number;
  targetSizePixels?: number;
}

export function ImageUpload({ 
  currentImageUrl, 
  onImageChange, 
  entityType, 
  entityId,
  maxSizePixels = 2500,
  targetSizePixels = 500
}: ImageUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentImageUrl || null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.match(/^image\/(png|jpeg|jpg)$/i)) {
      toast({
        title: "Invalid file type",
        description: "Please select a PNG or JPG image.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 10MB.",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);

    try {
      // Create form data
      const formData = new FormData();
      formData.append('image', file);
      formData.append('entityType', entityType);
      formData.append('maxSizePixels', maxSizePixels.toString());
      formData.append('targetSizePixels', targetSizePixels.toString());
      if (entityId) {
        formData.append('entityId', entityId);
      }

      // Upload and process image
      const response = await apiRequest('/api/upload-image', {
        method: 'POST',
        body: formData,
      });

      const { imageUrl } = response;
      setPreviewUrl(imageUrl);
      onImageChange(imageUrl);

      toast({
        title: "Image uploaded",
        description: "Image has been processed and saved successfully.",
      });
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload image.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = () => {
    setPreviewUrl(null);
    onImageChange("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-3">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/jpg"
        onChange={handleFileSelect}
        className="hidden"
      />

      {previewUrl ? (
        <div className="relative">
          <div className="w-24 h-24 rounded-lg border-2 border-dashed border-muted-foreground/25 overflow-hidden bg-muted/50 flex items-center justify-center">
            <img 
              src={previewUrl} 
              alt="Preview" 
              className="w-full h-full object-cover"
            />
          </div>
          <Button
            type="button"
            variant="destructive"
            size="sm"
            className="absolute -top-2 -right-2 w-6 h-6 p-0 rounded-full"
            onClick={handleRemove}
            data-testid="button-remove-image"
          >
            <X className="w-3 h-3" />
          </Button>
        </div>
      ) : (
        <div
          onClick={handleClick}
          className="w-24 h-24 rounded-lg border-2 border-dashed border-muted-foreground/25 hover:border-muted-foreground/50 cursor-pointer bg-muted/25 hover:bg-muted/50 transition-colors flex items-center justify-center"
        >
          {uploading ? (
            <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
          ) : (
            <div className="text-center">
              <ImageIcon className="w-6 h-6 mx-auto mb-1 text-muted-foreground" />
              <p className="text-xs text-muted-foreground">Upload</p>
            </div>
          )}
        </div>
      )}

      <div className="text-xs text-muted-foreground space-y-1">
        <p>PNG/JPG up to {maxSizePixels}×{maxSizePixels} pixels</p>
        <p>Auto-resized to {targetSizePixels}×{targetSizePixels} WEBP</p>
      </div>
    </div>
  );
}