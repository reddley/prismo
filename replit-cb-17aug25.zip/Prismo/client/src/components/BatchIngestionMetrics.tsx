import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  TrendingUp, 
  TrendingDown, 
  Zap, 
  DollarSign, 
  Filter, 
  Clock,
  PlayCircle,
  BarChart3,
  Play,
  Loader2,
  Activity
} from "lucide-react";
import { useState } from "react";

interface BatchIngestionMetrics {
  current: {
    timestamp: string;
    totalItems: number;
    duplicatesRemoved: number;
    batchesProcessed: number;
    throughputPerSecond: number | null;
    costPerItem: number;
    totalCost: number;
    processingTimeMs: number;
  } | null;
  aggregateStats: {
    totalItemsProcessed: number;
    totalDuplicatesRemoved: number;
    averageThroughput: number;
    averageCostPerItem: number;
    totalCost: number;
    batchCount: number;
  };
  last24Hours: Array<{
    timestamp: string;
    totalItems: number;
    duplicatesRemoved: number;
    batchesProcessed: number;
    throughputPerSecond: number;
    costPerItem: number;
    totalCost: number;
    processingTimeMs: number;
  }>;
  timestamp: string;
}

export function BatchIngestionMetrics() {
  const [isProcessing, setIsProcessing] = useState(false);
  
  const { data: metrics, isLoading, refetch } = useQuery<BatchIngestionMetrics>({
    queryKey: ['/api/batch-ingestion/metrics'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: dataSources } = useQuery({
    queryKey: ['/api/data-sources'],
  });
  


  const handleManualProcess = async () => {
    console.log('Button clicked - handleManualProcess called');
    console.log('dataSources:', dataSources);
    console.log('isProcessing:', isProcessing);
    
    setIsProcessing(true);
    try {
      // Use empty array if no data sources available for testing purposes
      const sourceIds = Array.isArray(dataSources) ? dataSources.map((source: any) => source.id) : [];
      console.log('Processing sourceIds:', sourceIds);
      
      const response = await fetch('/api/batch-ingestion/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sourceIds, testMode: false }),
      });
      
      console.log('API response status:', response.status);
      const result = await response.json();
      console.log('API response:', result);
      
      if (response.ok) {
        refetch();
      }
    } catch (error) {
      console.error('Manual batch processing failed:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Batch Ingestion Performance
            </CardTitle>
            <Button 
              onClick={handleManualProcess}
              disabled={isProcessing || !Array.isArray(dataSources) || !dataSources.length}
              size="sm"
              data-testid="button-manual-process"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Processing...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Process Now
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="h-4 bg-muted rounded " />
            <div className="h-4 bg-muted rounded  w-3/4" />
            <div className="h-4 bg-muted rounded  w-1/2" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const stats = metrics?.aggregateStats;
  const current = metrics?.current;
  
  // Calculate efficiency metrics
  const deduplicationRate = stats?.totalItemsProcessed 
    ? (stats.totalDuplicatesRemoved / (stats.totalItemsProcessed + stats.totalDuplicatesRemoved)) * 100 
    : 0;
  
  const costEfficiency = stats?.averageCostPerItem ? (1 / stats.averageCostPerItem) * 1000 : 0; // Items per $0.001

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-blue-500" />
                Batch Ingestion Performance
              </CardTitle>
              <CardDescription>
                Real-time metrics for batch RSS processing and cost optimization
              </CardDescription>
            </div>
            <Button 
              onClick={handleManualProcess}
              disabled={isProcessing || !Array.isArray(dataSources) || !dataSources.length}
              size="sm"
              className="gap-2"
              data-testid="button-manual-process"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4" />
                  Process Now
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {/* Throughput Metric */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-500" />
                <span className="text-sm font-medium">Throughput</span>
              </div>
              <div className="text-2xl font-bold" data-testid="text-throughput">
                {stats?.averageThroughput?.toFixed(1) || '0'} <span className="text-sm text-muted-foreground">items/sec</span>
              </div>
              <Progress 
                value={Math.min((stats?.averageThroughput || 0) * 10, 100)} 
                className="h-2"
              />
            </div>

            {/* Cost Efficiency */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-emerald-500" />
                <span className="text-sm font-medium">Cost per Item</span>
              </div>
              <div className="text-2xl font-bold" data-testid="text-cost-per-item">
                ${(stats?.averageCostPerItem || 0).toFixed(4)}
              </div>
              <Badge variant={stats?.averageCostPerItem && stats.averageCostPerItem < 0.001 ? 'default' : 'secondary'}>
                {costEfficiency.toFixed(0)} items/$0.001
              </Badge>
            </div>

            {/* Deduplication Rate */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-purple-500" />
                <span className="text-sm font-medium">Deduplication</span>
              </div>
              <div className="text-2xl font-bold" data-testid="text-deduplication-rate">
                {deduplicationRate.toFixed(1)}%
              </div>
              <Progress 
                value={deduplicationRate} 
                className="h-2"
              />
            </div>

            {/* Processing Speed */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-orange-500" />
                <span className="text-sm font-medium">Avg. Processing</span>
              </div>
              <div className="text-2xl font-bold" data-testid="text-processing-time">
                {current?.processingTimeMs ? (current.processingTimeMs / 1000).toFixed(1) : '0'}
                <span className="text-sm text-muted-foreground">s</span>
              </div>
              <Badge variant={current?.processingTimeMs && current.processingTimeMs < 5000 ? 'default' : 'secondary'}>
                {current?.processingTimeMs && current.processingTimeMs < 5000 ? 'Fast' : 'Normal'}
              </Badge>
            </div>
          </div>

          <Separator />

          {/* 24-Hour Summary */}
          <div className="mt-6 space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              24-Hour Summary
            </h3>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600" data-testid="text-total-items">
                  {stats?.totalItemsProcessed?.toLocaleString() || '0'}
                </div>
                <div className="text-sm text-muted-foreground">Items Processed</div>
              </div>
              
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600" data-testid="text-total-duplicates">
                  {stats?.totalDuplicatesRemoved?.toLocaleString() || '0'}
                </div>
                <div className="text-sm text-muted-foreground">Duplicates Removed</div>
              </div>
              
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-green-600" data-testid="text-total-cost">
                  ${(stats?.totalCost || 0).toFixed(3)}
                </div>
                <div className="text-sm text-muted-foreground">Total Cost</div>
              </div>
            </div>
          </div>

          {/* Current Batch Status */}
          {current && (
            <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg border">
              <h4 className="font-semibold mb-2">Latest Batch</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Items:</span>
                  <span className="ml-2 font-medium" data-testid="text-current-items">{current.totalItems}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Batches:</span>
                  <span className="ml-2 font-medium" data-testid="text-current-batches">{current.batchesProcessed}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Throughput:</span>
                  <span className="ml-2 font-medium" data-testid="text-current-throughput">{current.throughputPerSecond?.toFixed(1) ?? '0.0'}/s</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Time:</span>
                  <span className="ml-2 font-medium" data-testid="text-current-time">
                    {new Date(current.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}