import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Settings, Save } from "lucide-react";

interface ConfigureReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  report: {
    id: string;
    templateSlug: string;
    templateName: string;
    configJson: any;
    templateInputsSchema: any;
  };
  onSave: (reportId: string, config: any) => void;
  isSaving?: boolean;
}

export function ConfigureReportDialog({ 
  open, 
  onOpenChange, 
  report, 
  onSave, 
  isSaving = false 
}: ConfigureReportDialogProps) {
  const [config, setConfig] = useState(report.configJson || {});

  const handleSave = () => {
    onSave(report.id, config);
  };

  const renderConfigField = (key: string, fieldSchema: any) => {
    const value = config[key] ?? fieldSchema.default;

    switch (fieldSchema.type) {
      case 'number':
        return (
          <div key={key} className="space-y-2">
            <Label htmlFor={key} className="text-sm font-medium capitalize">
              {key.replace(/([A-Z])/g, ' $1').trim()}
            </Label>
            <Input
              id={key}
              type="number"
              value={value || ''}
              onChange={(e) => setConfig(prev => ({ ...prev, [key]: parseInt(e.target.value) || fieldSchema.default }))}
              min={fieldSchema.minimum}
              max={fieldSchema.maximum}
              placeholder={`Default: ${fieldSchema.default}`}
            />
            {fieldSchema.description && (
              <p className="text-xs text-muted-foreground">{fieldSchema.description}</p>
            )}
          </div>
        );

      case 'string':
        if (fieldSchema.enum) {
          return (
            <div key={key} className="space-y-2">
              <Label htmlFor={key} className="text-sm font-medium capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </Label>
              <Select value={value || fieldSchema.default} onValueChange={(newValue) => setConfig(prev => ({ ...prev, [key]: newValue }))}>
                <SelectTrigger>
                  <SelectValue placeholder={`Select ${key}`} />
                </SelectTrigger>
                <SelectContent>
                  {fieldSchema.enum.map((option: string) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {fieldSchema.description && (
                <p className="text-xs text-muted-foreground">{fieldSchema.description}</p>
              )}
            </div>
          );
        } else {
          return (
            <div key={key} className="space-y-2">
              <Label htmlFor={key} className="text-sm font-medium capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </Label>
              <Input
                id={key}
                value={value || ''}
                onChange={(e) => setConfig(prev => ({ ...prev, [key]: e.target.value }))}
                placeholder={fieldSchema.default ? `Default: ${fieldSchema.default}` : `Enter ${key}`}
              />
              {fieldSchema.description && (
                <p className="text-xs text-muted-foreground">{fieldSchema.description}</p>
              )}
            </div>
          );
        }

      case 'array':
        if (fieldSchema.items?.enum) {
          const selectedItems = Array.isArray(value) ? value : (fieldSchema.default || []);
          return (
            <div key={key} className="space-y-2">
              <Label className="text-sm font-medium capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </Label>
              <div className="space-y-2">
                {fieldSchema.items.enum.map((option: string) => {
                  const isChecked = selectedItems.includes(option);
                  return (
                    <div key={option} className="flex items-center space-x-2">
                      <Checkbox
                        id={`${key}-${option}`}
                        checked={isChecked}
                        onCheckedChange={(checked) => {
                          const newValue = checked 
                            ? [...selectedItems, option]
                            : selectedItems.filter(item => item !== option);
                          setConfig(prev => ({ ...prev, [key]: newValue }));
                        }}
                      />
                      <Label htmlFor={`${key}-${option}`} className="text-sm capitalize">
                        {option}
                      </Label>
                    </div>
                  );
                })}
              </div>
              {fieldSchema.description && (
                <p className="text-xs text-muted-foreground">{fieldSchema.description}</p>
              )}
            </div>
          );
        }
        break;

      case 'boolean':
        return (
          <div key={key} className="flex items-center space-x-2">
            <Checkbox
              id={key}
              checked={value ?? fieldSchema.default ?? false}
              onCheckedChange={(checked) => setConfig(prev => ({ ...prev, [key]: checked }))}
            />
            <Label htmlFor={key} className="text-sm font-medium capitalize">
              {key.replace(/([A-Z])/g, ' $1').trim()}
            </Label>
            {fieldSchema.description && (
              <p className="text-xs text-muted-foreground ml-6">{fieldSchema.description}</p>
            )}
          </div>
        );

      default:
        return (
          <div key={key} className="space-y-2">
            <Label htmlFor={key} className="text-sm font-medium capitalize">
              {key.replace(/([A-Z])/g, ' $1').trim()}
            </Label>
            <Input
              id={key}
              value={value || ''}
              onChange={(e) => setConfig(prev => ({ ...prev, [key]: e.target.value }))}
              placeholder={`Configure ${key}`}
            />
          </div>
        );
    }
  };

  const schema = report.templateInputsSchema;
  const properties = schema?.properties || {};

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Configure {report.templateName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Report Info */}
          <div className="flex items-center justify-between">
            <Badge variant="secondary" className="text-xs">
              {report.templateSlug}
            </Badge>
          </div>

          <Separator />

          {/* Configuration Fields */}
          <div className="space-y-4">
            {Object.keys(properties).length > 0 ? (
              Object.entries(properties).map(([key, fieldSchema]: [string, any]) => 
                renderConfigField(key, fieldSchema)
              )
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Settings className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No configuration options available for this report.</p>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4">
            <Button 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isSaving}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={isSaving}
              className="gap-2"
            >
              <Save className="h-4 w-4" />
              {isSaving ? 'Saving...' : 'Save Configuration'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}