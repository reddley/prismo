import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { TrendingUp, Calendar, BarChart3, Settings, Clock, DollarSign, TrendingDown, Activity, Zap, Users, Globe, X } from "lucide-react";
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";

interface ReportProps {
  report: {
    id: string;
    templateSlug: string;
    templateName: string;
    configJson: any;
    state: 'active' | 'loading' | 'error';
    createdAt: string;
  };
  onConfigure?: () => void;
  onRemove?: () => void;
}

export function ReportComponent({ report, onConfigure, onRemove }: ReportProps) {
  const [isHovered, setIsHovered] = useState(false);

  // Fetch real data for insights (headlines)
  const { data: insights } = useQuery({
    queryKey: ['/api/insights', { limit: 5 }],
    enabled: report.templateSlug === 'recent-headlines',
  });

  // Mock real-time stock data
  const { data: stockData } = useQuery({
    queryKey: ['watchlist-data', report.id],
    queryFn: () => ({
      stocks: [
        { symbol: 'AAPL', name: 'Apple Inc.', price: 182.52, change: 2.34, changePercent: 1.30 },
        { symbol: 'MSFT', name: 'Microsoft', price: 384.30, change: -1.24, changePercent: -0.32 },
        { symbol: 'GOOGL', name: 'Alphabet', price: 138.21, change: 0.89, changePercent: 0.65 },
      ]
    }),
    enabled: report.templateSlug === 'watchlist',
    refetchInterval: 30000, // Refresh every 30s
  });

  const { data: marketMovers } = useQuery({
    queryKey: ['market-movers', report.id],
    queryFn: () => ({
      gainers: [
        { symbol: 'NVDA', change: 5.67, changePercent: 12.4 },
        { symbol: 'AMD', change: 3.21, changePercent: 8.9 },
      ],
      losers: [
        { symbol: 'TSLA', change: -8.45, changePercent: -4.2 },
        { symbol: 'META', change: -5.12, changePercent: -2.1 },
      ]
    }),
    enabled: report.templateSlug === 'market-movers',
    refetchInterval: 60000, // Refresh every minute
  });
  
  const renderReportContent = () => {
    switch (report.templateSlug) {
      case 'recent-headlines':
        return (
          <div className="space-y-3 h-full flex flex-col">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Latest Headlines ({report.configJson?.limit || 10})</span>
            </div>
            <div className="space-y-2 flex-1 overflow-hidden">
              {insights?.insights?.slice(0, report.configJson?.limit || 5).map((insight: any, i: number) => (
                <div key={i} className="text-xs border-l-2 border-primary/30 pl-2 py-1">
                  <div className="font-medium line-clamp-2 mb-1">{insight.title}</div>
                  <div className="text-muted-foreground flex items-center gap-2">
                    <Clock className="h-3 w-3" />
                    {new Date(insight.publishedAt).toLocaleTimeString()}
                  </div>
                </div>
              )) || (
                <div className="text-xs text-muted-foreground">
                  <Activity className="h-4 w-4 mx-auto mb-2" />
                  Loading latest insights...
                </div>
              )}
            </div>
          </div>
        );
      
      case 'watchlist':
        return (
          <div className="space-y-3 h-full flex flex-col">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <TrendingUp className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Stock Watchlist</span>
            </div>
            <div className="space-y-1 flex-1 overflow-hidden">
              {stockData?.stocks?.map((stock: any, i: number) => (
                <div key={i} className="flex items-center justify-between text-xs py-1">
                  <div>
                    <span className="font-medium">{stock.symbol}</span>
                    <span className="text-muted-foreground ml-1 truncate">{stock.name}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">${stock.price}</div>
                    <div className={`flex items-center gap-1 ${stock.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {stock.change >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {stock.changePercent > 0 ? '+' : ''}{stock.changePercent}%
                    </div>
                  </div>
                </div>
              )) || (
                <div className="text-xs text-muted-foreground text-center">
                  <DollarSign className="h-4 w-4 mx-auto mb-1 " />
                  Loading market data...
                </div>
              )}
            </div>
          </div>
        );
      
      case 'market-movers':
        return (
          <div className="space-y-3 h-full flex flex-col">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <BarChart3 className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Market Movers</span>
            </div>
            <div className="space-y-2 flex-1 overflow-hidden">
              {marketMovers ? (
                <>
                  <div className="space-y-1">
                    <div className="text-xs font-medium text-green-600 flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" /> Top Gainers
                    </div>
                    {marketMovers.gainers?.map((stock: any, i: number) => (
                      <div key={i} className="flex justify-between text-xs">
                        <span className="font-medium">{stock.symbol}</span>
                        <span className="text-green-600">+{stock.changePercent}%</span>
                      </div>
                    ))}
                  </div>
                  <div className="space-y-1">
                    <div className="text-xs font-medium text-red-600 flex items-center gap-1">
                      <TrendingDown className="h-3 w-3" /> Top Losers
                    </div>
                    {marketMovers.losers?.map((stock: any, i: number) => (
                      <div key={i} className="flex justify-between text-xs">
                        <span className="font-medium">{stock.symbol}</span>
                        <span className="text-red-600">{stock.changePercent}%</span>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-xs text-muted-foreground text-center">
                  <BarChart3 className="h-4 w-4 mx-auto mb-1 " />
                  Loading market movers...
                </div>
              )}
            </div>
          </div>
        );
      
      case 'rss-monitoring':
        return (
          <div className="space-y-3 h-full flex flex-col">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Globe className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">RSS Monitoring</span>
            </div>
            <div className="text-xs space-y-1">
              <div className="flex justify-between">
                <span>Active Feeds</span>
                <span className="font-medium">5</span>
              </div>
              <div className="flex justify-between">
                <span>Today's Articles</span>
                <span className="font-medium">23</span>
              </div>
              <div className="text-muted-foreground">Last updated: 2 mins ago</div>
            </div>
          </div>
        );

      case 'sentiment-analysis':
        return (
          <div className="space-y-3 h-full flex flex-col">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Sentiment Analysis</span>
            </div>
            <div className="text-xs space-y-1">
              <div className="flex justify-between items-center">
                <span>Overall Sentiment</span>
                <span className="text-green-600 font-medium">+62%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-1">
                <div className="bg-green-600 h-1 rounded-full" style={{width: '62%'}}></div>
              </div>
              <div className="text-muted-foreground">Based on 156 articles</div>
            </div>
          </div>
        );

      default:
        return (
          <div className="space-y-3 h-full flex flex-col">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Zap className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{report.templateName}</span>
            </div>
            <div className="text-xs text-muted-foreground flex-1 overflow-hidden">
              Dynamic content based on configuration
            </div>
          </div>
        );
    }
  };

  return (
    <Card 
      className="h-full report-tile hover-readable transition-all duration-300 ease-out transform hover:scale-[1.02] hover:-translate-y-1 hover:shadow-xl cursor-pointer group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      data-testid={`report-tile-${report.id}`}
    >
      <CardHeader className="pb-2 relative">
        <CardTitle className="text-sm font-medium truncate flex items-center justify-between">
          <span className="transition-colors duration-200 group-hover:text-primary">
            {report.templateName}
          </span>
          <div className={`transition-all duration-75 ${
            isHovered ? 'opacity-100 scale-100' : 'opacity-60 scale-100'
          }`}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0 hover:bg-muted/80 hover:scale-110 transition-all duration-100"
                  data-testid={`button-report-settings-${report.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                >
                  <Settings className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" side="bottom">
                <DropdownMenuItem 
                  onClick={(e) => {
                    e.stopPropagation();
                    onConfigure?.();
                  }}
                  data-testid={`menu-configure-${report.id}`}
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Configure
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemove?.();
                  }}
                  className="text-destructive"
                  data-testid={`menu-remove-${report.id}`}
                >
                  <X className="h-4 w-4 mr-2" />
                  Remove
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardTitle>
        {/* Removed gradient background overlay */}
      </CardHeader>
      <CardContent className="pt-0 relative">
        <div className={`transition-transform duration-200 ${isHovered ? 'transform translate-y-[-1px]' : ''}`}>
          {report.state === 'loading' ? (
            <div className="flex items-center justify-center h-20">
              <div className="text-sm text-muted-foreground">
                Loading...
              </div>
            </div>
          ) : report.state === 'error' ? (
            <div className="flex items-center justify-center h-20">
              <div className="text-sm text-destructive">
                Error loading report
              </div>
            </div>
          ) : (
            renderReportContent()
          )}
        </div>
        {/* Shine effect removed per user request */}
      </CardContent>
    </Card>
  );
}