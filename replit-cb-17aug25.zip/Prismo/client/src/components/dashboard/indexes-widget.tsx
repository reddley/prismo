import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus, TrendingUp, TrendingDown, RefreshCw, Search, BarChart3, Star } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { apiRequest } from "@/lib/queryClient";
import { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip as RechartsTooltip } from "recharts";

// Types
interface StockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  high: number;
  low: number;
  marketCap?: number;
  lastUpdated?: string;
}

interface WatchlistItem {
  id: string;
  symbol: string;
  name: string;
  userId: string;
  addedAt: Date;
}

// Mock historical data generator for mini chart
const generateMiniChartData = (currentPrice: number, change: number) => {
  const data = [];
  let price = currentPrice - change;
  
  for (let i = 0; i < 12; i++) {
    const volatility = (Math.random() - 0.5) * 1.5;
    price += volatility;
    data.push({
      time: i,
      price: Math.max(price, 0),
    });
  }
  
  // Ensure the last point matches current price
  data[data.length - 1].price = currentPrice;
  return data;
};

// Interface for search results
interface SearchResult {
  symbol: string;
  name: string;
  market?: string;
}

export function IndexesWidget() {
  const [searchSymbol, setSearchSymbol] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [tickerIndex, setTickerIndex] = useState(0);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const queryClient = useQueryClient();

  // Fetch watchlist
  const { data: watchlist = [], isLoading: watchlistLoading } = useQuery<WatchlistItem[]>({
    queryKey: ['/api/stocks/watchlist'],
    refetchInterval: 300000,
  });

  // Only show watchlist stocks, no defaults
  const symbolsToFetch = watchlist.map(item => item.symbol);
  
  const { data: stockQuotes = [], isLoading: quotesLoading, isFetching: quotesFetching } = useQuery<StockQuote[]>({
    queryKey: ['/api/stocks/quotes', symbolsToFetch.join(',')],
    queryFn: async () => {
      console.log(`[STOCKS-UI] Fetching quotes for: ${symbolsToFetch.join(',')}`);
      const response = await fetch(`/api/stocks/quotes?symbols=${symbolsToFetch.join(',')}`);
      if (!response.ok) {
        throw new Error('Failed to fetch stock quotes');
      }
      const data = await response.json();
      console.log(`[STOCKS-UI] Received ${data.length} quotes`);
      return data;
    },
    refetchInterval: 30000, // More frequent updates (30 seconds)
    staleTime: 10000, // Consider data stale after 10 seconds
    enabled: symbolsToFetch.length > 0,
  });

  // Animated ticker effect
  useEffect(() => {
    if (stockQuotes.length === 0) return;
    
    const interval = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % stockQuotes.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [stockQuotes.length]);

  // Mutations
  const addStockMutation = useMutation({
    mutationFn: async (stock: { symbol: string; name: string }) => {
      console.log(`[STOCK] Adding ${stock.symbol} to watchlist...`);
      return await apiRequest('/api/stocks/watchlist', 'POST', stock);
    },
    onSuccess: (data, variables) => {
      console.log(`[STOCK] Successfully added ${variables.symbol} to watchlist`);
      queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
      setSearchSymbol('');
      setShowSuggestions(false);
    },
    onError: (error) => {
      console.error('Failed to add stock:', error);
    },
  });

  const removeStockMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest(`/api/stocks/watchlist/${id}`, 'DELETE');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
    },
    onError: (error) => {
      console.error('Failed to remove stock:', error);
    },
  });

  // Formatting functions
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    const sign = value >= 0 ? '+' : '';
    return `${sign}${value.toFixed(2)}%`;
  };

  const getPriceChangeColor = (change: number) => {
    if (change > 0) return 'text-green-600 dark:text-green-400';
    if (change < 0) return 'text-red-600 dark:text-red-400';
    return 'text-muted-foreground';
  };

  // Debounced search function
  useEffect(() => {
    const timeoutId = setTimeout(async () => {
      if (searchSymbol.trim().length >= 2) {
        setIsSearching(true);
        try {
          console.log(`[STOCKS-UI] Searching for: "${searchSymbol}"`);
          const response = await fetch(`/api/stocks/search?q=${encodeURIComponent(searchSymbol)}`);
          if (response.ok) {
            const results = await response.json();
            console.log(`[STOCKS-UI] Found ${results.length} search results`);
            setSearchResults(results.filter((stock: SearchResult) => 
              !watchlist.some(w => w.symbol === stock.symbol)
            ));
          } else {
            setSearchResults([]);
          }
        } catch (error) {
          console.error('[STOCKS-UI] Search failed:', error);
          setSearchResults([]);
        } finally {
          setIsSearching(false);
        }
      } else {
        setSearchResults([]);
      }
    }, 500); // 500ms debounce to reduce API calls

    return () => clearTimeout(timeoutId);
  }, [searchSymbol, watchlist]);

  const handleAddStock = (stock: { symbol: string; name: string }) => {
    addStockMutation.mutate(stock);
  };

  const handleRemoveStock = (id: string) => {
    removeStockMutation.mutate(id);
  };

  const handleRefresh = () => {
    console.log('[STOCKS-UI] Manual refresh triggered');
    queryClient.invalidateQueries({ queryKey: ['/api/stocks/quotes'] });
    queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
  };

  // Animated ticker component - fixed height to prevent layout shift
  const TickerTape = () => {
    if (stockQuotes.length === 0) return (
      <div className="bg-gradient-to-r from-blue-50 to-green-50 dark:from-blue-950/20 dark:to-green-950/20 rounded-lg p-3 mb-4 h-12 flex items-center">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span className="text-sm text-muted-foreground">
              {watchlist.length > 0 ? `Loading ${watchlist.length} stocks...` : 'Add stocks to start tracking'}
            </span>
          </div>
        </div>
      </div>
    );

    const currentStock = stockQuotes[tickerIndex % stockQuotes.length];
    
    return (
      <div className="bg-gradient-to-r from-blue-50 to-green-50 dark:from-blue-950/20 dark:to-green-950/20 rounded-lg p-3 mb-4 h-12 flex items-center">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-4 overflow-hidden">
            <div key={currentStock.symbol} className="flex items-center gap-2">
              <span className="font-bold text-sm">{currentStock.symbol}</span>
              <span className="text-sm">{formatCurrency(currentStock.price)}</span>
              <span className={`text-xs ${getPriceChangeColor(currentStock.change)}`}>
                {formatPercent(currentStock.changePercent)}
              </span>
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Live • {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    );
  };

  // Clean stock item with fixed sizing
  const renderStockItem = (quote: StockQuote, isWatchlist: boolean = false, watchlistId?: string) => {
    const miniChartData = generateMiniChartData(quote.price, quote.change);
    
    return (
      <div
        key={quote.symbol}
        className="group border rounded-lg hover:shadow-md transition-shadow duration-200 h-24" // Fixed height
        data-testid={isWatchlist ? `stock-item-${quote.symbol.toLowerCase()}` : `default-stock-item-${quote.symbol.toLowerCase()}`}
      >
        <div className="flex items-center h-full p-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-bold text-sm">{quote.symbol}</span>
              <Badge 
                variant={quote.change >= 0 ? "default" : "destructive"}
                className="text-xs"
              >
                {quote.change >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                {formatPercent(quote.changePercent)}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex-1">
                <span className="text-lg font-bold">{formatCurrency(quote.price)}</span>
                <p className={`text-xs ${getPriceChangeColor(quote.change)}`}>
                  {quote.change >= 0 ? '+' : ''}{formatCurrency(quote.change)}
                </p>
              </div>

              {/* Mini chart - fixed size */}
              <div className="w-16 h-8 ml-2">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={miniChartData}>
                    <Line 
                      type="monotone" 
                      dataKey="price" 
                      stroke={quote.change >= 0 ? "#22c55e" : "#ef4444"}
                      strokeWidth={1.5}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="ml-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                isWatchlist && watchlistId ? handleRemoveStock(watchlistId) : handleAddStock({ symbol: quote.symbol, name: quote.name });
              }}
              className={`w-8 h-8 p-0 ${isWatchlist ? 'text-muted-foreground hover:text-destructive' : 'text-muted-foreground hover:text-yellow-500'}`}
              data-testid={isWatchlist ? `button-remove-${quote.symbol.toLowerCase()}` : `button-add-default-${quote.symbol.toLowerCase()}`}
              disabled={addStockMutation.isPending || removeStockMutation.isPending}
            >
              {isWatchlist ? <Trash2 className="w-4 h-4" /> : <Star className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </div>
    );
  };

  if (watchlistLoading) {
    return (
      <Card data-testid="stock-market-widget" className="h-fit">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Indexes
            </div>
            <div className="w-4 h-4 bg-muted rounded"></div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="h-12 bg-muted rounded-lg"></div>
            <div className="h-10 bg-muted rounded"></div>
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 bg-muted rounded-lg"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="stock-market-widget" className="h-fit">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2" data-testid="text-stock-widget-title">
            <BarChart3 className="w-5 h-5" />
            Indexes
          </CardTitle>
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleRefresh}
                    disabled={quotesLoading}
                    data-testid="button-refresh-stocks"
                    className="w-8 h-8 p-0"
                  >
                    <RefreshCw className={`w-4 h-4 ${quotesLoading ? 'animate-spin' : ''}`} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Refresh market data</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Animated Ticker Tape - Fixed Height */}
        <TickerTape />

        {/* Search Section - Fixed Height */}
        <div className="relative h-10">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search stocks (Apple, Microsoft...)"
              value={searchSymbol}
              onChange={(e) => {
                setSearchSymbol(e.target.value);
                setShowSuggestions(e.target.value.length > 0);
              }}
              onFocus={() => setShowSuggestions(searchSymbol.length > 0)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchSymbol.trim()) {
                  e.preventDefault();
                  handleAddStock({ symbol: searchSymbol.toUpperCase(), name: searchSymbol.toUpperCase() });
                }
              }}
              className="pl-10 text-sm h-10"
              data-testid="input-stock-search"
            />
          </div>
          
          {/* Suggestions Dropdown */}
          {showSuggestions && (
            <div className="absolute top-full left-0 right-0 z-10 bg-background border rounded-md mt-1 shadow-lg">
              <div className="max-h-48 overflow-y-auto">
                {isSearching ? (
                  <div className="p-3 text-center text-muted-foreground">
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                      Searching...
                    </div>
                  </div>
                ) : searchResults.length > 0 ? (
                  searchResults.slice(0, 8).map((stock) => (
                    <button
                      key={stock.symbol}
                      className="w-full px-3 py-2 text-left hover:bg-muted transition-colors flex items-center justify-between text-sm"
                      onClick={() => handleAddStock(stock)}
                      data-testid={`suggestion-${stock.symbol.toLowerCase()}`}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="font-medium">{stock.symbol}</div>
                        <div className="text-xs text-muted-foreground truncate">{stock.name}</div>
                      </div>
                      <Star className="w-4 h-4 text-muted-foreground flex-shrink-0 ml-2" />
                    </button>
                  ))
                ) : searchSymbol.trim().length >= 2 ? (
                  <div className="p-3 text-center text-muted-foreground">
                    No stocks found for "{searchSymbol}"
                  </div>
                ) : (
                  <div className="p-3 text-center text-muted-foreground">
                    Type at least 2 characters to search
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Stock Display - Fixed sizing */}
        <div className="space-y-3">
          {watchlist.length === 0 ? (
            <div className="text-center py-8">
              <div className="mb-4">
                <BarChart3 className="w-12 h-12 mx-auto text-muted-foreground/50" />
              </div>
              <p className="text-sm font-medium mb-2">No stocks in your watchlist</p>
              <p className="text-xs text-muted-foreground">Search and add stocks to start tracking</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="text-center py-2">
                <p className="text-sm font-medium">Your Watchlist</p>
              </div>
              {watchlist.map((watchItem) => {
                const quote = stockQuotes.find(q => q.symbol === watchItem.symbol);
                
                if (!quote) {
                  return (
                    <div
                      key={watchItem.id}
                      className="h-24 bg-muted/30 rounded-lg flex items-center p-4 border border-dashed"
                      data-testid={`loading-stock-item-${watchItem.symbol.toLowerCase()}`}
                    >
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-muted-foreground">{watchItem.symbol}</span>
                          <Badge variant="outline" className="text-xs">
                            <div className="w-2 h-2 bg-yellow-500 rounded-full animate-ping mr-1"></div>
                            Fetching...
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {quotesLoading ? 'Checking cache...' : 'Waiting for API quota'}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveStock(watchItem.id)}
                        className="w-8 h-8 p-0 text-muted-foreground hover:text-destructive"
                        data-testid={`button-remove-${watchItem.symbol.toLowerCase()}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  );
                }
                
                return renderStockItem(quote, true, watchItem.id);
              })}
            </div>
          )}
        </div>

        {(addStockMutation.isPending || removeStockMutation.isPending) && (
          <div className="text-center py-2 h-8"> {/* Fixed height for loading state */}
            <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              {addStockMutation.isPending ? 'Adding to watchlist...' : 'Removing from watchlist...'}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}