import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Activity, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: string;
  trend?: "up" | "down" | "neutral";
  icon: React.ReactNode;
  iconColor: string;
}

function MetricCard({ title, value, change, trend, icon, iconColor }: MetricCardProps) {
  return (
    <Card className="animate-fade-in">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground mb-1 truncate" data-testid={`text-metric-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {title}
            </p>
            <p className="text-lg font-bold text-foreground" data-testid={`text-value-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {value}
            </p>
            {change && (
              <div className="flex items-center mt-1">
                {trend === "up" && <TrendingUp className="w-3 h-3 text-green-400 mr-1 flex-shrink-0" />}
                {trend === "down" && <TrendingDown className="w-3 h-3 text-red-400 mr-1 flex-shrink-0" />}
                <span 
                  className={cn(
                    "text-xs truncate",
                    trend === "up" && "text-green-400",
                    trend === "down" && "text-red-400",
                    trend === "neutral" && "text-muted-foreground"
                  )}
                  data-testid={`text-change-${title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {change}
                </span>
              </div>
            )}
          </div>
          <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ml-3", iconColor)}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function MetricsGrid() {
  // Optimized: Use dashboard data endpoint for metrics
  const { data: dashboardData, isLoading } = useQuery<{
    insights: any[];
    keyPlayers: any[];
    metrics: any;
  }>({
    queryKey: ['/api/dashboard/data'],
  });

  const metrics = dashboardData?.metrics;

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="space-y-2 flex-1">
                  <div className="h-3 bg-muted rounded w-20"></div>
                  <div className="h-5 bg-muted rounded w-12"></div>
                  <div className="h-3 bg-muted rounded w-16"></div>
                </div>
                <div className="w-10 h-10 bg-muted rounded-lg ml-3"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!metrics) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground">Unable to load metrics</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3" data-testid="metrics-grid">
      <MetricCard
        title="Active Sources"
        value={(metrics as any)?.activeSources || 0}
        change="+12%"
        trend="up"
        icon={<Activity className="w-4 h-4 text-green-400" />}
        iconColor="bg-green-500/20"
      />
      
      <MetricCard
        title="Insights Today"
        value={((metrics as any)?.insightsToday || 0).toLocaleString()}
        change="+7%"
        trend="up"
        icon={<TrendingUp className="w-4 h-4 text-primary" />}
        iconColor="bg-primary/20"
      />
      
      <MetricCard
        title="High Priority Alerts"
        value={(metrics as any)?.highPriorityAlerts || 0}
        change="-3%"
        trend="down"
        icon={<AlertTriangle className="w-4 h-4 text-red-400" />}
        iconColor="bg-red-500/20"
      />
      
      <MetricCard
        title="Processing Speed"
        value={(metrics as any)?.processingSpeed || "N/A"}
        change="Optimal"
        trend="neutral"
        icon={<Activity className="w-4 h-4 text-amber-400" />}
        iconColor="bg-amber-500/20"
      />
    </div>
  );
}
