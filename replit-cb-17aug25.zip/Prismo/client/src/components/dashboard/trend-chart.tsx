import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Line, LineChart, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { useState, useMemo } from "react";

interface ChartData {
  day: string;
  positive: number;
  negative: number;
  neutral: number;
}

const mockData: Record<string, ChartData[]> = {
  "7D": [
    { day: "Mon", positive: 65, negative: 25, neutral: 10 },
    { day: "Tue", positive: 72, negative: 22, neutral: 6 },
    { day: "Wed", positive: 68, negative: 28, neutral: 4 },
    { day: "Thu", positive: 75, negative: 18, neutral: 7 },
    { day: "Fri", positive: 78, negative: 15, neutral: 7 },
    { day: "Sat", positive: 82, negative: 12, neutral: 6 },
    { day: "Sun", positive: 79, negative: 16, neutral: 5 },
  ],
  "30D": [
    { day: "Week 1", positive: 70, negative: 22, neutral: 8 },
    { day: "Week 2", positive: 75, negative: 18, neutral: 7 },
    { day: "Week 3", positive: 72, negative: 20, neutral: 8 },
    { day: "Week 4", positive: 78, negative: 16, neutral: 6 },
  ],
  "90D": [
    { day: "Month 1", positive: 68, negative: 24, neutral: 8 },
    { day: "Month 2", positive: 73, negative: 19, neutral: 8 },
    { day: "Month 3", positive: 76, negative: 17, neutral: 7 },
  ],
};

export function TrendChart() {
  const [selectedPeriod, setSelectedPeriod] = useState<"7D" | "30D" | "90D">("7D");
  
  const chartData = useMemo(() => mockData[selectedPeriod], [selectedPeriod]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-popover border border-border rounded-lg shadow-md p-3">
          <p className="font-medium text-foreground">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {`${entry.name}: ${entry.value}%`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <Card data-testid="trend-chart">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Market Sentiment Trends</CardTitle>
          <div className="flex space-x-2">
            {(["7D", "30D", "90D"] as const).map((period) => (
              <Button
                key={period}
                variant={selectedPeriod === period ? "default" : "ghost"}
                size="sm"
                onClick={() => setSelectedPeriod(period)}
                className="text-xs"
                data-testid={`button-period-${period}`}
              >
                {period}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64" data-testid="chart-container">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <XAxis 
                dataKey="day" 
                axisLine={false}
                tickLine={false}
                className="text-muted-foreground"
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                className="text-muted-foreground"
                domain={[0, 100]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="positive"
                stroke="hsl(var(--chart-2))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
                name="Positive"
              />
              <Line
                type="monotone"
                dataKey="negative"
                stroke="hsl(var(--destructive))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--destructive))", strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
                name="Negative"
              />
              <Line
                type="monotone"
                dataKey="neutral"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
                name="Neutral"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
