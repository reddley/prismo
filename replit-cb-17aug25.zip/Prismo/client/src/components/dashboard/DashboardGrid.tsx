import { useState, useCallback, useEffect, useRef } from 'react';
import { Responsive, WidthProvider, Layout, Layouts } from 'react-grid-layout';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Plus, Settings, X, MoreVertical } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ReportComponent } from '../dashboard/ReportComponent';
import { AddReportDialog } from '../dashboard/AddReportDialog';
import { ConfigureReportDialog } from '../ConfigureReportDialog';

// Make ResponsiveGridLayout responsive to container width
const ResponsiveGridLayout = WidthProvider(Responsive);

interface HomeData {
  layout: Array<{
    id: string;
    x: number;
    y: number;
    w: number;
    h: number;
    templateSlug: string;
  }>;
  installedReports: Array<{
    id: string;
    configJson: any;
    layoutJson: any;
    state: string;
    templateSlug: string;
    templateName: string;
    templateCategory: string;
    templateVersion: number;
    templateInputsSchema: any;
    templatePreviewImg?: string;
    createdAt: string;
  }>;
  total: number;
  userId: string;
}

interface ReportTemplate {
  id: string;
  slug: string;
  name: string;
  category: string;
  version: number;
  inputsSchema: any;
  previewImg?: string;
}

export function DashboardGrid() {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [selectedReport, setSelectedReport] = useState<string | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [configureReport, setConfigureReport] = useState<any>(null);
  const [showConfigDialog, setShowConfigDialog] = useState(false);
  const [contextMenuPos, setContextMenuPos] = useState<{ x: number; y: number } | null>(null);
  const [cardContextMenu, setCardContextMenu] = useState<{ x: number; y: number; report: any } | null>(null);
  const [newlyAddedReport, setNewlyAddedReport] = useState<string | null>(null);
  const [highlightedReport, setHighlightedReport] = useState<string | null>(null);
  
  // Preview placement system state
  const [placementMode, setPlacementMode] = useState<{ templateSlug: string; templateData: ReportTemplate; config?: any } | null>(null);
  const [previewPosition, setPreviewPosition] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [isShiftPressed, setIsShiftPressed] = useState(false);
  const [dragSelection, setDragSelection] = useState<{ start: { x: number; y: number }; current: { x: number; y: number } } | null>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  
  // Grid highlighting system
  const [isGridSelectionMode, setIsGridSelectionMode] = useState(false);
  const [selectedGridArea, setSelectedGridArea] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [hoveredCell, setHoveredCell] = useState<{ x: number; y: number } | null>(null);
  const [isDraggingSelection, setIsDraggingSelection] = useState(false);
  const [dragStartCell, setDragStartCell] = useState<{ x: number; y: number } | null>(null);
  const [showGridHint, setShowGridHint] = useState(true);
  const [hintDismissed, setHintDismissed] = useState(false);
  const queryClient = useQueryClient();

  // Clear grid selection when clicking outside or pressing escape
  const clearGridSelection = useCallback(() => {
    setIsGridSelectionMode(false);
    setSelectedGridArea(null);
    setContextMenuPos(null);
    setHoveredCell(null);
    setIsDraggingSelection(false);
    setDragStartCell(null);
    setCardContextMenu(null);
    console.log('🧹 Cleared grid selection state');
  }, []);

  // Keyboard event handlers for placement mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Shift') {
        setIsShiftPressed(true);
      }
      if (e.key === 'Escape') {
        if (placementMode) {
          setPlacementMode(null);
          setPreviewPosition(null);
          setDragSelection(null);
        }
        clearGridSelection();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'Shift') {
        setIsShiftPressed(false);
        setDragSelection(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [placementMode, clearGridSelection]);

  // Fetch home dashboard data
  const { data: homeData, isLoading } = useQuery<HomeData>({
    queryKey: ['/api/home'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch report templates for add dialog
  const { data: templatesData } = useQuery<{ templates: ReportTemplate[] }>({
    queryKey: ['/api/report-templates'],
  });

  // Update layout mutation
  const updateLayoutMutation = useMutation({
    mutationFn: async ({ reportId, layoutJson }: { reportId: string; layoutJson: any }) => {
      return apiRequest(`/api/installed-reports/${reportId}`, 'PATCH', { layoutJson });
    },
    onError: (error: any) => {
      console.error('Layout update error:', error);
      toast({
        title: 'Error',
        description: `Failed to save layout changes: ${error?.message || 'Unknown error'}`,
        variant: 'destructive',
      });
    },
  });

  // Install report mutation - supports both dialog and placement modes
  const installReportMutation = useMutation({
    mutationFn: async ({ templateSlug, config, position }: { templateSlug: string; config?: any; position?: { x: number; y: number; w: number; h: number } }) => {
      console.log('📍 installReportMutation called with:', { templateSlug, config, position });
      return apiRequest('/api/installed-reports', 'POST', { 
        templateSlug, 
        config: config || {},
        ...(position && { 
          layout: {
            x: position.x,
            y: position.y,
            w: position.w,
            h: position.h
          }
        })
      });
    },
    onSuccess: (data: any) => {
      // Set newly added report ID for drop animation
      if (data && data.id) {
        setNewlyAddedReport(data.id);
        // Clear animation state after animation completes
        setTimeout(() => setNewlyAddedReport(null), 800);
      }
      
      // Exit placement mode if active
      setPlacementMode(null);
      setPreviewPosition(null);
      setDragSelection(null);
      
      // Clear grid selection state
      setIsGridSelectionMode(false);
      setSelectedGridArea(null);
      setContextMenuPos(null);
      setHoveredCell(null);
      setIsDraggingSelection(false);
      setDragStartCell(null);
      console.log('🧹 Cleared all grid selection state after install');
      
      queryClient.invalidateQueries({ queryKey: ['/api/home'] });
      toast({
        title: 'Report installed',
        description: 'Added to your dashboard',
      });
      setShowAddDialog(false);
    },
    onError: (error: any) => {
      const isAlreadyInstalled = error?.message?.includes('already installed');
      
      // Remove the "crowded" logic entirely - the grid should automatically make room
      toast({
        title: isAlreadyInstalled ? 'Already there!' : 'Hmm, something went wrong',
        description: isAlreadyInstalled 
          ? 'This report is already on your dashboard' 
          : 'Unable to add the report right now. Please try again.',
        variant: 'default',
      });
    },
  });

  // Grid position calculation helpers
  const calculateGridPosition = (clientX: number, clientY: number) => {
    if (!gridRef.current) return null;
    
    const rect = gridRef.current.getBoundingClientRect();
    const relativeX = clientX - rect.left;
    const relativeY = clientY - rect.top;
    
    const colWidth = rect.width / 12; // 12 columns
    const rowHeight = 60; // Standard row height
    
    const x = Math.max(0, Math.min(11, Math.floor(relativeX / colWidth)));
    const y = Math.max(0, Math.floor(relativeY / rowHeight));
    
    return { x, y, w: 2, h: 2 }; // Default 2x2 size
  };

  // Handle grid mouse events for placement preview
  const handleGridMouseMove = (e: React.MouseEvent) => {
    if (!placementMode) return;
    
    const position = calculateGridPosition(e.clientX, e.clientY);
    if (position) {
      if (isShiftPressed && dragSelection?.start) {
        // Update drag selection
        setDragSelection(prev => prev ? {
          ...prev,
          current: { x: position.x, y: position.y }
        } : null);
        
        // Calculate drag bounds
        const startX = Math.min(dragSelection.start.x, position.x);
        const startY = Math.min(dragSelection.start.y, position.y);
        const endX = Math.max(dragSelection.start.x, position.x);
        const endY = Math.max(dragSelection.start.y, position.y);
        
        setPreviewPosition({
          x: startX,
          y: startY,
          w: endX - startX + 1,
          h: endY - startY + 1
        });
      } else {
        setPreviewPosition(position);
      }
    }
  };

  const handleGridMouseDown = (e: React.MouseEvent) => {
    if (!placementMode || !isShiftPressed) return;
    
    const position = calculateGridPosition(e.clientX, e.clientY);
    if (position) {
      setDragSelection({
        start: { x: position.x, y: position.y },
        current: { x: position.x, y: position.y }
      });
    }
  };

  const handleGridClick = (e: React.MouseEvent) => {
    if (!placementMode || !previewPosition) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    console.log('📍 Installing report at position:', previewPosition);
    
    // Install the report at the preview position
    installReportMutation.mutate({
      templateSlug: placementMode.templateSlug,
      config: placementMode.config || {},
      position: previewPosition
    });
    
    // Exit placement mode
    setPlacementMode(null);
    setPreviewPosition(null);
  };

  // Remove report mutation
  const removeReportMutation = useMutation({
    mutationFn: async (reportId: string) => {
      return apiRequest(`/api/installed-reports/${reportId}`, 'DELETE');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/home'] });
      toast({
        title: 'Success',
        description: 'Report removed from dashboard',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to remove report',
        variant: 'destructive',
      });
    },
  });

  // Configure report mutation
  const configurationMutation = useMutation({
    mutationFn: async ({ reportId, config }: { reportId: string; config: any }) => {
      return apiRequest(`/api/installed-reports/${reportId}/config`, 'PATCH', { configJson: config });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/home'] });
      toast({
        title: "Configuration saved",
        description: "Report configuration has been updated successfully.",
      });
      setShowConfigDialog(false);
      setConfigureReport(null);
    },
    onError: (error) => {
      console.error('Error configuring report:', error);
      toast({
        title: "Configuration failed",
        description: "Failed to save the configuration. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Auto-fade hint after 5 seconds on empty grids
  useEffect(() => {
    const hasReports = homeData?.installedReports && homeData.installedReports.length > 0;
    
    if (!hintDismissed && !hasReports && showGridHint) {
      const timer = setTimeout(() => {
        setShowGridHint(false);
      }, 4000);
      
      return () => clearTimeout(timer);
    }
    
    // Hide hint if reports are added
    if (hasReports) {
      setShowGridHint(false);
    }
  }, [showGridHint, hintDismissed, homeData?.installedReports]);

  // Convert home data to react-grid-layout format
  const layouts: Layouts = {
    lg: homeData?.layout.map(item => ({
      i: item.id,
      x: item.x,
      y: item.y,
      w: item.w,
      h: item.h,
      minW: 2,
      minH: 2,
    })) || [],
  };

  // Handle layout changes with telemetry
  const handleLayoutChange = useCallback((layout: Layout[], layouts: Layouts) => {
    if (isDragging && homeData) {
      // Clear grid selection when layout is being changed
      clearGridSelection();
      
      // Telemetry logging for development
      if (process.env.NODE_ENV === 'development') {
        const hashedUserId = homeData?.userId ? `user_${btoa(homeData.userId).slice(0, 8)}` : 'anonymous';
        const reportCount = homeData?.installedReports?.length || 0;
        
        console.log('[TELEMETRY] layout_change', {
          user_id: hashedUserId,
          report_count: reportCount,
          layout_items: layout.length,
          timestamp: new Date().toISOString()
        });
      }

      // Update each report's layout in the database
      layout.forEach(item => {
        const report = homeData.installedReports.find(r => r.id === item.i);
        if (report) {
          const newLayoutJson = {
            x: item.x,
            y: item.y,
            w: item.w,
            h: item.h,
          };
          
          updateLayoutMutation.mutate({
            reportId: report.id,
            layoutJson: newLayoutJson,
          });
        }
      });
    }
  }, [isDragging, homeData, updateLayoutMutation, clearGridSelection]);

  // Handle resize events
  const handleResizeStop = useCallback((layout: Layout[], oldItem: Layout, newItem: Layout) => {
    setIsResizing(false);
    
    // Clear any remaining grid selection state after resize
    clearGridSelection();
    
    if (homeData) {
      // Telemetry logging for development
      if (process.env.NODE_ENV === 'development') {
        const hashedUserId = homeData?.userId ? `user_${btoa(homeData.userId).slice(0, 8)}` : 'anonymous';
        
        console.log('[TELEMETRY] report_resize', {
          user_id: hashedUserId,
          report_id: newItem.i,
          old_size: { w: oldItem.w, h: oldItem.h },
          new_size: { w: newItem.w, h: newItem.h },
          timestamp: new Date().toISOString()
        });
      }

      // Update the report's layout in the database
      const report = homeData.installedReports.find(r => r.id === newItem.i);
      if (report) {
        const newLayoutJson = {
          x: newItem.x,
          y: newItem.y,
          w: newItem.w,
          h: newItem.h,
        };
        
        updateLayoutMutation.mutate({
          reportId: report.id,
          layoutJson: newLayoutJson,
        });
      }
    }
  }, [homeData, updateLayoutMutation, clearGridSelection]);

  // Handle drag start/stop
  const handleDragStart = useCallback(() => {
    setIsDragging(true);
    // Clear any active grid selection when starting drag
    clearGridSelection();
  }, [clearGridSelection]);

  const handleDragStop = useCallback(() => {
    setIsDragging(false);
    // Clear any remaining grid selection state after drag
    clearGridSelection();
  }, [clearGridSelection]);

  const handleResizeStart = useCallback(() => {
    setIsResizing(true);
    // Clear any active grid selection when starting resize
    clearGridSelection();
  }, [clearGridSelection]);

  // Check for duplicate reports and highlight existing ones
  const checkForDuplicate = useCallback((templateSlug: string) => {
    const existingReport = homeData?.installedReports?.find(
      report => report.templateSlug === templateSlug
    );
    
    if (existingReport) {
      // Highlight the existing report with pinkish purple glow
      setHighlightedReport(existingReport.id);
      
      // Auto-scroll to the duplicate report
      setTimeout(() => {
        const reportElement = document.querySelector(`[data-testid="report-${existingReport.templateSlug}-${existingReport.id}"]`);
        if (reportElement) {
          reportElement.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'center',
            inline: 'center'
          });
        }
      }, 100); // Small delay to ensure the highlight has been applied
      
      // Clear highlight after 3 seconds (extended for better visibility)
      setTimeout(() => setHighlightedReport(null), 3000);
      
      toast({
        title: 'Already on your dashboard!',
        description: 'This report is already installed - highlighting it for you.',
        variant: 'default',
      });
      
      return true; // Duplicate found
    }
    
    return false; // No duplicate
  }, [homeData?.installedReports, toast]);

  // Handle report installation
  const handleInstallReport = useCallback((templateSlug: string, config?: any) => {
    // Check for duplicates first
    if (checkForDuplicate(templateSlug)) {
      return; // Stop installation if duplicate found
    }
    
    installReportMutation.mutate({ templateSlug, config });
  }, [installReportMutation, checkForDuplicate]);

  // Handle report removal
  const handleRemoveReport = useCallback((reportId: string) => {
    removeReportMutation.mutate(reportId);
  }, [removeReportMutation]);

  // Handle report configuration
  const handleConfigureReport = useCallback((reportId: string, config: any) => {
    configurationMutation.mutate({ reportId, config });
  }, [configurationMutation]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedReport) return;

      const currentLayout = layouts.lg?.find(item => item.i === selectedReport);
      if (!currentLayout) return;

      let newX = currentLayout.x;
      let newY = currentLayout.y;
      
      switch (e.key) {
        case 'ArrowLeft':
          e.preventDefault();
          newX = Math.max(0, currentLayout.x - 1);
          break;
        case 'ArrowRight':
          e.preventDefault();
          newX = currentLayout.x + 1;
          break;
        case 'ArrowUp':
          e.preventDefault();
          newY = Math.max(0, currentLayout.y - 1);
          break;
        case 'ArrowDown':
          e.preventDefault();
          newY = currentLayout.y + 1;
          break;
        case 'Escape':
          e.preventDefault();
          setSelectedReport(null);
          return;
        case 'Enter':
          e.preventDefault();
          setSelectedReport(null);
          return;
        default:
          return;
      }

      // Update layout if position changed
      if (newX !== currentLayout.x || newY !== currentLayout.y) {
        const report = homeData?.installedReports.find(r => r.id === selectedReport);
        if (report) {
          updateLayoutMutation.mutate({
            reportId: report.id,
            layoutJson: { x: newX, y: newY, w: currentLayout.w, h: currentLayout.h },
          });
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [selectedReport, layouts.lg, homeData, updateLayoutMutation]);

  // Grid cell calculation
  const getCellFromCoordinates = (clientX: number, clientY: number) => {
    if (!gridRef.current) return null;
    
    const rect = gridRef.current.getBoundingClientRect();
    const relativeX = clientX - rect.left;
    const relativeY = clientY - rect.top;
    
    const colWidth = rect.width / 12;
    const rowHeight = 60 + 8; // rowHeight + margin
    
    const x = Math.max(0, Math.min(11, Math.floor(relativeX / colWidth)));
    const y = Math.max(0, Math.floor(relativeY / rowHeight));
    
    return { x, y };
  };

  // Handle grid area selection with drag support
  const handleGridSelectionMouseDown = useCallback((e: React.MouseEvent) => {
    if (placementMode) return; // Don't interfere with placement mode
    
    // Check if we're clicking on a report card or any interactive element
    const target = e.target as HTMLElement;
    const isOnReportCard = target.closest('[data-testid^="report-"]') || 
                          target.closest('.react-grid-item') ||
                          target.closest('[role="button"]') ||
                          target.className.includes('report') ||
                          target.tagName === 'CANVAS' ||
                          target.tagName === 'SVG' ||
                          target.closest('button') ||
                          target.closest('a') ||
                          target.closest('[draggable]');
    
    if (isOnReportCard) return; // Don't start grid selection on report cards
    
    const cell = getCellFromCoordinates(e.clientX, e.clientY);
    if (!cell) return;
    
    e.preventDefault();
    setDragStartCell(cell);
    setSelectedGridArea({ x: cell.x, y: cell.y, w: 1, h: 1 });
    setIsGridSelectionMode(true);
    setIsDraggingSelection(true);
    console.log('🎯 Started grid selection at:', cell);
  }, [placementMode]);

  const handleGridSelectionMouseMove = useCallback((e: React.MouseEvent) => {
    const cell = getCellFromCoordinates(e.clientX, e.clientY);
    if (!cell) return;
    
    // Update hover state for visual feedback
    setHoveredCell(cell);
    
    // If dragging, update selection area
    if (isDraggingSelection && dragStartCell) {
      const newArea = {
        x: Math.min(dragStartCell.x, cell.x),
        y: Math.min(dragStartCell.y, cell.y),
        w: Math.abs(cell.x - dragStartCell.x) + 1,
        h: Math.abs(cell.y - dragStartCell.y) + 1
      };
      setSelectedGridArea(newArea);
    }
  }, [isDraggingSelection, dragStartCell]);

  const handleGridSelectionMouseUp = useCallback(() => {
    if (isDraggingSelection) {
      setIsDraggingSelection(false);
      setDragStartCell(null);
      console.log('🎯 Completed grid selection:', selectedGridArea);
    }
  }, [isDraggingSelection, selectedGridArea]);

  // Handle clicks outside to clear selection and context menus
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      
      // Don't clear if clicking on context menu, dialog, or specific buttons
      const isContextMenuClick = target.closest('[data-testid^="context-menu"]');
      const isDialogClick = target.closest('[role="dialog"]') || target.closest('.dialog-overlay');
      const isAddButtonClick = target.closest('[data-testid="button-add-report"]');
      const isReportClick = target.closest('[data-testid^="report-"]');
      
      // Only clear selection if clicking completely outside the grid system
      if (!isContextMenuClick && !isDialogClick && !isAddButtonClick && !isReportClick) {
        clearGridSelection();
      }
    };

    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [clearGridSelection]);

  // Handle right-click context menu for empty space
  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    // Only show add context menu if clicking on empty space (not on a report card)
    const target = e.target as HTMLElement;
    
    // More robust check - ensure we're not clicking on any report content
    const isOnReportCard = target.closest('[data-testid^="report-"]') || 
                          target.closest('.react-grid-item') ||
                          target.closest('[role="button"]') ||
                          target.className.includes('report') ||
                          target.tagName === 'CANVAS' ||
                          target.tagName === 'SVG';
                          
    if (!isOnReportCard) {
      e.preventDefault();
      setCardContextMenu(null); // Close card context menu
      
      // Clear any existing grid selection - don't auto-select on right-click
      clearGridSelection();
      
      // Smart positioning to keep menu within viewport
      const menuWidth = 240; // Expected menu width
      const menuHeight = 400; // Expected menu height (approximate)
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      
      let x = e.clientX;
      let y = e.clientY;
      
      // Adjust X position if menu would overflow right edge
      if (x + menuWidth > viewportWidth) {
        x = viewportWidth - menuWidth - 10;
      }
      
      // Adjust Y position if menu would overflow bottom edge  
      if (y + menuHeight > viewportHeight) {
        y = viewportHeight - menuHeight - 10;
      }
      
      // Ensure minimum margins from edges
      x = Math.max(10, x);
      y = Math.max(10, y);
      
      setContextMenuPos({ x, y });
    }
  }, []);

  // Handle card context menu
  const handleCardContextMenu = useCallback((e: React.MouseEvent, report: any) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenuPos(null); // Close add context menu
    
    // Smart positioning for card context menu
    const menuWidth = 160;
    const menuHeight = 120;
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    let x = e.clientX;
    let y = e.clientY;
    
    // Adjust X position if menu would overflow right edge
    if (x + menuWidth > viewportWidth) {
      x = viewportWidth - menuWidth - 10;
    }
    
    // Adjust Y position if menu would overflow bottom edge
    if (y + menuHeight > viewportHeight) {
      y = viewportHeight - menuHeight - 10;
    }
    
    // Ensure minimum margins from edges
    x = Math.max(10, x);
    y = Math.max(10, y);
    
    setCardContextMenu({ x, y, report });
  }, []);

  // Group templates by category
  const templatesByCategory = templatesData?.templates.reduce((acc, template) => {
    if (!acc[template.category]) {
      acc[template.category] = [];
    }
    acc[template.category].push(template);
    return acc;
  }, {} as Record<string, ReportTemplate[]>) || {};

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96" data-testid="dashboard-loading">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading dashboard...</span>
      </div>
    );
  }

  return (
    <div 
      className={cn(
        "w-full h-full p-4 relative",
        placementMode && "cursor-crosshair",
        isDraggingSelection && "select-none"
      )}
      onContextMenu={handleContextMenu}
      onMouseMove={(e) => {
        handleGridMouseMove(e);
        handleGridSelectionMouseMove(e);
      }}
      onMouseDown={(e) => {
        handleGridMouseDown(e);
        if (!placementMode) handleGridSelectionMouseDown(e);
      }}
      onMouseUp={handleGridSelectionMouseUp}
      onMouseLeave={handleGridSelectionMouseUp}
      onClick={handleGridClick}
      ref={gridRef}
      data-testid="dashboard-grid"
    >
      {/* Add Report Button - Upper Right Corner */}
      <div className="mb-4 flex justify-end">
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              size="sm"
              className="add-report-button animate-smooth-scale h-8 w-8 p-0"
              data-testid="button-add-report"
              disabled={installReportMutation.isPending}
            >
              <Plus className="h-4 w-4 transition-transform duration-200 group-hover:rotate-90" />
            </Button>
          </DialogTrigger>
        </Dialog>
        
        {/* Reports Modal */}
        <AddReportDialog
          open={showAddDialog}
          onOpenChange={setShowAddDialog}
          onInstallTemplate={(templateSlug, config) => {
            console.log('📍 Placement mode triggered for:', templateSlug, 'with config:', config);
            
            // Check for duplicates first
            if (checkForDuplicate(templateSlug)) {
              setShowAddDialog(false); // Close dialog since we found a duplicate
              return; // Stop installation if duplicate found
            }
            
            // Find the template data for placement mode
            const templateData = templatesData?.templates.find(t => t.slug === templateSlug);
            
            if (templateData) {
              console.log('📍 Template data found, entering placement mode:', templateData.name);
              // Enter placement mode with config - don't close dialog here, AddReportDialog handles it
              setPlacementMode({ templateSlug, templateData, config });
            } else {
              console.log('📍 Template data not found, using direct installation');
              // Fallback to direct installation
              installReportMutation.mutate({ templateSlug, config });
            }
          }}

        />

        {/* Configure Report Dialog */}
        {configureReport && (
          <ConfigureReportDialog
            open={showConfigDialog}
            onOpenChange={setShowConfigDialog}
            report={configureReport}
            onSave={handleConfigureReport}
            isSaving={configurationMutation.isPending}
          />
        )}
      </div>

      {/* Placement Preview Overlay */}
      {placementMode && previewPosition && (
        <div 
          className="absolute z-20 border-2 border-primary/50 bg-primary/10 rounded-lg flex items-center justify-center transition-all duration-150"
          style={{
            left: `${(previewPosition.x / 12) * 100}%`,
            top: `${previewPosition.y * 76}px`, // 60px row height + 16px margin
            width: `${(previewPosition.w / 12) * 100}%`,
            height: `${previewPosition.h * 76 - 16}px`
          }}
        >
          <div className="text-center text-primary font-medium">
            <div className="text-sm">{placementMode.templateData.name}</div>
            <div className="text-xs opacity-75">
              {isShiftPressed ? 'Drag to resize • Release to place' : 'Click to place • Shift+drag to resize'}
            </div>
          </div>
        </div>
      )}

      {/* Grid Cell Overlay for Selection */}
      {isGridSelectionMode && selectedGridArea && (
        <div 
          className="absolute inset-0 pointer-events-none z-20"
          style={{ gridColumn: 'span 12', gridRow: 'span 20' }}
        >
          <div
            className="absolute border-2 border-primary bg-primary/10 rounded-lg transition-all duration-200"
            style={{
              left: `${(selectedGridArea.x / 12) * 100}%`,
              top: `${selectedGridArea.y * 68}px`, // rowHeight + margin
              width: `${(selectedGridArea.w / 12) * 100}%`,
              height: `${selectedGridArea.h * 68 - 8}px`
            }}
          />
          <div
            className="absolute text-xs font-medium text-primary px-2 py-1 bg-background border rounded"
            style={{
              left: `${(selectedGridArea.x / 12) * 100}%`,
              top: `${selectedGridArea.y * 68 - 30}px`,
            }}
          >
            {selectedGridArea.w}×{selectedGridArea.h} area selected
          </div>
        </div>
      )}

      {/* Interactive Instructions */}
      {/* Grid interaction hint - only show on empty grids */}
      {!placementMode && !contextMenuPos && !cardContextMenu && 
       showGridHint && !hintDismissed && 
       (!homeData?.installedReports || homeData.installedReports.length === 0) && (
        <div className={`absolute bottom-4 right-4 text-xs text-muted-foreground bg-background/90 px-3 py-2 rounded-lg border backdrop-blur-sm shadow-lg transition-all duration-300 max-w-xs ${showGridHint ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="font-medium mb-1">Welcome to your dashboard!</div>
              <div>Right-click empty space to place reports • Drag to select custom areas</div>
            </div>
            <button
              onClick={() => {
                setHintDismissed(true);
                setShowGridHint(false);
              }}
              className="text-muted-foreground hover:text-foreground p-1 rounded transition-colors"
              data-testid="hint-dismiss-button"
              aria-label="Dismiss hint"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Grid Layout */}
      {homeData && homeData.installedReports.length > 0 ? (
        <ResponsiveGridLayout
          className="layout"
          layouts={layouts}
          onLayoutChange={handleLayoutChange}
          onDragStart={handleDragStart}
          onDragStop={handleDragStop}
          onResizeStart={handleResizeStart}
          onResizeStop={handleResizeStop}
          breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
          cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
          rowHeight={60}
          isDraggable={!placementMode}
          isResizable={!placementMode}
          resizeHandles={['s', 'w', 'e', 'n', 'sw', 'nw', 'se', 'ne']}
          useCSSTransforms={true}
          compactType="vertical"
          preventCollision={false}
          margin={[8, 8]}
          containerPadding={[0, 0]}
          autoSize={true}
          transformScale={1}
          data-testid="grid-layout"
        >
          {homeData.installedReports.map((report) => {
            const isNewlyAdded = newlyAddedReport === report.id;
            const isHighlighted = highlightedReport === report.id;
            
            return (
              <div 
                key={report.id}
                className={cn(
                  "relative bg-background border rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-move",
                  selectedReport === report.id && "ring-2 ring-primary",
                  isNewlyAdded && "animate-drop-in",
                  isHighlighted && "animate-duplicate-highlight"
                )}
                onClick={() => setSelectedReport(report.id)}
                onContextMenu={(e) => handleCardContextMenu(e, report)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    setSelectedReport(selectedReport === report.id ? null : report.id);
                  }
                }}
                tabIndex={0}
                role="button"
                aria-label={`${report.templateName} report`}
                data-testid={`report-${report.templateSlug}-${report.id}`}
                style={isNewlyAdded ? {
                  animationDelay: '0ms',
                  animationDuration: '600ms',
                  animationFillMode: 'both'
                } : undefined}
              >
              {/* Report Controls */}
              <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 hover:bg-muted"
                      data-testid={`button-report-menu-${report.id}`}
                    >
                      <MoreVertical className="h-3 w-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => {
                      setConfigureReport(report);
                      setShowConfigDialog(true);
                    }}>
                      <Settings className="h-4 w-4 mr-2" />
                      Configure
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={() => handleRemoveReport(report.id)}
                      className="text-destructive"
                      data-testid={`button-remove-report-${report.id}`}
                    >
                      <X className="h-4 w-4 mr-2" />
                      Remove
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Report Content */}
              <ReportComponent 
                report={{
                  ...report,
                  state: (report.state as "loading" | "error" | "active") || "active"
                }}
                onConfigure={() => {
                  setConfigureReport(report);
                  setShowConfigDialog(true);
                }}
                onRemove={() => handleRemoveReport(report.id)}
              />
            </div>
            );
          })}
        </ResponsiveGridLayout>
      ) : (
        // Empty state
        <div 
          className={cn(
            "flex flex-col items-center justify-center h-96 border-2 border-dashed rounded-lg transition-all duration-300",
            placementMode 
              ? "border-primary/50 bg-primary/5 cursor-crosshair" 
              : "border-muted-foreground/25 add-report-button hover-readable hover:border-primary/50 animate-smooth-scale"
          )}
          data-testid="dashboard-empty-state"
          onClick={(e) => {
            if (placementMode && previewPosition) {
              handleGridClick(e);
            } else if (!placementMode) {
              setShowAddDialog(true);
            }
          }}
        >
          {placementMode ? (
            <div className="text-center space-y-4">
              <div className="text-lg font-medium text-primary">
                Place {placementMode.templateData.name}
              </div>
              <div className="text-sm text-muted-foreground">
                {isShiftPressed ? 'Drag to resize • Release to place' : 'Click to place • Shift+drag to resize • ESC to cancel'}
              </div>
            </div>
          ) : (
            <div className="text-center space-y-4 cursor-pointer group">
              <div className="mx-auto h-12 w-12 text-muted-foreground transition-all duration-300 group-hover:text-primary group-hover:scale-110">
                <Plus className="h-full w-full" />
              </div>
              <div>
                <h3 className="text-lg font-medium transition-colors duration-200 group-hover:text-primary">No reports installed</h3>
                <p className="text-muted-foreground transition-opacity duration-200 group-hover:opacity-80">
                  Add your first report to get started with your personalized dashboard
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Context Menu for Quick Add */}
      {contextMenuPos && (
        <div
          className="fixed z-50 bg-background border rounded-md shadow-lg py-1 w-60 max-h-96 overflow-y-auto"
          style={{
            left: contextMenuPos.x,
            top: contextMenuPos.y,
          }}
          data-testid="context-menu-add-report"
        >
          <div className="px-3 py-2 text-sm font-medium border-b">Add Report</div>
          {Object.entries(templatesByCategory).map(([category, templates]) => (
            <div key={category}>
              <div className="px-3 py-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                {category}
              </div>
              {templates.map((template) => (
                <button
                  key={template.id}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors"
                  onClick={() => {
                    if (selectedGridArea) {
                      // Install at the selected grid area
                      installReportMutation.mutate({ 
                        templateSlug: template.slug, 
                        config: {},
                        position: selectedGridArea 
                      });
                    } else {
                      // Fallback to auto-positioning
                      handleInstallReport(template.slug);
                    }
                    // Clear all selection state after placing a report
                    clearGridSelection();
                  }}
                  data-testid={`context-menu-template-${template.slug}`}
                >
                  {template.name}
                </button>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Context Menu for Report Cards */}
      {cardContextMenu && (
        <div
          className="fixed z-50 bg-background border rounded-md shadow-lg py-1 w-40"
          style={{
            left: cardContextMenu.x,
            top: cardContextMenu.y,
          }}
          data-testid="context-menu-card"
        >
          <div className="px-3 py-2 text-sm font-medium border-b">{cardContextMenu.report.templateName}</div>
          <button
            className="w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors flex items-center"
            onClick={() => {
              setConfigureReport(cardContextMenu.report);
              setShowConfigDialog(true);
              setCardContextMenu(null);
            }}
            data-testid={`context-menu-configure-${cardContextMenu.report.id}`}
          >
            <Settings className="h-4 w-4 mr-2" />
            Configure
          </button>
          <button
            className="w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors flex items-center text-destructive"
            onClick={() => {
              handleRemoveReport(cardContextMenu.report.id);
              setCardContextMenu(null);
            }}
            data-testid={`context-menu-remove-${cardContextMenu.report.id}`}
          >
            <X className="h-4 w-4 mr-2" />
            Remove
          </button>
        </div>
      )}

      {/* Click outside to close context menus */}
      {(contextMenuPos || cardContextMenu) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => {
            setContextMenuPos(null);
            setCardContextMenu(null);
          }}
        />
      )}
    </div>
  );
}