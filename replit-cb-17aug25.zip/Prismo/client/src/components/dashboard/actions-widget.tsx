import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Download, Settings } from "lucide-react";

export function ActionsWidget() {
  const actions = [
    {
      label: "Add New Monitor",
      icon: Plus,
      color: "text-primary",
      action: () => console.log("Add monitor clicked"),
      testId: "button-add-monitor"
    },
    {
      label: "Export Report", 
      icon: Download,
      color: "text-green-400",
      action: () => console.log("Export report clicked"),
      testId: "button-export-report"
    },
    {
      label: "Configure Alerts",
      icon: Settings,
      color: "text-amber-400", 
      action: () => console.log("Configure alerts clicked"),
      testId: "button-configure-alerts"
    },
  ];

  return (
    <Card data-testid="actions-widget">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="ghost"
              className="w-full justify-start p-3 h-auto bg-muted hover:bg-muted/80"
              onClick={action.action}
              data-testid={action.testId}
            >
              <action.icon className={`w-4 h-4 mr-3 ${action.color}`} />
              <span className="text-sm text-foreground">{action.label}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
