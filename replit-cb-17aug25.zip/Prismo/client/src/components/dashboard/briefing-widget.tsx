import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export function BriefingWidget() {
  const { data: briefing, isLoading } = useQuery({
    queryKey: ['/api/briefings/latest'],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Today's Briefing
            <div className="w-4 h-4 bg-muted rounded"></div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="h-4 bg-muted rounded w-32"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
              <div className="h-3 bg-muted rounded w-3/4"></div>
            </div>
            <div className="h-10 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!briefing) {
    return (
      <Card data-testid="briefing-widget">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Today's Briefing
            <Button variant="ghost" size="sm" disabled>
              <ExternalLink className="w-4 h-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-muted-foreground text-sm">No briefing available yet.</p>
            <p className="text-xs text-muted-foreground mt-1">
              Daily briefings are generated automatically at 8 AM.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="briefing-widget">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle data-testid="text-briefing-title">Today's Briefing</CardTitle>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-primary hover:text-primary/80"
            data-testid="button-briefing-external"
          >
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-sm text-muted-foreground space-y-3">
            {(briefing as any)?.keyPoints && Array.isArray((briefing as any).keyPoints) && (briefing as any).keyPoints.length > 0 ? (
              (briefing as any).keyPoints.slice(0, 3).map((point: any, index: number) => (
                <div key={index}>
                  <h4 className="font-medium text-foreground mb-2" data-testid={`text-briefing-section-${index}`}>
                    {point.split(':')[0]}
                  </h4>
                  <p className="mb-3" data-testid={`text-briefing-content-${index}`}>
                    {point.split(':').slice(1).join(':').trim()}
                  </p>
                </div>
              ))
            ) : (
              <div>
                <h4 className="font-medium text-foreground mb-2">Key Insights</h4>
                <p className="mb-3" data-testid="text-briefing-summary">
                  {(briefing as any)?.content?.slice(0, 200) || "No content available"}...
                </p>
              </div>
            )}
          </div>
          <Button 
            className="w-full"
            data-testid="button-view-full-briefing"
          >
            View Full Briefing
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
