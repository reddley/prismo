import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

const statusColors: Record<string, string> = {
  "active": "bg-green-500/20 text-green-400",
  "paused": "bg-muted text-muted-foreground", 
  "limited": "bg-amber-500/20 text-amber-400",
};

const statusIndicators: Record<string, string> = {
  "active": "bg-green-400",
  "paused": "bg-muted-foreground",
  "limited": "bg-amber-400",
};

export function MonitorsWidget() {
  const { data: monitors, isLoading } = useQuery({
    queryKey: ['/api/monitors'],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Active Monitors
            <div className="w-4 h-4 bg-muted rounded"></div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between py-2">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-muted rounded-full"></div>
                  <div className="space-y-1">
                    <div className="h-4 bg-muted rounded w-24"></div>
                    <div className="h-3 bg-muted rounded w-16"></div>
                  </div>
                </div>
                <div className="h-5 bg-muted rounded w-16"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!monitors || !Array.isArray(monitors) || monitors.length === 0) {
    return (
      <Card data-testid="monitors-widget">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Active Monitors</CardTitle>
            <Button 
              variant="ghost" 
              size="sm"
              className="text-primary hover:text-primary/80"
              data-testid="button-add-monitor"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-muted-foreground text-sm">No monitors configured.</p>
            <p className="text-xs text-muted-foreground mt-1">
              Add monitors to track specific topics or competitors.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="monitors-widget">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Active Monitors</CardTitle>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-primary hover:text-primary/80"
            data-testid="button-add-monitor"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {(monitors || []).map((monitor: any) => (
            <div 
              key={monitor.id} 
              className="flex items-center justify-between py-2"
              data-testid={`monitor-item-${monitor.id}`}
            >
              <div className="flex items-center space-x-3">
                <div 
                  className={cn("w-2 h-2 rounded-full", statusIndicators[monitor.status || "active"])}
                  data-testid={`status-indicator-${monitor.id}`}
                />
                <div>
                  <p className="text-sm font-medium text-foreground" data-testid={`text-monitor-name-${monitor.id}`}>
                    {monitor.name}
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid={`text-monitor-sources-${monitor.id}`}>
                    {monitor.sourceCount} sources
                  </p>
                </div>
              </div>
              <Badge 
                variant="secondary" 
                className={cn("text-xs capitalize", statusColors[monitor.status || "active"])}
                data-testid={`badge-monitor-status-${monitor.id}`}
              >
                {monitor.status}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
