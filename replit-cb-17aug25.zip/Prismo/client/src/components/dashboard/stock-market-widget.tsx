import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  Trash2, 
  Search, 
  DollarSign,
  BarChart3,
  Clock,
  Star,
  StarOff,
  RefreshCw
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface StockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  high: number;
  low: number;
  previousClose: number;
  lastUpdated: string;
}

interface WatchlistItem {
  id: string;
  symbol: string;
  name: string;
  isWatched: boolean;
  addedAt: string;
}

// Popular tech and finance companies for quick add suggestions
const SUGGESTED_STOCKS = [
  { symbol: 'AAPL', name: 'Apple Inc.' },
  { symbol: 'MSFT', name: 'Microsoft Corporation' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.' },
  { symbol: 'AMZN', name: 'Amazon.com Inc.' },
  { symbol: 'TSLA', name: 'Tesla Inc.' },
  { symbol: 'META', name: 'Meta Platforms Inc.' },
  { symbol: 'NVDA', name: 'NVIDIA Corporation' },
  { symbol: 'JPM', name: 'JPMorgan Chase & Co.' },
];

export function StockMarketWidget() {
  const [searchSymbol, setSearchSymbol] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const queryClient = useQueryClient();

  // Fetch watchlist
  const { data: watchlist = [], isLoading: watchlistLoading } = useQuery<WatchlistItem[]>({
    queryKey: ['/api/stocks/watchlist'],
    refetchInterval: 300000, // Refresh every 5 minutes
  });

  // Always show some stock data - watchlist if available, otherwise default tech stocks
  const defaultTechStocks = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA'];
  const symbolsToFetch = watchlist.length > 0 ? watchlist.map(item => item.symbol) : defaultTechStocks;
  
  const { data: stockQuotes = [], isLoading: quotesLoading } = useQuery<StockQuote[]>({
    queryKey: ['/api/stocks/quotes', { symbols: symbolsToFetch.join(',') }],
    queryFn: async () => {
      const response = await fetch(`/api/stocks/quotes?symbols=${symbolsToFetch.join(',')}`);
      if (!response.ok) {
        throw new Error('Failed to fetch stock quotes');
      }
      return response.json();
    },
    refetchInterval: 60000, // Refresh every minute
    enabled: symbolsToFetch.length > 0,
  });

  // Add stock to watchlist mutation
  const addStockMutation = useMutation({
    mutationFn: async (stock: { symbol: string; name: string }) => {
      return await apiRequest('/api/stocks/watchlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(stock),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
      setSearchSymbol('');
      setShowSuggestions(false);
    },
  });

  // Remove stock from watchlist mutation
  const removeStockMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest(`/api/stocks/watchlist/${id}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
    },
  });

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  // Format percentage
  const formatPercent = (value: number) => {
    const sign = value >= 0 ? '+' : '';
    return `${sign}${value.toFixed(2)}%`;
  };

  // Format large numbers (market cap, volume)
  const formatLargeNumber = (value: number) => {
    if (value >= 1e12) {
      return `$${(value / 1e12).toFixed(2)}T`;
    } else if (value >= 1e9) {
      return `$${(value / 1e9).toFixed(2)}B`;
    } else if (value >= 1e6) {
      return `$${(value / 1e6).toFixed(2)}M`;
    }
    return formatCurrency(value);
  };

  // Get price change color
  const getPriceChangeColor = (change: number) => {
    if (change > 0) return 'text-green-600';
    if (change < 0) return 'text-red-600';
    return 'text-muted-foreground';
  };

  // Filter suggestions based on search
  const filteredSuggestions = SUGGESTED_STOCKS.filter(
    stock => 
      (stock.symbol.toLowerCase().includes(searchSymbol.toLowerCase()) ||
       stock.name.toLowerCase().includes(searchSymbol.toLowerCase())) &&
      !watchlist.some(w => w.symbol === stock.symbol)
  );

  const handleAddStock = (stock: { symbol: string; name: string }) => {
    addStockMutation.mutate(stock);
  };

  const handleRemoveStock = (id: string) => {
    removeStockMutation.mutate(id);
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/stocks/quotes'] });
    queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
  };

  if (watchlistLoading) {
    return (
      <Card data-testid="stock-market-widget">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Market Watch
            </div>
            <div className="w-4 h-4 bg-muted rounded"></div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="h-4 bg-muted rounded w-32"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
              <div className="h-3 bg-muted rounded w-3/4"></div>
            </div>
            <div className="h-10 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="stock-market-widget">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2" data-testid="text-stock-widget-title">
            <BarChart3 className="w-5 h-5" />
            Market Watch
          </CardTitle>
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleRefresh}
                    disabled={quotesLoading}
                    data-testid="button-refresh-stocks"
                  >
                    <RefreshCw className={`w-4 h-4 ${quotesLoading ? 'animate-spin' : ''}`} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Refresh market data</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add Stock Section */}
        <div className="relative">
          <div className="flex gap-2">
            <Input
              placeholder="Search stocks (e.g., AAPL, Microsoft)"
              value={searchSymbol}
              onChange={(e) => {
                setSearchSymbol(e.target.value);
                setShowSuggestions(e.target.value.length > 0);
              }}
              onFocus={() => setShowSuggestions(searchSymbol.length > 0)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchSymbol.trim()) {
                  e.preventDefault();
                  handleAddStock({ symbol: searchSymbol.toUpperCase(), name: searchSymbol.toUpperCase() });
                }
              }}
              className="text-sm"
              data-testid="input-stock-search"
            />
            <Button 
              size="sm" 
              disabled={!searchSymbol.trim()}
              onClick={() => handleAddStock({ symbol: searchSymbol.toUpperCase(), name: searchSymbol.toUpperCase() })}
              data-testid="button-add-stock"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          
          {/* Suggestions Dropdown */}
          {showSuggestions && filteredSuggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 z-10 bg-background border rounded-md mt-1 shadow-lg">
              <div className="max-h-48 overflow-y-auto">
                {filteredSuggestions.slice(0, 5).map((stock) => (
                  <button
                    key={stock.symbol}
                    className="w-full px-3 py-2 text-left hover:bg-muted transition-colors flex items-center justify-between text-sm"
                    onClick={() => handleAddStock(stock)}
                    data-testid={`suggestion-${stock.symbol.toLowerCase()}`}
                  >
                    <div>
                      <div className="font-medium">{stock.symbol}</div>
                      <div className="text-xs text-muted-foreground truncate">{stock.name}</div>
                    </div>
                    <Plus className="w-4 h-4 text-muted-foreground" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Stock Data Display */}
        <div className="space-y-3">
          {watchlist.length === 0 ? (
            <div className="space-y-3">
              <div className="text-center py-2">
                <p className="text-sm text-muted-foreground">Top Tech Stocks</p>
                <p className="text-xs text-muted-foreground">
                  Add to watchlist to track your favorites
                </p>
              </div>
              {/* Show default tech stocks with option to add to watchlist */}
              {quotesLoading && stockQuotes.length === 0 ? (
                // Loading skeleton for default stocks
                [...Array(5)].map((_, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-muted rounded w-16"></div>
                      <div className="h-3 bg-muted rounded w-32"></div>
                      <div className="h-6 bg-muted rounded w-24"></div>
                    </div>
                    <div className="w-8 h-8 bg-muted rounded"></div>
                  </div>
                ))
              ) : (
                stockQuotes.map((quote) => (
                  <div
                    key={quote.symbol}
                    className="relative p-2 border rounded-lg hover:bg-muted/50 transition-colors"
                    data-testid={`default-stock-item-${quote.symbol.toLowerCase()}`}
                  >
                    <div className="flex flex-col space-y-1 pr-8">
                      <div className="flex items-center gap-1 flex-wrap">
                        <span className="font-medium text-sm">{quote.symbol}</span>
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${getPriceChangeColor(quote.change)}`}
                        >
                          {quote.change >= 0 ? <TrendingUp className="w-2 h-2 mr-1" /> : <TrendingDown className="w-2 h-2 mr-1" />}
                          {formatPercent(quote.changePercent)}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground truncate" title={quote.name}>
                        {quote.name}
                      </p>
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold">{formatCurrency(quote.price)}</span>
                        <span className={`text-xs ${getPriceChangeColor(quote.change)}`}>
                          {quote.change >= 0 ? '+' : ''}{formatCurrency(quote.change)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Vol: {(quote.volume / 1000000).toFixed(1)}M</span>
                        <span>H/L: {formatCurrency(quote.high)}/{formatCurrency(quote.low)}</span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleAddStock({ symbol: quote.symbol, name: quote.name })}
                      className="absolute top-2 right-2 text-muted-foreground hover:text-primary h-6 w-6 p-0"
                      data-testid={`button-add-default-${quote.symbol.toLowerCase()}`}
                    >
                      <Star className="w-3 h-3" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          ) : (
            watchlist.map((watchItem) => {
              const quote = stockQuotes.find(q => q.symbol === watchItem.symbol);
              
              return (
                <div
                  key={watchItem.id}
                  className="relative p-2 border rounded-lg hover:bg-muted/50 transition-colors"
                  data-testid={`stock-item-${watchItem.symbol.toLowerCase()}`}
                >
                  <div className="flex flex-col space-y-1 pr-8">
                    <div className="flex items-center gap-1 flex-wrap">
                      <span className="font-medium text-sm">{watchItem.symbol}</span>
                      {quote && (
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${getPriceChangeColor(quote.change)}`}
                        >
                          {quote.change >= 0 ? <TrendingUp className="w-2 h-2 mr-1" /> : <TrendingDown className="w-2 h-2 mr-1" />}
                          {formatPercent(quote.changePercent)}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground truncate" title={watchItem.name}>
                      {watchItem.name}
                    </p>
                    {quote && (
                      <>
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold">{formatCurrency(quote.price)}</span>
                          <span className={`text-xs ${getPriceChangeColor(quote.change)}`}>
                            {quote.change >= 0 ? '+' : ''}{formatCurrency(quote.change)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Vol: {(quote.volume / 1000000).toFixed(1)}M</span>
                          <span>H/L: {formatCurrency(quote.high)}/{formatCurrency(quote.low)}</span>
                        </div>
                      </>
                    )}
                    {quotesLoading && !quote && (
                      <div className="h-3 bg-muted rounded w-24"></div>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveStock(watchItem.id)}
                    className="absolute top-2 right-2 text-muted-foreground hover:text-destructive h-6 w-6 p-0"
                    data-testid={`button-remove-${watchItem.symbol.toLowerCase()}`}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        {stockQuotes.length > 0 && (
          <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Live data from Alpha Vantage
            </span>
            <span>Last updated: {new Date().toLocaleTimeString()}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}