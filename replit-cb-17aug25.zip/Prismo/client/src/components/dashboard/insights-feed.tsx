import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Eye, Share, Bookmark, TrendingUp, AlertTriangle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import type { Insight } from "@shared/schema";

const categoryColors: Record<string, string> = {
  "AI/ML": "bg-primary/20 text-primary",
  "Cybersecurity": "bg-amber-500/20 text-amber-400",
  "FinTech": "bg-green-500/20 text-green-400",
  "Healthcare": "bg-blue-500/20 text-blue-400",
  "Enterprise": "bg-purple-500/20 text-purple-400",
  "Other": "bg-muted text-muted-foreground",
};

const priorityColors: Record<string, string> = {
  "critical": "text-red-400",
  "high": "text-amber-400", 
  "medium": "text-primary",
  "low": "text-muted-foreground",
};

const priorityIcons: Record<string, React.ReactNode> = {
  "critical": <AlertTriangle className="w-3 h-3" />,
  "high": <TrendingUp className="w-3 h-3" />,
  "medium": <Eye className="w-3 h-3" />,
  "low": <Eye className="w-3 h-3" />,
};

interface InsightCardProps {
  insight: Insight;
}

function InsightCard({ insight }: InsightCardProps) {
  const formatTimeAgo = (date: Date | null | undefined) => {
    if (!date) return "Unknown";
    
    const dateObj = new Date(date);
    if (isNaN(dateObj.getTime())) return "Invalid date";
    
    const now = new Date();
    const diff = now.getTime() - dateObj.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return "< 1h ago";
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  const getSentimentColor = (sentiment?: string) => {
    switch (sentiment) {
      case "positive": return "text-green-400";
      case "negative": return "text-red-400";
      default: return "text-muted-foreground";
    }
  };

  const getSentimentLabel = (sentiment?: string) => {
    switch (sentiment) {
      case "positive": return "Bullish Signal";
      case "negative": return "Risk Alert";
      default: return "Neutral";
    }
  };

  return (
    <Card className="hover:border-accent-foreground/20 transition-colors" data-testid={`insight-card-${insight.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <Badge 
                variant="secondary" 
                className={cn(
                  "text-xs font-medium",
                  categoryColors[insight.category || "Other"]
                )}
                data-testid={`badge-category-${insight.id}`}
              >
                {insight.category || "General"}
              </Badge>
              <span className="text-slate-400 text-xs" data-testid={`text-source-${insight.id}`}>
                {insight.source} • {formatTimeAgo(insight.createdAt)}
              </span>
            </div>
            
            <h4 className="font-medium text-foreground mb-2 line-clamp-2" data-testid={`text-title-${insight.id}`}>
              {insight.title}
            </h4>
            
            <p className="text-sm text-muted-foreground mb-3 line-clamp-3" data-testid={`text-summary-${insight.id}`}>
              {insight.summary || insight.content}
            </p>
            
            <div className="flex items-center space-x-4 text-xs text-muted-foreground">
              <span data-testid={`text-views-${insight.id}`}>
                <Eye className="w-3 h-3 mr-1 inline" /> 
                {Math.floor(Math.random() * 2000 + 100)} views
              </span>
              <span data-testid={`text-shares-${insight.id}`}>
                <Share className="w-3 h-3 mr-1 inline" /> 
                {Math.floor(Math.random() * 50 + 5)} shares
              </span>
              <span className={cn("flex items-center", priorityColors[insight.priority || "medium"])}>
                {priorityIcons[insight.priority || "medium"]}
                <span className="ml-1 capitalize" data-testid={`text-priority-${insight.id}`}>
                  {insight.priority} Impact
                </span>
              </span>
            </div>
          </div>
          
          <div className="flex flex-col items-end space-y-2 ml-4">
            <Button
              variant="ghost"
              size="sm"
              className="text-muted-foreground hover:text-foreground"
              data-testid={`button-bookmark-${insight.id}`}
            >
              <Bookmark className="w-4 h-4" />
            </Button>
            <div className="text-right">
              <div className={cn("text-xs font-medium", getSentimentColor(insight.sentiment || undefined))}>
                {getSentimentLabel(insight.sentiment || undefined)}
              </div>
              <div className="text-xs text-muted-foreground" data-testid={`text-confidence-${insight.id}`}>
                {insight.confidence || 0}% confidence
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function InsightsFeed() {
  // Optimized: Use dashboard data endpoint for insights
  const { data: dashboardData, isLoading } = useQuery<{
    insights: any[];
    keyPlayers: any[];
    metrics: any;
  }>({
    queryKey: ['/api/dashboard/data'],
  });

  const insights = dashboardData?.insights || [];

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="">
                <div className="flex items-start justify-between p-4 border border-border rounded-lg">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center space-x-2">
                      <div className="h-4 bg-muted rounded w-20"></div>
                      <div className="h-4 bg-muted rounded w-32"></div>
                    </div>
                    <div className="h-5 bg-muted rounded w-3/4"></div>
                    <div className="h-4 bg-muted rounded w-full"></div>
                    <div className="h-4 bg-muted rounded w-2/3"></div>
                  </div>
                  <div className="w-12 h-12 bg-muted rounded ml-4"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!insights || !Array.isArray(insights) || insights.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-muted-foreground">No insights available yet.</p>
            <p className="text-sm text-muted-foreground mt-1">
              Insights will appear here as data sources are processed.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="insights-feed">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Recent Insights</CardTitle>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-primary hover:text-primary/80"
            data-testid="button-view-all-insights"
          >
            View All <ArrowRight className="ml-1 w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {(insights || []).slice(0, 5).map((insight: any) => (
            <InsightCard key={insight.id} insight={insight} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
