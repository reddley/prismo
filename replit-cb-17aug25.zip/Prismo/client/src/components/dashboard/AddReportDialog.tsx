import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { ReportsModal } from '../ReportsModal';

interface ReportTemplate {
  id: string;
  slug: string;
  name: string;
  category: string;
  description?: string;
  tags?: string[];
  isFeatured: boolean;
  popularityScore: number;
  version: number;
  inputsSchema: any;
  previewImg?: string;
  createdAt: string;
}

interface AddReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onInstallTemplate?: (templateSlug: string, config?: any) => void;
}

export function AddReportDialog({ open, onOpenChange, onInstallTemplate }: AddReportDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleInstallTemplate = async (template: ReportTemplate, config?: any) => {
    // Always close the modal immediately to enable placement mode
    onOpenChange(false);
    
    // Use the parent's install function if provided, otherwise install directly
    if (onInstallTemplate) {
      onInstallTemplate(template.slug, config || {});
    } else {
      // Fallback to direct installation
      try {
        const response = await apiRequest(`/api/installed-reports`, 'POST', {
          templateSlug: template.slug,
          config: config || {}
        });
        
        queryClient.invalidateQueries({ queryKey: ['/api/home'] });
        toast({
          title: 'Report installed',
          description: 'Added to your dashboard',
        });
      } catch (error: any) {
        // Handle validation errors
        if (error.message.includes('400') && error.validationErrors) {
          toast({
            title: 'Configuration invalid',
            description: `${error.validationErrors.length} validation errors found`,
            variant: 'destructive',
          });
        } else {
          toast({
            title: 'Installation failed',
            description: 'Could not add report to dashboard',
            variant: 'destructive',
          });
        }
      }
    }
  };

  return (
    <ReportsModal
      open={open}
      onOpenChange={onOpenChange}
      onInstallTemplate={handleInstallTemplate}
    />
  );
}