import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

export function SourcesWidget() {
  const { data: sources, isLoading } = useQuery({
    queryKey: ['/api/data-sources'],
  });

  const formatTimeAgo = (date: Date | null | undefined) => {
    if (!date) return "Never";
    
    const dateObj = new Date(date);
    if (isNaN(dateObj.getTime())) return "Invalid";
    
    const now = new Date();
    const diff = now.getTime() - dateObj.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    
    if (minutes < 1) return "< 1m ago";
    if (minutes < 60) return `${minutes}m ago`;
    return `${Math.floor(minutes / 60)}h ago`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Data Sources
            <div className="h-5 bg-muted rounded w-20"></div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-muted rounded-full"></div>
                  <div className="h-4 bg-muted rounded w-32"></div>
                </div>
                <div className="h-3 bg-muted rounded w-16"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const activeSources = Array.isArray(sources) ? sources.filter((source: any) => source.isActive) : [];

  return (
    <Card data-testid="sources-widget">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Data Sources</CardTitle>
          <Badge 
            variant="secondary" 
            className="bg-green-500/20 text-green-400 text-xs"
            data-testid="badge-sources-status"
          >
            {activeSources.length}/{Array.isArray(sources) ? sources.length : 0} Online
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {activeSources.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground text-sm">No active data sources.</p>
            <p className="text-xs text-muted-foreground mt-1">
              Configure RSS feeds and other sources to start monitoring.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {activeSources.map((source: any) => (
              <div 
                key={source.id} 
                className="flex items-center justify-between"
                data-testid={`source-item-${source.id}`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-400 rounded-full" />
                  <span className="text-sm text-foreground" data-testid={`text-source-name-${source.id}`}>
                    {source.name}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground" data-testid={`text-source-time-${source.id}`}>
                  {formatTimeAgo(source.lastFetched)}
                </span>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
