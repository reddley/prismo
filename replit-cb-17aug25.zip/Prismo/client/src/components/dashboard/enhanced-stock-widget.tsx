import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus, TrendingUp, TrendingDown, RefreshCw, Search, BarChart3, Star } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { apiRequest } from "@/lib/queryClient";
import { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip as RechartsTooltip } from "recharts";

// Types
interface StockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  high: number;
  low: number;
  marketCap?: number;
  lastUpdated?: string;
}

interface WatchlistItem {
  id: string;
  symbol: string;
  name: string;
  userId: string;
  addedAt: Date;
}

// Mock historical data generator for chart
const generateMockHistoricalData = (currentPrice: number, change: number) => {
  const data = [];
  let price = currentPrice - change;
  
  for (let i = 0; i < 24; i++) {
    const volatility = (Math.random() - 0.5) * 2;
    price += volatility;
    data.push({
      time: `${i}:00`,
      price: Math.max(price, 0),
    });
  }
  
  // Ensure the last point matches current price
  data[data.length - 1].price = currentPrice;
  
  return data;
};

// Suggested stocks for search
const SUGGESTED_STOCKS = [
  { symbol: 'AAPL', name: 'Apple Inc.' },
  { symbol: 'MSFT', name: 'Microsoft Corporation' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.' },
  { symbol: 'AMZN', name: 'Amazon.com Inc.' },
  { symbol: 'TSLA', name: 'Tesla Inc.' },
  { symbol: 'META', name: 'Meta Platforms Inc.' },
  { symbol: 'NVDA', name: 'NVIDIA Corporation' },
  { symbol: 'NFLX', name: 'Netflix Inc.' },
  { symbol: 'CRM', name: 'Salesforce Inc.' },
  { symbol: 'ORCL', name: 'Oracle Corporation' }
];

export function EnhancedStockWidget() {
  const [searchSymbol, setSearchSymbol] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedStock, setSelectedStock] = useState<StockQuote | null>(null);
  const [tickerIndex, setTickerIndex] = useState(0);
  const queryClient = useQueryClient();

  // Fetch watchlist
  const { data: watchlist = [], isLoading: watchlistLoading } = useQuery<WatchlistItem[]>({
    queryKey: ['/api/stocks/watchlist'],
    refetchInterval: 300000,
  });

  // Always show some stock data - watchlist if available, otherwise default tech stocks
  const defaultTechStocks = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA'];
  const symbolsToFetch = watchlist.length > 0 ? watchlist.map(item => item.symbol) : defaultTechStocks;
  
  const { data: stockQuotes = [], isLoading: quotesLoading } = useQuery<StockQuote[]>({
    queryKey: ['/api/stocks/quotes', { symbols: symbolsToFetch.join(',') }],
    queryFn: async () => {
      const response = await fetch(`/api/stocks/quotes?symbols=${symbolsToFetch.join(',')}`);
      if (!response.ok) {
        throw new Error('Failed to fetch stock quotes');
      }
      return response.json();
    },
    refetchInterval: 60000,
    enabled: symbolsToFetch.length > 0,
  });

  // Animated ticker effect
  useEffect(() => {
    if (stockQuotes.length === 0) return;
    
    const interval = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % stockQuotes.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [stockQuotes.length]);

  // Mutations
  const addStockMutation = useMutation({
    mutationFn: async (stock: { symbol: string; name: string }) => {
      const response = await apiRequest('/api/stocks/watchlist', 'POST', stock);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
      setSearchSymbol('');
      setShowSuggestions(false);
    },
    onError: (error) => {
      console.error('Failed to add stock:', error);
    },
  });

  const removeStockMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest(`/api/stocks/watchlist/${id}`, 'DELETE');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
    },
    onError: (error) => {
      console.error('Failed to remove stock:', error);
    },
  });

  // Formatting functions
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    const sign = value >= 0 ? '+' : '';
    return `${sign}${value.toFixed(2)}%`;
  };

  const getPriceChangeColor = (change: number) => {
    if (change > 0) return 'text-green-600';
    if (change < 0) return 'text-red-600';
    return 'text-muted-foreground';
  };

  const filteredSuggestions = SUGGESTED_STOCKS.filter(
    stock => 
      (stock.symbol.toLowerCase().includes(searchSymbol.toLowerCase()) ||
       stock.name.toLowerCase().includes(searchSymbol.toLowerCase())) &&
      !watchlist.some(w => w.symbol === stock.symbol)
  );

  const handleAddStock = (stock: { symbol: string; name: string }) => {
    addStockMutation.mutate(stock);
  };

  const handleRemoveStock = (id: string) => {
    removeStockMutation.mutate(id);
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/stocks/quotes'] });
    queryClient.invalidateQueries({ queryKey: ['/api/stocks/watchlist'] });
  };

  // Animated ticker component
  const TickerTape = () => {
    if (stockQuotes.length === 0) return null;

    return (
      <div className="bg-gradient-to-r from-blue-50 to-green-50 dark:from-blue-950/20 dark:to-green-950/20 rounded-lg p-3 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 overflow-hidden">
            <div className="flex items-center gap-4">
              {stockQuotes.slice(tickerIndex, tickerIndex + 3).map((quote, index) => (
                <div key={`${quote.symbol}-${index}`} className="flex items-center gap-2 whitespace-nowrap">
                  <span className="font-bold text-sm">{quote.symbol}</span>
                  <span className="text-sm">{formatCurrency(quote.price)}</span>
                  <span className={`text-xs ${getPriceChangeColor(quote.change)}`}>
                    {formatPercent(quote.changePercent)}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Live • {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    );
  };

  // Enhanced stock item with mini chart
  const renderStockItem = (quote: StockQuote, isWatchlist: boolean = false, watchlistId?: string) => {
    const historicalData = generateMockHistoricalData(quote.price, quote.change);
    
    return (
      <div
        key={quote.symbol}
        className="group border rounded-lg hover:shadow-md transition-all duration-200 cursor-pointer"
        onClick={() => setSelectedStock(selectedStock?.symbol === quote.symbol ? null : quote)}
        data-testid={isWatchlist ? `stock-item-${quote.symbol.toLowerCase()}` : `default-stock-item-${quote.symbol.toLowerCase()}`}
      >
        <div className="flex items-center justify-between p-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-2">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-base">{quote.symbol}</span>
                  <Badge 
                    variant={quote.change >= 0 ? "default" : "destructive"}
                    className="text-xs"
                  >
                    {quote.change >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                    {formatPercent(quote.changePercent)}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground truncate mt-1" title={quote.name}>
                  {quote.name}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <span className="text-xl font-bold">{formatCurrency(quote.price)}</span>
                <p className={`text-sm ${getPriceChangeColor(quote.change)}`}>
                  {quote.change >= 0 ? '+' : ''}{formatCurrency(quote.change)}
                </p>
              </div>

              {/* Mini chart */}
              <div className="w-24 h-12">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={historicalData}>
                    <Line 
                      type="monotone" 
                      dataKey="price" 
                      stroke={quote.change >= 0 ? "#22c55e" : "#ef4444"}
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-muted-foreground mt-2">
              <span>Vol: {(quote.volume / 1000000).toFixed(1)}M</span>
              <span>H/L: {formatCurrency(quote.high)}/{formatCurrency(quote.low)}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 ml-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                isWatchlist && watchlistId ? handleRemoveStock(watchlistId) : handleAddStock({ symbol: quote.symbol, name: quote.name });
              }}
              className={`${isWatchlist ? 'text-muted-foreground hover:text-destructive' : 'text-muted-foreground hover:text-yellow-500'}`}
              data-testid={isWatchlist ? `button-remove-${quote.symbol.toLowerCase()}` : `button-add-default-${quote.symbol.toLowerCase()}`}
              disabled={addStockMutation.isPending || removeStockMutation.isPending}
            >
              {isWatchlist ? <Trash2 className="w-4 h-4" /> : <Star className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Expanded chart view */}
        {selectedStock?.symbol === quote.symbol && (
          <div className="border-t p-4 bg-muted/20">
            <h4 className="font-medium mb-3">24-Hour Price Movement</h4>
            <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={historicalData}>
                  <XAxis 
                    dataKey="time" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 10 }}
                  />
                  <YAxis 
                    domain={['dataMin - 5', 'dataMax + 5']}
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 10 }}
                    tickFormatter={value => `$${value.toFixed(0)}`}
                  />
                  <RechartsTooltip
                    formatter={([value]: [number]) => [`$${value.toFixed(2)}`, 'Price']}
                    labelStyle={{ fontSize: '12px' }}
                    contentStyle={{ fontSize: '12px' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="price" 
                    stroke={quote.change >= 0 ? "#22c55e" : "#ef4444"}
                    strokeWidth={3}
                    dot={false}
                    activeDot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>
    );
  };

  if (watchlistLoading) {
    return (
      <Card data-testid="stock-market-widget">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Indexes
            </div>
            <div className="w-4 h-4 bg-muted rounded"></div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="h-16 bg-muted rounded-lg"></div>
            <div className="space-y-2">
              <div className="h-4 bg-muted rounded w-32"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
              <div className="h-3 bg-muted rounded w-3/4"></div>
            </div>
            <div className="h-10 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="stock-market-widget">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2" data-testid="text-stock-widget-title">
            <BarChart3 className="w-5 h-5" />
            Indexes
          </CardTitle>
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleRefresh}
                    disabled={quotesLoading}
                    data-testid="button-refresh-stocks"
                  >
                    <RefreshCw className={`w-4 h-4 ${quotesLoading ? 'animate-spin' : ''}`} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Refresh market data</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Animated Ticker Tape */}
        <TickerTape />

        {/* Search Section */}
        <div className="relative">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search stocks (e.g., AAPL, Microsoft) - Press Enter to add"
              value={searchSymbol}
              onChange={(e) => {
                setSearchSymbol(e.target.value);
                setShowSuggestions(e.target.value.length > 0);
              }}
              onFocus={() => setShowSuggestions(searchSymbol.length > 0)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchSymbol.trim()) {
                  e.preventDefault();
                  handleAddStock({ symbol: searchSymbol.toUpperCase(), name: searchSymbol.toUpperCase() });
                }
              }}
              className="pl-10 text-sm"
              data-testid="input-stock-search"
            />
          </div>
          
          {/* Suggestions Dropdown */}
          {showSuggestions && filteredSuggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 z-10 bg-background border rounded-md mt-1 shadow-lg">
              <div className="max-h-48 overflow-y-auto">
                {filteredSuggestions.slice(0, 5).map((stock) => (
                  <button
                    key={stock.symbol}
                    className="w-full px-3 py-2 text-left hover:bg-muted transition-colors flex items-center justify-between text-sm"
                    onClick={() => handleAddStock(stock)}
                    data-testid={`suggestion-${stock.symbol.toLowerCase()}`}
                  >
                    <div>
                      <div className="font-medium">{stock.symbol}</div>
                      <div className="text-xs text-muted-foreground truncate">{stock.name}</div>
                    </div>
                    <Plus className="w-4 h-4 text-muted-foreground" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Stock Display */}
        <div className="space-y-3">
          {watchlist.length === 0 ? (
            <div className="space-y-3">
              <div className="text-center py-2">
                <p className="text-sm font-medium">Top Tech Stocks</p>
                <p className="text-xs text-muted-foreground">
                  Click stocks to view detailed charts • Add to watchlist to track favorites
                </p>
              </div>
              {quotesLoading && stockQuotes.length === 0 ? (
                [...Array(5)].map((_, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-muted rounded w-16 "></div>
                      <div className="h-3 bg-muted rounded w-32 "></div>
                      <div className="h-6 bg-muted rounded w-24 "></div>
                    </div>
                    <div className="w-24 h-12 bg-muted rounded "></div>
                  </div>
                ))
              ) : (
                stockQuotes.map((quote) => renderStockItem(quote, false))
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="text-center py-2">
                <p className="text-sm font-medium">Your Watchlist</p>
                <p className="text-xs text-muted-foreground">
                  Click stocks to view detailed charts • Remove with trash icon
                </p>
              </div>
              {watchlist.map((watchItem) => {
                const quote = stockQuotes.find(q => q.symbol === watchItem.symbol);
                
                if (!quote) {
                  return (
                    <div
                      key={watchItem.id}
                      className="flex items-center justify-between p-4 border rounded-lg bg-muted/50"
                      data-testid={`loading-stock-item-${watchItem.symbol.toLowerCase()}`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-medium">{watchItem.symbol}</span>
                          <Badge variant="outline" className="text-xs">Loading...</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{watchItem.name}</p>
                        <div className="mt-2 space-y-1">
                          <div className="h-4 bg-muted rounded w-20 "></div>
                          <div className="h-3 bg-muted rounded w-32 "></div>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveStock(watchItem.id)}
                        className="text-muted-foreground hover:text-destructive"
                        data-testid={`button-remove-${watchItem.symbol.toLowerCase()}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  );
                }
                
                return renderStockItem(quote, true, watchItem.id);
              })}
            </div>
          )}
        </div>

        {(addStockMutation.isPending || removeStockMutation.isPending) && (
          <div className="text-center py-2">
            <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              {addStockMutation.isPending ? 'Adding to watchlist...' : 'Removing from watchlist...'}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}