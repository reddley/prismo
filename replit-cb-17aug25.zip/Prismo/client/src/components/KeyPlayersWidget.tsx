import { useQuery } from "@tanstack/react-query";
import { Building2, User, Users, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface EntityCard {
  id: string;
  name: string;
  type: 'company' | 'person' | 'organization';
  imageUrl?: string;
  logoUrl?: string;
  profilePictureUrl?: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  lastMentioned: string;
  description?: string;
  industry?: string;
  mentionCount: number;
}

export function KeyPlayersWidget() {
  // Optimized: Use single dashboard endpoint instead of N+1 queries
  const { data: dashboardData, isLoading } = useQuery<{
    insights: any[];
    keyPlayers: EntityCard[];
    metrics: any;
  }>({
    queryKey: ['/api/dashboard/data'],
  });

  const allEntities: EntityCard[] = dashboardData?.keyPlayers || [];

  const getEntityIcon = (type: string) => {
    switch (type) {
      case 'company': return <Building2 className="h-4 w-4" />;
      case 'person': return <User className="h-4 w-4" />;
      case 'organization': return <Users className="h-4 w-4" />;
      default: return <Building2 className="h-4 w-4" />;
    }
  };

  const getEntityImage = (entity: EntityCard) => {
    switch (entity.type) {
      case 'company': return entity.logoUrl;
      case 'person': return entity.profilePictureUrl;
      case 'organization': return entity.logoUrl;
      default: return undefined;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getEntityLink = (entity: EntityCard) => {
    switch (entity.type) {
      case 'company': return `/companies`;
      case 'person': return `/people`;
      case 'organization': return `/organizations`;
      default: return `/companies`;
    }
  };

  if (isLoading) {
    return (
      <Card data-testid="key-players-widget">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Users className="h-4 w-4" />
            Key Players
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="">
                <div className="bg-muted rounded-lg p-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-muted-foreground/20 rounded-full" />
                    <div className="flex-1">
                      <div className="h-3 bg-muted-foreground/20 rounded mb-1" />
                      <div className="h-2 bg-muted-foreground/20 rounded w-2/3" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="key-players-widget">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <Users className="h-4 w-4" />
          Key Players
          <Badge variant="secondary" className="text-xs">
            {allEntities.length}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {allEntities.length === 0 ? (
          <div className="text-center py-8">
            <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-sm text-muted-foreground mb-2">No key players discovered yet</p>
            <p className="text-xs text-muted-foreground">
              High-impact insights will automatically create entity profiles
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {allEntities.map((entity) => (
                <div 
                  key={`${entity.type}-${entity.id}`}
                  className="group bg-muted/50 hover:bg-muted rounded-lg p-2 transition-colors border border-transparent hover:border-border relative"
                  data-testid={`entity-card-${entity.type}-${entity.id}`}
                >
                  <div className="flex items-center gap-2">
                    {/* Clickable Avatar */}
                    <Link href={`/dossiers`}>
                      <div className="relative cursor-pointer">
                        <Avatar className="h-8 w-8 hover:ring-1 hover:ring-primary/30 transition-all">
                          <AvatarImage 
                            src={getEntityImage(entity)} 
                            alt={entity.name}
                            className="object-cover aspect-square"
                          />
                          <AvatarFallback className="text-xs">
                            {getEntityIcon(entity.type)}
                          </AvatarFallback>
                        </Avatar>
                        {/* Priority indicator dot */}
                        <div 
                          className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-background ${getPriorityColor(entity.priority)}`}
                          title={`${entity.priority} priority`}
                        />
                      </div>
                    </Link>
                    <div className="flex-1 min-w-0">
                      {/* Clickable Name */}
                      <Link href={`/decks`}>
                        <div className="font-medium text-xs truncate hover:text-primary transition-colors cursor-pointer">
                          {entity.name}
                        </div>
                      </Link>
                      <div className="text-xs text-muted-foreground truncate">
                        {entity.industry || 
                         (entity.type === 'person' ? 'Executive' : 
                          entity.type === 'organization' ? 'Organization' : 'Company')}
                      </div>
                    </div>
                    {/* Mentions with trending icon instead of external link */}
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <TrendingUp className="h-3 w-3" />
                      {entity.mentionCount || 0}
                    </div>
                  </div>
                </div>
            ))}
          </div>
        )}
        
        {allEntities.length > 0 && (
          <div className="mt-3 pt-3 border-t">
            <Link href="/decks">
              <button 
                className="w-full text-xs text-muted-foreground hover:text-foreground transition-colors py-1"
                data-testid="view-all-dossiers"
              >
                View All Decks →
              </button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}