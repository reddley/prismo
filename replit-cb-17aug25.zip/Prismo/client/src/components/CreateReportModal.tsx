import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Plus, X, Code, Eye, Settings, Layers, Zap, BarChart3 } from "lucide-react";

interface CreateReportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ReportConfig {
  name: string;
  description: string;
  category: string;
  useCase: string;
  tags: string[];
  builderConfigJson: {
    version: "1.0.0";
    components: Array<{
      id: string;
      type: string;
      props: Record<string, any>;
      layout: { x: number; y: number; w: number; h: number };
    }>;
    dataSource?: {
      type: string;
      endpoint: string;
      refreshInterval: number;
    };
    styling: {
      theme: string;
      colors: string[];
    };
  };
  previewData?: any;
}

const categories = [
  "Analytics", "Market Intelligence", "Financial", "Operational", 
  "Social Media", "Technology", "Custom"
];

const useCases = [
  "market-analysis", "competitive-tracking", "trend-monitoring", 
  "performance-dashboard", "social-listening", "risk-assessment"
];

const dslTemplates = {
  basic: {
    version: "1.0.0",
    components: [
      {
        id: "chart-1",
        type: "chart",
        props: {
          chartType: "line",
          title: "Sample Chart",
          dataKey: "value"
        },
        layout: { x: 0, y: 0, w: 6, h: 4 }
      },
      {
        id: "metric-1", 
        type: "metric",
        props: {
          label: "Key Metric",
          value: "${data.totalValue}",
          format: "number"
        },
        layout: { x: 6, y: 0, w: 3, h: 2 }
      }
    ],
    styling: {
      theme: "default",
      colors: ["#8884d8", "#82ca9d", "#ffc658"]
    }
  },
  dashboard: {
    version: "1.0.0",
    components: [
      {
        id: "kpi-grid",
        type: "kpi-grid",
        props: {
          metrics: [
            { label: "Revenue", value: "${data.revenue}", format: "currency" },
            { label: "Growth", value: "${data.growth}", format: "percentage" },
            { label: "Users", value: "${data.users}", format: "number" }
          ]
        },
        layout: { x: 0, y: 0, w: 12, h: 2 }
      },
      {
        id: "trend-chart",
        type: "chart",
        props: {
          chartType: "area",
          title: "Trend Analysis",
          dataKey: "trend"
        },
        layout: { x: 0, y: 2, w: 8, h: 4 }
      },
      {
        id: "summary-card",
        type: "summary",
        props: {
          title: "Key Insights",
          content: "${data.summary}"
        },
        layout: { x: 8, y: 2, w: 4, h: 4 }
      }
    ],
    styling: {
      theme: "modern",
      colors: ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"]
    }
  }
};

export function CreateReportModal({ open, onOpenChange }: CreateReportModalProps) {
  const [step, setStep] = useState(1);
  const [config, setConfig] = useState<ReportConfig>({
    name: "",
    description: "",
    category: "",
    useCase: "",
    tags: [],
    builderConfigJson: dslTemplates.basic
  });
  const [newTag, setNewTag] = useState("");
  const [configText, setConfigText] = useState(JSON.stringify(dslTemplates.basic, null, 2));
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createBlueprintMutation = useMutation({
    mutationFn: async (blueprintData: any) => {
      const response = await apiRequest('/api/report-blueprints', {
        method: 'POST',
        body: JSON.stringify(blueprintData)
      });
      return response;
    },
    onSuccess: () => {
      toast({ description: "Custom report created successfully!" });
      queryClient.invalidateQueries({ queryKey: ['/api/report-blueprints'] });
      onOpenChange(false);
      setStep(1);
      setConfig({
        name: "",
        description: "",
        category: "",
        useCase: "",
        tags: [],
        builderConfigJson: dslTemplates.basic
      });
    },
    onError: (error) => {
      toast({ description: "Failed to create custom report", variant: "destructive" });
      console.error("Create blueprint error:", error);
    }
  });

  const addTag = () => {
    if (newTag.trim() && !config.tags.includes(newTag.trim())) {
      setConfig(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    setConfig(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
  };

  const handlePrevious = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = async () => {
    try {
      let parsedConfig;
      try {
        parsedConfig = JSON.parse(configText);
      } catch (e) {
        toast({ description: "Invalid JSON configuration", variant: "destructive" });
        return;
      }

      const blueprintData = {
        ...config,
        builderConfigJson: parsedConfig,
        slug: config.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
      };

      await createBlueprintMutation.mutateAsync(blueprintData);
    } catch (error) {
      console.error("Submit error:", error);
    }
  };

  const loadTemplate = (templateKey: keyof typeof dslTemplates) => {
    const template = dslTemplates[templateKey];
    setConfig(prev => ({ ...prev, builderConfigJson: template }));
    setConfigText(JSON.stringify(template, null, 2));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="create-report-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Create Custom Report
          </DialogTitle>
          <DialogDescription>
            Design your own report template with custom layouts, data sources, and visualizations
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress Steps */}
          <div className="flex items-center justify-between">
            {[1, 2, 3, 4].map((stepNum) => (
              <div key={stepNum} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step >= stepNum ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                }`}>
                  {stepNum}
                </div>
                {stepNum < 4 && <div className={`w-12 h-px ${step > stepNum ? 'bg-primary' : 'bg-muted'}`} />}
              </div>
            ))}
          </div>

          {/* Step Content */}
          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Basic Information
                </CardTitle>
                <CardDescription>Define the core details of your custom report</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Report Name</Label>
                    <Input
                      id="name"
                      placeholder="My Custom Report"
                      value={config.name}
                      onChange={(e) => setConfig(prev => ({ ...prev, name: e.target.value }))}
                      data-testid="input-report-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select value={config.category} onValueChange={(value) => setConfig(prev => ({ ...prev, category: value }))}>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(cat => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe what this report displays and its purpose..."
                    value={config.description}
                    onChange={(e) => setConfig(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                    data-testid="textarea-description"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="useCase">Use Case</Label>
                  <Select value={config.useCase} onValueChange={(value) => setConfig(prev => ({ ...prev, useCase: value }))}>
                    <SelectTrigger data-testid="select-use-case">
                      <SelectValue placeholder="Select use case" />
                    </SelectTrigger>
                    <SelectContent>
                      {useCases.map(useCase => (
                        <SelectItem key={useCase} value={useCase}>
                          {useCase.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Tags</Label>
                  <div className="flex gap-2 mb-2 flex-wrap">
                    {config.tags.map(tag => (
                      <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                        {tag}
                        <X 
                          className="w-3 h-3 cursor-pointer" 
                          onClick={() => removeTag(tag)}
                        />
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add tag..."
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addTag()}
                      data-testid="input-tag"
                    />
                    <Button size="sm" onClick={addTag} data-testid="button-add-tag">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="w-4 h-4" />
                  Template Selection
                </CardTitle>
                <CardDescription>Choose a starting template for your report configuration</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => loadTemplate('basic')}>
                    <CardHeader>
                      <CardTitle className="text-sm">Basic Template</CardTitle>
                      <CardDescription className="text-xs">
                        Simple chart and metric layout for getting started
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="text-xs text-muted-foreground">
                        • Line chart component<br/>
                        • Key metric display<br/>
                        • Basic styling
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => loadTemplate('dashboard')}>
                    <CardHeader>
                      <CardTitle className="text-sm">Dashboard Template</CardTitle>
                      <CardDescription className="text-xs">
                        Complete dashboard with KPIs, charts, and summary
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="text-xs text-muted-foreground">
                        • KPI grid layout<br/>
                        • Trend analysis chart<br/>
                        • Summary insights<br/>
                        • Modern styling
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          )}

          {step === 3 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="w-4 h-4" />
                  Configuration Editor
                </CardTitle>
                <CardDescription>Edit the DSL v1 configuration for your report</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="editor" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="editor">JSON Editor</TabsTrigger>
                    <TabsTrigger value="preview">Preview</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="editor" className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="config">DSL Configuration (JSON)</Label>
                      <Textarea
                        id="config"
                        value={configText}
                        onChange={(e) => setConfigText(e.target.value)}
                        rows={20}
                        className="font-mono text-sm"
                        data-testid="textarea-config"
                      />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="preview" className="space-y-4">
                    <div className="border rounded-lg p-4 bg-muted/20">
                      <div className="text-sm text-muted-foreground mb-2">Configuration Preview:</div>
                      <pre className="text-xs overflow-auto max-h-96 bg-background p-3 rounded border">
                        {JSON.stringify(JSON.parse(configText || '{}'), null, 2)}
                      </pre>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}

          {step === 4 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Review & Create
                </CardTitle>
                <CardDescription>Review your report configuration before creating</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm font-medium">Name</div>
                    <div className="text-sm text-muted-foreground">{config.name}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium">Category</div>
                    <div className="text-sm text-muted-foreground">{config.category}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium">Use Case</div>
                    <div className="text-sm text-muted-foreground">
                      {config.useCase.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium">Tags</div>
                    <div className="flex gap-1 flex-wrap">
                      {config.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <div className="text-sm font-medium mb-2">Description</div>
                  <div className="text-sm text-muted-foreground">{config.description}</div>
                </div>
                
                <Separator />
                
                <div>
                  <div className="text-sm font-medium mb-2">Configuration Summary</div>
                  <div className="text-xs text-muted-foreground">
                    {JSON.parse(configText).components?.length || 0} components configured
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Navigation */}
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={handlePrevious} 
              disabled={step === 1}
              data-testid="button-previous"
            >
              Previous
            </Button>
            
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              
              {step < 4 ? (
                <Button 
                  onClick={handleNext}
                  disabled={
                    (step === 1 && (!config.name || !config.category)) ||
                    (step === 3 && !configText.trim())
                  }
                  data-testid="button-next"
                >
                  Next
                </Button>
              ) : (
                <Button 
                  onClick={handleSubmit}
                  disabled={createBlueprintMutation.isPending}
                  data-testid="button-create"
                >
                  {createBlueprintMutation.isPending ? "Creating..." : "Create Report"}
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}