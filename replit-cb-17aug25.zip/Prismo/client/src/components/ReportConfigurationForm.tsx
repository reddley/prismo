import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, AlertCircle, Eye, CheckCircle2 } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface ValidationError {
  field: string;
  message: string;
  code: string;
}

interface ReportTemplate {
  id: string;
  slug: string;
  name: string;
  category: string;
  description?: string;
  inputsSchema: any;
}

interface ReportConfigurationFormProps {
  template: ReportTemplate;
  onInstall: (config: any) => void;
  onPreview?: (config: any) => void;
  isInstalling?: boolean;
  className?: string;
}

export function ReportConfigurationForm({ 
  template, 
  onInstall, 
  onPreview,
  isInstalling = false,
  className 
}: ReportConfigurationFormProps) {
  const [config, setConfig] = useState<Record<string, any>>({});
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [hasValidated, setHasValidated] = useState(false);

  // Initialize config with defaults
  useEffect(() => {
    if (template.inputsSchema?.properties) {
      const defaultConfig: Record<string, any> = {};
      
      Object.entries(template.inputsSchema.properties).forEach(([key, fieldSchema]) => {
        const field = fieldSchema as any;
        if (field.default !== undefined) {
          defaultConfig[key] = field.default;
        }
      });
      
      setConfig(defaultConfig);
    }
  }, [template.inputsSchema]);

  // Preview mutation
  const previewMutation = useMutation({
    mutationFn: async (configData: any) => {
      return apiRequest(`/api/report-templates/${template.slug}/render-sample`, 'POST', {
        config: configData
      });
    },
    onSuccess: (data) => {
      setValidationErrors([]);
      onPreview?.(data);
    },
    onError: (error: any) => {
      if (error.message.includes('400') && error.validationErrors) {
        setValidationErrors(error.validationErrors);
      }
    }
  });

  // Client-side validation
  const validateConfig = (configData: Record<string, any>): ValidationError[] => {
    const errors: ValidationError[] = [];
    
    if (!template.inputsSchema?.properties) return errors;
    
    Object.entries(template.inputsSchema.properties).forEach(([key, fieldSchema]) => {
      const field = fieldSchema as any;
      const value = configData[key];
      
      // Required validation
      if (template.inputsSchema.required?.includes(key)) {
        if (value === undefined || value === null || value === '' || value === 0) {
          errors.push({
            field: key,
            message: `${key} is required`,
            code: 'REQUIRED'
          });
        }
      }
      
      // Type validation
      if (value !== undefined && value !== null && value !== '') {
        if (field.type === 'number' && isNaN(Number(value))) {
          errors.push({
            field: key,
            message: `${key} must be a number`,
            code: 'TYPE_ERROR'
          });
        }
        
        // Range validation for numbers
        if (field.type === 'number' && !isNaN(Number(value))) {
          const numValue = Number(value);
          if (field.minimum !== undefined && numValue < field.minimum) {
            errors.push({
              field: key,
              message: `${key} must be at least ${field.minimum}`,
              code: 'MIN_VALUE'
            });
          }
          if (field.maximum !== undefined && numValue > field.maximum) {
            errors.push({
              field: key,
              message: `${key} must be at most ${field.maximum}`,
              code: 'MAX_VALUE'
            });
          }
        }
        
        // Enum validation
        if (field.enum && !field.enum.includes(value)) {
          errors.push({
            field: key,
            message: `${key} must be one of: ${field.enum.join(', ')}`,
            code: 'INVALID_OPTION'
          });
        }
      }
    });
    
    return errors;
  };

  const handleConfigChange = (key: string, value: any) => {
    const newConfig = { ...config, [key]: value };
    setConfig(newConfig);
    
    // Real-time validation after first submit attempt
    if (hasValidated) {
      const errors = validateConfig(newConfig);
      setValidationErrors(errors);
    }
  };

  const handlePreview = () => {
    const errors = validateConfig(config);
    setValidationErrors(errors);
    setHasValidated(true);
    
    if (errors.length === 0) {
      previewMutation.mutate(config);
    }
  };

  const handleInstall = () => {
    const errors = validateConfig(config);
    setValidationErrors(errors);
    setHasValidated(true);
    
    if (errors.length === 0) {
      onInstall(config);
    }
  };

  const getFieldError = (fieldName: string) => {
    return validationErrors.find(error => error.field === fieldName);
  };

  const renderConfigField = (key: string, fieldSchema: any) => {
    const value = config[key] ?? fieldSchema.default ?? '';
    const error = getFieldError(key);
    const isRequired = template.inputsSchema?.required?.includes(key);

    const fieldName = key.replace(/([A-Z])/g, ' $1').trim();
    const capitalizedName = fieldName.charAt(0).toUpperCase() + fieldName.slice(1);

    const commonProps = {
      id: key,
      'data-testid': `input-${key}`,
    };

    let inputElement;

    switch (fieldSchema.type) {
      case 'number':
        inputElement = (
          <Input
            {...commonProps}
            type="number"
            value={value || ''}
            onChange={(e) => handleConfigChange(key, parseInt(e.target.value) || fieldSchema.default || 0)}
            min={fieldSchema.minimum}
            max={fieldSchema.maximum}
            placeholder={fieldSchema.default ? `Default: ${fieldSchema.default}` : `Enter ${fieldName}`}
            className={error ? 'border-destructive' : ''}
          />
        );
        break;

      case 'string':
        if (fieldSchema.enum) {
          inputElement = (
            <Select 
              value={value || fieldSchema.default || ''} 
              onValueChange={(newValue) => handleConfigChange(key, newValue)}
            >
              <SelectTrigger className={error ? 'border-destructive' : ''} data-testid={`select-${key}`}>
                <SelectValue placeholder={`Select ${fieldName}`} />
              </SelectTrigger>
              <SelectContent>
                {fieldSchema.enum.map((option: string) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          );
        } else {
          inputElement = (
            <Input
              {...commonProps}
              value={value || ''}
              onChange={(e) => handleConfigChange(key, e.target.value)}
              placeholder={fieldSchema.default ? `Default: ${fieldSchema.default}` : `Enter ${fieldName}`}
              className={error ? 'border-destructive' : ''}
            />
          );
        }
        break;

      case 'boolean':
        return (
          <div key={key} className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id={key}
                checked={!!value}
                onCheckedChange={(checked) => handleConfigChange(key, checked)}
                data-testid={`checkbox-${key}`}
              />
              <Label htmlFor={key} className="text-sm font-medium">
                {capitalizedName}
                {isRequired && <span className="text-destructive ml-1">*</span>}
              </Label>
            </div>
            {fieldSchema.description && (
              <p className="text-xs text-muted-foreground ml-6">{fieldSchema.description}</p>
            )}
            {error && (
              <p className="text-xs text-destructive ml-6 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                {error.message}
              </p>
            )}
          </div>
        );

      default:
        inputElement = (
          <Input
            {...commonProps}
            value={value || ''}
            onChange={(e) => handleConfigChange(key, e.target.value)}
            placeholder={`Enter ${fieldName}`}
            className={error ? 'border-destructive' : ''}
          />
        );
    }

    return (
      <div key={key} className="space-y-2">
        <Label htmlFor={key} className="text-sm font-medium">
          {capitalizedName}
          {isRequired && <span className="text-destructive ml-1">*</span>}
        </Label>
        {inputElement}
        {fieldSchema.description && (
          <p className="text-xs text-muted-foreground">{fieldSchema.description}</p>
        )}
        {error && (
          <p className="text-xs text-destructive flex items-center gap-1">
            <AlertCircle className="h-3 w-3" />
            {error.message}
          </p>
        )}
      </div>
    );
  };

  const hasRequiredFields = template.inputsSchema?.required?.length > 0;
  const hasFields = template.inputsSchema?.properties && Object.keys(template.inputsSchema.properties).length > 0;

  if (!hasFields) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="text-lg">Ready to Install</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            This template doesn't require any configuration.
          </p>
          <div className="flex gap-2 pt-2">
            <Button 
              onClick={() => onInstall({})}
              disabled={isInstalling}
              className="flex-1"
              data-testid="button-install-report"
            >
              {isInstalling ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Installing...
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Install Report
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-lg">Configure {template.name}</CardTitle>
        {template.description && (
          <p className="text-sm text-muted-foreground">{template.description}</p>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Validation Summary */}
        {validationErrors.length > 0 && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Please fix {validationErrors.length} validation error{validationErrors.length > 1 ? 's' : ''} before proceeding.
            </AlertDescription>
          </Alert>
        )}

        {/* Form Fields */}
        <div className="space-y-4">
          {Object.entries(template.inputsSchema.properties).map(([key, fieldSchema]) => 
            renderConfigField(key, fieldSchema as any)
          )}
        </div>

        {/* Required Fields Notice */}
        {hasRequiredFields && (
          <p className="text-xs text-muted-foreground">
            Fields marked with <span className="text-destructive">*</span> are required.
          </p>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2 pt-2">
          {onPreview && (
            <Button 
              variant="outline" 
              onClick={handlePreview}
              disabled={previewMutation.isPending}
              data-testid="button-preview-report"
            >
              {previewMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Previewing...
                </>
              ) : (
                <>
                  <Eye className="h-4 w-4 mr-2" />
                  Preview
                </>
              )}
            </Button>
          )}
          
          <Button 
            onClick={handleInstall}
            disabled={isInstalling || validationErrors.length > 0}
            className="flex-1"
            data-testid="button-install-report"
          >
            {isInstalling ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Installing...
              </>
            ) : (
              <>
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Install Report
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}