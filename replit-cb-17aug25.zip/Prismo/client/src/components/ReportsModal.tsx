import { useState, useRef, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Search, Star, Plus, TrendingUp, DollarSign, Users, FileText, Filter, Zap } from 'lucide-react';
import { StaticChartPreview } from '@/components/charts/StaticChartPreview';
import { cn } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CreateReportModal } from './CreateReportModal';

interface ReportTemplate {
  id: string;
  slug: string;
  name: string;
  category: string;
  description?: string;
  tags?: string[];
  isFeatured: boolean;
  popularityScore: number;
  version: number;
  inputsSchema: any;
  previewImg?: string;
  createdAt: string;
  resultType?: string;
  useCase?: string;
}

interface SearchResult {
  id: string;
  slug?: string;
  name: string;
  description?: string;
  useCase?: string;
  tags?: string[];
  resultType: 'template' | 'blueprint';
  createdAt: string;
  inputsSchema?: any;
}

interface LibraryResponse {
  groups: Record<string, ReportTemplate[]>;
  pagination: {
    hasMore: boolean;
    nextCursor: string | null;
    limit: number;
  };
  meta: {
    totalTemplates: number;
    groupCount: number;
  };
}

interface ReportsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onInstallTemplate?: (template: ReportTemplate) => void;
}

type SortOption = 'popularity' | 'recent' | 'custom';

const USE_CASES = [
  { id: 'all', label: 'All Templates', icon: FileText },
  { id: 'Intelligence', label: 'Intelligence', icon: Users },
  { id: 'Finance', label: 'Finance', icon: DollarSign },
  { id: 'Analytics', label: 'Analytics', icon: TrendingUp },
];

export function ReportsModal({ open, onOpenChange, onInstallTemplate }: ReportsModalProps) {
  const [selectedUseCase, setSelectedUseCase] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('popularity');
  const [cursor, setCursor] = useState<string | null>(null);
  const [allTemplates, setAllTemplates] = useState<Record<string, ReportTemplate[]>>({});
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState("browse");
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Build query parameters
  const queryParams = new URLSearchParams();
  if (selectedUseCase !== 'all') queryParams.set('useCase', selectedUseCase);
  if (searchQuery) queryParams.set('q', searchQuery);
  if (sortBy) queryParams.set('sortBy', sortBy);
  if (cursor) queryParams.set('cursor', cursor);
  queryParams.set('limit', '20');

  const { data: libraryData, isLoading, error } = useQuery<LibraryResponse>({
    queryKey: [`/api/report-templates/library?${queryParams.toString()}`],
    enabled: open,
  });

  // Merge new results with existing ones for infinite scroll
  const displayGroups = cursor && libraryData ? {
    ...allTemplates,
    ...Object.entries(libraryData.groups).reduce((acc, [category, templates]) => {
      acc[category] = [...(allTemplates[category] || []), ...templates];
      return acc;
    }, {} as Record<string, ReportTemplate[]>)
  } : libraryData?.groups || {};

  // Update local state when new data arrives
  if (libraryData && (!cursor || Object.keys(allTemplates).length === 0)) {
    if (JSON.stringify(displayGroups) !== JSON.stringify(allTemplates)) {
      setAllTemplates(displayGroups);
    }
  }

  const loadMore = useCallback(() => {
    if (libraryData?.pagination.hasMore && libraryData?.pagination.nextCursor) {
      setCursor(libraryData.pagination.nextCursor);
    }
  }, [libraryData]);

  // Handle scroll to bottom for infinite scroll
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - scrollTop <= clientHeight * 1.5 && libraryData?.pagination.hasMore) {
      loadMore();
    }
  }, [loadMore, libraryData?.pagination.hasMore]);

  // Reset state when use case, search, or sort changes
  const handleUseCaseChange = (useCase: string) => {
    setSelectedUseCase(useCase);
    setCursor(null);
    setAllTemplates({});
  };

  const handleSearchChange = async (query: string) => {
    setSearchQuery(query);
    setCursor(null);
    setAllTemplates({});
    
    if (query.trim()) {
      setIsSearching(true);
      try {
        const response = await apiRequest(`/api/search?q=${encodeURIComponent(query)}&useCase=${selectedUseCase !== 'all' ? selectedUseCase : ''}`);
        setSearchResults(response.results || []);
      } catch (error) {
        console.error('Search failed:', error);
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    } else {
      setSearchResults([]);
    }
  };

  const handleKeyDown = async (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchQuery.trim() && searchResults.length > 0) {
      // Quick install first configless result
      const firstTemplate = searchResults.find(r => r.resultType === 'template' && (!r.inputsSchema || Object.keys(r.inputsSchema).length === 0));
      if (firstTemplate && onInstallTemplate) {
        await recordTelemetry('report_install', firstTemplate.slug || firstTemplate.id, firstTemplate.useCase, firstTemplate.tags);
        onInstallTemplate(firstTemplate as ReportTemplate);
      }
    }
  };

  const recordTelemetry = async (event: string, slugOrId: string, useCase?: string, tags?: string[]) => {
    try {
      await apiRequest('/api/telemetry', 'POST', {
        event,
        slugOrId,
        use_case: useCase,
        tags: tags || [],
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Telemetry failed:', error);
    }
  };

  const handleSortChange = (sort: SortOption) => {
    setSortBy(sort);
    setCursor(null);
    setAllTemplates({});
  };

  const getSortLabel = (sort: SortOption) => {
    switch (sort) {
      case 'popularity': return 'Popularity';
      case 'recent': return 'Recent';
      case 'custom': return 'Custom';
      default: return 'Popularity';
    }
  };

  const handleInstall = async (template: ReportTemplate, event?: React.MouseEvent) => {
    if (!onInstallTemplate) return;
    
    // Get the clicked element position for drop animation
    const clickedElement = event?.currentTarget as HTMLElement;
    if (clickedElement) {
      // Add installation feedback animation
      clickedElement.style.transform = 'scale(0.95)';
      clickedElement.style.transition = 'transform 0.1s ease-out';
      
      // Reset scale after animation
      setTimeout(() => {
        clickedElement.style.transform = '';
      }, 100);
    }
    
    // Install immediately (under 200ms target)
    try {
      await onInstallTemplate(template);
      // Close modal immediately after successful installation
      onOpenChange(false);
    } catch (error) {
      console.error('Failed to install template:', error);
      // Modal stays open on error so user can retry
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Intelligence': return Users;
      case 'Finance': return DollarSign;
      case 'Analytics': return TrendingUp;
      default: return FileText;
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-6xl h-[80vh] flex flex-col p-0">
          <DialogHeader className="px-6 py-4 border-b flex-shrink-0">
            <DialogTitle>Reports Library</DialogTitle>
            
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mt-4">
                <TabsTrigger value="browse" data-testid="tab-browse">Browse Templates</TabsTrigger>
                <TabsTrigger value="create" data-testid="tab-create">
                  <Zap className="w-4 h-4 mr-2" />
                  Create Custom Report
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="browse" className="mt-4">
                <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search templates & blueprints..."
                value={searchQuery}
                onChange={(e) => handleSearchChange(e.target.value)}
                onKeyDown={handleKeyDown}
                className="pl-10"
                data-testid="input-search-templates"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2" data-testid="button-sort-filter">
                  <Filter className="h-4 w-4" />
                  {getSortLabel(sortBy)}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem 
                  onClick={() => handleSortChange('popularity')}
                  data-testid="sort-popularity"
                >
                  Popularity
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => handleSortChange('recent')}
                  data-testid="sort-recent"
                >
                  Recent
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => handleSortChange('custom')}
                  data-testid="sort-custom"
                >
                  Custom
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
                </div>
              </TabsContent>
              
              <TabsContent value="create" className="mt-4">
                <div className="p-4 text-center">
                  <div className="mb-4">
                    <Zap className="w-12 h-12 mx-auto text-primary mb-2" />
                    <h3 className="text-lg font-semibold">Create Your Custom Report</h3>
                    <p className="text-muted-foreground">Design a personalized report template with custom layouts and data sources</p>
                  </div>
                  <Button 
                    onClick={() => setShowCreateModal(true)}
                    className="gap-2"
                    data-testid="button-open-create-modal"
                  >
                    <Plus className="w-4 h-4" />
                    Start Creating
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </DialogHeader>
        
        {activeTab === "browse" && (
        <div className="flex flex-1 min-h-0 overflow-hidden">
          {/* Left Navigation */}
          <div className="w-64 border-r bg-muted/20 p-4 flex-shrink-0">
            <div className="space-y-2">
              {USE_CASES.map((useCase) => {
                const IconComponent = useCase.icon;
                return (
                  <Button
                    key={useCase.id}
                    variant={selectedUseCase === useCase.id ? 'secondary' : 'ghost'}
                    className={cn(
                      'w-full justify-start gap-3 text-left',
                      selectedUseCase === useCase.id && 'bg-secondary'
                    )}
                    onClick={() => handleUseCaseChange(useCase.id)}
                    data-testid={`button-use-case-${useCase.id}`}
                  >
                    <IconComponent className="h-4 w-4" />
                    {useCase.label}
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Right Content Area */}
          <div className="flex-1 min-h-0 overflow-hidden">
            <ScrollArea 
              className="h-full w-full"
              ref={scrollAreaRef}
              onScrollCapture={handleScroll}
              data-testid="scroll-area-templates"
            >
              <div className="p-6">
              {/* Search Results */}
              {searchQuery.trim() && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-4">
                    Search Results {isSearching ? '(searching...)' : `(${searchResults.length})`}
                  </h3>
                  {isSearching ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="p-4 border rounded-lg animate-pulse">
                          <div className="h-5 bg-muted rounded w-48 mb-2" />
                          <div className="h-4 bg-muted rounded w-full" />
                        </div>
                      ))}
                    </div>
                  ) : searchResults.length > 0 ? (
                    <div className="space-y-4">
                      {searchResults.map((result) => (
                        <div 
                          key={result.id} 
                          className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                          onMouseEnter={() => recordTelemetry('report_preview_hover', result.slug || result.id, result.useCase, result.tags)}
                          onClick={(e) => {
                            if (result.resultType === 'template') {
                              handleInstall(result as ReportTemplate, e);
                            } else {
                              recordTelemetry('blueprint_create', result.id, result.useCase, result.tags);
                              // Handle blueprint creation
                            }
                          }}
                          data-testid={`search-result-${result.id}`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-medium">{result.name}</h4>
                            <Badge variant={result.resultType === 'template' ? 'secondary' : 'outline'}>
                              {result.resultType}
                            </Badge>
                          </div>
                          {result.description && (
                            <p className="text-sm text-muted-foreground mb-3">{result.description}</p>
                          )}
                          <div className="flex gap-2">
                            {result.tags?.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Search className="h-8 w-8 mx-auto mb-2" />
                      <p>No results found for "{searchQuery}"</p>
                    </div>
                  )}
                  <Separator className="mt-6" />
                </div>
              )}
              
              {/* Regular Template Library */}
              {!searchQuery.trim() && (
                isLoading && Object.keys(displayGroups).length === 0 ? (
                <div className="space-y-6">
                  {/* Loading Skeletons */}
                  {[1, 2, 3].map((i) => (
                    <div key={i}>
                      <div className="h-6 bg-muted rounded w-32 mb-4" />
                      <div className="grid gap-4">
                        {[1, 2, 3].map((j) => (
                          <div key={j} className="p-4 border rounded-lg">
                            <div className="flex items-start justify-between mb-2">
                              <div className="h-5 bg-muted rounded w-48" />
                              <div className="h-4 bg-muted rounded w-16" />
                            </div>
                            <div className="h-4 bg-muted rounded w-full mb-3" />
                            <div className="flex gap-2">
                              <div className="h-5 bg-muted rounded w-16" />
                              <div className="h-5 bg-muted rounded w-20" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                ) : error ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Error loading templates. Please try again.
                  </div>
                ) : Object.keys(displayGroups).length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No templates found matching your criteria.
                  </div>
                ) : (
                <div className="space-y-8">
                  {Object.entries(displayGroups).map(([category, templates]) => {
                    const IconComponent = getCategoryIcon(category);
                    return (
                      <div key={category}>
                        <div className="flex items-center gap-3 mb-4">
                          <IconComponent className="h-5 w-5 text-primary" />
                          <h3 className="text-lg font-semibold">{category}</h3>
                          <Badge variant="secondary" className="ml-2">
                            {templates.length}
                          </Badge>
                        </div>
                        
                        <div className="grid gap-4">
                          {templates.map((template) => (
                            <div
                              key={template.id}
                              className="p-4 border rounded-lg hover:shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all duration-150 bg-card cursor-pointer select-none"
                              data-testid={`card-template-${template.slug}`}
                              onMouseEnter={() => recordTelemetry('report_preview_hover', template.slug, template.useCase || template.category, template.tags)}
                              onClick={(e) => {
                                recordTelemetry('report_install', template.slug, template.useCase || template.category, template.tags);
                                handleInstall(template, e);
                              }}
                            >
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-medium">{template.name}</h4>
                                  {template.isFeatured && (
                                    <Star className="h-4 w-4 text-yellow-500 fill-current" />
                                  )}
                                </div>
                                <div className="flex items-center gap-2">
                                  <StaticChartPreview 
                                    category={template.category}
                                    name={template.name}
                                    tags={template.tags}
                                  />
                                </div>
                              </div>
                              
                              {template.description && (
                                <p className="text-sm text-muted-foreground mb-3">
                                  {template.description}
                                </p>
                              )}
                              
                              <div className="flex items-center justify-between">
                                <div className="flex flex-wrap gap-1">
                                  {template.tags?.slice(0, 3).map((tag) => (
                                    <Badge key={tag} variant="secondary" className="text-xs pointer-events-none">
                                      {tag}
                                    </Badge>
                                  ))}
                                  {(template.tags?.length || 0) > 3 && (
                                    <Badge variant="secondary" className="text-xs pointer-events-none">
                                      +{(template.tags?.length || 0) - 3}
                                    </Badge>
                                  )}
                                </div>
                                <div className="text-xs text-muted-foreground font-medium pointer-events-none">
                                  Click to install
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        
                        {category !== Object.keys(displayGroups)[Object.keys(displayGroups).length - 1] && (
                          <Separator className="mt-6" />
                        )}
                      </div>
                    );
                  })}
                  
                  {/* Load More Indicator */}
                  {isLoading && cursor && (
                    <div className="text-center py-4 text-muted-foreground">
                      Loading more templates...
                    </div>
                  )}
                  
                  {libraryData?.pagination.hasMore && !isLoading && (
                    <div className="text-center py-4">
                      <Button variant="outline" onClick={loadMore} data-testid="button-load-more">
                        Load More Templates
                      </Button>
                    </div>
                  )}
                </div>
                )
              )}
              </div>
            </ScrollArea>
          </div>
        </div>
        )}
      </DialogContent>
      
    </Dialog>
    
    <CreateReportModal 
      open={showCreateModal} 
      onOpenChange={setShowCreateModal} 
    />
    </>
  );
}