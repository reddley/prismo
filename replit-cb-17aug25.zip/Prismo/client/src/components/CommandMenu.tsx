import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  CommandDialog,
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  Plus, 
  TrendingUp, 
  Eye, 
  BarChart3, 
  FileText,
  Settings,
  User,
  Home,
  AlertCircle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ReportTemplate {
  id: string;
  slug: string;
  name: string;
  category: string;
  version: string;
  inputsSchema: any;
}

interface CommandMenuProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Telemetry function to emit events
function emitTelemetry(event: string, data: any) {
  console.log(`[TELEMETRY] ${event}:`, data);
  // In a real app, this would send to analytics service
}

export function CommandMenu({ open, onOpenChange }: CommandMenuProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch report templates for the Reports section
  const { data: templates = [] } = useQuery<ReportTemplate[]>({
    queryKey: ['/api/report-templates'],
    select: (data: any) => data.templates || [],
  });

  // Install report mutation
  const installMutation = useMutation({
    mutationFn: async (templateSlug: string) => {
      return apiRequest(`/api/installed-reports`, 'POST', { templateSlug });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/home'] });
      queryClient.invalidateQueries({ queryKey: ['/api/installed-reports'] });
      toast({
        title: "Report Installed",
        description: "The report has been added to your dashboard.",
      });
      onOpenChange(false);
    },
    onError: (error: any) => {
      console.error('Install error:', error);
      toast({
        title: "Installation Failed",
        description: error.message || "Failed to install report. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Emit telemetry when menu opens/closes
  useEffect(() => {
    if (open) {
      emitTelemetry('search_open', { timestamp: Date.now() });
    }
  }, [open]);

  // Get template icon
  const getTemplateIcon = (slug: string) => {
    switch (slug) {
      case 'recent-headlines':
        return <FileText className="h-4 w-4" />;
      case 'watchlist':
        return <Eye className="h-4 w-4" />;
      case 'market-movers':
        return <TrendingUp className="h-4 w-4" />;
      default:
        return <BarChart3 className="h-4 w-4" />;
    }
  };

  // Check if template requires inputs
  const requiresInputs = (template: ReportTemplate) => {
    const schema = template.inputsSchema;
    return schema && typeof schema === 'object' && 
           schema.properties && Object.keys(schema.properties).length > 0;
  };

  // Handle template installation
  const handleInstallTemplate = async (template: ReportTemplate) => {
    if (requiresInputs(template)) {
      // TODO: Open InstallReportModal for templates with required inputs
      toast({
        title: "Configuration Required",
        description: `${template.name} requires configuration. Modal support coming soon.`,
        variant: "default",
      });
      return;
    }

    // Install immediately for templates without required inputs
    emitTelemetry('search_install_quick', { 
      template_slug: template.slug,
      timestamp: Date.now()
    });
    
    installMutation.mutate(template.slug);
  };

  // Filter templates based on search query
  const filteredTemplates = templates.filter(template =>
    template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    template.slug.toLowerCase().includes(searchQuery.toLowerCase()) ||
    template.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Navigation actions
  const navigationActions = [
    {
      id: 'home',
      label: 'Go to Home',
      icon: <Home className="h-4 w-4" />,
      action: () => {
        window.location.href = '/';
        onOpenChange(false);
      }
    },
    {
      id: 'search',
      label: 'Go to Search',
      icon: <Search className="h-4 w-4" />,
      action: () => {
        window.location.href = '/search';
        onOpenChange(false);
      }
    },
    {
      id: 'settings',
      label: 'Go to Settings',
      icon: <Settings className="h-4 w-4" />,
      action: () => {
        window.location.href = '/settings';
        onOpenChange(false);
      }
    },
    {
      id: 'profile',
      label: 'Go to Profile',
      icon: <User className="h-4 w-4" />,
      action: () => {
        window.location.href = '/profile';
        onOpenChange(false);
      }
    }
  ];

  // Filter navigation actions based on search query
  const filteredNavigation = navigationActions.filter(action =>
    action.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <Command className="rounded-lg border shadow-md">
        <CommandInput
          placeholder="Search reports, navigation, and more..."
          value={searchQuery}
          onValueChange={setSearchQuery}
          data-testid="command-menu-input"
        />
        <CommandList>
          <CommandEmpty>
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <Search className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                No results found for "{searchQuery}"
              </p>
            </div>
          </CommandEmpty>

          {/* Reports Section */}
          {filteredTemplates.length > 0 && (
            <CommandGroup heading="Reports" data-testid="command-group-reports">
              {filteredTemplates.map((template) => (
                <CommandItem
                  key={template.id}
                  value={`report-${template.slug}`}
                  onSelect={() => handleInstallTemplate(template)}
                  className="hover-readable"
                  data-testid={`command-item-report-${template.slug}`}
                >
                  <div className="flex items-center gap-3 flex-1">
                    <div className="flex-shrink-0">
                      {getTemplateIcon(template.slug)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{template.name}</span>
                        <Badge variant="secondary" className="text-xs">
                          v{template.version}
                        </Badge>
                        {requiresInputs(template) && (
                          <Badge variant="outline" className="text-xs">
                            <Settings className="h-3 w-3 mr-1" />
                            Config
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground capitalize">
                        {template.category}
                      </p>
                    </div>
                    <div className="flex-shrink-0">
                      <Plus className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          )}

          {/* Navigation Section */}
          {filteredNavigation.length > 0 && (
            <CommandGroup heading="Navigation" data-testid="command-group-navigation">
              {filteredNavigation.map((action) => (
                <CommandItem
                  key={action.id}
                  value={`nav-${action.id}`}
                  onSelect={action.action}
                  className="hover-readable"
                  data-testid={`command-item-nav-${action.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0">
                      {action.icon}
                    </div>
                    <span>{action.label}</span>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          )}
        </CommandList>
      </Command>
    </CommandDialog>
  );
}