import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { UserProvider } from "@/hooks/use-user";
import { Sidebar } from "@/components/layout/sidebar";
import Dashboard from "@/pages/dashboard";
import Home from "@/pages/home";
import SearchPage from "@/pages/search";
import Sources from "@/pages/sources";
import Settings from "@/pages/settings";
import ProfilePage from "@/pages/profile";
import NotFound from "@/pages/not-found";
import Companies from "@/pages/companies";
import People from "@/pages/people";
import Organizations from "@/pages/organizations";
import Decks from "@/pages/decks";
import IntelligentAlerts from "@/pages/IntelligentAlerts";
import ObservabilityDashboard from "@/pages/ObservabilityDashboard";
import FeatureFlagsPage from "@/pages/FeatureFlagsPage";
import { CompanyProfile } from "@/pages/CompanyProfile";
import { PersonProfile } from "@/pages/PersonProfile";
import { OrganizationProfile } from "@/pages/OrganizationProfile";
import { useState } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/search" component={SearchPage} />
      <Route path="/companies" component={Companies} />
      <Route path="/companies/:id" component={CompanyProfile} />
      <Route path="/people" component={People} />
      <Route path="/people/:id" component={PersonProfile} />
      <Route path="/organizations" component={Organizations} />
      <Route path="/organizations/:id" component={OrganizationProfile} />
      <Route path="/decks" component={Decks} />
      <Route path="/alerts" component={IntelligentAlerts} />
      <Route path="/sources" component={Sources} />
      <Route path="/observability" component={ObservabilityDashboard} />
      <Route path="/feature-flags" component={FeatureFlagsPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [logoUrl, setLogoUrl] = useState<string | null>(null);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark">
        <UserProvider>
          <TooltipProvider>
            <div className="flex h-screen overflow-hidden bg-background text-foreground">
              <Sidebar logoUrl={logoUrl} />
              <div className="flex-1 flex flex-col overflow-hidden">
                <Router />
              </div>
            </div>
            <Toaster />
          </TooltipProvider>
        </UserProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
