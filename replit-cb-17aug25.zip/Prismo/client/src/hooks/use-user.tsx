import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@shared/schema';

interface UserContextType {
  user: User | null;
  isLoading: boolean;
  isAdmin: boolean;
  updateUser: (updates: Partial<User>) => Promise<void>;
  setUser: (user: User | null) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

interface UserProviderProps {
  children: ReactNode;
}

export function UserProvider({ children }: UserProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load user from API
    const loadUser = async () => {
      try {
        const response = await fetch('/api/user/profile');
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        } else {
          console.error('Failed to load user profile');
        }
      } catch (error) {
        console.error('Failed to load user:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
  }, []);

  const updateUser = async (updates: Partial<User>) => {
    if (user) {
      try {
        const response = await fetch('/api/user/profile', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(updates),
        });
        
        if (response.ok) {
          const updatedUser = await response.json();
          setUser(updatedUser);
        } else {
          console.error('Failed to update user profile');
        }
      } catch (error) {
        console.error('Error updating user:', error);
      }
    }
  };

  const isAdmin = user?.role === 'admin';

  return (
    <UserContext.Provider 
      value={{ 
        user, 
        isLoading, 
        isAdmin, 
        updateUser, 
        setUser 
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}