import { useState, useRef, useCallback } from 'react';

interface PreviewState {
  isVisible: boolean;
  slug: string | null;
  position: { x: number; y: number } | null;
}

export function useChartPreview() {
  const [previewState, setPreviewState] = useState<PreviewState>({
    isVisible: false,
    slug: null,
    position: null
  });
  
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const prefetchCache = useRef<Set<string>>(new Set());

  // Debounced prefetch on hover
  const handleHoverStart = useCallback((slug: string, event?: React.MouseEvent) => {
    // Clear existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Prefetch data after 300ms hover
    timeoutRef.current = setTimeout(() => {
      if (!prefetchCache.current.has(slug)) {
        fetch(`/api/report-templates/${slug}/preview`)
          .then(response => {
            if (response.ok) {
              prefetchCache.current.add(slug);
            }
          })
          .catch(() => {
            // Silent fail for prefetch
          });
      }
    }, 300);

    // Show preview after 500ms hover
    timeoutRef.current = setTimeout(() => {
      const position = event ? { 
        x: event.clientX, 
        y: event.clientY 
      } : null;
      
      setPreviewState({
        isVisible: true,
        slug,
        position
      });
    }, 500);
  }, []);

  const handleHoverEnd = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    
    // Delay closing slightly to allow moving to preview
    setTimeout(() => {
      setPreviewState(prev => ({ ...prev, isVisible: false }));
    }, 100);
  }, []);

  const handleClose = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    
    setPreviewState({
      isVisible: false,
      slug: null,
      position: null
    });
  }, []);

  // Keyboard focus support
  const handleFocus = useCallback((slug: string) => {
    setPreviewState({
      isVisible: true,
      slug,
      position: null // Center on screen for keyboard navigation
    });
  }, []);

  const handleBlur = useCallback(() => {
    // Delay closing to allow for keyboard navigation within preview
    setTimeout(() => {
      if (!document.activeElement?.closest('[data-testid^="preview-chart"]')) {
        handleClose();
      }
    }, 100);
  }, [handleClose]);

  return {
    previewState,
    handleHoverStart,
    handleHoverEnd,
    handleFocus,
    handleBlur,
    handleClose
  };
}