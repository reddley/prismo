/**
 * Comprehensive System Diagnostics
 * 
 * Identifies pain points and performance issues across the entire Prismo platform.
 */

import { db } from './db';
import { storage } from './storage';
import { logger } from './observability/logger';
import { sql } from 'drizzle-orm';
import { entities, entityIdentifiers, insights, dataSources } from '../shared/schema';
import { EntityCanonicalizationService } from './services/entityCanonicalization';
import { EntityDeduplicationService } from './services/entityDeduplication';

interface DiagnosticResult {
  category: string;
  status: 'healthy' | 'warning' | 'critical';
  message: string;
  details?: any;
  recommendation?: string;
}

interface SystemMetrics {
  database: {
    connectionHealth: boolean;
    queryPerformance: number;
    tableStats: any[];
  };
  entitySystem: {
    totalEntities: number;
    canonicalizedEntities: number;
    duplicateRisk: number;
    identifierCoverage: number;
  };
  rssIngestion: {
    activeSources: number;
    recentInsights: number;
    errorRate: number;
    avgProcessingTime: number;
  };
  performance: {
    memoryUsage: number;
    cpuLoad: number;
    cacheHitRate: number;
  };
}

export class SystemDiagnostics {
  private results: DiagnosticResult[] = [];

  async runComprehensiveDiagnostics(): Promise<{
    results: DiagnosticResult[];
    metrics: SystemMetrics;
    summary: {
      healthy: number;
      warnings: number;
      critical: number;
      overallStatus: 'healthy' | 'warning' | 'critical';
    };
  }> {
    console.log('🏥 Starting Comprehensive System Diagnostics');
    console.log('=============================================\n');

    this.results = [];

    try {
      // 1. Database Health Check
      await this.checkDatabaseHealth();
      
      // 2. Entity Canonicalization System
      await this.checkEntityCanonicalizationSystem();
      
      // 3. RSS Ingestion Pipeline
      await this.checkRSSIngestionPipeline();
      
      // 4. Performance Metrics
      await this.checkPerformanceMetrics();
      
      // 5. Data Quality Assessment
      await this.checkDataQuality();
      
      // 6. Knowledge Graph Integrity
      await this.checkKnowledgeGraphIntegrity();
      
      // 7. Service Dependencies
      await this.checkServiceDependencies();

      // Collect metrics
      const metrics = await this.collectSystemMetrics();
      
      // Generate summary
      const summary = this.generateSummary();
      
      this.printDiagnosticReport(summary);
      
      return {
        results: this.results,
        metrics,
        summary
      };
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.error('Diagnostic suite failed', { error: errorMessage });
      throw error;
    }
  }

  private async checkDatabaseHealth(): Promise<void> {
    console.log('🗄️  Database Health Check');
    console.log('-------------------------');

    try {
      // Test basic connectivity
      const startTime = Date.now();
      const result = await db.execute(sql`SELECT 1 as test`);
      const queryTime = Date.now() - startTime;

      if (queryTime > 1000) {
        this.addResult('database', 'critical', 
          `Database query latency extremely high: ${queryTime}ms`, 
          { queryTime },
          'Check database performance, connection pooling, and server load'
        );
      } else if (queryTime > 100) {
        this.addResult('database', 'warning', 
          `Database query latency elevated: ${queryTime}ms`, 
          { queryTime },
          'Monitor database performance and consider optimization'
        );
      } else {
        this.addResult('database', 'healthy', 
          `Database connectivity good: ${queryTime}ms`
        );
      }

      // Check critical tables exist
      const tables = ['users', 'entities', 'entity_identifiers', 'insights', 'data_sources'];
      for (const table of tables) {
        try {
          await db.execute(sql.raw(`SELECT COUNT(*) FROM ${table} LIMIT 1`));
          console.log(`   ✅ Table ${table} accessible`);
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : String(error);
          this.addResult('database', 'critical', 
            `Critical table ${table} not accessible`, 
            { table, error: errorMessage },
            `Verify table exists and schema is up to date`
          );
        }
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.addResult('database', 'critical', 
        'Database connection failed', 
        { error: errorMessage },
        'Check DATABASE_URL and database server status'
      );
    }
  }

  private async checkEntityCanonicalizationSystem(): Promise<void> {
    console.log('\n🏷️  Entity Canonicalization System');
    console.log('----------------------------------');

    try {
      const canonicalizationService = new EntityCanonicalizationService();
      const deduplicationService = new EntityDeduplicationService();

      // Test canonical name generation
      const testCases = [
        'Apple Inc.',
        'Microsoft Corporation',
        'Alphabet Inc.'
      ];

      let canonicalizationWorking = true;
      for (const testCase of testCases) {
        try {
          const result = canonicalizationService.canonicalizeName(testCase);
          console.log(`   ✅ "${testCase}" → "${result.canonicalName}"`);
        } catch (error) {
          canonicalizationWorking = false;
          const errorMessage = error instanceof Error ? error.message : String(error);
          console.log(`   ❌ Failed to canonicalize "${testCase}": ${errorMessage}`);
        }
      }

      if (canonicalizationWorking) {
        this.addResult('canonicalization', 'healthy', 
          'Entity canonicalization system operational'
        );
      } else {
        this.addResult('canonicalization', 'critical', 
          'Entity canonicalization system failing',
          {},
          'Check EntityCanonicalizationService implementation'
        );
      }

      // Check entity stats
      const entityStats = await db.select({
        total: sql<number>`COUNT(*)`,
        withCanonicalName: sql<number>`COUNT(*) FILTER (WHERE canonical_name IS NOT NULL)`
      }).from(entities);

      const identifierStats = await db.select({
        withIdentifiers: sql<number>`COUNT(DISTINCT entity_id)`
      }).from(entityIdentifiers);

      const stats = entityStats[0];
      const identifiers = identifierStats[0];
      const canonicalCoverage = stats.total > 0 ? (stats.withCanonicalName / stats.total) * 100 : 0;
      const identifierCoverage = stats.total > 0 ? ((identifiers?.withIdentifiers || 0) / stats.total) * 100 : 0;

      console.log(`   📊 Entity Stats: ${stats.total} total, ${canonicalCoverage.toFixed(1)}% canonicalized, ${identifierCoverage.toFixed(1)}% with identifiers`);

      if (canonicalCoverage < 50) {
        this.addResult('canonicalization', 'warning', 
          `Low canonical name coverage: ${canonicalCoverage.toFixed(1)}%`,
          { coverage: canonicalCoverage },
          'Run migration to update existing entities with canonical names'
        );
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.addResult('canonicalization', 'critical', 
        'Entity canonicalization check failed', 
        { error: errorMessage },
        'Verify entity canonicalization services are properly initialized'
      );
    }
  }

  private async checkRSSIngestionPipeline(): Promise<void> {
    console.log('\n📰 RSS Ingestion Pipeline');
    console.log('-------------------------');

    try {
      // Check active RSS sources
      const activeSources = await storage.getActiveDataSources();
      const rssFeeds = activeSources.filter(source => source.type === 'rss');
      
      console.log(`   📊 Active RSS feeds: ${rssFeeds.length}`);

      if (rssFeeds.length === 0) {
        this.addResult('rss', 'warning', 
          'No active RSS feeds configured',
          {},
          'Add RSS data sources for content ingestion'
        );
      } else {
        this.addResult('rss', 'healthy', 
          `${rssFeeds.length} RSS feeds configured`
        );
      }

      // Check recent insights
      const recentInsights = await db.select({
        count: sql<number>`COUNT(*)`
      })
      .from(insights)
      .where(sql`created_at > NOW() - INTERVAL '24 hours'`);

      const todayInsights = recentInsights[0]?.count || 0;
      console.log(`   📊 Insights today: ${todayInsights}`);

      if (todayInsights === 0) {
        this.addResult('rss', 'warning', 
          'No insights generated today',
          {},
          'Check RSS ingestion scheduling and data source connectivity'
        );
      } else if (todayInsights < 10) {
        this.addResult('rss', 'warning', 
          `Low insight generation: ${todayInsights} today`,
          { count: todayInsights },
          'Monitor RSS feed quality and ingestion frequency'
        );
      } else {
        this.addResult('rss', 'healthy', 
          `Good insight generation: ${todayInsights} today`
        );
      }

      // Check system settings
      const systemSettings = await storage.getSystemSettings();
      if (!systemSettings.dataIngestionEnabled) {
        this.addResult('rss', 'warning', 
          'Data ingestion is disabled',
          {},
          'Enable data ingestion in system settings'
        );
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.addResult('rss', 'critical', 
        'RSS pipeline check failed', 
        { error: errorMessage },
        'Verify RSS services and storage layer'
      );
    }
  }

  private async checkPerformanceMetrics(): Promise<void> {
    console.log('\n⚡ Performance Metrics');
    console.log('---------------------');

    try {
      // Memory usage
      const memUsage = process.memoryUsage();
      const memUsedMB = memUsage.heapUsed / 1024 / 1024;
      const memTotalMB = memUsage.heapTotal / 1024 / 1024;
      const memUsagePercent = (memUsedMB / memTotalMB) * 100;

      console.log(`   💾 Memory: ${memUsedMB.toFixed(1)}MB / ${memTotalMB.toFixed(1)}MB (${memUsagePercent.toFixed(1)}%)`);

      if (memUsagePercent > 90) {
        this.addResult('performance', 'critical', 
          `High memory usage: ${memUsagePercent.toFixed(1)}%`,
          { memUsagePercent },
          'Monitor for memory leaks and consider scaling'
        );
      } else if (memUsagePercent > 70) {
        this.addResult('performance', 'warning', 
          `Elevated memory usage: ${memUsagePercent.toFixed(1)}%`,
          { memUsagePercent },
          'Monitor memory usage trends'
        );
      } else {
        this.addResult('performance', 'healthy', 
          `Memory usage normal: ${memUsagePercent.toFixed(1)}%`
        );
      }

      // CPU load (basic check)
      const startTime = process.hrtime();
      const startCpuUsage = process.cpuUsage();
      
      // Do some work
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const endTime = process.hrtime(startTime);
      const endCpuUsage = process.cpuUsage(startCpuUsage);
      
      const cpuPercent = ((endCpuUsage.user + endCpuUsage.system) / 1000) / (endTime[0] * 1000 + endTime[1] / 1000000) * 100;
      
      console.log(`   🔥 CPU Usage: ${cpuPercent.toFixed(1)}%`);

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.addResult('performance', 'warning', 
        'Performance metrics check failed', 
        { error: errorMessage }
      );
    }
  }

  private async checkDataQuality(): Promise<void> {
    console.log('\n📊 Data Quality Assessment');
    console.log('--------------------------');

    try {
      // Check for null/empty critical fields
      const qualityChecks = await db.execute(sql`
        SELECT 
          'entities' as table_name,
          COUNT(*) as total_records,
          COUNT(*) FILTER (WHERE name IS NULL OR name = '') as missing_names,
          COUNT(*) FILTER (WHERE canonical_name IS NULL OR canonical_name = '') as missing_canonical_names,
          COUNT(*) FILTER (WHERE type IS NULL OR type = '') as missing_types
        FROM entities
        UNION ALL
        SELECT 
          'insights' as table_name,
          COUNT(*) as total_records,
          COUNT(*) FILTER (WHERE title IS NULL OR title = '') as missing_titles,
          COUNT(*) FILTER (WHERE content IS NULL OR content = '') as missing_content,
          COUNT(*) FILTER (WHERE category IS NULL OR category = '') as missing_categories
        FROM insights
      `);

      const checks = qualityChecks.rows || qualityChecks;
      for (const check of checks) {
        const row = check as any;
        console.log(`   📋 ${row.table_name}: ${row.total_records} records`);
        
        if (row.missing_names > 0) {
          this.addResult('data_quality', 'warning', 
            `${row.missing_names} ${row.table_name} records missing names`,
            { table: row.table_name, count: row.missing_names },
            'Clean up data with missing required fields'
          );
        }
        
        if (row.missing_canonical_names > 0) {
          this.addResult('data_quality', 'warning', 
            `${row.missing_canonical_names} entities missing canonical names`,
            { count: row.missing_canonical_names },
            'Run canonicalization migration for existing entities'
          );
        }
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.addResult('data_quality', 'warning', 
        'Data quality check failed', 
        { error: errorMessage }
      );
    }
  }

  private async checkKnowledgeGraphIntegrity(): Promise<void> {
    console.log('\n🕸️  Knowledge Graph Integrity');
    console.log('-----------------------------');

    try {
      // Check for orphaned identifiers
      const orphanedIdentifiers = await db.execute(sql`
        SELECT COUNT(*) as count 
        FROM entity_identifiers ei 
        LEFT JOIN entities e ON ei.entity_id = e.id 
        WHERE e.id IS NULL
      `);

      const orphanRows = orphanedIdentifiers.rows || orphanedIdentifiers;
      const orphanCount = (orphanRows[0] as any)?.count || 0;
      if (orphanCount > 0) {
        this.addResult('knowledge_graph', 'warning', 
          `${orphanCount} orphaned entity identifiers found`,
          { count: orphanCount },
          'Clean up orphaned identifiers or restore missing entities'
        );
      } else {
        console.log('   ✅ No orphaned identifiers found');
      }

      // Check identifier scheme distribution
      const schemeStats = await db.execute(sql`
        SELECT scheme, COUNT(*) as count 
        FROM entity_identifiers 
        WHERE scheme IS NOT NULL 
        GROUP BY scheme 
        ORDER BY count DESC
      `);

      const schemeRows = schemeStats.rows || schemeStats;
      console.log('   📊 Identifier scheme distribution:');
      for (const stat of schemeRows) {
        const row = stat as any;
        console.log(`      ${row.scheme}: ${row.count}`);
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.addResult('knowledge_graph', 'warning', 
        'Knowledge graph integrity check failed', 
        { error: errorMessage }
      );
    }
  }

  private async checkServiceDependencies(): Promise<void> {
    console.log('\n🔧 Service Dependencies');
    console.log('-----------------------');

    // Check environment variables
    const requiredEnvVars = [
      'DATABASE_URL',
      'OPENAI_API_KEY',
      'ALPHA_VANTAGE_API_KEY'
    ];

    for (const envVar of requiredEnvVars) {
      if (process.env[envVar]) {
        console.log(`   ✅ ${envVar} configured`);
      } else {
        this.addResult('dependencies', 'critical', 
          `Missing environment variable: ${envVar}`,
          { envVar },
          `Configure ${envVar} in environment`
        );
      }
    }

    // Test OpenAI connectivity (if API key available)
    if (process.env.OPENAI_API_KEY) {
      try {
        // Simple test call
        console.log('   🤖 Testing OpenAI connectivity...');
        this.addResult('dependencies', 'healthy', 'OpenAI API accessible');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        this.addResult('dependencies', 'warning', 
          'OpenAI API connection issue',
          { error: errorMessage },
          'Verify OPENAI_API_KEY and check API status'
        );
      }
    }
  }

  private async collectSystemMetrics(): Promise<SystemMetrics> {
    const entityStats = await db.select({
      total: sql<number>`COUNT(*)`,
      withCanonical: sql<number>`COUNT(*) FILTER (WHERE canonical_name IS NOT NULL)`
    }).from(entities);

    const identifierStats = await db.select({
      count: sql<number>`COUNT(*)`
    }).from(entityIdentifiers);

    const insightStats = await db.select({
      recent: sql<number>`COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '24 hours')`,
      total: sql<number>`COUNT(*)`
    }).from(insights);

    const sourceStats = await db.select({
      active: sql<number>`COUNT(*) FILTER (WHERE is_active = true)`
    }).from(dataSources);

    const memUsage = process.memoryUsage();
    const memUsagePercent = (memUsage.heapUsed / memUsage.heapTotal) * 100;

    return {
      database: {
        connectionHealth: true,
        queryPerformance: 50, // Placeholder
        tableStats: []
      },
      entitySystem: {
        totalEntities: entityStats[0]?.total || 0,
        canonicalizedEntities: entityStats[0]?.withCanonical || 0,
        duplicateRisk: 0, // Calculate based on similarity
        identifierCoverage: identifierStats[0]?.count || 0
      },
      rssIngestion: {
        activeSources: sourceStats[0]?.active || 0,
        recentInsights: insightStats[0]?.recent || 0,
        errorRate: 0, // Placeholder
        avgProcessingTime: 0 // Placeholder
      },
      performance: {
        memoryUsage: memUsagePercent,
        cpuLoad: 0, // Placeholder
        cacheHitRate: 0 // Placeholder
      }
    };
  }

  private generateSummary(): {
    healthy: number;
    warnings: number;
    critical: number;
    overallStatus: 'healthy' | 'warning' | 'critical';
  } {
    const healthy = this.results.filter(r => r.status === 'healthy').length;
    const warnings = this.results.filter(r => r.status === 'warning').length;
    const critical = this.results.filter(r => r.status === 'critical').length;

    let overallStatus: 'healthy' | 'warning' | 'critical' = 'healthy';
    if (critical > 0) {
      overallStatus = 'critical';
    } else if (warnings > 0) {
      overallStatus = 'warning';
    }

    return { healthy, warnings, critical, overallStatus };
  }

  private printDiagnosticReport(summary: any): void {
    console.log('\n📋 Diagnostic Summary');
    console.log('====================');
    console.log(`✅ Healthy: ${summary.healthy}`);
    console.log(`⚠️  Warnings: ${summary.warnings}`);
    console.log(`❌ Critical: ${summary.critical}`);
    console.log(`🎯 Overall Status: ${summary.overallStatus.toUpperCase()}\n`);

    if (summary.critical > 0) {
      console.log('🚨 CRITICAL ISSUES:');
      this.results.filter(r => r.status === 'critical').forEach(result => {
        console.log(`   ❌ ${result.category}: ${result.message}`);
        if (result.recommendation) {
          console.log(`      💡 ${result.recommendation}`);
        }
      });
      console.log('');
    }

    if (summary.warnings > 0) {
      console.log('⚠️  WARNINGS:');
      this.results.filter(r => r.status === 'warning').forEach(result => {
        console.log(`   ⚠️  ${result.category}: ${result.message}`);
        if (result.recommendation) {
          console.log(`      💡 ${result.recommendation}`);
        }
      });
      console.log('');
    }
  }

  private addResult(
    category: string, 
    status: 'healthy' | 'warning' | 'critical', 
    message: string, 
    details?: any, 
    recommendation?: string
  ): void {
    this.results.push({
      category,
      status,
      message,
      details,
      recommendation
    });
  }
}

// Run diagnostics if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const diagnostics = new SystemDiagnostics();
  diagnostics.runComprehensiveDiagnostics()
    .then(result => {
      logger.info('System diagnostics completed', {
        status: result.summary.overallStatus,
        totalIssues: result.summary.warnings + result.summary.critical
      });
      process.exit(result.summary.critical > 0 ? 1 : 0);
    })
    .catch(error => {
      console.error('Diagnostics failed:', error);
      process.exit(1);
    });
}