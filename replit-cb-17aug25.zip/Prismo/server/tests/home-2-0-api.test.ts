import { describe, test, expect, beforeEach, afterEach } from '@jest/globals';
import request from 'supertest';
import express from 'express';
import { db } from '../db';
import { reportTemplates, installedReports } from '@shared/schema';
import { eq, and } from 'drizzle-orm';

// Mock the database and logger for testing
jest.mock('../db');
jest.mock('../observability/logger');

const mockDb = {
  select: jest.fn(),
  insert: jest.fn(),
  delete: jest.fn(),
};

// Create a test app with the Home 2.0 routes
const createTestApp = () => {
  const app = express();
  app.use(express.json());
  
  // Add the Home 2.0 routes (simplified for testing)
  app.get('/api/report-templates', async (req, res) => {
    try {
      const { category } = req.query;
      
      const mockTemplates = [
        {
          id: 'template-1',
          slug: 'recent-headlines',
          name: 'Recent Headlines',
          category: 'news',
          version: 1,
          inputsSchema: { type: 'object', properties: { limit: { type: 'number', default: 10 } } },
          previewImg: null,
          createdAt: new Date()
        },
        {
          id: 'template-2',
          slug: 'watchlist',
          name: 'Stock Watchlist',
          category: 'finance',
          version: 1,
          inputsSchema: { type: 'object', properties: { displayMode: { type: 'string', default: 'detailed' } } },
          previewImg: null,
          createdAt: new Date()
        }
      ];
      
      const filteredTemplates = category 
        ? mockTemplates.filter(t => t.category === category)
        : mockTemplates;
      
      res.json({
        templates: filteredTemplates,
        total: filteredTemplates.length,
        category: category || 'all'
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to get report templates' });
    }
  });
  
  app.post('/api/installed-reports', async (req, res) => {
    try {
      const { templateSlug, config = {} } = req.body;
      
      if (!templateSlug) {
        return res.status(400).json({ error: 'templateSlug is required' });
      }
      
      // Mock template lookup
      if (templateSlug === 'invalid-template') {
        return res.status(404).json({ error: 'Template not found' });
      }
      
      if (templateSlug === 'already-installed') {
        return res.status(409).json({ 
          error: 'Template already installed',
          installedReportId: 'existing-installation-id'
        });
      }
      
      // Mock successful installation
      const newInstallation = {
        id: 'new-installation-id',
        userId: 'user-1',
        templateId: 'template-1',
        configJson: config,
        layoutJson: {},
        state: 'active',
        createdAt: new Date()
      };
      
      res.status(201).json({
        installedReportId: newInstallation.id,
        templateSlug,
        config: newInstallation.configJson,
        state: newInstallation.state
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to install report' });
    }
  });
  
  app.delete('/api/installed-reports/:id', async (req, res) => {
    try {
      const { id } = req.params;
      
      if (!id) {
        return res.status(400).json({ error: 'Report ID is required' });
      }
      
      if (id === 'non-existent-id') {
        return res.status(404).json({ error: 'Installed report not found' });
      }
      
      res.json({
        message: 'Report uninstalled successfully',
        installedReportId: id
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to uninstall report' });
    }
  });
  
  app.get('/api/home', async (req, res) => {
    try {
      const mockInstalledReports = [
        {
          id: 'installed-1',
          configJson: { limit: 10 },
          layoutJson: {},
          state: 'active',
          createdAt: new Date(),
          templateSlug: 'recent-headlines',
          templateName: 'Recent Headlines',
          templateCategory: 'news',
          templateVersion: 1,
          templateInputsSchema: { type: 'object', properties: { limit: { type: 'number', default: 10 } } },
          templatePreviewImg: null
        },
        {
          id: 'installed-2',
          configJson: { displayMode: 'detailed' },
          layoutJson: {},
          state: 'active',
          createdAt: new Date(),
          templateSlug: 'watchlist',
          templateName: 'Stock Watchlist',
          templateCategory: 'finance',
          templateVersion: 1,
          templateInputsSchema: { type: 'object', properties: { displayMode: { type: 'string', default: 'detailed' } } },
          templatePreviewImg: null
        }
      ];
      
      const layout = mockInstalledReports.map((report, index) => ({
        id: report.id,
        x: (index % 3) * 4,
        y: Math.floor(index / 3) * 4,
        w: 4,
        h: 4,
        templateSlug: report.templateSlug
      }));
      
      res.json({
        layout,
        installedReports: mockInstalledReports,
        total: mockInstalledReports.length,
        userId: 'user-1'
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to get home dashboard' });
    }
  });
  
  return app;
};

describe('Home 2.0 API Endpoints', () => {
  let app: express.Application;
  
  beforeEach(() => {
    app = createTestApp();
    jest.clearAllMocks();
  });
  
  afterEach(() => {
    jest.restoreAllMocks();
  });
  
  describe('GET /api/report-templates', () => {
    test('should return all templates when no category filter', async () => {
      const response = await request(app)
        .get('/api/report-templates')
        .expect(200);
      
      expect(response.body).toMatchObject({
        templates: expect.arrayContaining([
          expect.objectContaining({
            slug: 'recent-headlines',
            name: 'Recent Headlines',
            category: 'news'
          }),
          expect.objectContaining({
            slug: 'watchlist',
            name: 'Stock Watchlist',
            category: 'finance'
          })
        ]),
        total: 2,
        category: 'all'
      });
    });
    
    test('should filter templates by category', async () => {
      const response = await request(app)
        .get('/api/report-templates?category=finance')
        .expect(200);
      
      expect(response.body).toMatchObject({
        templates: expect.arrayContaining([
          expect.objectContaining({
            slug: 'watchlist',
            category: 'finance'
          })
        ]),
        total: 1,
        category: 'finance'
      });
    });
  });
  
  describe('POST /api/installed-reports', () => {
    test('should install a report successfully', async () => {
      const response = await request(app)
        .post('/api/installed-reports')
        .send({
          templateSlug: 'recent-headlines',
          config: { limit: 15 }
        })
        .expect(201);
      
      expect(response.body).toMatchObject({
        installedReportId: 'new-installation-id',
        templateSlug: 'recent-headlines',
        config: { limit: 15 },
        state: 'active'
      });
    });
    
    test('should return 400 if templateSlug is missing', async () => {
      const response = await request(app)
        .post('/api/installed-reports')
        .send({
          config: { limit: 15 }
        })
        .expect(400);
      
      expect(response.body).toMatchObject({
        error: 'templateSlug is required'
      });
    });
    
    test('should return 404 if template not found', async () => {
      const response = await request(app)
        .post('/api/installed-reports')
        .send({
          templateSlug: 'invalid-template'
        })
        .expect(404);
      
      expect(response.body).toMatchObject({
        error: 'Template not found'
      });
    });
    
    test('should return 409 if template already installed', async () => {
      const response = await request(app)
        .post('/api/installed-reports')
        .send({
          templateSlug: 'already-installed'
        })
        .expect(409);
      
      expect(response.body).toMatchObject({
        error: 'Template already installed',
        installedReportId: 'existing-installation-id'
      });
    });
    
    test('should handle invalid config gracefully', async () => {
      const response = await request(app)
        .post('/api/installed-reports')
        .send({
          templateSlug: 'recent-headlines',
          config: { invalidProperty: 'invalid-value' }
        })
        .expect(201);
      
      expect(response.body.config).toMatchObject({
        invalidProperty: 'invalid-value'
      });
    });
  });
  
  describe('DELETE /api/installed-reports/:id', () => {
    test('should uninstall a report successfully', async () => {
      const response = await request(app)
        .delete('/api/installed-reports/valid-installation-id')
        .expect(200);
      
      expect(response.body).toMatchObject({
        message: 'Report uninstalled successfully',
        installedReportId: 'valid-installation-id'
      });
    });
    
    test('should return 404 if report not found', async () => {
      const response = await request(app)
        .delete('/api/installed-reports/non-existent-id')
        .expect(404);
      
      expect(response.body).toMatchObject({
        error: 'Installed report not found'
      });
    });
  });
  
  describe('GET /api/home', () => {
    test('should return home dashboard with layout and installed reports', async () => {
      const response = await request(app)
        .get('/api/home')
        .expect(200);
      
      expect(response.body).toMatchObject({
        layout: expect.arrayContaining([
          expect.objectContaining({
            id: 'installed-1',
            x: 0,
            y: 0,
            w: 4,
            h: 4,
            templateSlug: 'recent-headlines'
          }),
          expect.objectContaining({
            id: 'installed-2',
            x: 4,
            y: 0,
            w: 4,
            h: 4,
            templateSlug: 'watchlist'
          })
        ]),
        installedReports: expect.arrayContaining([
          expect.objectContaining({
            id: 'installed-1',
            templateSlug: 'recent-headlines',
            templateName: 'Recent Headlines',
            templateCategory: 'news'
          }),
          expect.objectContaining({
            id: 'installed-2',
            templateSlug: 'watchlist',
            templateName: 'Stock Watchlist',
            templateCategory: 'finance'
          })
        ]),
        total: 2,
        userId: 'user-1'
      });
    });
  });
});