import { Request, Response } from 'express';

// RED Metrics (Rate, Errors, Duration)
interface RedMetrics {
  requests: {
    total: number;
    rate: number; // requests per second
    last1min: number;
    last5min: number;
    last15min: number;
  };
  errors: {
    total: number;
    rate: number; // errors per second
    last1min: number;
    last5min: number;
    last15min: number;
    errorRate: number; // percentage
  };
  duration: {
    p50: number;
    p95: number;
    p99: number;
    avg: number;
    max: number;
  };
}

// USE Metrics (Utilization, Saturation, Errors)
interface UseMetrics {
  utilization: {
    cpu: number; // percentage
    memory: number; // percentage
    dbConnections: number; // percentage of pool
    activeRequests: number;
  };
  saturation: {
    queueLength: number;
    waitTime: number; // ms
    throttledRequests: number;
  };
  errors: {
    systemErrors: number;
    dbErrors: number;
    apiErrors: number;
  };
}

interface ServiceMetrics {
  timestamp: number;
  red: RedMetrics;
  use: UseMetrics;
  business: {
    activeUsers: number;
    insightsProcessed: number;
    aiCalls: number;
    costToday: number;
  };
}

class MetricsCollector {
  private metrics: ServiceMetrics;
  private requestTimes: number[] = [];
  private requestTimestamps: number[] = [];
  private errorCounts: number[] = [];
  private errorTimestamps: number[] = [];
  private startTime: number = Date.now();

  constructor() {
    this.metrics = this.initializeMetrics();
    
    // Update metrics every 30 seconds
    setInterval(() => {
      this.updateMetrics();
    }, 30000);

    // Cleanup old data every 5 minutes
    setInterval(() => {
      this.cleanupOldData();
    }, 300000);
  }

  private initializeMetrics(): ServiceMetrics {
    return {
      timestamp: Date.now(),
      red: {
        requests: { total: 0, rate: 0, last1min: 0, last5min: 0, last15min: 0 },
        errors: { total: 0, rate: 0, last1min: 0, last5min: 0, last15min: 0, errorRate: 0 },
        duration: { p50: 0, p95: 0, p99: 0, avg: 0, max: 0 }
      },
      use: {
        utilization: { cpu: 0, memory: 0, dbConnections: 0, activeRequests: 0 },
        saturation: { queueLength: 0, waitTime: 0, throttledRequests: 0 },
        errors: { systemErrors: 0, dbErrors: 0, apiErrors: 0 }
      },
      business: {
        activeUsers: 0,
        insightsProcessed: 0,
        aiCalls: 0,
        costToday: 0
      }
    };
  }

  // Record request metrics
  recordRequest(duration: number, isError: boolean = false): void {
    const now = Date.now();
    
    this.requestTimes.push(duration);
    this.requestTimestamps.push(now);
    this.metrics.red.requests.total++;

    if (isError) {
      this.errorCounts.push(1);
      this.errorTimestamps.push(now);
      this.metrics.red.errors.total++;
    }

    // Update duration metrics immediately
    this.updateDurationMetrics();
  }

  // Record business metrics
  recordBusinessMetric(metric: keyof ServiceMetrics['business'], value: number): void {
    this.metrics.business[metric] = value;
  }

  // Record system metrics
  recordSystemMetric(category: 'utilization' | 'saturation' | 'errors', metric: string, value: number): void {
    if (category === 'utilization' && metric in this.metrics.use.utilization) {
      (this.metrics.use.utilization as any)[metric] = value;
    } else if (category === 'saturation' && metric in this.metrics.use.saturation) {
      (this.metrics.use.saturation as any)[metric] = value;
    } else if (category === 'errors' && metric in this.metrics.use.errors) {
      (this.metrics.use.errors as any)[metric] = value;
    }
  }

  private updateMetrics(): void {
    const now = Date.now();
    
    // Update request rates
    this.metrics.red.requests.last1min = this.countInTimeWindow(this.requestTimestamps, now, 60000);
    this.metrics.red.requests.last5min = this.countInTimeWindow(this.requestTimestamps, now, 300000);
    this.metrics.red.requests.last15min = this.countInTimeWindow(this.requestTimestamps, now, 900000);
    this.metrics.red.requests.rate = this.metrics.red.requests.last1min / 60;

    // Update error rates
    this.metrics.red.errors.last1min = this.countInTimeWindow(this.errorTimestamps, now, 60000);
    this.metrics.red.errors.last5min = this.countInTimeWindow(this.errorTimestamps, now, 300000);
    this.metrics.red.errors.last15min = this.countInTimeWindow(this.errorTimestamps, now, 900000);
    this.metrics.red.errors.rate = this.metrics.red.errors.last1min / 60;
    this.metrics.red.errors.errorRate = this.metrics.red.requests.last1min > 0 
      ? (this.metrics.red.errors.last1min / this.metrics.red.requests.last1min) * 100 
      : 0;

    // Update system metrics
    this.updateSystemMetrics();
    
    this.metrics.timestamp = now;
  }

  private updateDurationMetrics(): void {
    if (this.requestTimes.length === 0) return;

    const sorted = [...this.requestTimes].sort((a, b) => a - b);
    const len = sorted.length;

    this.metrics.red.duration.avg = this.requestTimes.reduce((a, b) => a + b, 0) / len;
    this.metrics.red.duration.max = Math.max(...this.requestTimes);
    this.metrics.red.duration.p50 = sorted[Math.floor(len * 0.5)];
    this.metrics.red.duration.p95 = sorted[Math.floor(len * 0.95)];
    this.metrics.red.duration.p99 = sorted[Math.floor(len * 0.99)];
  }

  private updateSystemMetrics(): void {
    // Memory usage
    const memUsage = process.memoryUsage();
    this.metrics.use.utilization.memory = (memUsage.heapUsed / memUsage.heapTotal) * 100;

    // Uptime as a proxy for stability
    const uptime = process.uptime();
    
    // CPU usage (simplified - in production, use more sophisticated monitoring)
    const cpuUsage = process.cpuUsage();
    // This is a rough approximation
    this.metrics.use.utilization.cpu = Math.min(100, (cpuUsage.user + cpuUsage.system) / 1000000);
  }

  private countInTimeWindow(timestamps: number[], now: number, windowMs: number): number {
    return timestamps.filter(timestamp => (now - timestamp) <= windowMs).length;
  }

  private cleanupOldData(): void {
    const now = Date.now();
    const maxAge = 900000; // 15 minutes

    // Keep only recent request times and timestamps
    const recentIndices = this.requestTimestamps
      .map((timestamp, index) => ({ timestamp, index }))
      .filter(({ timestamp }) => (now - timestamp) <= maxAge)
      .map(({ index }) => index);

    this.requestTimes = recentIndices.map(i => this.requestTimes[i]);
    this.requestTimestamps = recentIndices.map(i => this.requestTimestamps[i]);

    // Cleanup error timestamps
    this.errorTimestamps = this.errorTimestamps.filter(timestamp => (now - timestamp) <= maxAge);
    this.errorCounts = this.errorCounts.slice(-this.errorTimestamps.length);
  }

  // Get current metrics
  getMetrics(): ServiceMetrics {
    return { ...this.metrics };
  }

  // Get health status based on SLOs
  getHealthStatus(): {
    status: 'healthy' | 'degraded' | 'unhealthy';
    slos: {
      availability: { target: number; current: number; passing: boolean };
      latency: { target: number; current: number; passing: boolean };
      errorRate: { target: number; current: number; passing: boolean };
    };
    alerts: string[];
  } {
    const slos = {
      availability: { 
        target: 99.9, 
        current: Math.max(0, 100 - this.metrics.red.errors.errorRate),
        passing: false
      },
      latency: { 
        target: 500, 
        current: this.metrics.red.duration.p95,
        passing: false
      },
      errorRate: { 
        target: 1, 
        current: this.metrics.red.errors.errorRate,
        passing: false
      }
    };

    slos.availability.passing = slos.availability.current >= slos.availability.target;
    slos.latency.passing = slos.latency.current <= slos.latency.target;
    slos.errorRate.passing = slos.errorRate.current <= slos.errorRate.target;

    const alerts: string[] = [];
    if (!slos.availability.passing) alerts.push(`Availability below target: ${slos.availability.current.toFixed(2)}%`);
    if (!slos.latency.passing) alerts.push(`P95 latency above target: ${slos.latency.current.toFixed(0)}ms`);
    if (!slos.errorRate.passing) alerts.push(`Error rate above target: ${slos.errorRate.current.toFixed(2)}%`);

    const passingCount = Object.values(slos).filter(slo => slo.passing).length;
    const status = passingCount === 3 ? 'healthy' : passingCount >= 2 ? 'degraded' : 'unhealthy';

    return { status, slos, alerts };
  }
}

export const metricsCollector = new MetricsCollector();

// Middleware to collect request metrics
export function metricsMiddleware(req: Request, res: Response, next: Function): void {
  const startTime = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    const isError = res.statusCode >= 400;
    metricsCollector.recordRequest(duration, isError);
  });

  next();
}