import { metricsCollector } from './metrics';
import { logger } from './logger';

interface AlertRule {
  id: string;
  name: string;
  condition: (metrics: any) => boolean;
  severity: 'critical' | 'warning' | 'info';
  description: string;
  cooldownMs: number; // Minimum time between alerts
  actionRequired: string;
}

interface Alert {
  id: string;
  ruleId: string;
  timestamp: number;
  severity: 'critical' | 'warning' | 'info';
  message: string;
  description: string;
  actionRequired: string;
  resolved?: boolean;
  resolvedAt?: number;
}

class AlertManager {
  private alerts: Map<string, Alert> = new Map();
  private lastAlertTime: Map<string, number> = new Map();
  private alertRules: AlertRule[] = [];

  constructor() {
    this.setupDefaultRules();
    this.startMonitoring();
  }

  private setupDefaultRules(): void {
    this.alertRules = [
      // SLO-based alerts
      {
        id: 'high_error_rate',
        name: 'High Error Rate',
        condition: (metrics) => metrics.red.errors.errorRate > 15, // More lenient for development
        severity: 'critical',
        description: 'Error rate exceeded 15% threshold',
        cooldownMs: 600000, // 10 minutes
        actionRequired: 'Check application logs and recent deployments'
      },
      {
        id: 'high_latency_p95',
        name: 'High P95 Latency',
        condition: (metrics) => metrics.red.duration.p95 > 3000, // More lenient for development
        severity: 'warning',
        description: 'P95 response time exceeded 3000ms',
        cooldownMs: 600000, // 10 minutes
        actionRequired: 'Check database performance and system resources'
      },
      {
        id: 'high_latency_p99',
        name: 'High P99 Latency',
        condition: (metrics) => metrics.red.duration.p99 > 8000, // More lenient for development
        severity: 'critical',
        description: 'P99 response time exceeded 8000ms',
        cooldownMs: 300000, // 5 minutes
        actionRequired: 'Investigate slow queries and system bottlenecks'
      },
      
      // Resource utilization alerts
      {
        id: 'high_memory_usage',
        name: 'High Memory Usage',
        condition: (metrics) => metrics.use.utilization.memory > 95, // More lenient for development
        severity: 'warning',
        description: 'Memory usage exceeded 95%',
        cooldownMs: 900000, // 15 minutes
        actionRequired: 'Monitor for memory leaks and consider scaling'
      },
      {
        id: 'high_db_connections',
        name: 'High Database Connection Usage',
        condition: (metrics) => metrics.use.utilization.dbConnections > 80,
        severity: 'warning',
        description: 'Database connection pool usage exceeded 80%',
        cooldownMs: 300000,
        actionRequired: 'Check for connection leaks and optimize queries'
      },
      
      // Request volume alerts
      {
        id: 'low_request_rate',
        name: 'Unusually Low Request Rate',
        condition: (metrics) => metrics.red.requests.rate < 0.1 && Date.now() - 600000 > 0, // After 10min uptime
        severity: 'warning',
        description: 'Request rate below expected threshold',
        cooldownMs: 900000, // 15 minutes
        actionRequired: 'Check if service is receiving traffic correctly'
      },
      {
        id: 'high_request_rate',
        name: 'High Request Rate',
        condition: (metrics) => metrics.red.requests.rate > 100,
        severity: 'info',
        description: 'Request rate exceeded 100 requests/second',
        cooldownMs: 600000,
        actionRequired: 'Monitor system performance under load'
      },

      // Business metrics alerts
      {
        id: 'high_ai_cost',
        name: 'High AI Cost',
        condition: (metrics) => metrics.business.costToday > 10, // $10/day threshold
        severity: 'warning',
        description: 'Daily AI cost exceeded budget threshold',
        cooldownMs: 3600000, // 1 hour
        actionRequired: 'Review AI usage patterns and implement cost controls'
      },
      
      // System health alerts
      {
        id: 'multiple_consecutive_errors',
        name: 'Multiple Consecutive Errors',
        condition: (metrics) => metrics.red.errors.last1min > 10,
        severity: 'critical',
        description: 'More than 10 errors in the last minute',
        cooldownMs: 180000,
        actionRequired: 'Immediate investigation required - check system stability'
      }
    ];
  }

  private startMonitoring(): void {
    // Check alerts every 30 seconds
    setInterval(() => {
      this.checkAlerts();
    }, 30000);

    // Cleanup old alerts every hour
    setInterval(() => {
      this.cleanupOldAlerts();
    }, 3600000);
  }

  private checkAlerts(): void {
    const metrics = metricsCollector.getMetrics();
    const now = Date.now();

    this.alertRules.forEach(rule => {
      try {
        if (rule.condition(metrics)) {
          const lastAlert = this.lastAlertTime.get(rule.id) || 0;
          
          // Check cooldown period
          if (now - lastAlert >= rule.cooldownMs) {
            this.fireAlert(rule, metrics);
            this.lastAlertTime.set(rule.id, now);
          }
        } else {
          // Check if we should resolve any existing alerts for this rule
          this.resolveAlert(rule.id);
        }
      } catch (error) {
        logger.error(`Alert rule evaluation failed: ${rule.id}`, {
          error: error instanceof Error ? error.message : 'Unknown error',
          metadata: { ruleId: rule.id }
        });
      }
    });
  }

  private fireAlert(rule: AlertRule, metrics: any): void {
    const alertId = `${rule.id}_${Date.now()}`;
    const alert: Alert = {
      id: alertId,
      ruleId: rule.id,
      timestamp: Date.now(),
      severity: rule.severity,
      message: rule.name,
      description: rule.description,
      actionRequired: rule.actionRequired,
      resolved: false
    };

    this.alerts.set(alertId, alert);

    // Log the alert
    const logLevel = rule.severity === 'critical' ? 'error' : rule.severity === 'warning' ? 'warn' : 'info';
    logger[logLevel](`ALERT: ${rule.name}`, {
      metadata: {
        alertId,
        ruleId: rule.id,
        severity: rule.severity,
        description: rule.description,
        actionRequired: rule.actionRequired,
        metrics: this.extractRelevantMetrics(metrics, rule.id)
      }
    });

    // In production, this would also send notifications (email, Slack, PagerDuty, etc.)
    this.sendNotification(alert);
  }

  private resolveAlert(ruleId: string): void {
    const activeAlert = Array.from(this.alerts.values()).find(
      alert => alert.ruleId === ruleId && !alert.resolved
    );

    if (activeAlert) {
      activeAlert.resolved = true;
      activeAlert.resolvedAt = Date.now();
      
      logger.info(`ALERT RESOLVED: ${activeAlert.message}`, {
        metadata: {
          alertId: activeAlert.id,
          duration: activeAlert.resolvedAt - activeAlert.timestamp
        }
      });
    }
  }

  private sendNotification(alert: Alert): void {
    // In development, just log to console
    if (process.env.NODE_ENV === 'development') {
      const emoji = alert.severity === 'critical' ? '🚨' : alert.severity === 'warning' ? '⚠️' : 'ℹ️';
      console.log(`\n${emoji} ${alert.severity.toUpperCase()} ALERT: ${alert.message}`);
      console.log(`   ${alert.description}`);
      console.log(`   Action required: ${alert.actionRequired}\n`);
    }

    // In production, integrate with notification services
    // - Email notifications
    // - Slack/Teams integration
    // - PagerDuty for critical alerts
    // - SMS for critical alerts during off-hours
  }

  private extractRelevantMetrics(metrics: any, ruleId: string): any {
    // Return only metrics relevant to the specific alert
    switch (ruleId) {
      case 'high_error_rate':
      case 'multiple_consecutive_errors':
        return {
          errorRate: metrics.red.errors.errorRate,
          errorsLast1min: metrics.red.errors.last1min,
          totalErrors: metrics.red.errors.total
        };
      case 'high_latency_p95':
      case 'high_latency_p99':
        return {
          p95: metrics.red.duration.p95,
          p99: metrics.red.duration.p99,
          avg: metrics.red.duration.avg
        };
      case 'high_memory_usage':
        return {
          memoryUsage: metrics.use.utilization.memory
        };
      case 'high_db_connections':
        return {
          dbConnections: metrics.use.utilization.dbConnections
        };
      case 'low_request_rate':
      case 'high_request_rate':
        return {
          requestRate: metrics.red.requests.rate,
          requestsLast1min: metrics.red.requests.last1min
        };
      case 'high_ai_cost':
        return {
          costToday: metrics.business.costToday,
          aiCalls: metrics.business.aiCalls
        };
      default:
        return {};
    }
  }

  private cleanupOldAlerts(): void {
    const now = Date.now();
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours

    const alertEntries = Array.from(this.alerts.entries());
    for (const [alertId, alert] of alertEntries) {
      if (now - alert.timestamp > maxAge) {
        this.alerts.delete(alertId);
      }
    }
  }

  // Public methods for API access
  getActiveAlerts(): Alert[] {
    return Array.from(this.alerts.values())
      .filter(alert => !alert.resolved)
      .sort((a, b) => {
        // Sort by severity first, then by timestamp
        const severityOrder = { critical: 3, warning: 2, info: 1 };
        const severityDiff = severityOrder[b.severity] - severityOrder[a.severity];
        return severityDiff !== 0 ? severityDiff : b.timestamp - a.timestamp;
      });
  }

  getAllAlerts(includeResolved = false): Alert[] {
    const alerts = Array.from(this.alerts.values());
    return includeResolved 
      ? alerts.sort((a, b) => b.timestamp - a.timestamp)
      : alerts.filter(alert => !alert.resolved).sort((a, b) => b.timestamp - a.timestamp);
  }

  getAlertById(alertId: string): Alert | undefined {
    return this.alerts.get(alertId);
  }

  // Manual alert resolution (for ops team)
  manuallyResolveAlert(alertId: string, userId?: string): boolean {
    const alert = this.alerts.get(alertId);
    if (!alert || alert.resolved) return false;

    alert.resolved = true;
    alert.resolvedAt = Date.now();

    logger.info(`Alert manually resolved`, {
      metadata: {
        alertId,
        resolvedBy: userId,
        originalSeverity: alert.severity
      }
    });

    return true;
  }

  // Get alert statistics
  getAlertStats(): {
    totalAlerts: number;
    activeAlerts: number;
    criticalAlerts: number;
    avgResolutionTime: number;
    topAlertTypes: Array<{ ruleId: string; count: number }>;
  } {
    const allAlerts = Array.from(this.alerts.values());
    const activeAlerts = allAlerts.filter(a => !a.resolved);
    const criticalAlerts = activeAlerts.filter(a => a.severity === 'critical');
    
    const resolvedAlerts = allAlerts.filter(a => a.resolved && a.resolvedAt);
    const avgResolutionTime = resolvedAlerts.length > 0
      ? resolvedAlerts.reduce((sum, a) => sum + ((a.resolvedAt || 0) - a.timestamp), 0) / resolvedAlerts.length
      : 0;

    // Count alert types
    const alertTypeCounts = new Map<string, number>();
    allAlerts.forEach(alert => {
      const current = alertTypeCounts.get(alert.ruleId) || 0;
      alertTypeCounts.set(alert.ruleId, current + 1);
    });

    const topAlertTypes = Array.from(alertTypeCounts.entries())
      .map(([ruleId, count]) => ({ ruleId, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return {
      totalAlerts: allAlerts.length,
      activeAlerts: activeAlerts.length,
      criticalAlerts: criticalAlerts.length,
      avgResolutionTime,
      topAlertTypes
    };
  }
}

export const alertManager = new AlertManager();