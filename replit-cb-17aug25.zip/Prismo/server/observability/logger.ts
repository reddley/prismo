import { Request, Response, NextFunction } from 'express';

export interface LogContext {
  requestId?: string;
  userId?: string;
  ip?: string;
  userAgent?: string;
  method?: string;
  url?: string;
  statusCode?: number;
  responseTime?: number;
  error?: string;
  stack?: string;
  operation?: string;
  table?: string;
  duration?: number;
  metadata?: Record<string, any>;
}

export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'fatal';

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  service: string;
  version: string;
  environment: string;
  context: LogContext;
  traceId?: string;
  spanId?: string;
}

class StructuredLogger {
  private service: string = 'prismo-api';
  private version: string = process.env.npm_package_version || '1.0.0';
  private environment: string = process.env.NODE_ENV || 'development';

  private createLogEntry(level: LogLevel, message: string, context: LogContext = {}): LogEntry {
    return {
      timestamp: new Date().toISOString(),
      level,
      message,
      service: this.service,
      version: this.version,
      environment: this.environment,
      context,
      traceId: context.metadata?.traceId,
      spanId: context.metadata?.spanId,
    };
  }

  private output(entry: LogEntry): void {
    // In development, pretty print for readability
    if (this.environment === 'development') {
      const timestamp = entry.timestamp.split('T')[1].split('.')[0];
      const contextStr = Object.keys(entry.context).length > 0 
        ? ` :: ${JSON.stringify(entry.context)}`
        : '';
      console.log(`${timestamp} [${entry.level.toUpperCase()}] ${entry.message}${contextStr}`);
    } else {
      // In production, output structured JSON
      console.log(JSON.stringify(entry));
    }
  }

  debug(message: string, context: LogContext = {}): void {
    this.output(this.createLogEntry('debug', message, context));
  }

  info(message: string, context: LogContext = {}): void {
    this.output(this.createLogEntry('info', message, context));
  }

  warn(message: string, context: LogContext = {}): void {
    this.output(this.createLogEntry('warn', message, context));
  }

  error(message: string, context: LogContext = {}): void {
    this.output(this.createLogEntry('error', message, context));
  }

  fatal(message: string, context: LogContext = {}): void {
    this.output(this.createLogEntry('fatal', message, context));
    // Fatal errors should potentially crash the process
    if (this.environment === 'production') {
      process.exit(1);
    }
  }

  // Request logging helper
  logRequest(req: Request, res: Response, responseTime: number): void {
    const context: LogContext = {
      requestId: req.headers['x-request-id'] as string,
      userId: (req as any).user?.id,
      ip: req.ip || req.connection.remoteAddress,
      userAgent: req.get('User-Agent'),
      method: req.method,
      url: req.originalUrl,
      statusCode: res.statusCode,
      responseTime,
    };

    const level: LogLevel = res.statusCode >= 500 ? 'error' 
      : res.statusCode >= 400 ? 'warn' 
      : 'info';

    this.output(this.createLogEntry(level, 
      `${req.method} ${req.originalUrl} ${res.statusCode} in ${responseTime}ms`,
      context
    ));
  }

  // Error logging helper
  logError(error: Error, context: LogContext = {}): void {
    this.error(error.message, {
      ...context,
      error: error.name,
      stack: error.stack,
    });
  }

  // Database operation logging
  logDbOperation(operation: string, table: string, duration: number, context: LogContext = {}): void {
    this.info(`DB ${operation} on ${table}`, {
      ...context,
      operation,
      table,
      duration,
      metadata: { ...context.metadata, type: 'database' }
    });
  }

  // Business logic logging
  logBusinessEvent(event: string, context: LogContext = {}): void {
    this.info(`Business event: ${event}`, {
      ...context,
      metadata: { ...context.metadata, type: 'business' }
    });
  }
}

export const logger = new StructuredLogger();

// Request logging middleware
export function requestLogger(req: Request, res: Response, next: NextFunction): void {
  const startTime = Date.now();
  
  // Add request ID if not present
  if (!req.headers['x-request-id']) {
    req.headers['x-request-id'] = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  res.on('finish', () => {
    const responseTime = Date.now() - startTime;
    logger.logRequest(req, res, responseTime);
  });

  next();
}