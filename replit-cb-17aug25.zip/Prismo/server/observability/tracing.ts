import { Request, Response, NextFunction } from 'express';

// Simplified tracing implementation
// In production, this would integrate with OpenTelemetry
interface TraceContext {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  operationName: string;
  startTime: number;
  endTime?: number;
  duration?: number;
  tags: Record<string, any>;
  logs: Array<{ timestamp: number; message: string; level: string }>;
  status: 'ok' | 'error';
}

class TracingService {
  private traces: Map<string, TraceContext> = new Map();
  private activeSpans: Map<string, TraceContext> = new Map();

  // Generate unique IDs
  private generateId(): string {
    return Math.random().toString(36).substr(2, 16);
  }

  // Start a new trace
  startTrace(operationName: string, parentContext?: { traceId: string; spanId: string }): TraceContext {
    const traceId = parentContext?.traceId || this.generateId();
    const spanId = this.generateId();
    
    const context: TraceContext = {
      traceId,
      spanId,
      parentSpanId: parentContext?.spanId,
      operationName,
      startTime: Date.now(),
      tags: {},
      logs: [],
      status: 'ok'
    };

    this.traces.set(spanId, context);
    this.activeSpans.set(spanId, context);
    
    return context;
  }

  // Finish a trace
  finishTrace(spanId: string, status: 'ok' | 'error' = 'ok'): void {
    const context = this.activeSpans.get(spanId);
    if (!context) return;

    context.endTime = Date.now();
    context.duration = context.endTime - context.startTime;
    context.status = status;
    
    this.activeSpans.delete(spanId);
    
    // Log trace completion
    this.logTrace(context);
  }

  // Add tags to a trace
  addTags(spanId: string, tags: Record<string, any>): void {
    const context = this.activeSpans.get(spanId);
    if (!context) return;

    context.tags = { ...context.tags, ...tags };
  }

  // Add log to a trace
  addLog(spanId: string, message: string, level: string = 'info'): void {
    const context = this.activeSpans.get(spanId);
    if (!context) return;

    context.logs.push({
      timestamp: Date.now(),
      message,
      level
    });
  }

  // Get active trace context
  getContext(spanId: string): TraceContext | undefined {
    return this.activeSpans.get(spanId);
  }

  // Log completed trace
  private logTrace(context: TraceContext): void {
    if (process.env.NODE_ENV === 'development') {
      const duration = context.duration || 0;
      const statusEmoji = context.status === 'ok' ? '✓' : '✗';
      console.log(
        `[TRACE] ${statusEmoji} ${context.operationName} (${duration}ms) ` +
        `[trace: ${context.traceId.substr(0, 8)}] [span: ${context.spanId.substr(0, 8)}]`
      );
    } else {
      // In production, send to tracing backend
      console.log(JSON.stringify({
        timestamp: new Date().toISOString(),
        type: 'trace',
        traceId: context.traceId,
        spanId: context.spanId,
        parentSpanId: context.parentSpanId,
        operationName: context.operationName,
        duration: context.duration,
        tags: context.tags,
        logs: context.logs,
        status: context.status
      }));
    }
  }

  // Get trace statistics
  getTraceStats(): {
    totalTraces: number;
    avgDuration: number;
    errorRate: number;
    slowestOperations: Array<{ operation: string; avgDuration: number }>;
  } {
    const completedTraces = Array.from(this.traces.values()).filter(t => t.duration !== undefined);
    
    if (completedTraces.length === 0) {
      return {
        totalTraces: 0,
        avgDuration: 0,
        errorRate: 0,
        slowestOperations: []
      };
    }

    const totalDuration = completedTraces.reduce((sum, t) => sum + (t.duration || 0), 0);
    const errors = completedTraces.filter(t => t.status === 'error').length;
    
    // Group by operation name and calculate averages
    const operationStats = new Map<string, { total: number; count: number }>();
    completedTraces.forEach(trace => {
      const current = operationStats.get(trace.operationName) || { total: 0, count: 0 };
      current.total += trace.duration || 0;
      current.count += 1;
      operationStats.set(trace.operationName, current);
    });

    const slowestOperations = Array.from(operationStats.entries())
      .map(([operation, stats]) => ({
        operation,
        avgDuration: stats.total / stats.count
      }))
      .sort((a, b) => b.avgDuration - a.avgDuration)
      .slice(0, 5);

    return {
      totalTraces: completedTraces.length,
      avgDuration: totalDuration / completedTraces.length,
      errorRate: (errors / completedTraces.length) * 100,
      slowestOperations
    };
  }

  // Cleanup old traces (keep only last 1000)
  cleanup(): void {
    if (this.traces.size > 1000) {
      const entries = Array.from(this.traces.entries());
      const toDelete = entries.slice(0, entries.length - 1000);
      toDelete.forEach(([spanId]) => this.traces.delete(spanId));
    }
  }
}

export const tracingService = new TracingService();

// Cleanup traces every 5 minutes
setInterval(() => {
  tracingService.cleanup();
}, 300000);

// Express middleware for automatic request tracing
export function tracingMiddleware(req: Request, res: Response, next: NextFunction): void {
  const operationName = `${req.method} ${req.route?.path || req.path}`;
  const context = tracingService.startTrace(operationName);
  
  // Add request metadata
  tracingService.addTags(context.spanId, {
    'http.method': req.method,
    'http.url': req.originalUrl,
    'http.user_agent': req.get('User-Agent'),
    'user.id': (req as any).user?.id,
    'request.id': req.headers['x-request-id']
  });

  // Store context in request for use in route handlers
  (req as any).traceContext = context;

  res.on('finish', () => {
    tracingService.addTags(context.spanId, {
      'http.status_code': res.statusCode,
      'http.response_size': res.get('Content-Length')
    });

    const status = res.statusCode >= 400 ? 'error' : 'ok';
    tracingService.finishTrace(context.spanId, status);
  });

  next();
}

// Helper function to create child spans
export function createChildSpan(req: Request, operationName: string): TraceContext | null {
  const parentContext = (req as any).traceContext;
  if (!parentContext) return null;

  return tracingService.startTrace(operationName, {
    traceId: parentContext.traceId,
    spanId: parentContext.spanId
  });
}

// Helper function to finish child spans
export function finishChildSpan(spanId: string, status: 'ok' | 'error' = 'ok'): void {
  tracingService.finishTrace(spanId, status);
}