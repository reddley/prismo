// Test script for data enrichment service
import { DataEnrichmentService } from './services/dataEnrichmentService.js';

async function testEnrichment() {
  const enrichmentService = new DataEnrichmentService();
  
  console.log('Testing data enrichment...\n');
  
  // Test companies
  const companies = ['Apple Inc', 'Microsoft', 'Google', 'Tesla'];
  
  for (const company of companies) {
    console.log(`\n=== Testing ${company} ===`);
    const data = await enrichmentService.enrichCompanyData(company);
    if (data) {
      console.log('Success:', {
        name: data.name,
        hasDescription: !!data.description,
        hasLogo: !!data.logoUrl,
        logoUrl: data.logoUrl,
        source: data.source
      });
    } else {
      console.log('Failed to enrich');
    }
  }
  
  // Test people
  const people = ['Elon Musk', 'Tim Cook', 'Satya Nadella'];
  
  for (const person of people) {
    console.log(`\n=== Testing ${person} ===`);
    const data = await enrichmentService.enrichPersonData(person);
    if (data) {
      console.log('Success:', {
        name: data.name,
        hasDescription: !!data.description,
        hasImage: !!data.imageUrl,
        imageUrl: data.imageUrl,
        source: data.source
      });
    } else {
      console.log('Failed to enrich');
    }
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  testEnrichment().catch(console.error);
}