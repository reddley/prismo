import NodeCache from 'node-cache';
import Redis from 'ioredis';

// Cache configuration
const CACHE_TTLS = {
  insights: 15 * 60, // 15 minutes
  entities: 60 * 60, // 1 hour
  metrics: 5 * 60,   // 5 minutes
  sources: 30 * 60,  // 30 minutes
  briefings: 10 * 60 // 10 minutes
} as const;

type CacheKey = keyof typeof CACHE_TTLS;

interface CacheStats {
  l1Hits: number;
  l1Misses: number;
  l2Hits: number;
  l2Misses: number;
  totalRequests: number;
  hitRatio: number;
}

class CacheService {
  private l1Cache: NodeCache;
  private l2Cache: Redis | null = null;
  private stats: CacheStats = {
    l1Hits: 0,
    l1Misses: 0,
    l2Hits: 0,
    l2Misses: 0,
    totalRequests: 0,
    hitRatio: 0
  };

  constructor() {
    // L1 Cache - In-process memory cache
    this.l1Cache = new NodeCache({
      stdTTL: 300, // Default 5 minutes
      checkperiod: 60, // Check for expired keys every 60s
      useClones: false, // Don't clone objects for better performance
      maxKeys: 10000 // Limit memory usage
    });

    // L2 Cache - Redis (optional, graceful degradation)
    this.initializeRedis();

    // Log cache stats every 5 minutes
    setInterval(() => {
      this.logStats();
    }, 5 * 60 * 1000);
  }

  private async initializeRedis() {
    try {
      // Check if Redis URL is available
      const redisUrl = process.env.REDIS_URL || process.env.UPSTASH_REDIS_REST_URL;
      
      if (redisUrl) {
        this.l2Cache = new Redis(redisUrl, {
          maxRetriesPerRequest: 3,
          lazyConnect: true,
          connectTimeout: 5000,
          commandTimeout: 3000
        });

        await this.l2Cache.ping();
        console.log('[CACHE] L2 Cache (Redis) connected successfully');
      } else {
        console.log('[CACHE] Redis not configured, using L1 cache only');
      }
    } catch (error) {
      console.warn('[CACHE] Redis connection failed, using L1 cache only:', error instanceof Error ? error.message : String(error));
      this.l2Cache = null;
    }
  }

  private generateKey(type: CacheKey, identifier: string): string {
    return `${type}:${identifier}`;
  }

  private updateStats(l1Hit: boolean, l2Hit: boolean) {
    this.stats.totalRequests++;
    
    if (l1Hit) {
      this.stats.l1Hits++;
    } else {
      this.stats.l1Misses++;
      if (l2Hit) {
        this.stats.l2Hits++;
      } else {
        this.stats.l2Misses++;
      }
    }

    const totalHits = this.stats.l1Hits + this.stats.l2Hits;
    this.stats.hitRatio = (totalHits / this.stats.totalRequests) * 100;
  }

  async get<T>(type: CacheKey, identifier: string): Promise<T | null> {
    const key = this.generateKey(type, identifier);

    try {
      // Try L1 cache first
      const l1Value = this.l1Cache.get<T>(key);
      if (l1Value !== undefined) {
        this.updateStats(true, false);
        return l1Value;
      }

      // Try L2 cache if available
      if (this.l2Cache) {
        try {
          const l2Value = await this.l2Cache.get(key);
          if (l2Value) {
            const parsedValue = JSON.parse(l2Value) as T;
            // Backfill L1 cache
            this.l1Cache.set(key, parsedValue, CACHE_TTLS[type]);
            this.updateStats(false, true);
            return parsedValue;
          }
        } catch (error) {
          console.warn(`[CACHE] L2 cache error for key ${key}:`, error instanceof Error ? error.message : String(error));
        }
      }

      this.updateStats(false, false);
      return null;
    } catch (error) {
      console.error(`[CACHE] Error getting key ${key}:`, error);
      this.updateStats(false, false);
      return null;
    }
  }

  async set<T>(type: CacheKey, identifier: string, value: T): Promise<void> {
    const key = this.generateKey(type, identifier);
    const ttl = CACHE_TTLS[type];

    try {
      // Set in L1 cache
      this.l1Cache.set(key, value, ttl);

      // Set in L2 cache if available
      if (this.l2Cache) {
        try {
          await this.l2Cache.setex(key, ttl, JSON.stringify(value));
        } catch (error) {
          console.warn(`[CACHE] L2 cache set error for key ${key}:`, error instanceof Error ? error.message : String(error));
        }
      }
    } catch (error) {
      console.error(`[CACHE] Error setting key ${key}:`, error);
    }
  }

  async invalidate(type: CacheKey, identifier: string): Promise<void> {
    const key = this.generateKey(type, identifier);

    try {
      // Remove from L1 cache
      this.l1Cache.del(key);

      // Remove from L2 cache if available
      if (this.l2Cache) {
        try {
          await this.l2Cache.del(key);
        } catch (error) {
          console.warn(`[CACHE] L2 cache delete error for key ${key}:`, error instanceof Error ? error.message : String(error));
        }
      }
    } catch (error) {
      console.error(`[CACHE] Error invalidating key ${key}:`, error);
    }
  }

  async invalidatePattern(pattern: string): Promise<void> {
    try {
      // Invalidate L1 cache - get all keys and filter
      const l1Keys = this.l1Cache.keys();
      const matchingKeys = l1Keys.filter(key => key.includes(pattern));
      matchingKeys.forEach(key => this.l1Cache.del(key));

      // Invalidate L2 cache if available
      if (this.l2Cache) {
        try {
          const l2Keys = await this.l2Cache.keys(`*${pattern}*`);
          if (l2Keys.length > 0) {
            await this.l2Cache.del(...l2Keys);
          }
        } catch (error) {
          console.warn(`[CACHE] L2 cache pattern delete error for ${pattern}:`, error instanceof Error ? error.message : String(error));
        }
      }
    } catch (error) {
      console.error(`[CACHE] Error invalidating pattern ${pattern}:`, error);
    }
  }

  async flush(): Promise<void> {
    try {
      // Flush L1 cache
      this.l1Cache.flushAll();

      // Flush L2 cache if available
      if (this.l2Cache) {
        try {
          await this.l2Cache.flushall();
        } catch (error) {
          console.warn('[CACHE] L2 cache flush error:', error instanceof Error ? error.message : String(error));
        }
      }

      // Reset stats
      this.stats = {
        l1Hits: 0,
        l1Misses: 0,
        l2Hits: 0,
        l2Misses: 0,
        totalRequests: 0,
        hitRatio: 0
      };
    } catch (error) {
      console.error('[CACHE] Error flushing caches:', error);
    }
  }

  getStats(): CacheStats {
    return { ...this.stats };
  }

  private logStats(): void {
    if (this.stats.totalRequests > 0) {
      console.log(`[CACHE] Stats - Total: ${this.stats.totalRequests}, L1: ${this.stats.l1Hits}/${this.stats.l1Hits + this.stats.l1Misses}, L2: ${this.stats.l2Hits}/${this.stats.l2Hits + this.stats.l2Misses}, Hit Ratio: ${this.stats.hitRatio.toFixed(2)}%`);
      
      if (this.stats.hitRatio < 70) {
        console.warn(`[CACHE] WARNING: Hit ratio below target (${this.stats.hitRatio.toFixed(2)}% < 70%)`);
      }
    }
  }

  // Helper methods for common cache operations
  async wrap<T>(
    type: CacheKey,
    identifier: string,
    fetchFn: () => Promise<T>
  ): Promise<T> {
    // Try to get from cache first
    const cached = await this.get<T>(type, identifier);
    if (cached !== null) {
      return cached;
    }

    // Fetch from source and cache
    const value = await fetchFn();
    await this.set(type, identifier, value);
    return value;
  }
}

// Export singleton instance
export const cacheService = new CacheService();
export type { CacheStats };