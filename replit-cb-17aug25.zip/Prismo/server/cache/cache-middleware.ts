import { cacheService } from './cache-service';
import type { Request, Response, NextFunction } from 'express';

/**
 * Cache middleware for HTTP endpoints
 * Provides request/response caching with automatic invalidation
 */
export function cacheMiddleware(type: 'insights' | 'entities' | 'metrics' | 'sources' | 'briefings') {
  return (req: Request, res: Response, next: NextFunction) => {
    const originalSend = res.send;
    const cacheKey = `${req.method}:${req.originalUrl}:${JSON.stringify(req.query)}`;

    // For GET requests, try to serve from cache
    if (req.method === 'GET') {
      cacheService.get(type, cacheKey).then(cachedData => {
        if (cachedData) {
          return res.json(cachedData);
        }
        
        // Override res.send to cache the response
        res.send = function(data: any) {
          try {
            const parsedData = typeof data === 'string' ? JSON.parse(data) : data;
            cacheService.set(type, cacheKey, parsedData).catch(err => 
              console.warn('[CACHE] Failed to cache response:', err)
            );
          } catch (error) {
            console.warn('[CACHE] Failed to parse response for caching:', error);
          }
          return originalSend.call(this, data);
        };
        
        next();
      }).catch(err => {
        console.warn('[CACHE] Cache lookup failed:', err);
        next();
      });
    } else {
      // For write operations (POST, PUT, DELETE), invalidate related caches
      const invalidateCache = () => {
        const patterns = getCacheInvalidationPatterns(req.originalUrl, req.method);
        patterns.forEach(pattern => {
          cacheService.invalidatePattern(pattern).catch(err =>
            console.warn('[CACHE] Cache invalidation failed:', err)
          );
        });
      };

      // Override res.send to invalidate cache after successful write
      res.send = function(data: any) {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          invalidateCache();
        }
        return originalSend.call(this, data);
      };
      
      next();
    }
  };
}

/**
 * Determines cache invalidation patterns based on URL and HTTP method
 */
function getCacheInvalidationPatterns(url: string, method: string): string[] {
  const patterns: string[] = [];
  
  if (url.startsWith('/api/insights')) {
    patterns.push('GET:/api/insights');
    patterns.push('GET:/api/dashboard/data');
    patterns.push('GET:/api/metrics');
    patterns.push('GET:/api/cost-stats');
  }
  
  if (url.startsWith('/api/sources')) {
    patterns.push('GET:/api/sources');
    patterns.push('GET:/api/dashboard/data');
    patterns.push('GET:/api/metrics');
  }
  
  if (url.startsWith('/api/monitors')) {
    patterns.push('GET:/api/monitors');
    patterns.push('GET:/api/dashboard/data');
  }
  
  if (url.startsWith('/api/briefings')) {
    patterns.push('GET:/api/briefings');
  }
  
  if (url.startsWith('/api/notifications')) {
    patterns.push('GET:/api/notifications');
  }
  
  // Dashboard and metrics always need fresh data after any write
  if (method !== 'GET') {
    patterns.push('GET:/api/dashboard/data');
    patterns.push('GET:/api/metrics');
    patterns.push('GET:/api/cost-stats');
  }
  
  return patterns;
}

/**
 * Simple wrapper function to cache database queries
 */
export async function withCache<T>(
  type: 'insights' | 'entities' | 'metrics' | 'sources' | 'briefings',
  key: string,
  fetchFn: () => Promise<T>
): Promise<T> {
  return cacheService.wrap(type, key, fetchFn);
}