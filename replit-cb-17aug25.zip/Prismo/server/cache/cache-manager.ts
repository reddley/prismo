import { logger } from '../observability/logger';
import Redis from 'ioredis';

// L1 Cache - In-memory cache with LRU eviction
class MemoryCache {
  private cache = new Map<string, { value: any; expiry: number }>();
  private accessOrder = new Map<string, number>();
  private currentTime = 0;
  
  constructor(private maxSize: number = 1000) {}
  
  set(key: string, value: any, ttlMs: number): void {
    const expiry = Date.now() + ttlMs;
    
    // Remove expired entries and enforce size limit
    this.cleanup();
    
    if (this.cache.size >= this.maxSize && !this.cache.has(key)) {
      this.evictLRU();
    }
    
    this.cache.set(key, { value, expiry });
    this.accessOrder.set(key, ++this.currentTime);
  }
  
  get(key: string): any | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    
    if (entry.expiry < Date.now()) {
      this.cache.delete(key);
      this.accessOrder.delete(key);
      return null;
    }
    
    this.accessOrder.set(key, ++this.currentTime);
    return entry.value;
  }
  
  delete(key: string): void {
    this.cache.delete(key);
    this.accessOrder.delete(key);
  }
  
  clear(): void {
    this.cache.clear();
    this.accessOrder.clear();
  }
  
  private cleanup(): void {
    const now = Date.now();
    for (const [key, entry] of this.cache.entries()) {
      if (entry.expiry < now) {
        this.cache.delete(key);
        this.accessOrder.delete(key);
      }
    }
  }
  
  private evictLRU(): void {
    let oldestKey = '';
    let oldestTime = Infinity;
    
    for (const [key, time] of this.accessOrder.entries()) {
      if (time < oldestTime) {
        oldestTime = time;
        oldestKey = key;
      }
    }
    
    if (oldestKey) {
      this.delete(oldestKey);
    }
  }
  
  getStats(): { size: number; maxSize: number } {
    this.cleanup();
    return { size: this.cache.size, maxSize: this.maxSize };
  }
}

// Cache configuration
export const CACHE_TTL = {
  INSIGHTS: 15 * 60 * 1000,     // 15 minutes
  ENTITIES: 60 * 60 * 1000,     // 1 hour  
  METRICS: 5 * 60 * 1000,       // 5 minutes
  SEARCH: 10 * 60 * 1000,       // 10 minutes
  BRIEFINGS: 30 * 60 * 1000,    // 30 minutes
} as const;

export interface CacheStats {
  l1: { hits: number; misses: number; size: number; maxSize: number };
  l2: { hits: number; misses: number; connected: boolean };
  hitRatio: number;
}

export class CacheManager {
  private l1Cache = new MemoryCache(2000);
  private redis: Redis | null = null;
  private stats = {
    l1: { hits: 0, misses: 0 },
    l2: { hits: 0, misses: 0 }
  };
  
  constructor() {
    this.initRedis();
  }
  
  private async initRedis(): Promise<void> {
    try {
      // Try to connect to Redis if available
      const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';
      this.redis = new Redis(redisUrl, {
        retryDelayOnFailover: 100,
        maxRetriesPerRequest: 2,
        lazyConnect: true,
      });
      
      await this.redis.ping();
      logger.info('Redis L2 cache connected successfully');
    } catch (error) {
      logger.warn('Redis not available, using L1 cache only', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      this.redis = null;
    }
  }
  
  async get<T>(key: string): Promise<T | null> {
    // Try L1 cache first
    const l1Value = this.l1Cache.get(key);
    if (l1Value !== null) {
      this.stats.l1.hits++;
      return l1Value;
    }
    this.stats.l1.misses++;
    
    // Try L2 cache (Redis) if available
    if (this.redis) {
      try {
        const l2Value = await this.redis.get(key);
        if (l2Value) {
          this.stats.l2.hits++;
          const parsed = JSON.parse(l2Value);
          
          // Populate L1 cache with shorter TTL
          const l1TTL = Math.min(parsed.ttl || CACHE_TTL.INSIGHTS, CACHE_TTL.INSIGHTS);
          this.l1Cache.set(key, parsed.data, l1TTL);
          
          return parsed.data;
        }
      } catch (error) {
        logger.warn('Redis get failed', { key, error: error instanceof Error ? error.message : 'Unknown error' });
      }
    }
    this.stats.l2.misses++;
    
    return null;
  }
  
  async set(key: string, value: any, ttlMs: number): Promise<void> {
    // Set in L1 cache
    this.l1Cache.set(key, value, ttlMs);
    
    // Set in L2 cache (Redis) if available
    if (this.redis) {
      try {
        const cacheData = {
          data: value,
          ttl: ttlMs,
          timestamp: Date.now()
        };
        
        const ttlSeconds = Math.floor(ttlMs / 1000);
        await this.redis.setex(key, ttlSeconds, JSON.stringify(cacheData));
      } catch (error) {
        logger.warn('Redis set failed', { key, error: error instanceof Error ? error.message : 'Unknown error' });
      }
    }
  }
  
  async delete(key: string): Promise<void> {
    // Delete from L1 cache
    this.l1Cache.delete(key);
    
    // Delete from L2 cache (Redis) if available
    if (this.redis) {
      try {
        await this.redis.del(key);
      } catch (error) {
        logger.warn('Redis delete failed', { key, error: error instanceof Error ? error.message : 'Unknown error' });
      }
    }
  }
  
  async invalidatePattern(pattern: string): Promise<void> {
    // For L1 cache, we need to iterate and match pattern
    this.l1Cache.clear(); // Simple approach - clear all L1 cache
    
    // For L2 cache (Redis), use SCAN with pattern
    if (this.redis) {
      try {
        const stream = this.redis.scanStream({ match: pattern });
        const keysToDelete: string[] = [];
        
        stream.on('data', (keys: string[]) => {
          keysToDelete.push(...keys);
        });
        
        stream.on('end', async () => {
          if (keysToDelete.length > 0) {
            await this.redis!.del(...keysToDelete);
          }
        });
      } catch (error) {
        logger.warn('Redis pattern invalidation failed', { 
          pattern, 
          error: error instanceof Error ? error.message : 'Unknown error' 
        });
      }
    }
  }
  
  async clear(): Promise<void> {
    this.l1Cache.clear();
    
    if (this.redis) {
      try {
        await this.redis.flushdb();
      } catch (error) {
        logger.warn('Redis clear failed', { error: error instanceof Error ? error.message : 'Unknown error' });
      }
    }
  }
  
  getStats(): CacheStats {
    const l1Stats = this.l1Cache.getStats();
    const l1Total = this.stats.l1.hits + this.stats.l1.misses;
    const l2Total = this.stats.l2.hits + this.stats.l2.misses;
    const totalHits = this.stats.l1.hits + this.stats.l2.hits;
    const totalRequests = l1Total + l2Total;
    
    return {
      l1: {
        ...this.stats.l1,
        ...l1Stats
      },
      l2: {
        ...this.stats.l2,
        connected: this.redis !== null
      },
      hitRatio: totalRequests > 0 ? totalHits / totalRequests : 0
    };
  }
  
  resetStats(): void {
    this.stats = {
      l1: { hits: 0, misses: 0 },
      l2: { hits: 0, misses: 0 }
    };
  }
}

export const cacheManager = new CacheManager();