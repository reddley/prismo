import { Router } from 'express';
import multer from 'multer';
import sharp from 'sharp';
import { promises as fs } from 'fs';
import path from 'path';
import { randomUUID } from 'crypto';

const router = Router();

// Configure multer for memory storage
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.match(/^image\/(png|jpeg|jpg)$/i)) {
      cb(null, true);
    } else {
      cb(new Error('Only PNG and JPG images are allowed'));
    }
  },
});

// Ensure uploads directory exists
const ensureUploadDir = async () => {
  const uploadDir = path.join(process.cwd(), 'uploads');
  try {
    await fs.access(uploadDir);
  } catch {
    await fs.mkdir(uploadDir, { recursive: true });
  }
  return uploadDir;
};

router.post('/upload-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file provided' });
    }

    const { entityType, entityId, maxSizePixels = '2500', targetSizePixels = '500' } = req.body;
    
    if (!entityType || !['company', 'person', 'organization'].includes(entityType)) {
      return res.status(400).json({ error: 'Invalid entity type' });
    }

    const maxSize = parseInt(maxSizePixels);
    const targetSize = parseInt(targetSizePixels);

    // Validate dimensions
    if (maxSize > 2500 || targetSize > 1000) {
      return res.status(400).json({ error: 'Image dimensions exceed limits' });
    }

    const uploadDir = await ensureUploadDir();
    const filename = `${entityType}_${entityId || 'temp'}_${randomUUID()}.webp`;
    const filepath = path.join(uploadDir, filename);

    // Process image with Sharp
    let sharpInstance = sharp(req.file.buffer);
    
    // Get metadata to check original dimensions
    const metadata = await sharpInstance.metadata();
    
    // Validate original dimensions
    if (metadata.width && metadata.height) {
      if (metadata.width > maxSize || metadata.height > maxSize) {
        return res.status(400).json({ 
          error: `Image dimensions (${metadata.width}×${metadata.height}) exceed maximum allowed (${maxSize}×${maxSize})` 
        });
      }
    }

    // Resize to target dimensions and convert to WebP
    await sharpInstance
      .resize(targetSize, targetSize, {
        fit: 'cover',
        position: 'center'
      })
      .webp({ 
        quality: 85,
        effort: 4
      })
      .toFile(filepath);

    // Return the public URL
    const imageUrl = `/uploads/${filename}`;
    
    res.json({ 
      imageUrl,
      originalDimensions: {
        width: metadata.width,
        height: metadata.height
      },
      processedDimensions: {
        width: targetSize,
        height: targetSize
      }
    });

  } catch (error) {
    console.error('Image upload error:', error);
    res.status(500).json({ 
      error: error instanceof Error ? error.message : 'Failed to process image' 
    });
  }
});

export default router;