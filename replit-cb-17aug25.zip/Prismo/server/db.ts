import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";
import { getPoolConfig } from './pool-config';

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Get optimized pool configuration
const poolConfig = getPoolConfig();

// Create connection pool with PgBouncer-style transaction mode settings
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL,
  
  // Connection pool limits (PgBouncer transaction mode simulation)
  max: poolConfig.defaultPoolSize, // Max connections in pool
  min: Math.min(5, Math.floor(poolConfig.defaultPoolSize / 4)), // Minimum idle connections
  
  // Connection lifecycle
  idleTimeoutMillis: poolConfig.idleTimeout,
  connectionTimeoutMillis: poolConfig.connectionTimeout,
  
  // Query settings
  query_timeout: poolConfig.queryTimeout,
  
  // Performance optimizations
  allowExitOnIdle: false, // Keep pool alive
  maxUses: 10000, // Increase connection reuse
  maxLifetimeSeconds: 3600, // 1 hour connection lifetime
});

// Connection pool monitoring
let activeConnections = 0;
let totalQueries = 0;
let queryLatencies: number[] = [];

// Monitor connection usage
pool.on('connect', () => {
  activeConnections++;
  console.log(`[POOL] Connection opened (active: ${activeConnections})`);
});

pool.on('remove', () => {
  activeConnections--;
  console.log(`[POOL] Connection closed (active: ${activeConnections})`);
});

pool.on('error', (err) => {
  console.error('[POOL] Connection pool error:', err);
});

// Query performance tracking
const originalQuery = pool.query.bind(pool);
pool.query = function(text: any, params?: any, callback?: any) {
  const startTime = Date.now();
  totalQueries++;
  
  const result = originalQuery(text, params, callback);
  
  if (result && result instanceof Promise) {
    return result.then((res: any) => {
      const latency = Date.now() - startTime;
      queryLatencies.push(latency);
      
      // Keep only last 1000 latencies for P95 calculation
      if (queryLatencies.length > 1000) {
        queryLatencies = queryLatencies.slice(-1000);
      }
      
      // Log slow queries
      if (latency > poolConfig.targetP95Latency) {
        console.warn(`[POOL] Slow query detected: ${latency}ms`);
      }
      
      return res;
    }).catch((err: any) => {
      const latency = Date.now() - startTime;
      console.error(`[POOL] Query failed after ${latency}ms:`, err);
      throw err;
    });
  }
  
  return result;
};

// Pool health monitoring function
export function getPoolHealth() {
  const sortedLatencies = [...queryLatencies].sort((a, b) => a - b);
  const p95Index = Math.floor(sortedLatencies.length * 0.95);
  const p95Latency = sortedLatencies[p95Index] || 0;
  
  return {
    activeConnections,
    totalConnections: pool.totalCount,
    idleConnections: pool.idleCount,
    waitingCount: pool.waitingCount,
    totalQueries,
    p95Latency,
    isHealthy: p95Latency <= poolConfig.targetP95Latency,
    poolConfig: {
      maxConnections: poolConfig.defaultPoolSize,
      targetP95: poolConfig.targetP95Latency,
      mode: poolConfig.poolMode,
    }
  };
}

// Drizzle ORM with pooled connections
export const db = drizzle({ client: pool, schema });

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('[POOL] Gracefully closing connection pool...');
  await pool.end();
  console.log('[POOL] Connection pool closed');
});

process.on('SIGINT', async () => {
  console.log('[POOL] Gracefully closing connection pool...');
  await pool.end();
  console.log('[POOL] Connection pool closed');
});