/**
 * Comprehensive Test Suite for Unified Services
 * Validates service consolidation and dependency injection
 */

import { 
  getAiIntelligenceService,
  getDataIntelligenceService,
  getUserIntelligenceService,
  getCostIntelligenceService,
  checkServiceHealth,
  initializeServiceRegistry
} from './services/serviceRegistry';
import { logger } from './observability/logger';

async function testUnifiedServices() {
  console.log('\n🚀 Testing Unified Service Architecture\n');
  
  try {
    // Initialize service registry first
    console.log('0. Initializing Service Registry...');
    await initializeServiceRegistry();
    console.log('   ✅ Service Registry initialized successfully');
    
    // Small delay to ensure services are fully registered
    await new Promise(resolve => setTimeout(resolve, 100));
    // Test 1: Service Health Check
    console.log('1. Service Health Check...');
    const healthStatus = await checkServiceHealth();
    console.log(`   ✅ Overall Health: ${healthStatus.healthy ? 'HEALTHY' : 'DEGRADED'}`);
    
    for (const [serviceName, status] of Object.entries(healthStatus.services)) {
      const icon = status.status === 'healthy' ? '✅' : '❌';
      console.log(`   ${icon} ${serviceName}: ${status.status.toUpperCase()}`);
      if (status.error) console.log(`      Error: ${status.error}`);
    }

    // Test 2: AI Intelligence Service
    console.log('\n2. Testing AI Intelligence Service...');
    const aiService = getAiIntelligenceService();
    
    const sentimentResult = await aiService.analyzeSentiment("Apple reports record quarterly revenue growth!");
    console.log(`   ✅ Sentiment Analysis: ${sentimentResult.sentiment} (confidence: ${sentimentResult.confidence}, priority: ${sentimentResult.priority})`);
    
    const category = await aiService.categorizeContent("Apple unveils new AI-powered chip architecture");
    console.log(`   ✅ Content Categorization: ${category}`);

    // Test 3: Data Intelligence Service  
    console.log('\n3. Testing Data Intelligence Service...');
    const dataService = getDataIntelligenceService();
    
    const entities = await dataService.extractEntitiesFromContent("Apple CEO Tim Cook announces strategic partnership with Microsoft");
    console.log(`   ✅ Entity Extraction: Found ${entities.length} entities`);
    
    const companyEnrichment = await dataService.enrichCompanyData("Apple Inc");
    console.log(`   ✅ Company Enrichment: ${companyEnrichment ? 'Data retrieved' : 'No enrichment data'}`);

    // Test 4: User Intelligence Service
    console.log('\n4. Testing User Intelligence Service...');
    const userService = getUserIntelligenceService();
    
    await userService.trackInteraction({
      userId: 'test-user',
      interactionType: 'view',
      category: 'Technology',
      extractedKeywords: ['Apple', 'AI', 'chip'],
      sessionId: 'test-session'
    });
    console.log(`   ✅ Interaction Tracking: Recorded successfully`);
    
    const matchResult = await userService.checkInsightMatchesSpecs('test-user', {
      id: 'test-insight',
      title: 'Apple AI Breakthrough',
      content: 'Apple announces new AI chip technology',
      category: 'Technology',
      priority: 'high'
    });
    console.log(`   ✅ Specs Matching: ${matchResult.matches ? 'Match found' : 'No match'} (relevance: ${Math.round(matchResult.overallRelevance * 100)}%)`);

    // Test 5: Cost Intelligence Service
    console.log('\n5. Testing Cost Intelligence Service...');
    const costService = getCostIntelligenceService();
    
    await costService.recordCost({
      modelName: 'gpt-4o-mini',
      operation: 'test_analysis',
      inputTokens: 100,
      outputTokens: 50,
      cost: 0.001,
      priority: 'medium',
      success: true
    });
    console.log(`   ✅ Cost Recording: Logged successfully`);
    
    await costService.recordRuleBasedOperation('test_rule_operation', 0.002);
    console.log(`   ✅ Rule-Based Operation: Tracked successfully`);
    
    const costStats = await costService.getDailyCostStats();
    console.log(`   ✅ Cost Stats: $${costStats.totalCost.toFixed(3)} spent, ${costStats.ruleBasedOperations} rule-based ops, $${costStats.costSavings.toFixed(3)} saved`);
    
    const withinBudget = await costService.checkBudgetConstraints();
    console.log(`   ✅ Budget Check: ${withinBudget ? 'Within limits' : 'Exceeds limits'}`);

    // Test 6: Performance Metrics
    console.log('\n6. Performance Validation...');
    const startTime = Date.now();
    
    await Promise.all([
      aiService.analyzeSentiment("Test performance"),
      dataService.enrichCompanyData("Test Company"),
      userService.trackInteraction({
        userId: 'perf-test',
        interactionType: 'view',
        sessionId: 'perf-session'
      }),
      costService.recordRuleBasedOperation('performance_test')
    ]);
    
    const duration = Date.now() - startTime;
    console.log(`   ✅ Parallel Operations: Completed in ${duration}ms`);
    console.log(`   ${duration < 100 ? '✅' : '⚠️'} Performance: ${duration < 100 ? 'EXCELLENT' : 'ACCEPTABLE'} (<100ms target)`);

    console.log('\n🎉 Service Consolidation Test Suite PASSED');
    console.log('📊 Architecture Status: UNIFIED & OPERATIONAL');
    
    return true;
  } catch (error) {
    console.error('\n❌ Service Test Failed:', error);
    logger.error('Unified service test failed', { 
      error: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    });
    return false;
  }
}

// Export for use in other modules
export { testUnifiedServices };

// Run tests if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  testUnifiedServices().then(success => {
    process.exit(success ? 0 : 1);
  });
}