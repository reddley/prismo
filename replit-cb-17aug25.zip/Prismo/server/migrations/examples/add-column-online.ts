import { OnlineMigration, migrationRunner } from '../migration-runner';
import { db } from '../../db';
import { sql } from 'drizzle-orm';

/**
 * Example migration: Add priority column to insights table using zero-downtime pattern
 * 
 * Pattern: add → backfill → swap → validate
 * 1. Add new priority column without default (no lock)
 * 2. Backfill existing records in batches
 * 3. Add NOT NULL constraint with NOT VALID (no lock)
 * 4. Validate constraint online
 * 5. Create supporting index
 */
export const addInsightsPriorityMigration: OnlineMigration = {
  id: 'add-insights-priority-v1',
  name: 'Add Priority Column to Insights',
  description: 'Add priority scoring to insights table for better content ranking',
  batchSize: 1000,
  maxConcurrency: 3,
  steps: [
    {
      id: 'add-priority-column',
      description: 'Add priority column to insights table',
      execute: async () => {
        await migrationRunner.addColumnSafely(
          'insights',
          'priority_score',
          'INTEGER'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE insights DROP COLUMN IF EXISTS priority_score'));
      }
    },
    {
      id: 'backfill-priority-scores',
      description: 'Backfill priority scores for existing insights',
      execute: async () => {
        await migrationRunner.batchUpdate(
          'insights',
          `UPDATE insights 
           SET priority_score = CASE 
             WHEN sentiment = 'positive' THEN 80
             WHEN sentiment = 'negative' THEN 60
             WHEN sentiment = 'neutral' THEN 40
             ELSE 50
           END`,
          'priority_score IS NULL',
          (processed, total) => {
            console.log(`Backfilling priority scores: ${processed}/${total}`);
          }
        );
      },
      validation: async () => {
        // Validate that all insights have priority scores
        const result = await db.execute(sql.raw(`
          SELECT COUNT(*) as null_count 
          FROM insights 
          WHERE priority_score IS NULL
        `));
        const nullCount = Number((result as any)[0]?.null_count || 0);
        return nullCount === 0;
      }
    },
    {
      id: 'add-not-null-constraint',
      description: 'Add NOT NULL constraint to priority_score',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'insights',
          'chk_insights_priority_not_null',
          'CHECK (priority_score IS NOT NULL)'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE insights DROP CONSTRAINT IF EXISTS chk_insights_priority_not_null'));
      }
    },
    {
      id: 'add-priority-range-constraint',
      description: 'Add constraint to ensure priority is within valid range',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'insights',
          'chk_insights_priority_range',
          'CHECK (priority_score >= 0 AND priority_score <= 100)'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE insights DROP CONSTRAINT IF EXISTS chk_insights_priority_range'));
      }
    },
    {
      id: 'create-priority-index',
      description: 'Create index on priority_score for fast queries',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_insights_priority_score',
          'insights',
          ['priority_score DESC']
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_insights_priority_score'));
      }
    },
    {
      id: 'create-compound-priority-index',
      description: 'Create compound index for priority + timestamp queries',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_insights_priority_timestamp',
          'insights',
          ['priority_score DESC', 'created_at DESC']
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_insights_priority_timestamp'));
      }
    }
  ]
};

export async function runInsightsPriorityMigration(): Promise<void> {
  await migrationRunner.runMigration(addInsightsPriorityMigration);
}