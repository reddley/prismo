import { OnlineMigration, migrationRunner } from '../migration-runner';
import { db } from '../../db';
import { sql } from 'drizzle-orm';

/**
 * Example migration: Add user preferences table using zero-downtime pattern
 * 
 * Pattern: add → backfill → swap
 * 1. Add new user_preferences table
 * 2. Add foreign key constraint (NOT VALID)
 * 3. Validate constraint
 * 4. Create indexes concurrently
 * 5. Backfill default preferences for existing users
 */
export const addUserPreferencesMigration: OnlineMigration = {
  id: 'add-user-preferences-v1',
  name: 'Add User Preferences System',
  description: 'Add user_preferences table with theme, notifications, and dashboard settings',
  batchSize: 500,
  maxConcurrency: 2,
  steps: [
    {
      id: 'create-user-preferences-table',
      description: 'Create user_preferences table',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS user_preferences (
            id SERIAL PRIMARY KEY,
            user_id VARCHAR(255) NOT NULL,
            theme VARCHAR(20) DEFAULT 'system',
            email_notifications BOOLEAN DEFAULT true,
            push_notifications BOOLEAN DEFAULT true,
            dashboard_layout JSONB DEFAULT '{"layout": "default"}',
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS user_preferences'));
      }
    },
    {
      id: 'add-foreign-key-constraint',
      description: 'Add foreign key constraint to users table',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'user_preferences',
          'fk_user_preferences_user_id',
          'FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE user_preferences DROP CONSTRAINT IF EXISTS fk_user_preferences_user_id'));
      }
    },
    {
      id: 'create-user-id-index',
      description: 'Create index on user_id column',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_user_preferences_user_id',
          'user_preferences',
          ['user_id'],
          { unique: true }
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_user_preferences_user_id'));
      }
    },
    {
      id: 'create-updated-at-index',
      description: 'Create index on updated_at for efficient queries',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_user_preferences_updated_at',
          'user_preferences',
          ['updated_at']
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_user_preferences_updated_at'));
      }
    },
    {
      id: 'backfill-existing-users',
      description: 'Create default preferences for existing users',
      execute: async () => {
        await migrationRunner.batchUpdate(
          'users',
          `INSERT INTO user_preferences (user_id, theme, email_notifications, push_notifications)
           SELECT id, 'system', true, true FROM users u
           WHERE NOT EXISTS (SELECT 1 FROM user_preferences p WHERE p.user_id = u.id)`,
          'EXISTS (SELECT 1 FROM users WHERE id = users.id)',
          (processed, total) => {
            console.log(`Backfilling user preferences: ${processed}/${total}`);
          }
        );
      },
      validation: async () => {
        // Validate that all users have preferences
        const result = await db.execute(sql.raw(`
          SELECT COUNT(*) as missing_count 
          FROM users u 
          WHERE NOT EXISTS (SELECT 1 FROM user_preferences p WHERE p.user_id = u.id)
        `));
        const missingCount = Number((result as any)[0]?.missing_count || 0);
        return missingCount === 0;
      }
    }
  ]
};

// Function to run the migration
export async function runUserPreferencesMigration(): Promise<void> {
  await migrationRunner.runMigration(addUserPreferencesMigration);
}