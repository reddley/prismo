-- Migration tracking tables for zero-downtime migrations

-- Create migration history table to track all migration executions
CREATE TABLE IF NOT EXISTS migration_history (
  id VARCHAR(255) PRIMARY KEY,
  name VARCHAR(500) NOT NULL,
  description TEXT,
  status VARCHAR(50) NOT NULL DEFAULT 'pending', -- pending, running, completed, failed
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create migration steps table to track individual step progress
CREATE TABLE IF NOT EXISTS migration_steps (
  migration_id VARCHAR(255) NOT NULL,
  step_id VARCHAR(255) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'pending', -- pending, running, completed, failed
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (migration_id, step_id),
  FOREIGN KEY (migration_id) REFERENCES migration_history(id) ON DELETE CASCADE
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_migration_history_status ON migration_history(status);
CREATE INDEX IF NOT EXISTS idx_migration_history_started ON migration_history(started_at);
CREATE INDEX IF NOT EXISTS idx_migration_steps_status ON migration_steps(status);

-- Add trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_migration_history_updated_at 
    BEFORE UPDATE ON migration_history 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_migration_steps_updated_at 
    BEFORE UPDATE ON migration_steps 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();