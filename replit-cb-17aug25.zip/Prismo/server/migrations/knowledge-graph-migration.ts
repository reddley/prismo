/**
 * Knowledge Graph Core Data Model Migration
 * 
 * Creates the complete knowledge graph schema with optimized indexes
 * for entity lookups, ANN search, and evidence tracking
 * 
 * Performance targets:
 * - p95 entity lookups <100ms
 * - ANN queries <200ms  
 * - Zero-downtime deployment
 */

import { OnlineMigration, migrationRunner } from './migration-runner';
import { db } from '../db';
import { sql } from 'drizzle-orm';
import { logger } from '../observability/logger';

export const knowledgeGraphMigration: OnlineMigration = {
  id: 'knowledge-graph-core-v1',
  name: 'Knowledge Graph Core Data Model',
  description: 'Create entities, edges, events, and embeddings tables with optimized indexes',
  batchSize: 1000,
  maxConcurrency: 2,
  steps: [
    {
      id: 'enable-pgvector',
      description: 'Enable pgvector extension for vector embeddings',
      execute: async () => {
        await db.execute(sql.raw('CREATE EXTENSION IF NOT EXISTS vector'));
        logger.info('pgvector extension enabled');
      },
      rollback: async () => {
        // Don't drop extension as it might be used by other features
        logger.info('pgvector extension left in place (safe for other features)');
      }
    },

    {
      id: 'create-entities-table',
      description: 'Create entities table with core entity information',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS entities (
            id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
            type TEXT NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'merged', 'deprecated')),
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            source TEXT DEFAULT 'manual',
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
          )
        `));
        logger.info('Entities table created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS entities CASCADE'));
      }
    },

    {
      id: 'create-entity-identifiers-table',
      description: 'Create entity identifiers table for aliases and external IDs',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS entity_identifiers (
            id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
            entity_id VARCHAR NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
            type TEXT NOT NULL,
            value TEXT NOT NULL,
            is_primary BOOLEAN DEFAULT FALSE,
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            source TEXT DEFAULT 'manual',
            created_at TIMESTAMP DEFAULT NOW()
          )
        `));
        logger.info('Entity identifiers table created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS entity_identifiers CASCADE'));
      }
    },

    {
      id: 'create-entity-attributes-table',
      description: 'Create entity attributes table for flexible properties',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS entity_attributes (
            id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
            entity_id VARCHAR NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            data_type TEXT DEFAULT 'text' CHECK (data_type IN ('text', 'number', 'date', 'boolean', 'json', 'url')),
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            source TEXT DEFAULT 'manual',
            source_url TEXT,
            valid_from TIMESTAMP DEFAULT NOW(),
            valid_to TIMESTAMP,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
          )
        `));
        logger.info('Entity attributes table created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS entity_attributes CASCADE'));
      }
    },

    {
      id: 'create-entity-embeddings-table',
      description: 'Create entity embeddings table for vector search',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS entity_embeddings (
            id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
            entity_id VARCHAR NOT NULL REFERENCES entities(id) ON DELETE CASCADE,

            model TEXT NOT NULL DEFAULT 'text-embedding-3-small',
            embedding VECTOR(1536) NOT NULL,
            metadata JSONB,
            created_at TIMESTAMP DEFAULT NOW()
          )
        `));
        logger.info('Entity embeddings table created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS entity_embeddings CASCADE'));
      }
    },

    {
      id: 'create-edges-table',
      description: 'Create edges table for entity relationships',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS edges (
            id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
            from_entity_id VARCHAR NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
            to_entity_id VARCHAR NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
            type TEXT NOT NULL,
            strength REAL DEFAULT 0.5 CHECK (strength >= 0.0 AND strength <= 1.0),
            direction TEXT DEFAULT 'directed' CHECK (direction IN ('directed', 'undirected')),
            status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'historical')),
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            valid_from TIMESTAMP DEFAULT NOW(),
            valid_to TIMESTAMP,
            properties JSONB,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
          )
        `));
        logger.info('Edges table created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS edges CASCADE'));
      }
    },

    {
      id: 'create-edge-evidence-table',
      description: 'Create edge evidence table for relationship proof',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS edge_evidence (
            id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
            edge_id VARCHAR NOT NULL REFERENCES edges(id) ON DELETE CASCADE,
            evidence_type TEXT NOT NULL,
            source_url TEXT,
            source_title TEXT,
            excerpt TEXT,
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            extracted_at TIMESTAMP DEFAULT NOW(),
            created_at TIMESTAMP DEFAULT NOW()
          )
        `));
        logger.info('Edge evidence table created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS edge_evidence CASCADE'));
      }
    },

    {
      id: 'create-events-table',
      description: 'Create events table for temporal knowledge',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS events (
            id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
            type TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            summary TEXT,
            impact TEXT DEFAULT 'medium' CHECK (impact IN ('low', 'medium', 'high', 'critical')),
            status TEXT DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'rumored', 'planned', 'cancelled')),
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            occurred_at TIMESTAMP,
            announced_at TIMESTAMP,
            source_url TEXT,
            source_title TEXT,
            metadata JSONB,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
          )
        `));
        logger.info('Events table created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS events CASCADE'));
      }
    },

    {
      id: 'create-event-participants-table',
      description: 'Create event participants table linking entities to events',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS event_participants (
            id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
            event_id VARCHAR NOT NULL REFERENCES events(id) ON DELETE CASCADE,
            entity_id VARCHAR NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
            role TEXT NOT NULL,
            importance TEXT DEFAULT 'primary' CHECK (importance IN ('primary', 'secondary', 'mentioned')),
            created_at TIMESTAMP DEFAULT NOW()
          )
        `));
        logger.info('Event participants table created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS event_participants CASCADE'));
      }
    },

    // CRITICAL PERFORMANCE INDEXES
    {
      id: 'create-entity-indexes',
      description: 'Create optimized indexes for entity lookups',
      execute: async () => {
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entities_type ON entities(type)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entities_name_trgm ON entities USING gin(name gin_trgm_ops)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entities_status ON entities(status) WHERE status = \'active\''));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entities_type_status ON entities(type, status) WHERE status = \'active\''));
        logger.info('Entity indexes created for <100ms lookup performance');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entities_type'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entities_name_trgm'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entities_status'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entities_type_status'));
      }
    },

    {
      id: 'create-identifier-indexes',
      description: 'Create indexes for entity identifier lookups',
      execute: async () => {
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_identifiers_entity ON entity_identifiers(entity_id)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_identifiers_type_value ON entity_identifiers(type, value)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_identifiers_value_trgm ON entity_identifiers USING gin(value gin_trgm_ops)'));
        await db.execute(sql.raw('CREATE UNIQUE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_identifiers_primary ON entity_identifiers(entity_id, type) WHERE is_primary = true'));
        logger.info('Entity identifier indexes created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_identifiers_entity'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_identifiers_type_value'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_identifiers_value_trgm'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_identifiers_primary'));
      }
    },

    {
      id: 'create-attribute-indexes',
      description: 'Create indexes for entity attribute lookups',
      execute: async () => {
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_attributes_entity ON entity_attributes(entity_id)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_attributes_key ON entity_attributes(key)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_attributes_entity_key ON entity_attributes(entity_id, key)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_attributes_valid ON entity_attributes(valid_from, valid_to) WHERE valid_to IS NULL'));
        logger.info('Entity attribute indexes created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_attributes_entity'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_attributes_key'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_attributes_entity_key'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_attributes_valid'));
      }
    },

    {
      id: 'create-embedding-indexes',
      description: 'Create vector indexes for ANN search (<200ms target)',
      execute: async () => {
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_embeddings_entity ON entity_embeddings(entity_id)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_embeddings_model ON entity_embeddings(model)'));
        // HNSW index for fast vector similarity search
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_embeddings_vector_cosine ON entity_embeddings USING hnsw (embedding vector_cosine_ops)'));
        logger.info('Vector embeddings indexes created for <200ms ANN queries');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_embeddings_entity'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_embeddings_model'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_entity_embeddings_vector_cosine'));
      }
    },

    {
      id: 'create-edge-indexes',
      description: 'Create indexes for relationship traversal',
      execute: async () => {
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_edges_from_entity ON edges(from_entity_id)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_edges_to_entity ON edges(to_entity_id)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_edges_type ON edges(type)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_edges_from_to_type ON edges(from_entity_id, to_entity_id, type)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_edges_valid ON edges(valid_from, valid_to) WHERE valid_to IS NULL'));
        logger.info('Edge indexes created for efficient graph traversal');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_edges_from_entity'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_edges_to_entity'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_edges_type'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_edges_from_to_type'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_edges_valid'));
      }
    },

    {
      id: 'create-evidence-indexes',
      description: 'Create indexes for edge evidence lookups',
      execute: async () => {
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_edge_evidence_edge ON edge_evidence(edge_id)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_edge_evidence_type ON edge_evidence(evidence_type)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_edge_evidence_source ON edge_evidence(source_url) WHERE source_url IS NOT NULL'));
        logger.info('Edge evidence indexes created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_edge_evidence_edge'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_edge_evidence_type'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_edge_evidence_source'));
      }
    },

    {
      id: 'create-event-indexes',
      description: 'Create indexes for event and temporal queries',
      execute: async () => {
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_events_type ON events(type)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_events_occurred_at ON events(occurred_at)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_events_announced_at ON events(announced_at)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_events_impact ON events(impact)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_event_participants_event ON event_participants(event_id)'));
        await db.execute(sql.raw('CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_event_participants_entity ON event_participants(entity_id)'));
        logger.info('Event and participant indexes created');
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_events_type'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_events_occurred_at'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_events_announced_at'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_events_impact'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_event_participants_event'));
        await db.execute(sql.raw('DROP INDEX CONCURRENTLY IF EXISTS idx_event_participants_entity'));
      }
    },

    {
      id: 'enable-trigram-extension',
      description: 'Enable pg_trgm extension for fuzzy text search',
      execute: async () => {
        await db.execute(sql.raw('CREATE EXTENSION IF NOT EXISTS pg_trgm'));
        logger.info('pg_trgm extension enabled for fuzzy text matching');
      },
      rollback: async () => {
        // Don't drop extension as it might be used by other features
        logger.info('pg_trgm extension left in place (safe for other features)');
      }
    },

    {
      id: 'validate-schema',
      description: 'Validate knowledge graph schema integrity',
      execute: async () => {
        // Verify all tables exist
        const tables = ['entities', 'entity_identifiers', 'entity_attributes', 
                       'entity_embeddings', 'edges', 'edge_evidence', 'events', 'event_participants'];
        
        for (const table of tables) {
          const result = await db.execute(sql.raw(`
            SELECT EXISTS (
              SELECT FROM information_schema.tables 
              WHERE table_schema = 'public' 
              AND table_name = '${table}'
            ) as exists
          `));
          const exists = (result.rows as any)[0]?.exists;
          if (!exists) {
            throw new Error(`Table ${table} does not exist`);
          }
        }

        // Verify vector extension
        const vectorResult = await db.execute(sql.raw(`
          SELECT EXISTS (
            SELECT FROM pg_extension 
            WHERE extname = 'vector'
          ) as exists
        `));
        const vectorExists = (vectorResult.rows as any)[0]?.exists;
        if (!vectorExists) {
          throw new Error('pgvector extension not installed');
        }

        logger.info('Knowledge graph schema validation successful');
      },
      validation: async () => {
        try {
          // Test basic operations
          await db.execute(sql.raw('SELECT COUNT(*) FROM entities LIMIT 1'));
          await db.execute(sql.raw('SELECT COUNT(*) FROM entity_embeddings LIMIT 1'));
          await db.execute(sql.raw('SELECT COUNT(*) FROM edges LIMIT 1'));
          return true;
        } catch (error) {
          logger.error('Schema validation failed', { error });
          return false;
        }
      }
    }
  ]
};

// Export for use in migration runner
export default knowledgeGraphMigration;