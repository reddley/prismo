import { db } from '../db';
import { sql } from 'drizzle-orm';
import { logger } from '../observability/logger';

export interface MigrationStep {
  id: string;
  description: string;
  execute: () => Promise<void>;
  rollback?: () => Promise<void>;
  validation?: () => Promise<boolean>;
}

export interface OnlineMigration {
  id: string;
  name: string;
  description: string;
  steps: MigrationStep[];
  batchSize?: number;
  maxConcurrency?: number;
}

export class ZeroDowntimeMigrationRunner {
  private batchSize: number = 1000;
  private maxConcurrency: number = 2;
  private isRunning: boolean = false;

  constructor() {}

  async runMigration(migration: OnlineMigration): Promise<void> {
    if (this.isRunning) {
      throw new Error('Migration already in progress');
    }

    this.isRunning = true;
    this.batchSize = migration.batchSize || this.batchSize;
    this.maxConcurrency = migration.maxConcurrency || this.maxConcurrency;

    logger.info(`Starting zero-downtime migration: ${migration.name}`);

    try {
      // Create migration tracking entry
      await this.recordMigrationStart(migration);

      for (const [index, step] of migration.steps.entries()) {
        logger.info(`Executing step ${index + 1}/${migration.steps.length}: ${step.description}`);
        
        try {
          await step.execute();
          
          // Validate step if validation function exists
          if (step.validation) {
            const isValid = await step.validation();
            if (!isValid) {
              throw new Error(`Step validation failed: ${step.description}`);
            }
          }
          
          await this.recordStepCompletion(migration.id, step.id);
          logger.info(`Completed step: ${step.description}`);
        } catch (error) {
          logger.error(`Step failed: ${step.description}`, { error });
          
          // Attempt rollback if available
          if (step.rollback) {
            logger.info(`Attempting rollback for step: ${step.description}`);
            try {
              await step.rollback();
              logger.info(`Rollback successful for step: ${step.description}`);
            } catch (rollbackError) {
              logger.error(`Rollback failed for step: ${step.description}`, { error: rollbackError });
            }
          }
          
          throw error;
        }
      }

      await this.recordMigrationCompletion(migration);
      logger.info(`Migration completed successfully: ${migration.name}`);
    } catch (error) {
      await this.recordMigrationFailure(migration, error as Error);
      logger.error(`Migration failed: ${migration.name}`, { error });
      throw error;
    } finally {
      this.isRunning = false;
    }
  }

  async batchUpdate<T>(
    tableName: string,
    updateQuery: string,
    whereCondition: string = '1=1',
    progressCallback?: (processed: number, total: number) => void
  ): Promise<void> {
    const countResult = await db.execute(sql.raw(`SELECT COUNT(*) as total FROM ${tableName} WHERE ${whereCondition}`));
    const total = Number(countResult[0]?.total || 0);
    
    if (total === 0) {
      logger.info(`No records to update in ${tableName}`);
      return;
    }

    let processed = 0;
    let offset = 0;

    logger.info(`Starting batch update on ${tableName}: ${total} records`);

    while (processed < total) {
      const batchQuery = `
        ${updateQuery}
        WHERE id IN (
          SELECT id FROM ${tableName} 
          WHERE ${whereCondition}
          ORDER BY id
          LIMIT ${this.batchSize} OFFSET ${offset}
        )
      `;

      const result = await db.execute(sql.raw(batchQuery));
      const batchProcessed = result.rowCount || 0;
      
      processed += batchProcessed;
      offset += this.batchSize;

      if (progressCallback) {
        progressCallback(processed, total);
      }

      logger.info(`Batch update progress: ${processed}/${total} (${Math.round((processed/total) * 100)}%)`);

      // Small delay to avoid overwhelming the database
      await new Promise(resolve => setTimeout(resolve, 10));
      
      // Break if no more records were processed
      if (batchProcessed === 0) break;
    }

    logger.info(`Completed batch update on ${tableName}: ${processed} records processed`);
  }

  async addColumnSafely(
    tableName: string,
    columnName: string,
    columnDefinition: string,
    defaultValue?: string
  ): Promise<void> {
    logger.info(`Adding column ${columnName} to ${tableName}`);
    
    // Add column without default to avoid table lock
    await db.execute(sql.raw(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${columnDefinition}`));
    
    // If default value is specified, update in batches
    if (defaultValue) {
      await this.batchUpdate(
        tableName,
        `UPDATE ${tableName} SET ${columnName} = ${defaultValue}`,
        `${columnName} IS NULL`
      );
    }
  }

  async addConstraintSafely(
    tableName: string,
    constraintName: string,
    constraintDefinition: string
  ): Promise<void> {
    logger.info(`Adding constraint ${constraintName} to ${tableName}`);
    
    // Add constraint as NOT VALID (no lock)
    await db.execute(sql.raw(
      `ALTER TABLE ${tableName} ADD CONSTRAINT ${constraintName} ${constraintDefinition} NOT VALID`
    ));
    
    // Validate constraint (can be done online)
    await db.execute(sql.raw(`ALTER TABLE ${tableName} VALIDATE CONSTRAINT ${constraintName}`));
    
    logger.info(`Constraint ${constraintName} validated successfully`);
  }

  async createIndexConcurrently(
    indexName: string,
    tableName: string,
    columns: string[],
    options: { unique?: boolean; where?: string } = {}
  ): Promise<void> {
    logger.info(`Creating index ${indexName} on ${tableName} concurrently`);
    
    const uniqueClause = options.unique ? 'UNIQUE' : '';
    const whereClause = options.where ? `WHERE ${options.where}` : '';
    
    await db.execute(sql.raw(
      `CREATE ${uniqueClause} INDEX CONCURRENTLY ${indexName} ON ${tableName} (${columns.join(', ')}) ${whereClause}`
    ));
    
    logger.info(`Index ${indexName} created successfully`);
  }

  private async recordMigrationStart(migration: OnlineMigration): Promise<void> {
    await db.execute(sql`
      INSERT INTO migration_history (id, name, description, status, started_at)
      VALUES (${migration.id}, ${migration.name}, ${migration.description}, 'running', NOW())
      ON CONFLICT (id) DO UPDATE SET
        status = 'running',
        started_at = NOW(),
        completed_at = NULL,
        error_message = NULL
    `);
  }

  private async recordStepCompletion(migrationId: string, stepId: string): Promise<void> {
    await db.execute(sql`
      INSERT INTO migration_steps (migration_id, step_id, status, completed_at)
      VALUES (${migrationId}, ${stepId}, 'completed', NOW())
      ON CONFLICT (migration_id, step_id) DO UPDATE SET
        status = 'completed',
        completed_at = NOW()
    `);
  }

  private async recordMigrationCompletion(migration: OnlineMigration): Promise<void> {
    await db.execute(sql`
      UPDATE migration_history 
      SET status = 'completed', completed_at = NOW()
      WHERE id = ${migration.id}
    `);
  }

  private async recordMigrationFailure(migration: OnlineMigration, error: Error): Promise<void> {
    await db.execute(sql`
      UPDATE migration_history 
      SET status = 'failed', completed_at = NOW(), error_message = ${error.message}
      WHERE id = ${migration.id}
    `);
  }

  async getMigrationStatus(migrationId?: string): Promise<any[]> {
    if (migrationId) {
      const result = await db.execute(sql`
        SELECT * FROM migration_history 
        WHERE id = ${migrationId}
        ORDER BY started_at DESC
      `);
      return result.rows || [];
    } else {
      const result = await db.execute(sql`
        SELECT * FROM migration_history 
        ORDER BY started_at DESC
      `);
      return result.rows || [];
    }
  }

  isRunningMigration(): boolean {
    return this.isRunning;
  }
}

export const migrationRunner = new ZeroDowntimeMigrationRunner();