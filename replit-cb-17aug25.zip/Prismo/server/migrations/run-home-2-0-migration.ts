import { ZeroDowntimeMigrationRunner } from './migration-runner';
import { addHome20ReportsMigration } from './add-home-2-0-reports';

async function runHome20Migration() {
  const migrationRunner = new ZeroDowntimeMigrationRunner();
  
  try {
    console.log('🚀 Starting Home 2.0 Reports Migration...');
    await migrationRunner.runMigration(addHome20ReportsMigration);
    console.log('✅ Home 2.0 Reports Migration completed successfully!');
    console.log('📊 Starter templates created: recent-headlines, watchlist, market-movers');
  } catch (error) {
    console.error('❌ Home 2.0 Reports Migration failed:', error);
    process.exit(1);
  }
}

// Run migration if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runHome20Migration()
    .then(() => {
      console.log('Migration process completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Migration process failed:', error);
      process.exit(1);
    });
}

export { runHome20Migration };