import { sql } from "drizzle-orm";
import type { OnlineMigration } from "./migration-runner";
import { migrationRunner } from "./migration-runner";
import { db } from "../db";

/**
 * Core Knowledge Graph Data Model Migration
 * 
 * Creates the foundational tables for entity-based intelligence:
 * - entities: Core entity registry
 * - entity_identifiers: Entity aliases and identifiers
 * - entity_attributes: Flexible entity properties
 * - entity_embeddings: Vector embeddings for semantic search
 * - edges: Entity relationships
 * - edge_evidence: Supporting evidence for relationships
 * - events: Time-based occurrences
 * - event_participants: Entity participation in events
 * 
 * Performance targets:
 * - P95 entity lookups <100ms
 * - ANN queries <200ms on sample data
 */
export const knowledgeGraphCoreMigration: OnlineMigration = {
  id: 'knowledge-graph-core-v2',
  name: 'Knowledge Graph Core Data Model',
  description: 'Add core entity, edge, and event tables with pgvector support for embeddings',
  batchSize: 1000,
  maxConcurrency: 3,
  steps: [
    {
      id: 'enable-pgvector-extension',
      description: 'Enable pgvector extension for vector operations',
      execute: async () => {
        await db.execute(sql.raw('CREATE EXTENSION IF NOT EXISTS vector'));
      },
      rollback: async () => {
        // Don't drop extension as it might be used by other features
        console.log('pgvector extension preserved (may be used by other features)');
      }
    },
    {
      id: 'enable-trigram-extension',
      description: 'Enable pg_trgm extension for fuzzy text search',
      execute: async () => {
        await db.execute(sql.raw('CREATE EXTENSION IF NOT EXISTS pg_trgm'));
      },
      rollback: async () => {
        // Don't drop extension as it might be used elsewhere
        console.log('pg_trgm extension preserved (may be used by other features)');
      }
    },
    {
      id: 'create-entities-table',
      description: 'Create core entities table',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS entities (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            type TEXT NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'merged', 'deprecated')),
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            source TEXT DEFAULT 'manual',
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS entities CASCADE'));
      }
    },
    {
      id: 'create-entity-identifiers-table',
      description: 'Create entity identifiers table for aliases and external IDs',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS entity_identifiers (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            entity_id VARCHAR(255) NOT NULL,
            type TEXT NOT NULL,
            value TEXT NOT NULL,
            is_primary BOOLEAN DEFAULT false,
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            source TEXT DEFAULT 'manual',
            created_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS entity_identifiers CASCADE'));
      }
    },
    {
      id: 'create-entity-attributes-table',
      description: 'Create entity attributes table for flexible properties',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS entity_attributes (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            entity_id VARCHAR(255) NOT NULL,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            data_type TEXT DEFAULT 'text' CHECK (data_type IN ('text', 'number', 'date', 'boolean', 'json', 'url')),
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            source TEXT DEFAULT 'manual',
            source_url TEXT,
            valid_from TIMESTAMPTZ DEFAULT NOW(),
            valid_to TIMESTAMPTZ,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS entity_attributes CASCADE'));
      }
    },
    {
      id: 'create-entity-embeddings-table',
      description: 'Create entity embeddings table for semantic search',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS entity_embeddings (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            entity_id VARCHAR(255) NOT NULL,
            model TEXT NOT NULL,
            embedding vector(1536),
            source_text TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS entity_embeddings CASCADE'));
      }
    },
    {
      id: 'create-edges-table',
      description: 'Create edges table for entity relationships',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS edges (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            from_entity_id VARCHAR(255) NOT NULL,
            to_entity_id VARCHAR(255) NOT NULL,
            type TEXT NOT NULL,
            strength REAL DEFAULT 0.5 CHECK (strength >= 0.0 AND strength <= 1.0),
            direction TEXT DEFAULT 'directed' CHECK (direction IN ('directed', 'undirected')),
            status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'historical')),
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            valid_from TIMESTAMPTZ DEFAULT NOW(),
            valid_to TIMESTAMPTZ,
            properties JSONB,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS edges CASCADE'));
      }
    },
    {
      id: 'create-edge-evidence-table',
      description: 'Create edge evidence table for relationship supporting evidence',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS edge_evidence (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            edge_id VARCHAR(255) NOT NULL,
            evidence_type TEXT NOT NULL,
            source_url TEXT,
            source_title TEXT,
            source_text TEXT,
            extracted_text TEXT,
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            published_at TIMESTAMPTZ,
            discovered_at TIMESTAMPTZ DEFAULT NOW(),
            created_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS edge_evidence CASCADE'));
      }
    },
    {
      id: 'create-events-table',
      description: 'Create events table for time-based occurrences',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS events (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            type TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            summary TEXT,
            impact TEXT DEFAULT 'medium' CHECK (impact IN ('low', 'medium', 'high', 'critical')),
            status TEXT DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'rumored', 'planned', 'cancelled')),
            confidence REAL DEFAULT 1.0 CHECK (confidence >= 0.0 AND confidence <= 1.0),
            occurred_at TIMESTAMPTZ,
            announced_at TIMESTAMPTZ,
            source_url TEXT,
            source_title TEXT,
            metadata JSONB,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS events CASCADE'));
      }
    },
    {
      id: 'create-event-participants-table',
      description: 'Create event participants table for entity involvement in events',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS event_participants (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            event_id VARCHAR(255) NOT NULL,
            entity_id VARCHAR(255) NOT NULL,
            role TEXT NOT NULL,
            importance TEXT DEFAULT 'primary' CHECK (importance IN ('primary', 'secondary', 'mentioned')),
            created_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS event_participants CASCADE'));
      }
    },
    // Add foreign key constraints after tables are created
    {
      id: 'add-entity-identifiers-fk',
      description: 'Add foreign key constraint for entity_identifiers.entity_id',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'entity_identifiers',
          'fk_entity_identifiers_entity_id',
          'FOREIGN KEY (entity_id) REFERENCES entities(id) ON DELETE CASCADE'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE entity_identifiers DROP CONSTRAINT IF EXISTS fk_entity_identifiers_entity_id'));
      }
    },
    {
      id: 'add-entity-attributes-fk',
      description: 'Add foreign key constraint for entity_attributes.entity_id',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'entity_attributes',
          'fk_entity_attributes_entity_id',
          'FOREIGN KEY (entity_id) REFERENCES entities(id) ON DELETE CASCADE'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE entity_attributes DROP CONSTRAINT IF EXISTS fk_entity_attributes_entity_id'));
      }
    },
    {
      id: 'add-entity-embeddings-fk',
      description: 'Add foreign key constraint for entity_embeddings.entity_id',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'entity_embeddings',
          'fk_entity_embeddings_entity_id',
          'FOREIGN KEY (entity_id) REFERENCES entities(id) ON DELETE CASCADE'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE entity_embeddings DROP CONSTRAINT IF EXISTS fk_entity_embeddings_entity_id'));
      }
    },
    {
      id: 'add-edges-fk',
      description: 'Add foreign key constraints for edges table',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'edges',
          'fk_edges_from_entity_id',
          'FOREIGN KEY (from_entity_id) REFERENCES entities(id) ON DELETE CASCADE'
        );
        await migrationRunner.addConstraintSafely(
          'edges',
          'fk_edges_to_entity_id',
          'FOREIGN KEY (to_entity_id) REFERENCES entities(id) ON DELETE CASCADE'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE edges DROP CONSTRAINT IF EXISTS fk_edges_from_entity_id'));
        await db.execute(sql.raw('ALTER TABLE edges DROP CONSTRAINT IF EXISTS fk_edges_to_entity_id'));
      }
    },
    {
      id: 'add-edge-evidence-fk',
      description: 'Add foreign key constraint for edge_evidence.edge_id',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'edge_evidence',
          'fk_edge_evidence_edge_id',
          'FOREIGN KEY (edge_id) REFERENCES edges(id) ON DELETE CASCADE'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE edge_evidence DROP CONSTRAINT IF EXISTS fk_edge_evidence_edge_id'));
      }
    },
    {
      id: 'add-event-participants-fk',
      description: 'Add foreign key constraints for event_participants table',
      execute: async () => {
        await migrationRunner.addConstraintSafely(
          'event_participants',
          'fk_event_participants_event_id',
          'FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE'
        );
        await migrationRunner.addConstraintSafely(
          'event_participants',
          'fk_event_participants_entity_id',
          'FOREIGN KEY (entity_id) REFERENCES entities(id) ON DELETE CASCADE'
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE event_participants DROP CONSTRAINT IF EXISTS fk_event_participants_event_id'));
        await db.execute(sql.raw('ALTER TABLE event_participants DROP CONSTRAINT IF EXISTS fk_event_participants_entity_id'));
      }
    },
    // Create optimized indexes for fast lookups and ANN search
    {
      id: 'create-entities-indexes',
      description: 'Create indexes on entities table for fast lookups',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_entities_type_name',
          'entities',
          ['type', 'name']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_entities_status_updated_at',
          'entities',
          ['status', 'updated_at DESC']
        );
        // Create trigram index for fuzzy name search
        await db.execute(sql.raw(`
          CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entities_name_trgm 
          ON entities USING gin (name gin_trgm_ops)
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entities_type_name'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entities_status_updated_at'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entities_name_trgm'));
      }
    },
    {
      id: 'create-entity-identifiers-indexes',
      description: 'Create indexes on entity_identifiers for efficient lookups',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_entity_identifiers_entity_id',
          'entity_identifiers',
          ['entity_id']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_entity_identifiers_type_value',
          'entity_identifiers',
          ['type', 'value'],
          { unique: true }
        );
        // Create trigram index for fuzzy value search
        await db.execute(sql.raw(`
          CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_identifiers_value_trgm 
          ON entity_identifiers USING gin (value gin_trgm_ops)
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_identifiers_entity_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_identifiers_type_value'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_identifiers_value_trgm'));
      }
    },
    {
      id: 'create-entity-attributes-indexes',
      description: 'Create indexes on entity_attributes for attribute lookups',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_entity_attributes_entity_id',
          'entity_attributes',
          ['entity_id']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_entity_attributes_key_value',
          'entity_attributes',
          ['key', 'value']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_entity_attributes_valid_range',
          'entity_attributes',
          ['entity_id', 'valid_from', 'valid_to']
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_attributes_entity_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_attributes_key_value'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_attributes_valid_range'));
      }
    },
    {
      id: 'create-entity-embeddings-indexes',
      description: 'Create vector indexes for ANN search on embeddings',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_entity_embeddings_entity_id',
          'entity_embeddings',
          ['entity_id']
        );
        // Create HNSW index for fast ANN queries (targeting <200ms performance)
        await db.execute(sql.raw(`
          CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_embeddings_vector_hnsw 
          ON entity_embeddings USING hnsw (embedding vector_cosine_ops) 
          WITH (m = 16, ef_construction = 64)
        `));
        await migrationRunner.createIndexConcurrently(
          'idx_entity_embeddings_model',
          'entity_embeddings',
          ['model', 'created_at DESC']
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_embeddings_entity_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_embeddings_vector_hnsw'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_entity_embeddings_model'));
      }
    },
    {
      id: 'create-edges-indexes',
      description: 'Create indexes on edges for relationship queries',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_edges_from_entity_id',
          'edges',
          ['from_entity_id', 'status']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_edges_to_entity_id',
          'edges',
          ['to_entity_id', 'status']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_edges_type_strength',
          'edges',
          ['type', 'strength DESC']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_edges_bidirectional',
          'edges',
          ['from_entity_id', 'to_entity_id', 'type']
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_edges_from_entity_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_edges_to_entity_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_edges_type_strength'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_edges_bidirectional'));
      }
    },
    {
      id: 'create-edge-evidence-indexes',
      description: 'Create indexes on edge_evidence for evidence lookups',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_edge_evidence_edge_id',
          'edge_evidence',
          ['edge_id']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_edge_evidence_type_confidence',
          'edge_evidence',
          ['evidence_type', 'confidence DESC']
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_edge_evidence_edge_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_edge_evidence_type_confidence'));
      }
    },
    {
      id: 'create-events-indexes',
      description: 'Create indexes on events for temporal and impact queries',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_events_type_occurred_at',
          'events',
          ['type', 'occurred_at DESC']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_events_impact_status',
          'events',
          ['impact', 'status', 'occurred_at DESC']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_events_announced_at',
          'events',
          ['announced_at DESC']
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_events_type_occurred_at'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_events_impact_status'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_events_announced_at'));
      }
    },
    {
      id: 'create-event-participants-indexes',
      description: 'Create indexes on event_participants for entity-event lookups',
      execute: async () => {
        await migrationRunner.createIndexConcurrently(
          'idx_event_participants_event_id',
          'event_participants',
          ['event_id', 'importance']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_event_participants_entity_id',
          'event_participants',
          ['entity_id', 'role']
        );
        await migrationRunner.createIndexConcurrently(
          'idx_event_participants_unique',
          'event_participants',
          ['event_id', 'entity_id', 'role'],
          { unique: true }
        );
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_event_participants_event_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_event_participants_entity_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_event_participants_unique'));
      }
    }
  ]
};