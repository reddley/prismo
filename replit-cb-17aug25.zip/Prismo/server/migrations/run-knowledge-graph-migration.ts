/**
 * Knowledge Graph Migration Runner
 * 
 * Executes the zero-downtime migration for the knowledge graph schema
 * with performance monitoring and rollback capabilities
 */

import { migrationRunner } from './migration-runner';
import knowledgeGraphMigration from './knowledge-graph-migration';
import { testKnowledgeGraphOperations } from '../test-knowledge-graph';
import { logger } from '../observability/logger';

async function runKnowledgeGraphMigration() {
  console.log('\n🚀 Starting Knowledge Graph Migration\n');
  
  try {
    // Run the zero-downtime migration
    console.log('1. Executing zero-downtime schema migration...');
    await migrationRunner.runMigration(knowledgeGraphMigration);
    console.log('   ✅ Schema migration completed successfully');

    // Wait a moment for indexes to be fully ready
    console.log('\n2. Allowing indexes to stabilize...');
    await new Promise(resolve => setTimeout(resolve, 2000));
    console.log('   ✅ Index stabilization complete');

    // Run comprehensive tests
    console.log('\n3. Running performance validation tests...');
    const testResults = await testKnowledgeGraphOperations();
    
    if (!testResults.success) {
      throw new Error(`Performance tests failed: ${testResults.error}`);
    }

    const { metrics } = testResults;
    console.log('\n🎉 Knowledge Graph Migration SUCCESSFUL');
    console.log('📊 Performance Validation Results:');
    console.log(`   • Entity lookup p95: ${metrics!.entityLookupP95}ms (target: <100ms)`);
    console.log(`   • ANN query p95: ${metrics!.annQueryP95}ms (target: <200ms)`);
    console.log(`   • Insert operations avg: ${metrics!.avgInsert.toFixed(1)}ms`);
    console.log(`   • Graph traversal avg: ${metrics!.avgTraversal.toFixed(1)}ms`);
    
    // Verify performance targets
    const entityTargetMet = metrics!.entityLookupP95 < 100;
    const annTargetMet = metrics!.annQueryP95 < 200;
    
    console.log('\n🎯 Performance Target Status:');
    console.log(`   ${entityTargetMet ? '✅' : '⚠️'} Entity lookups: ${entityTargetMet ? 'PASSED' : 'NEEDS OPTIMIZATION'}`);
    console.log(`   ${annTargetMet ? '✅' : '⚠️'} ANN queries: ${annTargetMet ? 'PASSED' : 'NEEDS OPTIMIZATION'}`);
    
    if (entityTargetMet && annTargetMet) {
      console.log('\n🏆 ALL PERFORMANCE TARGETS MET');
    } else {
      console.log('\n⚠️ Some performance targets not met - consider index tuning');
    }

    logger.info('Knowledge graph migration completed successfully', {
      entityLookupP95: metrics!.entityLookupP95,
      annQueryP95: metrics!.annQueryP95,
      avgInsert: metrics!.avgInsert,
      avgTraversal: metrics!.avgTraversal,
      entityTargetMet,
      annTargetMet
    });

    return true;
    
  } catch (error) {
    console.error('\n❌ Knowledge Graph Migration Failed:', error);
    logger.error('Knowledge graph migration failed', { 
      error: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    });
    
    console.log('\n🔄 Consider running rollback if needed:');
    console.log('   npx tsx server/migrations/rollback-knowledge-graph.ts');
    
    return false;
  }
}

// Export for use in other modules
export { runKnowledgeGraphMigration };

// Run migration if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runKnowledgeGraphMigration().then(success => {
    process.exit(success ? 0 : 1);
  });
}