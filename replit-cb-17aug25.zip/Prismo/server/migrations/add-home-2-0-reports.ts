import { sql } from 'drizzle-orm';
import { type OnlineMigration } from './migration-runner';
import { db } from '../db';

export const addHome20ReportsMigration: OnlineMigration = {
  id: 'add-home-2-0-reports-v1',
  name: 'Add Home 2.0 Customizable Reports System',
  description: 'Create report_templates and installed_reports tables for the new customizable dashboard',
  batchSize: 500,
  maxConcurrency: 2,
  steps: [
    {
      id: 'create-report-templates-table',
      description: 'Create report_templates table',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS report_templates (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            slug TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            version INTEGER DEFAULT 1,
            inputs_schema JSONB NOT NULL,
            preview_img TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS report_templates CASCADE'));
      }
    },
    {
      id: 'create-installed-reports-table',
      description: 'Create installed_reports table',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS installed_reports (
            id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid(),
            user_id VARCHAR(255) NOT NULL,
            template_id VARCHAR(255) NOT NULL,
            config_json JSONB DEFAULT '{}',
            layout_json JSONB DEFAULT '{}',
            state TEXT DEFAULT 'active' CHECK (state IN ('active', 'inactive', 'archived')),
            created_at TIMESTAMPTZ DEFAULT NOW()
          )
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP TABLE IF EXISTS installed_reports CASCADE'));
      }
    },
    {
      id: 'add-installed-reports-user-fk',
      description: 'Add foreign key constraint from installed_reports to users',
      execute: async () => {
        await db.execute(sql.raw(`
          ALTER TABLE installed_reports 
          ADD CONSTRAINT fk_installed_reports_user_id 
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE installed_reports DROP CONSTRAINT IF EXISTS fk_installed_reports_user_id'));
      }
    },
    {
      id: 'add-installed-reports-template-fk',
      description: 'Add foreign key constraint from installed_reports to report_templates',
      execute: async () => {
        await db.execute(sql.raw(`
          ALTER TABLE installed_reports 
          ADD CONSTRAINT fk_installed_reports_template_id 
          FOREIGN KEY (template_id) REFERENCES report_templates(id) ON DELETE CASCADE
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('ALTER TABLE installed_reports DROP CONSTRAINT IF EXISTS fk_installed_reports_template_id'));
      }
    },
    {
      id: 'create-report-templates-indexes',
      description: 'Create indexes for report_templates table',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_report_templates_slug 
          ON report_templates(slug)
        `));
        await db.execute(sql.raw(`
          CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_report_templates_category 
          ON report_templates(category)
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_report_templates_slug'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_report_templates_category'));
      }
    },
    {
      id: 'create-installed-reports-indexes',
      description: 'Create indexes for installed_reports table',
      execute: async () => {
        await db.execute(sql.raw(`
          CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_installed_reports_user_id 
          ON installed_reports(user_id)
        `));
        await db.execute(sql.raw(`
          CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_installed_reports_template_id 
          ON installed_reports(template_id)
        `));
        await db.execute(sql.raw(`
          CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_installed_reports_state 
          ON installed_reports(state)
        `));
      },
      rollback: async () => {
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_installed_reports_user_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_installed_reports_template_id'));
        await db.execute(sql.raw('DROP INDEX IF EXISTS idx_installed_reports_state'));
      }
    },
    {
      id: 'seed-starter-report-templates',
      description: 'Insert three starter report templates with JSON schemas',
      execute: async () => {
        await db.execute(sql.raw(`
          INSERT INTO report_templates (slug, name, category, inputs_schema) VALUES
          (
            'recent-headlines',
            'Recent Headlines',
            'news',
            '{"type": "object", "properties": {"limit": {"type": "number", "default": 10, "minimum": 1, "maximum": 50}, "categories": {"type": "array", "items": {"type": "string", "enum": ["technology", "finance", "general", "social", "patents"]}, "default": ["technology", "finance"]}, "timeRange": {"type": "string", "enum": ["1h", "6h", "24h", "3d", "1w"], "default": "24h"}}, "required": ["limit"]}'
          ),
          (
            'watchlist',
            'Stock Watchlist',
            'finance',
            '{"type": "object", "properties": {"displayMode": {"type": "string", "enum": ["compact", "detailed", "chart"], "default": "detailed"}, "sortBy": {"type": "string", "enum": ["name", "price", "change", "changePercent"], "default": "name"}, "showChange": {"type": "boolean", "default": true}, "refreshInterval": {"type": "number", "enum": [10, 30, 60, 300], "default": 30}}, "required": []}'
          ),
          (
            'market-movers',
            'Market Movers',
            'finance',
            '{"type": "object", "properties": {"period": {"type": "string", "enum": ["1d", "1w", "1m", "3m"], "default": "1d"}, "marketType": {"type": "string", "enum": ["stocks", "crypto", "forex"], "default": "stocks"}, "movementType": {"type": "string", "enum": ["gainers", "losers", "most_active"], "default": "gainers"}, "count": {"type": "number", "default": 10, "minimum": 5, "maximum": 25}}, "required": ["period", "count"]}'
          )
          ON CONFLICT (slug) DO NOTHING
        `));
      },
      validation: async () => {
        const result = await db.execute(sql.raw(`
          SELECT COUNT(*) as template_count 
          FROM report_templates 
          WHERE slug IN ('recent-headlines', 'watchlist', 'market-movers')
        `));
        const templateCount = Number((result as any)[0]?.template_count || 0);
        return templateCount === 3;
      }
    }
  ]
};