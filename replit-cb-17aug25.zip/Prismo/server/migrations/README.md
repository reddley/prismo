# Zero-Downtime Migration System

## Overview

This migration system implements the "add → backfill → swap" pattern to enable database schema changes without downtime or table locks. All operations are designed to be safe for production environments with high availability requirements.

## Architecture

### Core Components

1. **Migration Runner** (`migration-runner.ts`)
   - Executes migration steps in sequence
   - Provides batch processing for data backfills
   - Supports rollback functionality
   - Tracks migration progress and status

2. **Migration Tracking Tables**
   - `migration_history`: Records all migration executions
   - `migration_steps`: Tracks individual step progress
   - Automatically created via `migration-tables.sql`

3. **API Endpoints**
   - `GET /api/migrations/status` - View migration status and history
   - `GET /api/migrations/available` - List available migrations
   - `POST /api/migrations/run/:migrationName` - Execute a migration

## Migration Pattern: "Add → Backfill → Swap"

### 1. Add Phase
- Add new columns/tables without defaults (avoids table locks)
- Add constraints with `NOT VALID` (no immediate validation)
- Create indexes `CONCURRENTLY` (non-blocking)

### 2. Backfill Phase
- Update existing records in small batches
- Use configurable batch sizes (default: 1000 records)
- Include progress tracking and validation

### 3. Swap/Validate Phase
- Validate constraints online (`ALTER TABLE ... VALIDATE CONSTRAINT`)
- Switch application code to use new schema
- Drop unused columns/tables in future migrations

## Key Features

### Non-Blocking Operations
- Uses `CREATE INDEX CONCURRENTLY`
- Adds constraints with `NOT VALID` then validates online
- Processes data in configurable batch sizes

### Safety Mechanisms
- Step-by-step validation functions
- Automatic rollback support for failed steps
- Progress tracking and detailed logging
- Prevents concurrent migration execution

### Monitoring & Observability
- Real-time progress reporting
- Integration with existing logging system
- Migration status tracking in database
- API endpoints for external monitoring

## Example Migrations

### 1. Adding User Preferences Table
```typescript
// Creates new user_preferences table
// Adds foreign key constraints safely
// Creates indexes concurrently
// Backfills default preferences for existing users
```

### 2. Adding Priority Column to Insights
```typescript
// Adds priority_score column without default
// Backfills scores based on sentiment analysis
// Adds NOT NULL and range constraints
// Creates optimized indexes for queries
```

## Usage

### Running Migrations

1. **List Available Migrations**
   ```bash
   curl "http://localhost:5000/api/migrations/available"
   ```

2. **Check Migration Status**
   ```bash
   curl "http://localhost:5000/api/migrations/status"
   ```

3. **Run a Migration**
   ```bash
   curl -X POST "http://localhost:5000/api/migrations/run/user-preferences"
   ```

### Creating New Migrations

1. Create migration file in `examples/` directory
2. Define migration steps with execute/rollback functions
3. Add validation functions for critical steps
4. Register migration in `routes.ts`

## Best Practices

### Schema Changes
- Always add columns without defaults initially
- Use `NOT VALID` constraints, then validate online
- Create indexes `CONCURRENTLY`
- Plan rollback strategies for each step

### Data Backfills
- Use reasonable batch sizes (500-2000 records)
- Include progress callbacks for monitoring
- Add delays between batches to reduce load
- Validate data integrity after backfills

### Testing
- Test migrations on production-like data volumes
- Verify rollback procedures work correctly
- Monitor performance impact during execution
- Test concurrent application operations

## Monitoring

### Database Impact
- Connection pool usage remains stable
- Query performance not affected during migrations
- No table locks or blocking operations
- Progress visible in migration_history table

### Application Impact
- Zero downtime during schema changes
- No service interruptions
- Gradual data transitions
- Backward compatibility maintained

## Troubleshooting

### Common Issues
1. **Migration Stuck**: Check batch processing progress
2. **Constraint Violations**: Review validation functions
3. **Performance Impact**: Adjust batch sizes
4. **Rollback Failures**: Check rollback function implementation

### Recovery
- All migrations are logged in database
- Failed steps can be individually retried
- Rollback functions available for each step
- Manual intervention possible via direct SQL

## Implementation Notes

### PostgreSQL Features Used
- `CREATE INDEX CONCURRENTLY`
- `ALTER TABLE ... ADD CONSTRAINT ... NOT VALID`
- `ALTER TABLE ... VALIDATE CONSTRAINT`
- Batch processing with `LIMIT`/`OFFSET`
- Transaction isolation for safety

### Performance Characteristics
- Batch size: 1000 records (configurable)
- Max concurrency: 2 (configurable)
- Progress reporting every batch
- 10ms delays between batches
- Non-blocking index creation

This system ensures production databases can evolve safely without compromising availability or data integrity.