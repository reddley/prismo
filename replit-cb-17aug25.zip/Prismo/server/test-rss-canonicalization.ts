/**
 * Test RSS + Entity Canonicalization Integration
 * 
 * Demonstrates the full pipeline: RSS ingestion → Entity extraction → Canonicalization
 */

import { fetchRSSFeed } from './services/rss-parser';
import { storage } from './storage';
import { EntityCanonicalizationService } from './services/entityCanonicalization';
import { EntityDeduplicationService } from './services/entityDeduplication';
import { db } from './db';
import { entities, insights } from '../shared/schema';
import { sql } from 'drizzle-orm';

async function testRSSCanonicalizationIntegration() {
  console.log('🔄 Testing RSS + Entity Canonicalization Integration');
  console.log('====================================================\n');

  const canonicalizationService = new EntityCanonicalizationService();
  const deduplicationService = new EntityDeduplicationService();

  try {
    // 1. Get active RSS sources
    const sources = await storage.getActiveDataSources();
    const rssFeeds = sources.filter(source => source.type === 'rss');
    
    console.log(`📰 Found ${rssFeeds.length} active RSS feeds:`);
    for (const feed of rssFeeds) {
      console.log(`   • ${feed.name}: ${feed.url}`);
    }

    if (rssFeeds.length === 0) {
      console.log('❌ No RSS feeds configured. Add some RSS sources first.');
      return;
    }

    // 2. Process one RSS feed to demonstrate the integration
    const testFeed = rssFeeds[0];
    console.log(`\n🔄 Processing RSS feed: ${testFeed.name}`);
    console.log('----------------------------------------------');

    // Count entities and insights before processing
    const beforeEntities = await db.select({ count: sql<number>`COUNT(*)` }).from(entities);
    const beforeInsights = await db.select({ count: sql<number>`COUNT(*)` }).from(insights).where(sql`created_at > NOW() - INTERVAL '1 hour'`);

    console.log(`📊 Before processing: ${beforeEntities[0]?.count || 0} entities, ${beforeInsights[0]?.count || 0} recent insights`);

    // Process the RSS feed (this will trigger entity canonicalization)
    await fetchRSSFeed(testFeed);

    // Wait a moment for processing to complete
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Count entities and insights after processing
    const afterEntities = await db.select({ count: sql<number>`COUNT(*)` }).from(entities);
    const afterInsights = await db.select({ count: sql<number>`COUNT(*)` }).from(insights).where(sql`created_at > NOW() - INTERVAL '1 hour'`);

    console.log(`📊 After processing: ${afterEntities[0]?.count || 0} entities, ${afterInsights[0]?.count || 0} recent insights`);

    const newEntities = (afterEntities[0]?.count || 0) - (beforeEntities[0]?.count || 0);
    const newInsights = (afterInsights[0]?.count || 0) - (beforeInsights[0]?.count || 0);

    console.log(`\n✨ Processing Results:`);
    console.log(`   📈 New entities created: ${newEntities}`);
    console.log(`   📰 New insights created: ${newInsights}`);

    // 3. Show latest canonicalized entities
    console.log(`\n🏷️  Latest Canonicalized Entities:`);
    console.log('----------------------------------');

    const latestEntities = await db.select({
      name: entities.name,
      canonicalName: entities.canonicalName,
      type: entities.type,
      source: entities.source
    })
    .from(entities)
    .where(sql`created_at > NOW() - INTERVAL '1 hour'`)
    .orderBy(sql`created_at DESC`)
    .limit(10);

    if (latestEntities.length > 0) {
      for (const entity of latestEntities) {
        console.log(`   • ${entity.name} → ${entity.canonicalName} [${entity.type}] (${entity.source})`);
      }
    } else {
      console.log('   (No new entities in the last hour)');
    }

    // 4. Show latest insights with high-value content
    console.log(`\n📰 Latest High-Value Insights:`);
    console.log('-----------------------------');

    const latestInsights = await db.select({
      title: insights.title,
      category: insights.category,
      priority: insights.priority,
      sentiment: insights.sentiment,
      source: insights.source
    })
    .from(insights)
    .where(sql`created_at > NOW() - INTERVAL '1 hour' AND priority IN ('high', 'critical')`)
    .orderBy(sql`created_at DESC`)
    .limit(5);

    if (latestInsights.length > 0) {
      for (const insight of latestInsights) {
        console.log(`   📊 ${insight.title}`);
        console.log(`      Category: ${insight.category}, Priority: ${insight.priority}, Sentiment: ${insight.sentiment}`);
        console.log(`      Source: ${insight.source}\n`);
      }
    } else {
      console.log('   (No high-value insights in the last hour)');
    }

    // 5. Test entity canonicalization directly
    console.log(`\n🧪 Testing Entity Canonicalization:`);
    console.log('----------------------------------');

    const testCompanies = [
      'Apple Inc.',
      'Microsoft Corporation',
      'Amazon.com, Inc.',
      'Tesla, Inc.',
      'Meta Platforms, Inc.'
    ];

    for (const company of testCompanies) {
      const result = await deduplicationService.upsertEntity(
        company,
        'company',
        'Test entity from RSS integration demo'
      );

      console.log(`   ${company.padEnd(25)} → ${result.entity.canonicalName} ${result.wasCreated ? '(created)' : '(deduplicated)'}`);
    }

    console.log('\n✅ RSS + Entity Canonicalization Integration Test Complete!');
    console.log('============================================================');
    console.log('✓ RSS ingestion working');
    console.log('✓ Entity extraction from news content');
    console.log('✓ Entity canonicalization applied automatically');
    console.log('✓ Duplicate prevention working');
    console.log('✓ Knowledge graph populated with real-world data');

  } catch (error) {
    console.error('Integration test failed:', error);
    throw error;
  }
}

// Run test if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  testRSSCanonicalizationIntegration()
    .then(() => {
      console.log('\n🎉 Integration test completed successfully!');
      process.exit(0);
    })
    .catch(error => {
      console.error('Integration test failed:', error);
      process.exit(1);
    });
}

export { testRSSCanonicalizationIntegration };