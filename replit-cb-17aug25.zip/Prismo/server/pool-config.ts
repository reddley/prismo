// PgBouncer connection pooling configuration
// Transaction mode pooling for safe DB limits and optimal performance

export interface PoolConfig {
  // PgBouncer configuration
  poolMode: 'transaction' | 'session' | 'statement';
  maxClientConnections: number;
  defaultPoolSize: number;
  maxDbConnections: number;
  
  // Query concurrency limits
  maxConcurrentQueries: number;
  queryTimeout: number;
  connectionTimeout: number;
  
  // Performance targets
  targetP95Latency: number; // ms
  idleTimeout: number;
}

export const POOL_CONFIG: PoolConfig = {
  // Use transaction mode for optimal connection reuse
  poolMode: 'transaction',
  
  // Client connection limits (application side)
  maxClientConnections: 100,
  defaultPoolSize: 20,
  
  // Database connection limits (PgBouncer -> Postgres)
  maxDbConnections: 25, // Safe limit for Neon serverless
  
  // Query concurrency (per worker/process)
  maxConcurrentQueries: 10,
  queryTimeout: 30000, // 30 seconds
  connectionTimeout: 10000, // 10 seconds
  
  // Performance targets
  targetP95Latency: 250, // 250ms target for hot reads
  idleTimeout: 300000, // 5 minutes
};

// Environment-specific overrides
export function getPoolConfig(): PoolConfig {
  const config = { ...POOL_CONFIG };
  
  // Production environment adjustments
  if (process.env.NODE_ENV === 'production') {
    config.maxClientConnections = 200;
    config.defaultPoolSize = 30;
    config.maxDbConnections = 40;
    config.maxConcurrentQueries = 15;
  }
  
  // Development environment adjustments
  if (process.env.NODE_ENV === 'development') {
    config.maxClientConnections = 100;
    config.defaultPoolSize = 20;
    config.maxDbConnections = 30;
    config.maxConcurrentQueries = 10;
    config.queryTimeout = 60000; // Increase to 60 seconds
    config.connectionTimeout = 15000; // Increase to 15 seconds
    config.idleTimeout = 600000; // Increase to 10 minutes
  }
  
  return config;
}