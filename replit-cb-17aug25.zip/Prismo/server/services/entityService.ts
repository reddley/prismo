import OpenAI from 'openai';
import { storage } from '../storage';
import { DataEnrichmentService } from './dataEnrichmentService';
import type { Insight, Company, Person, Organization } from '@shared/schema';
import { EntityCanonicalizationService, IdentifierScheme } from './entityCanonicalization';
import { EntityDeduplicationService } from './entityDeduplication';
import { logger } from '../observability/logger';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface EntityMention {
  name: string;
  type: 'company' | 'person' | 'organization';
  confidence: number;
  context: string;
  category?: string;
  importance: 'low' | 'medium' | 'high' | 'critical';
}

export interface EntityRelationshipData {
  fromEntity: { type: string; name: string; id?: string };
  toEntity: { type: string; name: string; id?: string };
  relationshipType: string;
  description: string;
  confidence: number;
}

/**
 * AI-powered entity recognition service that processes insights to:
 * 1. Identify mentions of companies, people, and organizations
 * 2. Determine the importance/impact level of mentions
 * 3. Extract relationships between entities
 * 4. Automatically create deck entries for high-impact entities
 */
export class EntityService {
  private enrichmentService: DataEnrichmentService;
  private canonicalizationService: EntityCanonicalizationService;
  private deduplicationService: EntityDeduplicationService;

  constructor() {
    this.enrichmentService = new DataEnrichmentService();
    this.canonicalizationService = new EntityCanonicalizationService();
    this.deduplicationService = new EntityDeduplicationService();
  }
  /**
   * Process a high-impact insight to extract entity mentions and relationships
   */
  async processInsightForEntities(insight: Insight): Promise<{
    mentions: EntityMention[];
    relationships: EntityRelationshipData[];
  }> {
    try {
      const prompt = `Analyze this news article for mentions of companies, people, and organizations. Focus on entities that are central to the story, not just passing references.

Article Title: ${insight.title}
Article Content: ${insight.content}
Article Priority: ${insight.priority}
Article Category: ${insight.category}

Instructions:
1. Identify significant mentions of:
   - Companies (including startups, tech companies, enterprises)
   - People (executives, founders, industry leaders, analysts)
   - Organizations (agencies, nonprofits, government bodies, institutions)

2. For each entity, determine:
   - Type (company/person/organization)
   - Importance level based on their role in the story (critical/high/medium/low)
   - Context (brief description of how they're mentioned)
   - Confidence in identification (0.0-1.0)

3. Identify relationships between entities (works_at, partner_with, acquired_by, competitor_of, etc.)

4. Only include entities that are:
   - Directly involved in the main story
   - Named specifically (not generic references like "a tech company")
   - Relevant to competitive intelligence

Return your analysis in this JSON format:
{
  "entities": [
    {
      "name": "Company Name",
      "type": "company",
      "confidence": 0.95,
      "context": "Brief description of mention",
      "importance": "high"
    }
  ],
  "relationships": [
    {
      "fromEntity": {"type": "person", "name": "John Doe"},
      "toEntity": {"type": "company", "name": "Tech Corp"},
      "relationshipType": "works_at",
      "description": "John Doe is CEO of Tech Corp",
      "confidence": 0.9
    }
  ]
}`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini", // Use mini model for cost savings
        max_tokens: 1500, // Reduced tokens
        messages: [
          {
            role: "system",
            content: "You are an expert intelligence analyst specializing in entity recognition for competitive intelligence. Extract only the most relevant entities and relationships from news content. Respond with valid JSON only."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
      });

      const content = response.choices[0].message.content || '{}';
      console.log(`Used AI entity extraction (cost: ~$0.001)`);
      const cleanContent = content.trim();
      
      let analysis;
      try {
        analysis = JSON.parse(cleanContent);
      } catch (parseError) {
        console.error('JSON parse error:', parseError);
        console.error('Content that failed to parse:', cleanContent);
        return { mentions: [], relationships: [] };
      }

      return {
        mentions: analysis.entities || [],
        relationships: analysis.relationships || [],
      };
    } catch (error) {
      console.error('Error processing insight for entities:', error);
      return { mentions: [], relationships: [] };
    }
  }

  /**
   * Find or create a company entity based on AI mention using canonicalization
   */
  async findOrCreateCompany(mention: EntityMention): Promise<Company | null> {
    try {
      // Use entity canonicalization and deduplication system
      const result = await this.deduplicationService.upsertEntity(
        mention.name,
        'company',
        `Automatically detected: ${mention.context}`,
        { 
          source: 'entity_service'
        }
      );

      // Convert knowledge graph entity to legacy Company format for compatibility
      if (result.entity) {
        // Check if legacy company already exists
        const existingCompany = await storage.findCompanyByName(result.entity.canonicalName);
        if (existingCompany) {
          logger.debug('Found existing company for canonicalized entity', {
            mention: mention.name,
            canonical: result.entity.canonicalName,
            companyId: existingCompany.id
          });
          return existingCompany;
        }

        // If importance is high or critical, create new company automatically
        if (mention.importance === 'high' || mention.importance === 'critical') {
          // Enrich company data before creating
          const enrichmentData = await this.enrichmentService.enrichCompanyData(result.entity.canonicalName);
          
          const newCompany = await storage.createCompany({
            name: result.entity.canonicalName, // Use canonical name
            description: enrichmentData?.description || `Automatically detected entity: ${mention.context}`,
            industry: enrichmentData?.industry,
            founded: enrichmentData?.founded,
            website: enrichmentData?.website,
            headquarters: enrichmentData?.headquarters,
            logoUrl: enrichmentData?.logoUrl,
            priority: mention.importance === 'critical' ? 'critical' : 'high',
            isAutoCreated: true,
            tags: ['auto-discovered', 'canonicalized']
          });

          logger.info('Created new company with canonicalization', {
            mention: mention.name,
            canonical: result.entity.canonicalName,
            companyId: newCompany.id,
            wasCreated: result.wasCreated
          });

          return newCompany;
        }
      }

      return null;
    } catch (error) {
      console.error(`Error finding/creating company ${mention.name}:`, error);
      return null;
    }
  }

  /**
   * Find or create a person entity based on AI mention
   */
  async findOrCreatePerson(mention: EntityMention): Promise<Person | null> {
    try {
      const existingPerson = await storage.findPersonByName(mention.name);
      if (existingPerson) {
        await storage.updatePerson(existingPerson.id, {
          description: existingPerson.description + ` [Updated: ${new Date().toISOString()}]`
        });
        return existingPerson;
      }

      if (mention.importance === 'high' || mention.importance === 'critical') {
        // Enrich person data before creating
        const enrichmentData = await this.enrichmentService.enrichPersonData(mention.name);
        
        const newPerson = await storage.createPerson({
          name: mention.name,
          description: enrichmentData?.description || `Automatically detected entity: ${mention.context}`,
          priority: mention.importance === 'critical' ? 'critical' : 'high',
          isAutoCreated: true,
          tags: ['auto-discovered']
        });
        return newPerson;
      }

      return null;
    } catch (error) {
      console.error(`Error finding/creating person ${mention.name}:`, error);
      return null;
    }
  }

  /**
   * Find or create an organization entity based on AI mention
   */
  async findOrCreateOrganization(mention: EntityMention): Promise<Organization | null> {
    try {
      const existingOrg = await storage.findOrganizationByName(mention.name);
      if (existingOrg) {
        await storage.updateOrganization(existingOrg.id, {
          description: existingOrg.description + ` [Updated: ${new Date().toISOString()}]`
        });
        return existingOrg;
      }

      if (mention.importance === 'high' || mention.importance === 'critical') {
        // Enrich organization data before creating
        const enrichmentData = await this.enrichmentService.enrichOrganizationData(mention.name);
        
        const newOrg = await storage.createOrganization({
          name: mention.name,
          type: this.inferOrganizationType(mention.name, mention.context),
          description: enrichmentData?.description || `Automatically detected entity: ${mention.context}`,
          website: enrichmentData?.website,
          logoUrl: enrichmentData?.logoUrl,
          priority: mention.importance === 'critical' ? 'critical' : 'high',
          isAutoCreated: true,
          tags: ['auto-discovered']
        });
        return newOrg;
      }

      return null;
    } catch (error) {
      console.error(`Error finding/creating organization ${mention.name}:`, error);
      return null;
    }
  }

  /**
   * Process an insight to automatically create entity mentions and relationships
   */
  async processHighImpactInsight(insight: Insight): Promise<void> {
    // Only process high impact insights to avoid noise
    if (insight.priority !== 'high' && insight.priority !== 'critical') {
      return;
    }

    try {
      const { mentions, relationships } = await this.processInsightForEntities(insight);

      // Process each mention
      for (const mention of mentions) {
        let entityId: string | null = null;
        let entity: Company | Person | Organization | null = null;

        switch (mention.type) {
          case 'company':
            entity = await this.findOrCreateCompany(mention);
            entityId = entity?.id || null;
            break;
          case 'person':
            entity = await this.findOrCreatePerson(mention);
            entityId = entity?.id || null;
            break;
          case 'organization':
            entity = await this.findOrCreateOrganization(mention);
            entityId = entity?.id || null;
            break;
        }

        // Create entity mention record
        if (entityId) {
          await storage.createEntityMention({
            insightId: insight.id,
            entityType: mention.type,
            entityId,
            mentionType: this.inferMentionType(mention.context),
            confidence: mention.confidence,
            context: mention.context,
          });
        }
      }

      // Process relationships (future enhancement)
      // TODO: Implement relationship processing

      console.log(`Processed ${mentions.length} entities from insight: ${insight.title}`);
    } catch (error) {
      console.error('Error processing high impact insight:', error);
    }
  }

  /**
   * Infer the type of organization based on name and context
   */
  private inferOrganizationType(name: string, context: string): string {
    const nameAndContext = `${name} ${context}`.toLowerCase();
    
    if (nameAndContext.includes('government') || nameAndContext.includes('federal') || 
        nameAndContext.includes('agency') || nameAndContext.includes('department')) {
      return 'government';
    }
    if (nameAndContext.includes('nonprofit') || nameAndContext.includes('foundation') || 
        nameAndContext.includes('charity')) {
      return 'nonprofit';
    }
    if (nameAndContext.includes('association') || nameAndContext.includes('consortium') || 
        nameAndContext.includes('alliance')) {
      return 'association';
    }
    if (nameAndContext.includes('university') || nameAndContext.includes('institute') || 
        nameAndContext.includes('research')) {
      return 'think_tank';
    }
    
    return 'agency'; // default
  }

  /**
   * Infer the type of mention based on context
   */
  private inferMentionType(context: string): string {
    const lowerContext = context.toLowerCase();
    
    if (lowerContext.includes('announce') || lowerContext.includes('launch') || 
        lowerContext.includes('release')) {
      return 'announcement';
    }
    if (lowerContext.includes('said') || lowerContext.includes('stated') || 
        lowerContext.includes('comment')) {
      return 'quote';
    }
    if (lowerContext.includes('analysis') || lowerContext.includes('report') || 
        lowerContext.includes('study')) {
      return 'analysis';
    }
    
    return 'reference'; // default
  }
}

export const entityService = new EntityService();