/**
 * Entity Canonicalization Service
 * 
 * Handles consistent naming and identifier management for entities.
 * Provides normalization, deduplication, and identifier scheme support.
 */

import { logger } from '../observability/logger';

// Supported identifier schemes
export enum IdentifierScheme {
  DOMAIN = 'domain',
  CIK = 'cik',
  WIKIPEDIA = 'wikipedia',
  PATENT = 'patent',
  TICKER = 'ticker',
  LEI = 'lei',
  DUNS = 'duns',
  PERMID = 'permid'
}

// Corporate suffixes to normalize (case-insensitive)
const CORPORATE_SUFFIXES = [
  'Inc', 'Inc.', 'Incorporated',
  'Corp', 'Corp.', 'Corporation',
  'Ltd', 'Ltd.', 'Limited',
  'LLC', 'L.L.C.',
  'LLP', 'L.L.P.',
  'Co', 'Co.', 'Company',
  'SA', 'S.A.',
  'SE', // Societas Europaea (European company)  
  'AG', 'A.G.',
  'GmbH', 'G.m.b.H.',
  'BV', 'B.V.',
  'NV', 'N.V.',
  'Plc', 'PLC',
  'Pty', 'Pty.',
  'Srl', 'S.r.l.',
  'SpA', 'S.p.A.',
  'AB', 'A.B.'
];

export interface CanonicalizedEntity {
  canonicalName: string;
  originalName: string;
  normalized: {
    lowercase: string;
    withoutSuffixes: string;
    unicodeNormalized: string;
  };
}

export interface EntityIdentifier {
  scheme: IdentifierScheme;
  value: string;
  normalized: string;
  confidence: number;
}

export class EntityCanonicalizationService {
  
  /**
   * Canonicalize an entity name with comprehensive normalization
   */
  canonicalizeName(name: string): CanonicalizedEntity {
    const originalName = name.trim();
    
    // Step 1: Unicode normalization (NFD - Canonical Decomposition)
    const unicodeNormalized = originalName.normalize('NFD')
      .replace(/[\u0300-\u036f]/g, ''); // Remove diacritical marks
    
    // Step 2: Basic cleanup
    let cleaned = unicodeNormalized
      .replace(/\s+/g, ' ') // Normalize whitespace
      .replace(/[""'']/g, '"') // Normalize quotes
      .replace(/[–—]/g, '-') // Normalize dashes
      .trim();
    
    // Step 3: Remove corporate suffixes
    const withoutSuffixes = this.removeCorporateSuffixes(cleaned);
    
    // Step 4: Generate canonical form
    const canonicalName = withoutSuffixes
      .replace(/[^\w\s\-&.]/g, '') // Keep only alphanumeric, spaces, hyphens, ampersands, dots
      .replace(/\s+/g, ' ')
      .trim();
    
    const lowercase = canonicalName.toLowerCase();
    
    logger.debug('Entity canonicalization completed', {
      originalName,
      canonicalName,
      steps: {
        unicodeNormalized,
        withoutSuffixes,
        lowercase
      }
    });
    
    return {
      canonicalName,
      originalName,
      normalized: {
        lowercase,
        withoutSuffixes,
        unicodeNormalized
      }
    };
  }
  
  /**
   * Remove corporate suffixes from entity names
   */
  private removeCorporateSuffixes(name: string): string {
    let result = name;
    
    // Sort suffixes by length (longest first) to avoid partial matches
    const sortedSuffixes = CORPORATE_SUFFIXES.sort((a, b) => b.length - a.length);
    
    for (const suffix of sortedSuffixes) {
      // Create regex that matches suffix at end of string (case-insensitive)
      // With optional comma and/or whitespace before
      const regex = new RegExp(`[,\\s]*\\b${suffix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*$`, 'i');
      
      if (regex.test(result)) {
        result = result.replace(regex, '').trim();
        break; // Only remove one suffix to avoid over-processing
      }
    }
    
    return result;
  }
  
  /**
   * Normalize an identifier value based on its scheme
   */
  normalizeIdentifier(scheme: IdentifierScheme, value: string): string {
    const trimmed = value.trim();
    
    switch (scheme) {
      case IdentifierScheme.DOMAIN:
        return this.normalizeDomain(trimmed);
      
      case IdentifierScheme.CIK:
        return this.normalizeCIK(trimmed);
      
      case IdentifierScheme.WIKIPEDIA:
        return this.normalizeWikipedia(trimmed);
      
      case IdentifierScheme.PATENT:
        return this.normalizePatent(trimmed);
      
      case IdentifierScheme.TICKER:
        return this.normalizeTicker(trimmed);
      
      case IdentifierScheme.LEI:
        return this.normalizeLEI(trimmed);
      
      case IdentifierScheme.DUNS:
        return this.normalizeDUNS(trimmed);
      
      case IdentifierScheme.PERMID:
        return this.normalizePermID(trimmed);
      
      default:
        return trimmed.toLowerCase();
    }
  }
  
  private normalizeDomain(domain: string): string {
    return domain.toLowerCase()
      .replace(/^https?:\/\//, '')
      .replace(/^www\./, '')
      .replace(/\/$/, '');
  }
  
  private normalizeCIK(cik: string): string {
    // CIK is 10 digits, pad with zeros if needed
    const digits = cik.replace(/\D/g, '');
    return digits.padStart(10, '0');
  }
  
  private normalizeWikipedia(slug: string): string {
    // Extract slug from full URL if provided
    const match = slug.match(/\/wiki\/(.+)$/);
    if (match) {
      return decodeURIComponent(match[1]);
    }
    return slug;
  }
  
  private normalizePatent(patent: string): string {
    // Remove spaces and convert to uppercase for patent numbers
    return patent.replace(/\s/g, '').toUpperCase();
  }
  
  private normalizeTicker(ticker: string): string {
    // Ticker symbols are uppercase, remove exchange suffixes
    return ticker.toUpperCase().split('.')[0].split(':')[0];
  }
  
  private normalizeLEI(lei: string): string {
    // LEI is 20 alphanumeric characters, uppercase
    return lei.replace(/\s/g, '').toUpperCase();
  }
  
  private normalizeDUNS(duns: string): string {
    // DUNS is 9 digits, pad with zeros if needed
    const digits = duns.replace(/\D/g, '');
    return digits.padStart(9, '0');
  }
  
  private normalizePermID(permid: string): string {
    // PermID is numeric, keep as-is but remove non-digits
    return permid.replace(/\D/g, '');
  }
  
  /**
   * Create a standardized entity identifier
   */
  createIdentifier(
    scheme: IdentifierScheme, 
    value: string, 
    confidence: number = 1.0
  ): EntityIdentifier {
    const normalized = this.normalizeIdentifier(scheme, value);
    
    return {
      scheme,
      value: value.trim(),
      normalized,
      confidence: Math.max(0, Math.min(1, confidence))
    };
  }
  
  /**
   * Validate identifier format based on scheme
   */
  validateIdentifier(scheme: IdentifierScheme, value: string): boolean {
    const normalized = this.normalizeIdentifier(scheme, value);
    
    switch (scheme) {
      case IdentifierScheme.CIK:
        return /^\d{10}$/.test(normalized);
      
      case IdentifierScheme.DOMAIN:
        return /^[a-z0-9.-]+\.[a-z]{2,}$/.test(normalized);
      
      case IdentifierScheme.LEI:
        return /^[A-Z0-9]{20}$/.test(normalized);
      
      case IdentifierScheme.DUNS:
        return /^\d{9}$/.test(normalized);
      
      case IdentifierScheme.PERMID:
        return /^\d+$/.test(normalized) && normalized.length >= 6;
      
      case IdentifierScheme.TICKER:
        return /^[A-Z]{1,6}$/.test(normalized);
      
      case IdentifierScheme.PATENT:
        return normalized.length > 3;
      
      case IdentifierScheme.WIKIPEDIA:
        return normalized.length > 0;
      
      default:
        return true;
    }
  }
  
  /**
   * Generate similarity score between two canonical names
   */
  calculateSimilarity(name1: string, name2: string): number {
    const canon1 = this.canonicalizeName(name1);
    const canon2 = this.canonicalizeName(name2);
    
    // Exact match on canonical form
    if (canon1.canonicalName === canon2.canonicalName) {
      return 1.0;
    }
    
    // Exact match on lowercase
    if (canon1.normalized.lowercase === canon2.normalized.lowercase) {
      return 0.95;
    }
    
    // Levenshtein distance on canonical form
    const distance = this.levenshteinDistance(
      canon1.canonicalName, 
      canon2.canonicalName
    );
    const maxLen = Math.max(canon1.canonicalName.length, canon2.canonicalName.length);
    const similarity = 1 - (distance / maxLen);
    
    return Math.max(0, similarity);
  }
  
  private levenshteinDistance(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));
    
    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;
    
    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const substitutionCost = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1, // insertion
          matrix[j - 1][i] + 1, // deletion
          matrix[j - 1][i - 1] + substitutionCost, // substitution
        );
      }
    }
    
    return matrix[str2.length][str1.length];
  }
}