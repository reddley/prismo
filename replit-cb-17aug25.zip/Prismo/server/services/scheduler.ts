import { CronJob } from 'cron';
import { fetchAllRSSFeeds } from './rss-parser';
import { generateBriefing } from './openai';
import { storage } from '../storage';

let rssJob: CronJob | null = null;
let briefingJob: CronJob | null = null;

export function startScheduledTasks(): void {
  console.log('Starting scheduled tasks...');

  // Fetch RSS feeds every 15 minutes
  rssJob = new CronJob('*/15 * * * *', async () => {
    console.log('Running scheduled RSS feed fetch...');
    try {
      // Check if data ingestion is enabled
      const systemSettings = await storage.getSystemSettings();
      if (!systemSettings.dataIngestionEnabled) {
        console.log('⏸️  Data ingestion is paused - skipping RSS fetch');
        return;
      }
      await fetchAllRSSFeeds();
    } catch (error) {
      console.error('Error in scheduled RSS fetch:', error);
    }
  });

  // Generate daily briefing at 8 AM
  briefingJob = new CronJob('0 8 * * *', async () => {
    console.log('Generating daily briefing...');
    try {
      // Get recent high-impact insights
      const insights = await storage.getInsights(20);
      const highImpactInsights = insights.filter(
        insight => insight.priority === 'high' || insight.priority === 'critical'
      ).slice(0, 10);

      if (highImpactInsights.length > 0) {
        const briefingData = await generateBriefing(
          highImpactInsights.map(insight => ({
            title: insight.title,
            content: insight.summary || insight.content,
            category: insight.category || undefined,
            priority: insight.priority || undefined,
          }))
        );

        await storage.createBriefing({
          title: briefingData.title,
          content: briefingData.content,
          keyPoints: briefingData.keyPoints,
        });

        // Create notification for new briefing
        await storage.createNotification({
          title: 'Daily Briefing Ready',
          message: 'Your daily intelligence briefing has been generated and is ready for review.',
          type: 'info',
          priority: 'medium',
        });
      }
    } catch (error) {
      console.error('Error generating daily briefing:', error);
    }
  });

  rssJob.start();
  briefingJob.start();

  // Initial fetch on startup
  setTimeout(async () => {
    console.log('Performing initial RSS fetch...');
    try {
      // Check if data ingestion is enabled
      const systemSettings = await storage.getSystemSettings();
      if (!systemSettings.dataIngestionEnabled) {
        console.log('⏸️  Data ingestion is paused - skipping initial RSS fetch');
        return;
      }
      await fetchAllRSSFeeds();
    } catch (error) {
      console.error('Error in initial RSS fetch:', error);
    }
  }, 5000);
}

export function stopScheduledTasks(): void {
  console.log('Stopping scheduled tasks...');
  
  if (rssJob) {
    rssJob.stop();
    rssJob = null;
  }
  
  if (briefingJob) {
    briefingJob.stop();
    briefingJob = null;
  }
}
