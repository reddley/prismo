// AI enrichment service for queue-based content processing
import { storage } from '../storage';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function enrichContent(insightId: string, content: string): Promise<{
  sentiment: string;
  category: string;
  priority: string;
  extractedEntities: string[];
  summary: string;
}> {
  console.log(`[AI-ENRICHMENT] Processing insight: ${insightId}`);

  try {
    // Get the insight to update
    const insight = await storage.getInsight(insightId);
    if (!insight) {
      throw new Error(`Insight not found: ${insightId}`);
    }

    // Perform AI analysis
    const analysis = await analyzeContentWithAI(content, insight.title);

    // Update insight with enriched data
    await storage.updateInsight(insightId, {
      sentiment: analysis.sentiment,
      category: analysis.category,
      priority: analysis.priority,
      summary: analysis.summary,
    });

    // Extract and store entities
    if (analysis.extractedEntities.length > 0) {
      await storage.extractEntitiesFromInsight(insightId, analysis.extractedEntities);
    }

    console.log(`[AI-ENRICHMENT] Enriched insight ${insightId}: sentiment=${analysis.sentiment}, category=${analysis.category}`);
    
    return analysis;

  } catch (error) {
    console.error(`[AI-ENRICHMENT] Failed to enrich insight ${insightId}:`, error);
    throw error;
  }
}

async function analyzeContentWithAI(content: string, title: string): Promise<{
  sentiment: string;
  category: string;
  priority: string;
  extractedEntities: string[];
  summary: string;
}> {
  const prompt = `Analyze this content and provide:
1. Sentiment (positive/negative/neutral)
2. Category (AI/ML, Automotive, Energy, Finance, Healthcare, Technology, Other)
3. Priority (critical/high/medium/low/normal)
4. Key entities (companies, people, technologies - max 5)
5. Brief summary (max 2 sentences)

Title: ${title}
Content: ${content}

Respond in JSON format with keys: sentiment, category, priority, entities, summary`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini", // Using cost-efficient model
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 500,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      sentiment: result.sentiment || 'neutral',
      category: result.category || 'Other',
      priority: result.priority || 'normal',
      extractedEntities: Array.isArray(result.entities) ? result.entities : [],
      summary: result.summary || content.substring(0, 200) + '...',
    };

  } catch (error) {
    console.error('[AI-ENRICHMENT] AI analysis failed:', error);
    
    // Fallback to rule-based analysis
    return {
      sentiment: inferSentimentFromText(content),
      category: inferCategoryFromContent(content, title),
      priority: 'normal',
      extractedEntities: [],
      summary: content.substring(0, 200) + '...',
    };
  }
}

// Rule-based fallbacks
function inferSentimentFromText(text: string): string {
  const positiveWords = ['good', 'great', 'excellent', 'positive', 'growth', 'success', 'breakthrough'];
  const negativeWords = ['bad', 'terrible', 'negative', 'decline', 'failure', 'problem', 'crisis'];
  
  const lowerText = text.toLowerCase();
  const positiveCount = positiveWords.filter(word => lowerText.includes(word)).length;
  const negativeCount = negativeWords.filter(word => lowerText.includes(word)).length;
  
  if (positiveCount > negativeCount) return 'positive';
  if (negativeCount > positiveCount) return 'negative';
  return 'neutral';
}

function inferCategoryFromContent(content: string, title: string): string {
  const text = (content + ' ' + title).toLowerCase();
  
  if (text.includes('ai') || text.includes('artificial intelligence') || text.includes('machine learning')) {
    return 'AI/ML';
  }
  if (text.includes('car') || text.includes('automotive') || text.includes('vehicle')) {
    return 'Automotive';
  }
  if (text.includes('energy') || text.includes('solar') || text.includes('renewable')) {
    return 'Energy';
  }
  if (text.includes('finance') || text.includes('bank') || text.includes('investment')) {
    return 'Finance';
  }
  if (text.includes('health') || text.includes('medical') || text.includes('pharma')) {
    return 'Healthcare';
  }
  if (text.includes('tech') || text.includes('software') || text.includes('digital')) {
    return 'Technology';
  }
  
  return 'Other';
}