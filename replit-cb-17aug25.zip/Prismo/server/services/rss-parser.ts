import Parser from 'rss-parser';
import { storage } from '../storage';
import { analyzeSentiment, summarizeContent, categorizeContent, extractEntities } from './openai';
import { EntityService } from './entityService';
import { costOptimizer, shouldProcessWithAI, optimizeBatchSize, AI_COSTS } from './costOptimization';
import { getModelRouter } from './modelRouter';
import type { DataSource } from '@shared/schema';

const parser = new Parser({
  timeout: 10000,
  headers: {
    'User-Agent': 'Prismo Intelligence Platform/1.0'
  }
});

// Initialize services
const entityService = new EntityService();
const modelRouter = getModelRouter();

// Helper function to determine initial priority based on content keywords for intelligent model routing
function determineInitialPriority(content: string): 'low' | 'medium' | 'high' | 'critical' {
  const lowerContent = content.toLowerCase();
  
  // Critical priority keywords - major business events
  const criticalKeywords = ['acquisition', 'merger', 'ipo', 'bankruptcy', 'lawsuit', 'security breach', 'data breach', 'hack', 'regulation', 'ban', 'shutdown'];
  
  // High priority keywords - significant business developments
  const highKeywords = ['funding', 'investment', 'partnership', 'launch', 'revenue', 'profit', 'loss', 'layoffs', 'hiring', 'ceo', 'executive'];
  
  // Medium priority keywords - general business news
  const mediumKeywords = ['announce', 'release', 'update', 'feature', 'product', 'service', 'market', 'growth', 'sales'];
  
  // Check for critical keywords first
  if (criticalKeywords.some(keyword => lowerContent.includes(keyword))) {
    return 'critical';
  }
  
  // Check for high priority keywords
  if (highKeywords.some(keyword => lowerContent.includes(keyword))) {
    return 'high';
  }
  
  // Check for medium priority keywords
  if (mediumKeywords.some(keyword => lowerContent.includes(keyword))) {
    return 'medium';
  }
  
  // Default to low priority
  return 'low';
}

export async function fetchRSSFeed(source: DataSource): Promise<void> {
  try {
    console.log(`Fetching RSS feed from ${source.name}: ${source.url}`);
    
    const feed = await parser.parseURL(source.url);
    
    if (!feed.items || feed.items.length === 0) {
      console.log(`No items found in feed: ${source.name}`);
      return;
    }

    console.log(`Processing ${feed.items.length} items from ${source.name}`);

    // Process recent items (last 24 hours or top 10 items)
    const recentItems = feed.items
      .filter(item => {
        if (!item.pubDate) return true;
        const itemDate = new Date(item.pubDate);
        const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
        return itemDate > yesterday;
      })
      .slice(0, 10);

    for (const item of recentItems) {
      if (!item.title || !item.contentSnippet) continue;

      try {
        // Intelligent model routing for cost-optimized content analysis
        console.log(`Processing: ${item.title}`);
        
        // Determine initial priority from content (used for model selection)
        const contentText = item.title + ' ' + (item.contentSnippet || '');
        const initialPriority = determineInitialPriority(contentText);
        
        // Update model router with current spend from cost optimizer
        const costStats = costOptimizer.getCostStats();
        modelRouter.updateCurrentSpend(costStats.dailyAiCost);
        
        // Use intelligent model routing for all operations
        const [sentiment, summary, category] = await Promise.all([
          analyzeSentiment(contentText, initialPriority),
          summarizeContent(item.title, item.contentSnippet || '', initialPriority),
          categorizeContent(item.title, item.contentSnippet || '', initialPriority)
        ]);

        // Create insight with analyzed data
        const createdInsight = await storage.createInsight({
          title: item.title,
          content: item.contentSnippet || '',
          summary,
          category,
          source: source.name,
          sourceUrl: item.link || '',
          sentiment: sentiment.sentiment,
          confidence: sentiment.confidence,
          priority: sentiment.priority,
          tags: [category.toLowerCase(), source.name.toLowerCase()],
          metadata: {
            guid: item.guid,
            author: item.creator,
            categories: item.categories || []
          },
          publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
        });

        // Enhanced entity extraction using new models for high-value insights
        if (sentiment.priority === 'critical' || sentiment.priority === 'high') {
          try {
            // Use the new entity extraction with intelligent model routing
            const entities = await extractEntities(contentText, sentiment.priority);
            
            if (entities.confidence > 60) {
              // Process entities for deck creation if confidence is high
              await entityService.processInsightForEntities(createdInsight);
              
              // Also process entities through canonicalization system
              const { mentions } = await entityService.processInsightForEntities(createdInsight);
              console.log(`📊 Processed ${mentions.length} entities with canonicalization for: ${createdInsight.title}`);
            }
          } catch (entityError) {
            console.error('Error processing entities for insight:', entityError);
            // Don't fail the RSS processing if entity recognition fails
          }
        } else if (sentiment.priority === 'medium') {
          console.log(`Skipped AI entity extraction for ${sentiment.priority} priority item (cost optimization)`);
        }

        // Create high-priority notifications
        if (sentiment.priority === 'high' || sentiment.priority === 'critical') {
          await storage.createNotification({
            title: `High Priority Alert: ${category}`,
            message: `New ${sentiment.priority} priority insight: ${item.title}`,
            type: sentiment.priority === 'critical' ? 'error' : 'warning',
            priority: sentiment.priority,
          });
        }

        // Check for automatic alert triggering based on user specs
        if (sentiment.priority === 'high' || sentiment.priority === 'critical') {
          try {
            const { autoAlertTriggerService } = await import('./autoAlertTrigger');
            await autoAlertTriggerService.processInsightForAlerts(createdInsight.id);
          } catch (alertError) {
            console.error('Error processing automatic alerts:', alertError);
            // Don't fail RSS processing if alert generation fails
          }
        }

      } catch (error) {
        console.error(`Error processing item "${item.title}":`, error);
        continue;
      }
    }

    // Update source last fetched time - temporarily disabled until schema is properly configured
    // await storage.updateDataSource(source.id, {
    //   lastFetched: new Date()
    // });

    console.log(`Successfully processed ${recentItems.length} items from ${source.name}`);

  } catch (error) {
    console.error(`Error fetching RSS feed from ${source.name}:`, error);
    
    // Create error notification
    await storage.createNotification({
      title: 'RSS Feed Error',
      message: `Failed to fetch data from ${source.name}: ${error instanceof Error ? error.message : 'Unknown error'}`,
      type: 'error',
      priority: 'medium',
    });
  }
}

export async function fetchAllRSSFeeds(): Promise<void> {
  try {
    // Check if data ingestion is enabled
    const systemSettings = await storage.getSystemSettings();
    if (!systemSettings.dataIngestionEnabled) {
      console.log('⏸️  Data ingestion is paused - RSS feeds will not be fetched');
      return;
    }

    const sources = await storage.getActiveDataSources();
    const rssFeeds = sources.filter(source => source.type === 'rss');
    
    console.log(`Fetching ${rssFeeds.length} RSS feeds...`);
    
    // Process feeds in parallel but with concurrency limit
    const BATCH_SIZE = 3;
    for (let i = 0; i < rssFeeds.length; i += BATCH_SIZE) {
      const batch = rssFeeds.slice(i, i + BATCH_SIZE);
      await Promise.all(batch.map(fetchRSSFeed));
      
      // Small delay between batches to be respectful to RSS servers
      if (i + BATCH_SIZE < rssFeeds.length) {
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
    
    console.log('Completed fetching all RSS feeds');
  } catch (error) {
    console.error('Error in fetchAllRSSFeeds:', error);
  }
}
