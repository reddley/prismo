import { db } from '../db';
import { emailVerificationQueue, type EmailVerificationQueue } from '@shared/schema';
import { eq, and, lte, gte } from 'drizzle-orm';

export interface EmailTemplate {
  subject: string;
  html: string;
  text: string;
}

export interface VerificationEmailData {
  username: string;
  verificationUrl: string;
  expiresInHours: number;
}

export class EmailService {
  private readonly baseUrl: string;

  constructor() {
    // Use environment variable or default for verification URLs
    this.baseUrl = process.env.BASE_URL || 'http://localhost:5000';
  }

  /**
   * Generate email verification template
   */
  generateVerificationEmail(data: VerificationEmailData): EmailTemplate {
    const subject = 'Verify your Prismo account';
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Verify your email</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .logo { font-size: 24px; font-weight: bold; color: #2563eb; }
          .content { background: #f8fafc; padding: 30px; border-radius: 8px; margin: 20px 0; }
          .button { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 500; }
          .footer { text-align: center; margin-top: 30px; color: #6b7280; font-size: 14px; }
          .warning { background: #fef3cd; border: 1px solid #fbbf24; padding: 15px; border-radius: 6px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">Prismo</div>
            <h1>Verify your email address</h1>
          </div>
          
          <div class="content">
            <p>Hi ${data.username},</p>
            <p>Thank you for signing up for Prismo! To complete your registration and start monitoring competitive intelligence, please verify your email address by clicking the button below:</p>
            
            <p style="text-align: center; margin: 30px 0;">
              <a href="${data.verificationUrl}" class="button">Verify Email Address</a>
            </p>
            
            <p>Or copy and paste this link into your browser:</p>
            <p style="word-break: break-all; background: #e5e7eb; padding: 10px; border-radius: 4px; font-family: monospace;">
              ${data.verificationUrl}
            </p>
          </div>
          
          <div class="warning">
            <strong>⚠️ Security Notice:</strong> This verification link expires in ${data.expiresInHours} hours. If you didn't create a Prismo account, please ignore this email.
          </div>
          
          <div class="footer">
            <p>© 2025 Prismo - AI-Powered Competitive Intelligence</p>
            <p>If you have questions, reply to this email or contact our support team.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
      Prismo - Verify your email address
      
      Hi ${data.username},
      
      Thank you for signing up for Prismo! To complete your registration and start monitoring competitive intelligence, please verify your email address by visiting:
      
      ${data.verificationUrl}
      
      This verification link expires in ${data.expiresInHours} hours.
      
      If you didn't create a Prismo account, please ignore this email.
      
      © 2025 Prismo - AI-Powered Competitive Intelligence
    `;

    return { subject, html, text };
  }

  /**
   * Queue email verification for processing
   */
  async queueVerificationEmail(userId: string, email: string, token: string, priority: 'high' | 'normal' | 'low' = 'normal'): Promise<void> {
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    await db.insert(emailVerificationQueue).values({
      userId,
      email,
      token,
      expiresAt,
      priority,
      status: 'pending',
    });
  }

  /**
   * Process pending email verifications (batch job)
   */
  async processPendingVerifications(batchSize: number = 50): Promise<{ processed: number; failed: number }> {
    let processed = 0;
    let failed = 0;

    try {
      // Get pending emails, prioritizing high priority and older items
      const pendingEmails = await db
        .select()
        .from(emailVerificationQueue)
        .where(
          and(
            eq(emailVerificationQueue.status, 'pending'),
            gte(emailVerificationQueue.expiresAt, new Date()) // Not expired
          )
        )
        .orderBy(emailVerificationQueue.priority, emailVerificationQueue.createdAt)
        .limit(batchSize);

      console.log(`[EMAIL-QUEUE] Processing ${pendingEmails.length} pending verification emails`);

      for (const emailRecord of pendingEmails) {
        try {
          await this.sendVerificationEmailDirect(emailRecord);
          
          await db
            .update(emailVerificationQueue)
            .set({
              status: 'sent',
              lastAttemptAt: new Date(),
              attemptCount: (emailRecord.attemptCount || 0) + 1,
              updatedAt: new Date(),
            })
            .where(eq(emailVerificationQueue.id, emailRecord.id));

          processed++;
          console.log(`[EMAIL-QUEUE] Sent verification email to ${emailRecord.email}`);
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'Unknown error';
          console.error(`[EMAIL-QUEUE] Failed to send email to ${emailRecord.email}:`, errorMessage);
          
          const newAttemptCount = (emailRecord.attemptCount || 0) + 1;
          const maxAttempts = 3;
          
          await db
            .update(emailVerificationQueue)
            .set({
              status: newAttemptCount >= maxAttempts ? 'failed' : 'pending',
              lastAttemptAt: new Date(),
              attemptCount: newAttemptCount,
              errorMessage: errorMessage,
              updatedAt: new Date(),
            })
            .where(eq(emailVerificationQueue.id, emailRecord.id));

          failed++;
        }

        // Small delay between emails to avoid overwhelming mail service
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      // Clean up expired entries
      await this.cleanupExpiredVerifications();

    } catch (error) {
      console.error('[EMAIL-QUEUE] Batch processing failed:', error);
    }

    return { processed, failed };
  }

  /**
   * Send verification email directly (simulated for development)
   */
  private async sendVerificationEmailDirect(emailRecord: EmailVerificationQueue): Promise<void> {
    const verificationUrl = `${this.baseUrl}/verify-email?token=${emailRecord.token}`;
    
    const emailData: VerificationEmailData = {
      username: emailRecord.email.split('@')[0], // Simple username extraction
      verificationUrl,
      expiresInHours: 24,
    };

    const template = this.generateVerificationEmail(emailData);

    // In development, log the email instead of sending
    if (process.env.NODE_ENV === 'development') {
      console.log('\n=== EMAIL VERIFICATION (DEV MODE) ===');
      console.log(`To: ${emailRecord.email}`);
      console.log(`Subject: ${template.subject}`);
      console.log(`Verification URL: ${verificationUrl}`);
      console.log('=====================================\n');
      return;
    }

    // TODO: In production, integrate with actual email service (SendGrid, AWS SES, etc.)
    // For now, simulate successful sending
    await new Promise(resolve => setTimeout(resolve, 50)); // Simulate network delay
  }

  /**
   * Clean up expired verification entries
   */
  async cleanupExpiredVerifications(): Promise<number> {
    const result = await db
      .update(emailVerificationQueue)
      .set({
        status: 'expired',
        updatedAt: new Date(),
      })
      .where(
        and(
          lte(emailVerificationQueue.expiresAt, new Date()),
          eq(emailVerificationQueue.status, 'pending')
        )
      );

    const expiredCount = result.rowCount || 0;
    if (expiredCount > 0) {
      console.log(`[EMAIL-QUEUE] Marked ${expiredCount} verification emails as expired`);
    }

    return expiredCount;
  }

  /**
   * Get email queue metrics
   */
  async getQueueMetrics(): Promise<{
    pending: number;
    sent: number;
    failed: number;
    expired: number;
    avgProcessingTime: number;
  }> {
    // This would be implemented with proper aggregation queries
    // For now, return basic counts
    const pending = await db.$count(emailVerificationQueue, eq(emailVerificationQueue.status, 'pending'));
    const sent = await db.$count(emailVerificationQueue, eq(emailVerificationQueue.status, 'sent'));
    const failed = await db.$count(emailVerificationQueue, eq(emailVerificationQueue.status, 'failed'));
    const expired = await db.$count(emailVerificationQueue, eq(emailVerificationQueue.status, 'expired'));

    return {
      pending,
      sent,
      failed,
      expired,
      avgProcessingTime: 0, // Would calculate from processing timestamps
    };
  }

  /**
   * Resend verification email with rate limiting
   */
  async resendVerificationEmail(email: string): Promise<void> {
    // Check if there's already a recent pending verification
    const recentVerification = await db
      .select()
      .from(emailVerificationQueue)
      .where(
        and(
          eq(emailVerificationQueue.email, email),
          eq(emailVerificationQueue.status, 'pending'),
          gte(emailVerificationQueue.createdAt, new Date(Date.now() - 5 * 60 * 1000)) // Last 5 minutes
        )
      )
      .limit(1);

    if (recentVerification.length > 0) {
      throw new Error('Please wait 5 minutes before requesting another verification email');
    }

    // Find the most recent verification record for this email
    const [latestRecord] = await db
      .select()
      .from(emailVerificationQueue)
      .where(eq(emailVerificationQueue.email, email))
      .orderBy(emailVerificationQueue.createdAt)
      .limit(1);

    if (!latestRecord) {
      throw new Error('No verification record found for this email');
    }

    // Create new verification with high priority
    await db.insert(emailVerificationQueue).values({
      userId: latestRecord.userId,
      email: latestRecord.email,
      token: latestRecord.token, // Reuse the same token
      expiresAt: latestRecord.expiresAt,
      priority: 'high', // Prioritize resend requests
      status: 'pending',
    });
  }
}

export const emailService = new EmailService();