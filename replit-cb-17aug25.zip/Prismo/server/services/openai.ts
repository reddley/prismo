import OpenAI from "openai";
import { getModelRouter, createTaskContext, TaskType } from "./modelRouter";
import { persistentCostTracker } from './persistentCostTracking';

/*
Updated August 14, 2025: Now using intelligent model routing with latest OpenAI models including:
- GPT-5 series (released Aug 7, 2025): gpt-5, gpt-5-mini, gpt-5-nano
- o3/o4-mini reasoning models (released Aug 14, 2025)
- GPT-4.1 series for coding-focused tasks
- Dynamic model selection based on task complexity, budget, and quality requirements
*/

// Using the new model router for intelligent model selection
const modelRouter = getModelRouter();

// Rule-based pre-filtering to avoid AI calls for obvious cases
function getRuleBasedSentimentAndPriority(text: string): {
  sentiment: 'positive' | 'negative' | 'neutral';
  confidence: number;
  priority: 'low' | 'medium' | 'high' | 'critical';
} | null {
  const lowerText = text.toLowerCase();
  
  // High-priority keywords that indicate critical business events
  const criticalKeywords = ['acquisition', 'merger', 'ipo', 'bankruptcy', 'lawsuit', 'regulation', 'ban', 'security breach', 'data breach', 'layoffs', 'funding round', 'partnership'];
  const highKeywords = ['investment', 'launch', 'revenue', 'earnings', 'growth', 'expansion', 'deal', 'agreement', 'patent', 'innovation'];
  const positiveKeywords = ['success', 'growth', 'profit', 'increase', 'boost', 'win', 'award', 'breakthrough', 'expansion', 'partnership'];
  const negativeKeywords = ['loss', 'decline', 'problem', 'issue', 'failure', 'down', 'drop', 'concern', 'risk', 'threat', 'lawsuit', 'breach'];
  
  let priority: 'low' | 'medium' | 'high' | 'critical' = 'low';
  let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
  let confidence = 60; // Rule-based confidence
  
  // Determine priority based on keywords
  if (criticalKeywords.some(keyword => lowerText.includes(keyword))) {
    priority = 'critical';
    confidence = 80;
  } else if (highKeywords.some(keyword => lowerText.includes(keyword))) {
    priority = 'high';
    confidence = 70;
  } else if (lowerText.includes('announce') || lowerText.includes('report') || lowerText.includes('release')) {
    priority = 'medium';
  }
  
  // Determine sentiment
  const positiveCount = positiveKeywords.reduce((count, keyword) => count + (lowerText.includes(keyword) ? 1 : 0), 0);
  const negativeCount = negativeKeywords.reduce((count, keyword) => count + (lowerText.includes(keyword) ? 1 : 0), 0);
  
  if (positiveCount > negativeCount + 1) {
    sentiment = 'positive';
  } else if (negativeCount > positiveCount + 1) {
    sentiment = 'negative';
  }
  
  // Only use rule-based if we have high confidence
  if (priority === 'critical' || priority === 'high' || positiveCount > 2 || negativeCount > 2) {
    return { sentiment, confidence, priority };
  }
  
  return null; // Fall back to AI for uncertain cases
}

export async function analyzeSentiment(text: string, priority: 'low' | 'medium' | 'high' | 'critical' = 'medium'): Promise<{
  sentiment: 'positive' | 'negative' | 'neutral';
  confidence: number;
  priority: 'low' | 'medium' | 'high' | 'critical';
}> {
  // First try rule-based analysis to save AI costs
  const ruleBasedResult = getRuleBasedSentimentAndPriority(text);
  if (ruleBasedResult) {
    console.log('Used rule-based sentiment analysis (cost: $0)');
    // Track the rule-based operation for cost monitoring
    await persistentCostTracker.recordRuleBasedOperation('sentiment_analysis', 0.001);
    return ruleBasedResult;
  }
  
  // Use intelligent model routing for AI analysis
  const context = createTaskContext(TaskType.SENTIMENT_ANALYSIS, {
    priority,
    contentLength: text.length,
    budgetConstraint: priority === 'critical' ? 'flexible' : 'moderate',
    qualityRequirement: priority === 'critical' ? 'high' : 'good',
    timeConstraint: 'normal'
  });

  try {
    const { response, model, cost } = await modelRouter.makeOptimizedCall(
      context,
      [
        {
          role: "system",
          content: "You are a market intelligence analyst. Analyze the sentiment and business impact of the following text. Respond with JSON in this format: { \"sentiment\": \"positive|negative|neutral\", \"confidence\": number (0-100), \"priority\": \"low|medium|high|critical\", \"reasoning\": \"brief explanation\" }"
        },
        {
          role: "user",
          content: text
        }
      ],
      200
    );

    const result = JSON.parse(response.choices[0].message.content || '{}');
    console.log(`Used ${model} for sentiment analysis (cost: ~$${cost.toFixed(6)})`);
    
    return {
      sentiment: result.sentiment || 'neutral',
      confidence: Math.max(0, Math.min(100, result.confidence || 50)),
      priority: result.priority || 'medium',
    };
  } catch (error: any) {
    if (error?.message?.includes('Rule-based processing recommended')) {
      console.log(error.message);
      // Fall back to rule-based with defaults
      return {
        sentiment: 'neutral',
        confidence: 50,
        priority: 'medium',
      };
    }
    
    console.error("Failed to analyze sentiment:", error);
    return {
      sentiment: 'neutral',
      confidence: 0,
      priority: 'low',
    };
  }
}

// Rule-based summarization for cost savings
function createRuleBasedSummary(title: string, content: string): string | null {
  // For very short content, just use the first sentence
  if (content.length < 200) {
    const firstSentence = content.split('.')[0] + '.';
    if (firstSentence.length > 50) {
      return firstSentence;
    }
  }
  
  // Extract key sentences containing important keywords
  const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 20);
  const keywordScores = sentences.map(sentence => {
    const lowerSentence = sentence.toLowerCase();
    let score = 0;
    
    // Business impact keywords
    if (lowerSentence.includes('revenue') || lowerSentence.includes('profit') || lowerSentence.includes('loss')) score += 3;
    if (lowerSentence.includes('partnership') || lowerSentence.includes('deal') || lowerSentence.includes('agreement')) score += 2;
    if (lowerSentence.includes('launch') || lowerSentence.includes('announce') || lowerSentence.includes('release')) score += 2;
    if (lowerSentence.includes('investment') || lowerSentence.includes('funding')) score += 3;
    if (lowerSentence.includes('acquisition') || lowerSentence.includes('merger')) score += 3;
    
    // Company/people names (capitalized words)
    const capitalizedWords = sentence.match(/[A-Z][a-z]+/g) || [];
    score += Math.min(capitalizedWords.length * 0.5, 2);
    
    return { sentence: sentence.trim(), score };
  });
  
  // Select top 2-3 sentences
  const topSentences = keywordScores
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .filter(s => s.score > 1)
    .map(s => s.sentence);
    
  if (topSentences.length > 0) {
    return topSentences.join('. ') + '.';
  }
  
  return null;
}

export async function summarizeContent(title: string, content: string, priority: 'low' | 'medium' | 'high' | 'critical' = 'medium'): Promise<string> {
  // First try rule-based summarization
  const ruleBasedSummary = createRuleBasedSummary(title, content);
  if (ruleBasedSummary) {
    console.log('Used rule-based summarization (cost: $0)');
    // Track the rule-based operation for cost monitoring
    await persistentCostTracker.recordRuleBasedOperation('summarization', 0.002);
    return ruleBasedSummary;
  }
  
  // Use intelligent model routing for AI summarization
  const context = createTaskContext(TaskType.SUMMARIZATION, {
    priority,
    contentLength: content.length,
    budgetConstraint: priority === 'critical' ? 'moderate' : 'strict',
    qualityRequirement: priority === 'critical' ? 'high' : 'good',
    timeConstraint: 'normal'
  });

  try {
    const { response, model, cost } = await modelRouter.makeOptimizedCall(
      context,
      [
        {
          role: "system",
          content: "Create a concise summary highlighting key business implications and market insights. Keep it under 100 words."
        },
        {
          role: "user", 
          content: `Title: ${title}\n\nContent: ${content.substring(0, 1000)}` // Limit input for cost savings
        }
      ],
      150
    );

    console.log(`Used ${model} for summarization (cost: ~$${cost.toFixed(6)})`);
    return response.choices[0].message.content || "Unable to generate summary.";
  } catch (error: any) {
    if (error?.message?.includes('Rule-based processing recommended')) {
      console.log(error.message);
      return `${title}: ${content.substring(0, 150)}...`; // Simple fallback
    }
    
    console.error("Failed to summarize content:", error);
    return "Summary generation failed.";
  }
}

export async function generateBriefing(insights: Array<{ title: string; content: string; category?: string; priority?: string }>): Promise<{
  title: string;
  content: string;
  keyPoints: string[];
}> {
  // Briefing generation is always a complex task requiring high-quality AI
  const context = createTaskContext(TaskType.BRIEFING_GENERATION, {
    priority: 'high',
    contentLength: insights.length * 200, // Estimate content length
    budgetConstraint: 'moderate',
    qualityRequirement: 'high',
    timeConstraint: 'normal',
    requiresReasoning: true
  });

  try {
    const insightsText = insights.map(insight => 
      `[${insight.category || 'General'}] ${insight.title}: ${insight.content}`
    ).join('\n\n');

    const { response, model, cost } = await modelRouter.makeOptimizedCall(
      context,
      [
        {
          role: "system",
          content: "You are a senior market intelligence analyst. Create a daily intelligence briefing based on the provided insights. Respond with JSON in this format: {\"title\": \"Daily Intelligence Briefing - [Date]\", \"content\": \"comprehensive briefing text\", \"keyPoints\": [\"key point 1\", \"key point 2\", \"key point 3\"]} Focus on actionable insights, market trends, and strategic implications."
        },
        {
          role: "user",
          content: `Create a briefing from these insights:\n\n${insightsText}`
        }
      ],
      800
    );

    const result = JSON.parse(response.choices[0].message.content || '{}');
    console.log(`Used ${model} for briefing generation (cost: ~$${cost.toFixed(6)})`);
    
    return {
      title: result.title || `Daily Intelligence Briefing - ${new Date().toLocaleDateString()}`,
      content: result.content || "No briefing content generated.",
      keyPoints: result.keyPoints || [],
    };
  } catch (error) {
    console.error("Failed to generate briefing:", error);
    return {
      title: `Daily Intelligence Briefing - ${new Date().toLocaleDateString()}`,
      content: "Briefing generation failed. Please check the system status.",
      keyPoints: ["System error occurred", "Please retry later"],
    };
  }
}

// Rule-based categorization to save AI costs
function getCategoryByKeywords(title: string, content: string): string | null {
  const text = (title + ' ' + content).toLowerCase();
  
  const categories = {
    'AI/ML': ['artificial intelligence', 'machine learning', 'ai', 'ml', 'neural', 'deep learning', 'nlp', 'computer vision', 'chatgpt', 'openai', 'anthropic'],
    'Cybersecurity': ['cybersecurity', 'security', 'hack', 'breach', 'malware', 'ransomware', 'privacy', 'encryption', 'firewall', 'vulnerability'],
    'FinTech': ['fintech', 'financial', 'banking', 'payment', 'cryptocurrency', 'bitcoin', 'blockchain', 'wallet', 'lending', 'insurance'],
    'Healthcare': ['healthcare', 'medical', 'hospital', 'drug', 'pharma', 'biotech', 'patient', 'treatment', 'clinical', 'health'],
    'Enterprise': ['enterprise', 'business', 'saas', 'b2b', 'workflow', 'productivity', 'crm', 'erp', 'collaboration'],
    'Consumer Tech': ['consumer', 'mobile', 'app', 'gaming', 'social', 'entertainment', 'streaming', 'iphone', 'android'],
    'Automotive': ['automotive', 'car', 'vehicle', 'tesla', 'electric vehicle', 'autonomous', 'self-driving', 'mobility'],
    'Energy': ['energy', 'solar', 'renewable', 'battery', 'clean energy', 'wind', 'oil', 'gas', 'power'],
    'Retail': ['retail', 'ecommerce', 'shopping', 'marketplace', 'amazon', 'store', 'delivery', 'logistics']
  };
  
  for (const [category, keywords] of Object.entries(categories)) {
    if (keywords.some(keyword => text.includes(keyword))) {
      return category;
    }
  }
  
  return null;
}

export async function categorizeContent(title: string, content: string, priority: 'low' | 'medium' | 'high' | 'critical' = 'medium'): Promise<string> {
  // First try rule-based categorization
  const ruleBasedCategory = getCategoryByKeywords(title, content);
  if (ruleBasedCategory) {
    console.log('Used rule-based categorization (cost: $0)');
    // Track the rule-based operation for cost monitoring
    await persistentCostTracker.recordRuleBasedOperation('categorization', 0.0015);
    return ruleBasedCategory;
  }
  
  // Use intelligent model routing for AI categorization
  const context = createTaskContext(TaskType.CATEGORIZATION, {
    priority,
    contentLength: content.length,
    budgetConstraint: 'strict', // Categorization should be cost-efficient
    qualityRequirement: 'good',
    timeConstraint: 'normal'
  });

  try {
    const { response, model, cost } = await modelRouter.makeOptimizedCall(
      context,
      [
        {
          role: "system",
          content: "Categorize the following content into one of these categories: AI/ML, Cybersecurity, FinTech, Healthcare, Enterprise, Consumer Tech, Automotive, Energy, Retail, Other. Respond with only the category name."
        },
        {
          role: "user",
          content: `Title: ${title}\nContent: ${content.substring(0, 500)}`
        }
      ],
      10
    );

    console.log(`Used ${model} for categorization (cost: ~$${cost.toFixed(6)})`);
    return response.choices[0].message.content?.trim() || "Other";
  } catch (error: any) {
    if (error?.message?.includes('Rule-based processing recommended')) {
      console.log(error.message);
      return "Other";
    }
    
    console.error("Failed to categorize content:", error);
    return "Other";
  }
}

// New function for entity extraction using advanced models
export async function extractEntities(text: string, priority: 'low' | 'medium' | 'high' | 'critical'): Promise<{
  companies: string[];
  people: string[];
  organizations: string[];
  confidence: number;
}> {
  // Entity extraction is a complex task that benefits from advanced reasoning
  const context = createTaskContext(TaskType.ENTITY_EXTRACTION, {
    priority,
    contentLength: text.length,
    budgetConstraint: priority === 'critical' ? 'flexible' : 'moderate',
    qualityRequirement: priority === 'critical' ? 'premium' : 'high',
    timeConstraint: 'normal',
    requiresReasoning: true
  });

  try {
    const { response, model, cost } = await modelRouter.makeOptimizedCall(
      context,
      [
        {
          role: "system",
          content: "Extract entities from the text. Respond with JSON: {\"companies\": [\"company1\", \"company2\"], \"people\": [\"person1\", \"person2\"], \"organizations\": [\"org1\", \"org2\"], \"confidence\": number (0-100)}. Focus on business-relevant entities mentioned in the content."
        },
        {
          role: "user",
          content: text
        }
      ],
      300
    );

    const result = JSON.parse(response.choices[0].message.content || '{}');
    console.log(`Used ${model} for entity extraction (cost: ~$${cost.toFixed(6)})`);
    
    return {
      companies: result.companies || [],
      people: result.people || [],
      organizations: result.organizations || [],
      confidence: result.confidence || 0
    };
  } catch (error: any) {
    if (error?.message?.includes('Rule-based processing recommended')) {
      console.log(`Entity extraction skipped: ${error.message}`);
      return {
        companies: [],
        people: [],
        organizations: [],
        confidence: 0
      };
    }
    
    console.error("Failed to extract entities:", error);
    return {
      companies: [],
      people: [],
      organizations: [],
      confidence: 0
    };
  }
}
