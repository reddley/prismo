// Feature flags service for dynamic configuration management
import { db } from "../db";
import { featureFlags } from "../../shared/schema";
import { eq, inArray } from "drizzle-orm";
import { CORE_FEATURE_FLAGS, type CoreFeatureFlagId, type FeatureFlagValue, type FeatureFlagType, type CreateFeatureFlag, type UpdateFeatureFlag } from "../../shared/feature-flags";
import { logger } from "../observability/logger";

interface FeatureFlagEvaluationContext {
  userId?: string;
  environment: string;
  rolloutGroup?: number; // 0-99 for percentage rollouts
}

export class FeatureFlagService {
  private cache = new Map<string, any>();
  private cacheExpiry = new Map<string, number>();
  private readonly CACHE_TTL = 60000; // 1 minute cache

  constructor() {
    this.initializeCoreFlags();
  }

  /**
   * Initialize core feature flags in the database if they don't exist
   */
  private async initializeCoreFlags(): Promise<void> {
    try {
      const environment = process.env.NODE_ENV as 'development' | 'staging' | 'production' || 'development';
      
      for (const [flagId, flagConfig] of Object.entries(CORE_FEATURE_FLAGS)) {
        const existing = await db.select().from(featureFlags).where(eq(featureFlags.id, flagId)).limit(1);
        
        if (existing.length === 0) {
          await db.insert(featureFlags).values({
            id: flagId,
            name: flagConfig.name,
            description: flagConfig.description,
            type: flagConfig.type,
            defaultValue: flagConfig.defaultValue,
            currentValue: flagConfig.defaultValue,
            enabled: true,
            category: flagConfig.category,
            riskLevel: flagConfig.riskLevel,
            environment: [environment],
            lastModifiedBy: 'system'
          });
          
          logger.info(`Initialized core feature flag: ${flagId}`);
        }
      }
    } catch (error) {
      logger.error('Failed to initialize core feature flags', { error: error instanceof Error ? error.message : 'Unknown error' });
    }
  }

  /**
   * Get a feature flag value with type safety
   */
  async getFlag<T extends FeatureFlagType>(
    flagId: string, 
    defaultValue: FeatureFlagValue<T>,
    context: FeatureFlagEvaluationContext = { environment: process.env.NODE_ENV || 'development' }
  ): Promise<FeatureFlagValue<T>> {
    try {
      // Check cache first
      const cacheKey = `${flagId}:${context.environment}:${context.userId || 'anonymous'}`;
      const cached = this.getFromCache(cacheKey);
      if (cached !== undefined) {
        return cached;
      }

      // Fetch from database
      const [flag] = await db.select()
        .from(featureFlags)
        .where(eq(featureFlags.id, flagId))
        .limit(1);

      if (!flag) {
        logger.warn(`Feature flag not found: ${flagId}, using default value`);
        return defaultValue;
      }

      // Log the flag structure for debugging
      logger.debug(`Feature flag retrieved: ${flagId}`, { 
        flag: flag,
        hasDefaultValue: 'defaultValue' in flag,
        flagKeys: Object.keys(flag || {}),
        defaultValueType: typeof flag?.defaultValue
      });

      // Ensure flag object is valid before proceeding
      if (!flag || typeof flag !== 'object') {
        logger.error(`Invalid flag object retrieved for ${flagId}:`, { flag });
        return defaultValue;
      }

      // Check if flag is enabled and applies to current environment
      if (!flag.enabled || !flag.environment?.includes(context.environment as any)) {
        const fallbackValue = flag.defaultValue || defaultValue;
        this.setCache(cacheKey, fallbackValue);
        return fallbackValue as FeatureFlagValue<T>;
      }

      // Handle rollout percentage
      if (flag.rolloutPercentage && flag.rolloutPercentage < 100) {
        const rolloutGroup = context.rolloutGroup ?? this.getUserRolloutGroup(context.userId || 'anonymous');
        if (rolloutGroup >= flag.rolloutPercentage) {
          this.setCache(cacheKey, flag.defaultValue || defaultValue);
          return (flag.defaultValue || defaultValue) as FeatureFlagValue<T>;
        }
      }

      // Handle user targeting
      if (flag.targetUsers && flag.targetUsers.length > 0 && context.userId) {
        if (!flag.targetUsers.includes(context.userId)) {
          this.setCache(cacheKey, flag.defaultValue || defaultValue);
          return (flag.defaultValue || defaultValue) as FeatureFlagValue<T>;
        }
      }

      const value = (flag.currentValue || flag.defaultValue || defaultValue) as FeatureFlagValue<T>;
      this.setCache(cacheKey, value);
      return value;

    } catch (error) {
      logger.error(`Error getting feature flag ${flagId}`, { error: error instanceof Error ? error.message : 'Unknown error' });
      return defaultValue;
    }
  }

  /**
   * Type-safe getter for core feature flags
   */
  async getCoreFlag<K extends CoreFeatureFlagId>(
    flagId: K,
    context?: FeatureFlagEvaluationContext
  ): Promise<any> {
    const flagConfig = CORE_FEATURE_FLAGS[flagId];
    if (!flagConfig) {
      logger.error(`Core feature flag config not found: ${flagId}`);
      return false; // Safe default
    }
    
    logger.debug(`Getting core flag ${flagId}`, { 
      flagId, 
      hasConfig: !!flagConfig,
      defaultValue: flagConfig.defaultValue,
      configKeys: Object.keys(flagConfig || {})
    });
    
    return this.getFlag(flagId, flagConfig.defaultValue, context);
  }

  /**
   * Check if a feature is enabled (boolean flags only)
   */
  async isEnabled(flagId: string, context?: FeatureFlagEvaluationContext): Promise<boolean> {
    return this.getFlag(flagId, false, context);
  }

  /**
   * Update a feature flag value
   */
  async updateFlag(flagId: string, updates: UpdateFeatureFlag): Promise<boolean> {
    try {
      await db.update(featureFlags)
        .set({
          ...updates,
          updatedAt: new Date()
        })
        .where(eq(featureFlags.id, flagId));

      // Clear cache for this flag
      this.clearFlagCache(flagId);
      
      logger.info(`Feature flag updated: ${flagId}`, { 
        flagId,
        modifiedBy: updates.lastModifiedBy 
      });

      return true;
    } catch (error) {
      logger.error(`Failed to update feature flag ${flagId}`, { 
        error: error instanceof Error ? error.message : 'Unknown error',
        flagId 
      });
      return false;
    }
  }

  /**
   * Create a new feature flag
   */
  async createFlag(flag: CreateFeatureFlag & { lastModifiedBy: string }): Promise<boolean> {
    try {
      await db.insert(featureFlags).values({
        ...flag,
        createdAt: new Date(),
        updatedAt: new Date()
      });

      logger.info(`Feature flag created: ${flag.id}`, { 
        flagId: flag.id,
        createdBy: flag.lastModifiedBy 
      });

      return true;
    } catch (error) {
      logger.error(`Failed to create feature flag ${flag.id}`, { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      return false;
    }
  }

  /**
   * Get all feature flags with their current status
   */
  async getAllFlags(environment?: string): Promise<any[]> {
    try {
      let query = db.select().from(featureFlags);
      
      const flags = await query;
      
      return flags.filter(flag => 
        !environment || flag.environment.includes(environment as any)
      );
    } catch (error) {
      logger.error('Failed to get all feature flags', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      return [];
    }
  }

  /**
   * Emergency kill switch - disable all non-critical flags
   */
  async emergencyKillSwitch(userId: string): Promise<boolean> {
    try {
      await db.update(featureFlags)
        .set({
          enabled: false,
          updatedAt: new Date(),
          lastModifiedBy: userId
        })
        .where(inArray(featureFlags.riskLevel, ['high', 'critical']));

      this.clearAllCache();
      
      logger.warn('Emergency kill switch activated', { userId });
      return true;
    } catch (error) {
      logger.error('Failed to activate emergency kill switch', { 
        error: error instanceof Error ? error.message : 'Unknown error',
        userId 
      });
      return false;
    }
  }

  /**
   * System control flags for critical operations
   */
  async isReadOnlyMode(): Promise<boolean> {
    return this.getCoreFlag('READ_only_mode');
  }

  async isDataIngestionPaused(): Promise<boolean> {
    return this.getCoreFlag('PAUSE_DATA_INGESTION');
  }

  async isAiProcessingEnabled(): Promise<boolean> {
    return this.getCoreFlag('enable_ai_processing');
  }

  async isBulkAiCallsEnabled(): Promise<boolean> {
    return this.getCoreFlag('bulk_ai_calls');
  }

  async getDailyAiCostLimit(): Promise<number> {
    return this.getCoreFlag('ai_cost_limit_daily');
  }

  // Cache management
  private getFromCache(key: string): any {
    const expiry = this.cacheExpiry.get(key);
    if (expiry && Date.now() > expiry) {
      this.cache.delete(key);
      this.cacheExpiry.delete(key);
      return undefined;
    }
    return this.cache.get(key);
  }

  private setCache(key: string, value: any): void {
    this.cache.set(key, value);
    this.cacheExpiry.set(key, Date.now() + this.CACHE_TTL);
  }

  private clearFlagCache(flagId: string): void {
    const keysToDelete = Array.from(this.cache.keys())
      .filter(key => key.startsWith(`${flagId}:`));
    
    keysToDelete.forEach(key => {
      this.cache.delete(key);
      this.cacheExpiry.delete(key);
    });
  }

  private clearAllCache(): void {
    this.cache.clear();
    this.cacheExpiry.clear();
  }

  private getUserRolloutGroup(userId: string): number {
    // Simple hash-based rollout group assignment (0-99)
    let hash = 0;
    for (let i = 0; i < userId.length; i++) {
      const char = userId.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash) % 100;
  }
}

// Singleton instance
export const featureFlagService = new FeatureFlagService();

// Middleware helper for checking feature flags
export function requireFeatureFlag(flagId: string, defaultValue: any = false) {
  return async (req: any, res: any, next: any) => {
    try {
      const context = {
        userId: req.user?.id,
        environment: process.env.NODE_ENV || 'development'
      };
      
      const isEnabled = await featureFlagService.getFlag(flagId, defaultValue, context);
      
      if (!isEnabled) {
        return res.status(403).json({ 
          error: 'Feature not available',
          featureFlag: flagId 
        });
      }
      
      next();
    } catch (error) {
      logger.error(`Feature flag middleware error for ${flagId}`, { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      next();
    }
  };
}

// Kill switch middleware for critical operations
export function killSwitchMiddleware(req: any, res: any, next: any) {
  return async () => {
    try {
      const isReadOnly = await featureFlagService.isReadOnlyMode();
      
      if (isReadOnly && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
        return res.status(503).json({
          error: 'System is in read-only mode',
          message: 'Write operations are temporarily disabled'
        });
      }
      
      next();
    } catch (error) {
      logger.error('Kill switch middleware error', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      next();
    }
  };
}