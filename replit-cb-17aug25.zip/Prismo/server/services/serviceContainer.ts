/**
 * Dependency Injection Container
 * Manages service instantiation and dependencies with standardized error handling
 */

import { logger } from '../observability/logger';

// Error handling policies
export interface ErrorPolicy {
  retryAttempts: number;
  retryDelay: number;
  fallbackBehavior: 'throw' | 'return-null' | 'return-default';
  logLevel: 'error' | 'warn' | 'info';
}

export const DEFAULT_ERROR_POLICIES: Record<string, ErrorPolicy> = {
  'ai-operations': {
    retryAttempts: 2,
    retryDelay: 1000,
    fallbackBehavior: 'return-null',
    logLevel: 'warn'
  },
  'data-enrichment': {
    retryAttempts: 3,
    retryDelay: 500,
    fallbackBehavior: 'return-default',
    logLevel: 'warn'
  },
  'external-api': {
    retryAttempts: 3,
    retryDelay: 2000,
    fallbackBehavior: 'throw',
    logLevel: 'error'
  },
  'database': {
    retryAttempts: 1,
    retryDelay: 0,
    fallbackBehavior: 'throw',
    logLevel: 'error'
  },
  'cost-tracking': {
    retryAttempts: 2,
    retryDelay: 100,
    fallbackBehavior: 'return-null',
    logLevel: 'warn'
  }
};

// Service interfaces for dependency injection
export interface IDataEnrichmentService {
  enrichCompanyData(companyName: string): Promise<any | null>;
  enrichPersonData(personName: string): Promise<any | null>;
  cropImageToSquare(imageUrl: string): Promise<string | null>;
}

export interface IEntityProcessingService {
  processInsightForEntities(insight: any): Promise<{ mentions: any[]; relationships: any[]; }>;
  extractEntitiesFromContent(content: string): Promise<any[]>;
  createOrUpdateEntity(entityData: any): Promise<any>;
}

export interface IAiIntelligenceService {
  analyzeSentiment(text: string): Promise<{ sentiment: string; confidence: number; priority: string; }>;
  summarizeContent(text: string): Promise<string>;
  categorizeContent(text: string): Promise<string>;
  extractEntities(text: string): Promise<any[]>;
  selectOptimalModel(context: any): any;
}

export interface ICostTrackingService {
  recordCost(operation: any): Promise<void>;
  recordRuleBasedOperation(operation: string, savings?: number): Promise<void>;
  getDailyCostStats(): Promise<any>;
  checkBudgetConstraints(): Promise<boolean>;
}

export interface IUserIntelligenceService {
  trackInteraction(interaction: any): Promise<void>;
  checkInsightMatchesSpecs(userId: string, insight: any): Promise<any>;
  processInsightForAlerts(insightId: string): Promise<void>;
  generateAlert(userId: string, insight: any, matchResult: any): Promise<void>;
}

// Service registry with lazy initialization
class ServiceContainer {
  private services = new Map<string, any>();
  private singletons = new Map<string, any>();
  private errorPolicies = new Map<string, ErrorPolicy>();

  constructor() {
    // Register default error policies
    Object.entries(DEFAULT_ERROR_POLICIES).forEach(([key, policy]) => {
      this.errorPolicies.set(key, policy);
    });
  }

  // Register a service factory function
  register<T>(name: string, factory: () => T, singleton: boolean = true): void {
    this.services.set(name, { factory, singleton });
  }

  // Register a service instance directly
  registerInstance<T>(name: string, instance: T): void {
    this.singletons.set(name, instance);
  }

  // Get service with dependency injection
  get<T>(name: string): T {
    // Check if singleton instance already exists
    if (this.singletons.has(name)) {
      return this.singletons.get(name);
    }

    // Get service registration
    const registration = this.services.get(name);
    if (!registration) {
      throw new Error(`Service '${name}' not registered`);
    }

    // Create instance
    const instance = registration.factory();

    // Store as singleton if required
    if (registration.singleton) {
      this.singletons.set(name, instance);
    }

    return instance;
  }

  // Execute operation with standardized error handling
  async executeWithErrorPolicy<T>(
    operation: () => Promise<T>,
    policyName: string,
    operationName: string,
    defaultValue?: T
  ): Promise<T | null> {
    const policy = this.errorPolicies.get(policyName) || DEFAULT_ERROR_POLICIES['database'];
    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= policy.retryAttempts; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        if (attempt < policy.retryAttempts) {
          logger[policy.logLevel](`Operation '${operationName}' failed, retrying (${attempt + 1}/${policy.retryAttempts})`, {
            error: lastError.message,
            attempt: attempt + 1
          });
          
          if (policy.retryDelay > 0) {
            await new Promise(resolve => setTimeout(resolve, policy.retryDelay));
          }
        }
      }
    }

    // Handle final failure based on policy
    logger[policy.logLevel](`Operation '${operationName}' failed after ${policy.retryAttempts + 1} attempts`, {
      error: lastError?.message,
      policy: policyName
    });

    switch (policy.fallbackBehavior) {
      case 'throw':
        throw lastError;
      case 'return-default':
        return defaultValue || null;
      case 'return-null':
      default:
        return null;
    }
  }

  // Register custom error policy
  registerErrorPolicy(name: string, policy: ErrorPolicy): void {
    this.errorPolicies.set(name, policy);
  }

  // Clear all services (for testing)
  clear(): void {
    this.services.clear();
    this.singletons.clear();
  }
}

// Global service container instance
export const serviceContainer = new ServiceContainer();

// Helper function to wrap service methods with error handling
export function withErrorPolicy(policyName: string) {
  return function(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const originalMethod = descriptor.value;
    
    descriptor.value = function(...args: any[]) {
      return serviceContainer.executeWithErrorPolicy(
        () => originalMethod.apply(this, args),
        policyName,
        `${target.constructor.name}.${propertyKey}`
      );
    };
    
    return descriptor;
  };
}