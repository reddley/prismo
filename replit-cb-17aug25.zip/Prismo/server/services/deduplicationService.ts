import { storage } from '../storage';
import type { Company, Person, Organization } from '@shared/schema';

/**
 * Service for detecting and merging duplicate entities
 */
export class DeduplicationService {
  /**
   * Find potential duplicates for a company
   */
  async findDuplicateCompanies(companyName: string, excludeId?: string): Promise<Company[]> {
    const allCompanies = await storage.getCompanies();
    const normalizedName = this.normalizeEntityName(companyName);
    
    return allCompanies.filter((company: Company) => {
      if (excludeId && company.id === excludeId) return false;
      
      const normalizedCompanyName = this.normalizeEntityName(company.name);
      return this.isSimilarName(normalizedName, normalizedCompanyName) ||
             this.isKnownDuplicate(normalizedName, normalizedCompanyName);
    });
  }

  /**
   * Find potential duplicates for a person
   */
  async findDuplicatePeople(personName: string, excludeId?: string): Promise<Person[]> {
    const allPeople = await storage.getPeople();
    const normalizedName = this.normalizeEntityName(personName);
    
    return allPeople.filter((person: Person) => {
      if (excludeId && person.id === excludeId) return false;
      
      const normalizedPersonName = this.normalizeEntityName(person.name);
      return this.isSimilarName(normalizedName, normalizedPersonName);
    });
  }

  /**
   * Find potential duplicates for an organization
   */
  async findDuplicateOrganizations(orgName: string, excludeId?: string): Promise<Organization[]> {
    const allOrganizations = await storage.getOrganizations();
    const normalizedName = this.normalizeEntityName(orgName);
    
    return allOrganizations.filter((org: Organization) => {
      if (excludeId && org.id === excludeId) return false;
      
      const normalizedOrgName = this.normalizeEntityName(org.name);
      return this.isSimilarName(normalizedName, normalizedOrgName);
    });
  }

  /**
   * Merge two companies, keeping the better one
   */
  async mergeCompanies(keepId: string, removeId: string): Promise<Company> {
    const keepCompany = await storage.getCompany(keepId);
    const removeCompany = await storage.getCompany(removeId);
    
    if (!keepCompany || !removeCompany) {
      throw new Error('One or both companies not found');
    }

    // Merge data from both companies, preferring the one we're keeping
    const mergedData = {
      ...keepCompany,
      // Keep non-null values from the company being removed
      description: keepCompany.description || removeCompany.description,
      industry: keepCompany.industry || removeCompany.industry,
      founded: keepCompany.founded || removeCompany.founded,
      headquarters: keepCompany.headquarters || removeCompany.headquarters,
      website: keepCompany.website || removeCompany.website,
      logoUrl: keepCompany.logoUrl || removeCompany.logoUrl,
      marketCap: keepCompany.marketCap || removeCompany.marketCap,
      employees: keepCompany.employees || removeCompany.employees,
      revenue: keepCompany.revenue || removeCompany.revenue,
      keyPeople: keepCompany.keyPeople || removeCompany.keyPeople,
      socialMedia: keepCompany.socialMedia || removeCompany.socialMedia,
      mentionCount: (keepCompany.mentionCount || 0) + (removeCompany.mentionCount || 0),
      // Use the most recent mention date
      lastMentioned: this.getMostRecentDate(keepCompany.lastMentioned, removeCompany.lastMentioned),
      // Keep the highest priority
      priority: this.getHigherPriority(keepCompany.priority, removeCompany.priority),
      updatedAt: new Date()
    };

    // Update the company we're keeping (excluding computed fields)
    const updateData = { ...mergedData };
    delete (updateData as any).id;
    delete (updateData as any).createdAt;
    
    const updatedCompany = await storage.updateCompany(keepId, updateData);
    
    // Delete the duplicate
    await storage.deleteCompany(removeId);
    
    console.log(`Merged duplicate companies: kept ${keepCompany.name} (${keepId}), removed ${removeCompany.name} (${removeId})`);
    
    return updatedCompany!
  }

  /**
   * Automatically detect and clean up obvious duplicates
   */
  async cleanupDuplicates(): Promise<{
    companiesRemoved: number;
    peopleRemoved: number;
    organizationsRemoved: number;
  }> {
    let companiesRemoved = 0;
    let peopleRemoved = 0;
    let organizationsRemoved = 0;

    // Clean up companies
    const companies = await storage.getCompanies();
    const companyGroups = this.groupSimilarEntities(companies);
    
    for (const group of companyGroups) {
      if (group.length > 1) {
        // Keep the one with the most complete data
        const best = this.selectBestEntity(group);
        const toRemove = group.filter(c => c.id !== best.id);
        
        for (const duplicate of toRemove) {
          // Only merge if they're clearly the same entity
          if (this.isDefiniteDuplicate(best.name, duplicate.name)) {
            await this.mergeCompanies(best.id, duplicate.id);
            companiesRemoved++;
          }
        }
      }
    }

    return { companiesRemoved, peopleRemoved, organizationsRemoved };
  }

  /**
   * Normalize entity name for comparison
   */
  private normalizeEntityName(name: string): string {
    return name
      .toLowerCase()
      .trim()
      .replace(/\s+(inc|corp|corporation|llc|ltd|limited|company|co)\.?$/i, '')
      .replace(/[^\w\s]/g, '')
      .replace(/\s+/g, ' ');
  }

  /**
   * Check if two names are similar enough to be duplicates
   */
  private isSimilarName(name1: string, name2: string): boolean {
    // Exact match after normalization
    if (name1 === name2) return true;
    
    // Check if one is contained within the other (for company suffixes)
    if (name1.includes(name2) || name2.includes(name1)) {
      const longer = name1.length > name2.length ? name1 : name2;
      const shorter = name1.length <= name2.length ? name1 : name2;
      
      // Allow if the difference is just company suffixes
      if (longer.replace(shorter, '').trim().match(/^(inc|corp|corporation|company|co)$/i)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Check for known duplicate patterns
   */
  private isKnownDuplicate(name1: string, name2: string): boolean {
    const duplicatePairs = [
      ['apple', 'apple inc'],
      ['apple', 'apple computer'],
      ['google', 'alphabet'],
      ['facebook', 'meta'],
      ['twitter', 'x corp'],
      ['tesla', 'tesla inc'],
      ['microsoft', 'microsoft corporation']
    ];

    return duplicatePairs.some(pair => 
      (name1 === pair[0] && name2 === pair[1]) ||
      (name1 === pair[1] && name2 === pair[0])
    );
  }

  /**
   * Check if two entities are definitely the same (high confidence)
   */
  private isDefiniteDuplicate(name1: string, name2: string): boolean {
    const norm1 = this.normalizeEntityName(name1);
    const norm2 = this.normalizeEntityName(name2);
    
    // Exact match or known duplicates
    return norm1 === norm2 || this.isKnownDuplicate(norm1, norm2);
  }

  /**
   * Group similar entities together
   */
  private groupSimilarEntities<T extends { name: string; id: string }>(entities: T[]): T[][] {
    const groups: T[][] = [];
    const processed = new Set<string>();

    for (const entity of entities) {
      if (processed.has(entity.id)) continue;

      const group = [entity];
      processed.add(entity.id);

      // Find similar entities
      for (const other of entities) {
        if (other.id === entity.id || processed.has(other.id)) continue;
        
        if (this.isSimilarName(
          this.normalizeEntityName(entity.name),
          this.normalizeEntityName(other.name)
        )) {
          group.push(other);
          processed.add(other.id);
        }
      }

      if (group.length > 0) {
        groups.push(group);
      }
    }

    return groups;
  }

  /**
   * Select the best entity from a group of duplicates
   */
  private selectBestEntity<T extends { 
    name: string; 
    description?: string | null; 
    logoUrl?: string | null;
    priority: string;
    createdAt: Date;
  }>(entities: T[]): T {
    return entities.reduce((best, current) => {
      // Prefer entities with more complete data
      const bestScore = this.getEntityScore(best);
      const currentScore = this.getEntityScore(current);
      
      if (currentScore > bestScore) return current;
      if (currentScore < bestScore) return best;
      
      // If scores are equal, prefer the older one (likely more established)
      return new Date(best.createdAt) < new Date(current.createdAt) ? best : current;
    });
  }

  /**
   * Calculate a score for entity completeness
   */
  private getEntityScore(entity: { 
    description?: string | null; 
    logoUrl?: string | null;
    priority: string;
  }): number {
    let score = 0;
    
    if (entity.description && entity.description.length > 50) score += 2;
    if (entity.logoUrl) score += 2;
    
    // Priority scoring
    const priorityScores = { critical: 4, high: 3, medium: 2, low: 1 };
    score += priorityScores[entity.priority as keyof typeof priorityScores] || 0;
    
    return score;
  }

  /**
   * Get the more recent date
   */
  private getMostRecentDate(date1?: Date | string | null, date2?: Date | string | null): Date | null {
    if (!date1 && !date2) return null;
    if (!date1) return new Date(date2!);
    if (!date2) return new Date(date1);
    
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    
    return d1 > d2 ? d1 : d2;
  }

  /**
   * Get the higher priority
   */
  private getHigherPriority(priority1: string, priority2: string): string {
    const priorityOrder = ['critical', 'high', 'medium', 'low'];
    const index1 = priorityOrder.indexOf(priority1);
    const index2 = priorityOrder.indexOf(priority2);
    
    return index1 !== -1 && (index2 === -1 || index1 < index2) ? priority1 : priority2;
  }
}

export const deduplicationService = new DeduplicationService();