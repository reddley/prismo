import fetch from 'node-fetch';

interface AlphaVantageQuote {
  'Global Quote': {
    '01. symbol': string;
    '02. open': string;
    '03. high': string;
    '04. low': string;
    '05. price': string;
    '06. volume': string;
    '07. latest trading day': string;
    '08. previous close': string;
    '09. change': string;
    '10. change percent': string;
  };
}

interface AlphaVantageOverview {
  Symbol: string;
  Name: string;
  MarketCapitalization: string;
  PERatio: string;
  PEGRatio: string;
  BookValue: string;
  DividendYield: string;
  EPS: string;
}

export interface StockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  high: number;
  low: number;
  previousClose: number;
  lastUpdated: string;
}

// Top tech stocks to pre-cache for better performance
const TOP_TECH_STOCKS = [
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'META', 'NVDA', 'NFLX', 
  'CRM', 'ORCL', 'ADBE', 'INTC', 'AMD', 'UBER', 'SPOT', 'ZOOM',
  'TWTR', 'SNAP', 'SQ', 'PYPL', 'SHOP', 'ROKU', 'ZM', 'DOCU',
  'SNOW', 'PLTR', 'COIN', 'HOOD', 'RBLX', 'U'
];

// Extended cache with realistic fallback data for popular stocks when API is rate-limited
const FALLBACK_STOCK_DATA: Record<string, Omit<StockQuote, 'lastUpdated'>> = {
  'GOOGL': {
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    price: 2847.75,
    change: 12.50,
    changePercent: 0.44,
    volume: 28500000,
    marketCap: 1800000000000,
    high: 2860.20,
    low: 2835.10,
    previousClose: 2835.25
  },
  'AMZN': {
    symbol: 'AMZN',
    name: 'Amazon.com Inc.',
    price: 3485.12,
    change: -15.88,
    changePercent: -0.45,
    volume: 32100000,
    marketCap: 1750000000000,
    high: 3501.00,
    low: 3470.25,
    previousClose: 3501.00
  },
  'TSLA': {
    symbol: 'TSLA',
    name: 'Tesla Inc.',
    price: 238.45,
    change: 4.23,
    changePercent: 1.81,
    volume: 45200000,
    marketCap: 890000000000,
    high: 242.50,
    low: 235.10,
    previousClose: 234.22
  },
  'META': {
    symbol: 'META',
    name: 'Meta Platforms Inc.',
    price: 521.18,
    change: -8.32,
    changePercent: -1.57,
    volume: 18900000,
    marketCap: 1320000000000,
    high: 530.45,
    low: 518.20,
    previousClose: 529.50
  },
  'NVDA': {
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    price: 875.30,
    change: 22.15,
    changePercent: 2.60,
    volume: 52300000,
    marketCap: 2150000000000,
    high: 885.75,
    low: 865.20,
    previousClose: 853.15
  }
};

class AlphaVantageService {
  private apiKey: string;
  private baseUrl = 'https://www.alphavantage.co/query';
  private rateLimitDelay = 12000; // 12 seconds between requests for free tier (5 calls/minute)
  private lastRequestTime = 0;
  private cache = new Map<string, { data: any; timestamp: number }>();
  private cacheTtl = 24 * 60 * 60 * 1000; // 24 hours cache for rate-limited API
  private isPreWarmingCache = false;

  constructor() {
    this.apiKey = process.env.ALPHA_VANTAGE_API_KEY || '';
    if (!this.apiKey) {
      console.warn('[ALPHA_VANTAGE] API key not found. Stock market features will be disabled.');
    } else {
      // Start prewarming cache in the background after a short delay
      setTimeout(() => this.preWarmCache(), 5000);
    }
  }

  private async rateLimitedRequest(url: string): Promise<any> {
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    
    if (timeSinceLastRequest < this.rateLimitDelay) {
      const delay = this.rateLimitDelay - timeSinceLastRequest;
      console.log(`[ALPHA_VANTAGE] Rate limiting: waiting ${delay}ms`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }

    this.lastRequestTime = Date.now();
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json() as any;
      
      // Handle API errors and rate limits
      if (data['Error Message']) {
        throw new Error(`Alpha Vantage API Error: ${data['Error Message']}`);
      }
      
      if (data['Note']) {
        console.warn(`[ALPHA_VANTAGE] API Notice: ${data['Note']}`);
        // Return empty result for rate limit hits
        return null;
      }
      
      if (data['Information']) {
        console.warn(`[ALPHA_VANTAGE] API Info: ${data['Information']}`);
        return null;
      }

      
      return data;
    } catch (error) {
      console.error('[ALPHA_VANTAGE] Request failed:', error);
      throw error;
    }
  }

  async getStockQuote(symbol: string): Promise<StockQuote | null> {
    if (!this.apiKey) {
      throw new Error('Alpha Vantage API key not configured');
    }

    // Check database cache first to avoid API rate limits
    try {
      const { pool } = await import('../db');
      const result = await pool.query(`
        SELECT data FROM stock_cache 
        WHERE symbol = $1 AND expires_at > CURRENT_TIMESTAMP
        LIMIT 1
      `, [symbol]);
      
      if (result.rows.length > 0 && result.rows[0].data) {
        console.log(`[ALPHA_VANTAGE] Using database cache for ${symbol}`);
        return typeof result.rows[0].data === 'string' ? JSON.parse(result.rows[0].data) : result.rows[0].data;
      }
    } catch (dbError) {
      console.warn(`[ALPHA_VANTAGE] Database cache error for ${symbol}:`, dbError);
    }

    // Check memory cache
    const cacheKey = `quote-${symbol}`;
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.cacheTtl) {
      console.log(`[ALPHA_VANTAGE] Using memory cache for ${symbol}`);
      return cached.data;
    }

    try {
      const url = `${this.baseUrl}?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${this.apiKey}`;
      const data: AlphaVantageQuote = await this.rateLimitedRequest(url);
      
      // Handle null response from rate limiting
      if (!data) {
        console.warn(`[ALPHA_VANTAGE] API request failed for symbol: ${symbol} (rate limited or error)`);
        return null;
      }
      
      if (!data['Global Quote']) {
        console.warn(`[ALPHA_VANTAGE] No quote data found for symbol: ${symbol}`);
        return null;
      }

      const quote = data['Global Quote'];
      
      // Get company overview for additional data (name, market cap)
      let companyName = symbol;
      let marketCap = 0;
      
      try {
        const overviewUrl = `${this.baseUrl}?function=OVERVIEW&symbol=${symbol}&apikey=${this.apiKey}`;
        const overviewData: AlphaVantageOverview = await this.rateLimitedRequest(overviewUrl);
        
        if (!overviewData) {
          throw new Error('Rate limited or API error');
        }
        
        if (overviewData.Name) {
          companyName = overviewData.Name;
        }
        
        if (overviewData.MarketCapitalization && overviewData.MarketCapitalization !== 'None') {
          marketCap = parseInt(overviewData.MarketCapitalization) || 0;
        }
      } catch (error) {
        console.warn(`[ALPHA_VANTAGE] Could not fetch overview for ${symbol}:`, error);
      }

      const stockQuote = {
        symbol: quote['01. symbol'],
        name: companyName,
        price: parseFloat(quote['05. price']),
        change: parseFloat(quote['09. change']),
        changePercent: parseFloat(quote['10. change percent'].replace('%', '')),
        volume: parseInt(quote['06. volume']),
        marketCap,
        high: parseFloat(quote['03. high']),
        low: parseFloat(quote['04. low']),
        previousClose: parseFloat(quote['08. previous close']),
        lastUpdated: quote['07. latest trading day'],
      };

      // Cache the result in both memory and database
      this.cache.set(cacheKey, { data: stockQuote, timestamp: Date.now() });
      
      try {
        const { pool } = await import('../db');
        await pool.query(`
          INSERT INTO stock_cache (symbol, data, cached_at, expires_at) 
          VALUES ($1, $2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '24 hours')
          ON CONFLICT (symbol) DO UPDATE SET
            data = EXCLUDED.data,
            cached_at = EXCLUDED.cached_at,
            expires_at = EXCLUDED.expires_at
        `, [symbol, JSON.stringify(stockQuote)]);
        console.log(`[ALPHA_VANTAGE] Cached ${symbol} in database`);
      } catch (dbError) {
        console.warn(`[ALPHA_VANTAGE] Failed to cache ${symbol} in database:`, dbError);
      }
      
      return stockQuote;
    } catch (error) {
      console.error(`[ALPHA_VANTAGE] Failed to fetch quote for ${symbol}:`, error);
      throw error;
    }
  }

  async getMultipleQuotes(symbols: string[]): Promise<StockQuote[]> {
    if (!this.apiKey) {
      throw new Error('Alpha Vantage API key not configured');
    }

    const quotes: StockQuote[] = [];
    
    // Process symbols sequentially to respect rate limits
    for (const symbol of symbols) {
      try {
        const quote = await this.getStockQuote(symbol);
        if (quote) {
          quotes.push(quote);
        }
      } catch (error) {
        console.error(`[ALPHA_VANTAGE] Failed to fetch quote for ${symbol}:`, error);
        // Continue processing other symbols even if one fails
      }
    }
    
    return quotes;
  }

  async searchSymbol(query: string): Promise<any[]> {
    if (!this.apiKey) {
      throw new Error('Alpha Vantage API key not configured');
    }

    try {
      const url = `${this.baseUrl}?function=SYMBOL_SEARCH&keywords=${encodeURIComponent(query)}&apikey=${this.apiKey}`;
      const data = await this.rateLimitedRequest(url);
      
      if (data['bestMatches']) {
        return data['bestMatches'].slice(0, 10).map((match: any) => ({
          symbol: match['1. symbol'],
          name: match['2. name'],
          type: match['3. type'],
          region: match['4. region'],
          marketOpen: match['5. marketOpen'],
          marketClose: match['6. marketClose'],
          timezone: match['7. timezone'],
          currency: match['8. currency'],
          matchScore: parseFloat(match['9. matchScore']),
        }));
      }
      
      return [];
    } catch (error) {
      console.error(`[ALPHA_VANTAGE] Search failed for query "${query}":`, error);
      throw error;
    }
  }

  isConfigured(): boolean {
    return !!this.apiKey;
  }

  // Check rate limit status
  async checkRateLimit(): Promise<{ available: number; used: number; limit: number }> {
    // For free tier: 25 requests per day
    const limit = 25;
    const used = this.cache.size; // Rough estimate based on cache entries
    const available = Math.max(0, limit - used);
    
    return {
      available,
      used,
      limit
    };
  }

  /**
   * Pre-warm cache with popular tech stocks to improve performance
   */
  async preWarmCache(): Promise<void> {
    if (!this.apiKey || this.isPreWarmingCache) {
      return;
    }

    console.log('[ALPHA_VANTAGE] Starting cache pre-warming for top tech stocks...');
    this.isPreWarmingCache = true;
    
    let successCount = 0;
    let skipCount = 0;

    try {
      for (const symbol of TOP_TECH_STOCKS) {
        try {
          // Check if already cached in database first
          const { pool } = await import('../db');
          const result = await pool.query(`
            SELECT symbol FROM stock_cache 
            WHERE symbol = $1 AND expires_at > CURRENT_TIMESTAMP
          `, [symbol]);
          
          if (result.rows.length > 0) {
            skipCount++;
            continue; // Already cached, skip
          }

          // Fetch and cache the stock quote
          await this.getStockQuote(symbol);
          successCount++;
          
          // Respect rate limits - only cache a few per session to avoid hitting limits
          if (successCount >= 5) {
            console.log(`[ALPHA_VANTAGE] Cache pre-warming paused after ${successCount} new stocks to respect rate limits`);
            break;
          }
        } catch (error) {
          console.warn(`[ALPHA_VANTAGE] Failed to pre-warm cache for ${symbol}:`, error);
        }
      }

      console.log(`[ALPHA_VANTAGE] Cache pre-warming completed: ${successCount} new, ${skipCount} already cached`);
    } catch (error) {
      console.error('[ALPHA_VANTAGE] Cache pre-warming failed:', error);
    } finally {
      this.isPreWarmingCache = false;
    }
  }

  /**
   * Check if a stock is likely to be cached (popular tech stock)
   */
  isPopularStock(symbol: string): boolean {
    return TOP_TECH_STOCKS.includes(symbol.toUpperCase());
  }
}

export const alphaVantageService = new AlphaVantageService();