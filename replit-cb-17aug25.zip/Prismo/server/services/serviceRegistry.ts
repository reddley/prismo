/**
 * Service Registry and Initialization
 * Configures dependency injection container with all unified services
 */

import { serviceContainer } from './serviceContainer';
import { AiIntelligenceService } from './unified/aiIntelligenceService';
import { DataIntelligenceService } from './unified/dataIntelligenceService';
import { UserIntelligenceService } from './unified/userIntelligenceService';
import { CostIntelligenceService } from './unified/costIntelligenceService';
import { logger } from '../observability/logger';

// Import external dependencies
let modelRouter: any;
let storage: any;

// Initialize service dependencies
async function initializeDependencies() {
  try {
    // Import model router
    const { getModelRouter } = await import('./modelRouter');
    modelRouter = getModelRouter();
    
    // Import storage
    const storageModule = await import('../storage');
    storage = storageModule.storage;
    
    logger.info('Service dependencies initialized successfully');
  } catch (error) {
    logger.error('Failed to initialize service dependencies', {
      error: error instanceof Error ? error.message : 'Unknown error'
    });
    throw error;
  }
}

// Register all services in the container
async function registerServices() {
  try {
    await initializeDependencies();

    // Register Cost Intelligence Service (no dependencies)
    serviceContainer.register(
      'costIntelligence',
      () => new CostIntelligenceService(),
      true
    );

    // Register AI Intelligence Service (depends on model router and cost service)
    serviceContainer.register(
      'aiIntelligence',
      () => new AiIntelligenceService(
        modelRouter,
        serviceContainer.get('costIntelligence')
      ),
      true
    );

    // Register Data Intelligence Service (depends on AI service and storage)
    serviceContainer.register(
      'dataIntelligence',
      () => new DataIntelligenceService(
        serviceContainer.get('aiIntelligence'),
        storage
      ),
      true
    );

    // Register User Intelligence Service (depends on storage)
    serviceContainer.register(
      'userIntelligence',
      () => new UserIntelligenceService(storage),
      true
    );

    // Register legacy service aliases for backward compatibility
    serviceContainer.register(
      'entityService',
      () => serviceContainer.get('dataIntelligence'),
      true
    );

    serviceContainer.register(
      'dataEnrichmentService',
      () => serviceContainer.get('dataIntelligence'),
      true
    );

    serviceContainer.register(
      'specsLearningService',
      () => serviceContainer.get('userIntelligence'),
      true
    );

    serviceContainer.register(
      'intelligentAlertsService',
      () => serviceContainer.get('userIntelligence'),
      true
    );

    serviceContainer.register(
      'costTrackingService',
      () => serviceContainer.get('costIntelligence'),
      true
    );

    logger.info('All services registered successfully in container');
  } catch (error) {
    logger.error('Failed to register services', {
      error: error instanceof Error ? error.message : 'Unknown error'
    });
    throw error;
  }
}

// Initialize the service registry
export async function initializeServiceRegistry() {
  try {
    await registerServices();
    
    // Validate all services can be instantiated
    const serviceNames = [
      'aiIntelligence',
      'dataIntelligence', 
      'userIntelligence',
      'costIntelligence'
    ];

    for (const serviceName of serviceNames) {
      const service = serviceContainer.get(serviceName);
      if (!service) {
        throw new Error(`Failed to instantiate service: ${serviceName}`);
      }
    }

    logger.info('Service registry initialized and validated successfully');
  } catch (error) {
    logger.error('Failed to initialize service registry', {
      error: error instanceof Error ? error.message : 'Unknown error'
    });
    throw error;
  }
}

// Export service getter functions for easy access
export function getAiIntelligenceService() {
  return serviceContainer.get('aiIntelligence');
}

export function getDataIntelligenceService() {
  return serviceContainer.get('dataIntelligence');
}

export function getUserIntelligenceService() {
  return serviceContainer.get('userIntelligence');
}

export function getCostIntelligenceService() {
  return serviceContainer.get('costIntelligence');
}

// Legacy service getters for backward compatibility
export function getEntityService() {
  return serviceContainer.get('dataIntelligence');
}

export function getDataEnrichmentService() {
  return serviceContainer.get('dataIntelligence');
}

export function getSpecsLearningService() {
  return serviceContainer.get('userIntelligence');
}

export function getIntelligentAlertsService() {
  return serviceContainer.get('userIntelligence');
}

export function getCostTrackingService() {
  return serviceContainer.get('costIntelligence');
}

// Service health check
export async function checkServiceHealth(): Promise<{
  healthy: boolean;
  services: Record<string, { status: 'healthy' | 'unhealthy'; error?: string }>;
}> {
  const serviceNames = [
    'aiIntelligence',
    'dataIntelligence',
    'userIntelligence', 
    'costIntelligence'
  ];

  const serviceHealth: Record<string, { status: 'healthy' | 'unhealthy'; error?: string }> = {};
  let allHealthy = true;

  for (const serviceName of serviceNames) {
    try {
      const service = serviceContainer.get(serviceName);
      if (service) {
        serviceHealth[serviceName] = { status: 'healthy' };
      } else {
        serviceHealth[serviceName] = { status: 'unhealthy', error: 'Service not instantiated' };
        allHealthy = false;
      }
    } catch (error) {
      serviceHealth[serviceName] = { 
        status: 'unhealthy', 
        error: error instanceof Error ? error.message : 'Unknown error' 
      };
      allHealthy = false;
    }
  }

  return {
    healthy: allHealthy,
    services: serviceHealth
  };
}

// Export service container for advanced usage
export { serviceContainer };