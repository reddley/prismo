// Persistent Cost Tracking Service with Database Storage and CSV Export
import { db } from "../db";
import { costEntries, costSummaries, type InsertCostEntry, type InsertCostSummary, type CostEntry, type CostSummary } from "@shared/schema";
import { eq, sql, desc, gte, lte, and, sum } from "drizzle-orm";

export interface CostStats {
  dailyAiCalls: number;
  dailyAiCost: number;
  ruleBasedOperations: number;
  remainingBudget: number;
  remainingCalls: number;
  costSavings: number;
  totalCostAllTime: number;
  totalCallsAllTime: number;
}

export interface DetailedCostBreakdown {
  topModels: Array<{ model: string; calls: number; cost: number; percentage: number }>;
  topOperations: Array<{ operation: string; calls: number; cost: number; percentage: number }>;
  dailyTrend: Array<{ date: string; cost: number; calls: number }>;
  hourlyCosts: Array<{ hour: number; cost: number; calls: number }>;
}

class PersistentCostTrackingService {
  private readonly MAX_DAILY_COST = 5.00;
  private readonly MAX_DAILY_CALLS = 500;

  constructor() {
    // Initialize daily summary for today if it doesn't exist
    this.initializeTodaySummary();
  }

  private async initializeTodaySummary(): Promise<void> {
    const today = new Date().toISOString().split('T')[0];
    
    try {
      const existingSummary = await db
        .select()
        .from(costSummaries)
        .where(eq(costSummaries.date, today))
        .limit(1);

      if (existingSummary.length === 0) {
        await db.insert(costSummaries).values({
          date: today,
          totalCost: "0",
          totalCalls: 0,
          ruleBasedOperations: 0,
          costSavings: "0",
          topModels: [],
          topOperations: [],
        });
      }
    } catch (error) {
      console.error("Error initializing today's cost summary:", error);
    }
  }

  // Record a new cost entry with full details
  async recordCost({
    modelName,
    operation,
    inputTokens,
    outputTokens,
    cost,
    priority,
    success = true,
    metadata = {}
  }: {
    modelName: string;
    operation: string;
    inputTokens: number;
    outputTokens: number;
    cost: number;
    priority: string;
    success?: boolean;
    metadata?: Record<string, any>;
  }): Promise<void> {
    try {
      // Insert detailed cost entry
      await db.insert(costEntries).values({
        modelName,
        operation,
        inputTokens,
        outputTokens,
        cost: cost.toString(),
        priority,
        success,
        metadata,
      });

      // Update daily summary
      await this.updateDailySummary(cost, 1);
      
      console.log(`💰 Cost recorded: ${operation} with ${modelName} - $${cost.toFixed(6)}`);
    } catch (error) {
      console.error("Error recording cost entry:", error);
    }
  }

  // Record rule-based operation for cost savings tracking
  async recordRuleBasedOperation(operation: string, estimatedSavings: number = 0.001): Promise<void> {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      await db
        .update(costSummaries)
        .set({
          ruleBasedOperations: sql`${costSummaries.ruleBasedOperations} + 1`,
          costSavings: sql`${costSummaries.costSavings} + ${estimatedSavings}`,
          updatedAt: new Date(),
        })
        .where(eq(costSummaries.date, today));

      console.log(`💡 Rule-based ${operation} saved ~$${estimatedSavings.toFixed(4)}`);
    } catch (error) {
      console.error("Error recording rule-based operation:", error);
    }
  }

  private async updateDailySummary(cost: number, calls: number): Promise<void> {
    const today = new Date().toISOString().split('T')[0];
    
    try {
      await db
        .update(costSummaries)
        .set({
          totalCost: sql`${costSummaries.totalCost} + ${cost}`,
          totalCalls: sql`${costSummaries.totalCalls} + ${calls}`,
          updatedAt: new Date(),
        })
        .where(eq(costSummaries.date, today));

      // Update top models and operations aggregates
      await this.updateTopAggregates(today);
    } catch (error) {
      console.error("Error updating daily summary:", error);
    }
  }

  private async updateTopAggregates(date: string): Promise<void> {
    try {
      // Get top models for today
      const topModelsQuery = await db
        .select({
          model: costEntries.modelName,
          calls: sql<number>`count(*)`,
          cost: sql<number>`sum(${costEntries.cost}::numeric)`,
        })
        .from(costEntries)
        .where(
          and(
            gte(costEntries.timestamp, new Date(`${date}T00:00:00Z`)),
            lte(costEntries.timestamp, new Date(`${date}T23:59:59Z`))
          )
        )
        .groupBy(costEntries.modelName)
        .orderBy(desc(sql`sum(${costEntries.cost}::numeric)`))
        .limit(5);

      // Get top operations for today
      const topOperationsQuery = await db
        .select({
          operation: costEntries.operation,
          calls: sql<number>`count(*)`,
          cost: sql<number>`sum(${costEntries.cost}::numeric)`,
        })
        .from(costEntries)
        .where(
          and(
            gte(costEntries.timestamp, new Date(`${date}T00:00:00Z`)),
            lte(costEntries.timestamp, new Date(`${date}T23:59:59Z`))
          )
        )
        .groupBy(costEntries.operation)
        .orderBy(desc(sql`sum(${costEntries.cost}::numeric)`))
        .limit(5);

      // Update the summary with aggregated data
      await db
        .update(costSummaries)
        .set({
          topModels: topModelsQuery,
          topOperations: topOperationsQuery,
          updatedAt: new Date(),
        })
        .where(eq(costSummaries.date, date));
    } catch (error) {
      console.error("Error updating top aggregates:", error);
    }
  }

  // Get current cost statistics
  async getCostStats(): Promise<CostStats> {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      // Get today's summary
      const [todaySummary] = await db
        .select()
        .from(costSummaries)
        .where(eq(costSummaries.date, today))
        .limit(1);

      // Get all-time totals
      const allTimeTotals = await db
        .select({
          totalCost: sql<number>`sum(${costSummaries.totalCost}::numeric)`,
          totalCalls: sql<number>`sum(${costSummaries.totalCalls})`,
        })
        .from(costSummaries);

      const dailyCost = todaySummary ? parseFloat(todaySummary.totalCost) : 0;
      const dailyCalls = todaySummary ? todaySummary.totalCalls : 0;
      const ruleBasedOps = todaySummary ? todaySummary.ruleBasedOperations : 0;
      const costSavings = todaySummary ? parseFloat(todaySummary.costSavings) : 0;

      const totalCostAllTime = allTimeTotals[0]?.totalCost || 0;
      const totalCallsAllTime = allTimeTotals[0]?.totalCalls || 0;

      return {
        dailyAiCalls: dailyCalls,
        dailyAiCost: dailyCost,
        ruleBasedOperations: ruleBasedOps,
        remainingBudget: Math.max(0, this.MAX_DAILY_COST - dailyCost),
        remainingCalls: Math.max(0, this.MAX_DAILY_CALLS - dailyCalls),
        costSavings,
        totalCostAllTime,
        totalCallsAllTime,
      };
    } catch (error) {
      console.error("Error getting cost stats:", error);
      // Return default values on error
      return {
        dailyAiCalls: 0,
        dailyAiCost: 0,
        ruleBasedOperations: 0,
        remainingBudget: this.MAX_DAILY_COST,
        remainingCalls: this.MAX_DAILY_CALLS,
        costSavings: 0,
        totalCostAllTime: 0,
        totalCallsAllTime: 0,
      };
    }
  }

  // Get detailed cost breakdown for analytics
  async getDetailedBreakdown(days: number = 7): Promise<DetailedCostBreakdown> {
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      // Get daily trend
      const dailyTrend = await db
        .select({
          date: costSummaries.date,
          cost: sql<number>`${costSummaries.totalCost}::numeric`,
          calls: costSummaries.totalCalls,
        })
        .from(costSummaries)
        .where(gte(costSummaries.date, startDate.toISOString().split('T')[0]))
        .orderBy(costSummaries.date);

      // Get top models across the period
      const topModels = await db
        .select({
          model: costEntries.modelName,
          calls: sql<number>`count(*)`,
          cost: sql<number>`sum(${costEntries.cost}::numeric)`,
        })
        .from(costEntries)
        .where(gte(costEntries.timestamp, startDate))
        .groupBy(costEntries.modelName)
        .orderBy(desc(sql`sum(${costEntries.cost}::numeric)`))
        .limit(10);

      // Get top operations
      const topOperations = await db
        .select({
          operation: costEntries.operation,
          calls: sql<number>`count(*)`,
          cost: sql<number>`sum(${costEntries.cost}::numeric)`,
        })
        .from(costEntries)
        .where(gte(costEntries.timestamp, startDate))
        .groupBy(costEntries.operation)
        .orderBy(desc(sql`sum(${costEntries.cost}::numeric)`))
        .limit(10);

      // Calculate percentages
      const totalCost = topModels.reduce((sum, model) => sum + model.cost, 0);

      return {
        topModels: topModels.map(model => ({
          ...model,
          percentage: totalCost > 0 ? (model.cost / totalCost) * 100 : 0,
        })),
        topOperations: topOperations.map(op => ({
          ...op,
          percentage: totalCost > 0 ? (op.cost / totalCost) * 100 : 0,
        })),
        dailyTrend,
        hourlyCosts: [], // Can be implemented if needed
      };
    } catch (error) {
      console.error("Error getting detailed breakdown:", error);
      return {
        topModels: [],
        topOperations: [],
        dailyTrend: [],
        hourlyCosts: [],
      };
    }
  }

  // Export cost data to CSV format
  async exportCostHistoryCSV(startDate?: Date, endDate?: Date): Promise<string> {
    try {
      let whereCondition;
      if (startDate && endDate) {
        whereCondition = and(
          gte(costEntries.timestamp, startDate),
          lte(costEntries.timestamp, endDate)
        );
      } else if (startDate) {
        whereCondition = gte(costEntries.timestamp, startDate);
      }

      const entries = whereCondition 
        ? await db.select().from(costEntries).where(whereCondition).orderBy(desc(costEntries.timestamp))
        : await db.select().from(costEntries).orderBy(desc(costEntries.timestamp));



      // CSV Header
      const headers = [
        'Timestamp',
        'Model Name',
        'Operation',
        'Input Tokens',
        'Output Tokens', 
        'Cost (USD)',
        'Priority',
        'Success',
        'Metadata'
      ];

      // CSV Rows
      const rows = entries.map(entry => [
        entry.timestamp?.toISOString() || '',
        entry.modelName,
        entry.operation,
        entry.inputTokens.toString(),
        entry.outputTokens.toString(),
        entry.cost,
        entry.priority,
        entry.success.toString(),
        JSON.stringify(entry.metadata || {})
      ]);

      // Combine headers and rows
      const csvContent = [headers, ...rows]
        .map(row => row.map(field => `"${field.toString().replace(/"/g, '""')}"`).join(','))
        .join('\n');

      return csvContent;
    } catch (error) {
      console.error("Error exporting cost history:", error);
      return '';
    }
  }

  // Budget check for decision making
  async canAffordOperation(estimatedCost: number): Promise<{ canAfford: boolean; reason?: string }> {
    const stats = await this.getCostStats();
    
    if (stats.remainingBudget < estimatedCost) {
      return {
        canAfford: false,
        reason: `Daily budget exceeded. Remaining: $${stats.remainingBudget.toFixed(4)}, Required: $${estimatedCost.toFixed(4)}`
      };
    }

    if (stats.remainingCalls < 1) {
      return {
        canAfford: false,
        reason: `Daily call limit exceeded. Remaining calls: ${stats.remainingCalls}`
      };
    }

    return { canAfford: true };
  }

  // Clean up old entries (optional maintenance)
  async cleanupOldEntries(daysToKeep: number = 90): Promise<number> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      const result = await db
        .delete(costEntries)
        .where(lte(costEntries.timestamp, cutoffDate));

      console.log(`Cleaned up cost entries older than ${daysToKeep} days`);
      return 0; // Drizzle doesn't return affected row count by default
    } catch (error) {
      console.error("Error cleaning up old cost entries:", error);
      return 0;
    }
  }
}

// Export singleton instance
export const persistentCostTracker = new PersistentCostTrackingService();