import { db } from "../db";
import { insights, intelligentAlerts, userSpecs } from "@shared/schema";
import { eq, and, desc, gte, sql } from "drizzle-orm";
import { specsLearningService } from "./specsLearning";
import { IntelligentAlertsService } from "./intelligentAlerts";
import type { InsertIntelligentAlert } from "@shared/schema";

export class AutoAlertTriggerService {
  private intelligentAlertsService = new IntelligentAlertsService();

  // Check if a new insight should trigger alerts for any users
  async processInsightForAlerts(insightId: string): Promise<void> {
    try {
      // Get the insight
      const [insight] = await db
        .select()
        .from(insights)
        .where(eq(insights.id, insightId))
        .limit(1);

      if (!insight) {
        console.error("Insight not found:", insightId);
        return;
      }

      // Only process high-priority insights for auto-alerts
      if (insight.priority !== 'high' && insight.priority !== 'critical') {
        return;
      }

      console.log(`🔍 Checking if high-priority insight "${insight.title}" matches any user specs...`);

      // Get all active users with specs (for now using default user)
      const userId = "default-user";
      
      // Check if insight matches user specs
      const matchResult = await specsLearningService.checkInsightMatchesSpecs(userId, {
        id: insight.id,
        title: insight.title,
        content: insight.content || '',
        category: insight.category || undefined,
        tags: insight.tags || undefined,
        priority: insight.priority || 'medium'
      });

      if (matchResult.matches && matchResult.overallRelevance > 0.5) {
        console.log(`✅ Insight matches user specs with relevance ${matchResult.overallRelevance.toFixed(2)}`);
        console.log(`📍 Matched specs: ${matchResult.matchedSpecs.map(s => s.displayName).join(', ')}`);
        
        // Generate intelligent alert automatically
        await this.generateAutomaticAlert(userId, insight, matchResult);
        
        // Update spec activation timestamps
        await this.updateSpecActivations(matchResult.matchedSpecs);
      } else {
        console.log(`⏭️  Insight doesn't match user specs (relevance: ${matchResult.overallRelevance.toFixed(2)})`);
      }
    } catch (error) {
      console.error("Error processing insight for alerts:", error);
    }
  }

  // Generate an automatic alert when insight matches specs
  private async generateAutomaticAlert(
    userId: string, 
    insight: any, 
    matchResult: {
      matchedSpecs: Array<{
        specId: string;
        specType: string;
        displayName: string;
        matchStrength: number;
      }>;
      overallRelevance: number;
    }
  ): Promise<void> {
    try {
      // Create alert title that mentions the matched specs
      const specNames = matchResult.matchedSpecs.slice(0, 2).map(s => s.displayName);
      const alertTitle = `🎯 ${specNames.join(' & ')} Alert: ${insight.title}`;

      // Generate intelligent insight analysis
      const intelligentInsight = await this.generateInsightAnalysis(insight, matchResult);
      
      // Generate actionability advice
      const actionability = this.generateActionability(insight, matchResult);

      // Calculate alert priority based on insight priority and spec relevance
      const alertPriority = this.calculateAlertPriority(insight.priority, matchResult.overallRelevance);

      const alertData: InsertIntelligentAlert = {
        userId,
        title: alertTitle,
        insight: intelligentInsight,
        actionability,
        priority: alertPriority,
        confidence: Math.min(matchResult.overallRelevance + 0.2, 1.0),
        relevanceScore: matchResult.overallRelevance,
        triggerEntities: matchResult.matchedSpecs.map(spec => ({
          type: spec.specType,
          id: spec.specId
        })),
        relatedInsights: [insight.id],
        trendAnalysis: {
          patternType: "spec_match",
          strength: matchResult.overallRelevance,
          dataPoints: matchResult.matchedSpecs.length
        },
        marketContext: `This alert was automatically generated because the content strongly matches your interest in ${specNames.join(' and ')}.`,
        isRead: false,
        isArchived: false
      };

      // Save the alert
      await db.insert(intelligentAlerts).values(alertData);

      console.log(`🚨 Automatic alert generated: "${alertTitle}"`);
      console.log(`💡 Actionability: ${actionability.substring(0, 100)}...`);
      
      // TODO: Send real-time notification to user (email, in-app notification)
      await this.notifyUser(userId, alertData);

    } catch (error) {
      console.error("Error generating automatic alert:", error);
    }
  }

  // Generate intelligent analysis connecting the insight to user interests
  private async generateInsightAnalysis(insight: any, matchResult: any): Promise<string> {
    const specContext = matchResult.matchedSpecs
      .map((spec: any) => `your interest in ${spec.displayName}`)
      .join(' and ');

    // For now, use rule-based analysis to avoid costs
    return `This development is particularly relevant to ${specContext}. ` +
           `The ${insight.category || 'industry'} sector movement indicates potential shifts that align with your monitoring priorities. ` +
           `Key implications: ${insight.summary || insight.title}. ` +
           `This represents a ${insight.priority}-priority intelligence signal in your focus areas.`;
  }

  // Generate actionable advice
  private generateActionability(insight: any, matchResult: any): string {
    const specTypes = matchResult.matchedSpecs.map((s: any) => s.specType);
    
    if (specTypes.includes('company_tracking')) {
      return "Monitor related developments and consider strategic implications for your competitive positioning. Review if this affects partnership opportunities or competitive threats.";
    } else if (specTypes.includes('technology_interest')) {
      return "Evaluate how this technology trend affects your strategic roadmap. Consider implications for product development, technical partnerships, or investment opportunities.";
    } else if (specTypes.includes('industry_focus')) {
      return "Assess broader market implications and potential ripple effects across your industry vertical. Monitor for subsequent developments and stakeholder reactions.";
    } else {
      return "Review this development's strategic implications for your organization. Consider immediate and long-term impacts on your competitive landscape.";
    }
  }

  // Calculate alert priority based on insight priority and spec relevance
  private calculateAlertPriority(insightPriority: string, relevance: number): string {
    if (insightPriority === 'critical' && relevance > 0.8) {
      return 'critical';
    } else if (insightPriority === 'critical' || (insightPriority === 'high' && relevance > 0.7)) {
      return 'high';
    } else {
      return 'medium';
    }
  }

  // Update spec activation timestamps
  private async updateSpecActivations(matchedSpecs: Array<{ specId: string }>): Promise<void> {
    for (const spec of matchedSpecs) {
      try {
        await db
          .update(userSpecs)
          .set({ 
            lastActivated: new Date(),
            updatedAt: new Date()
          })
          .where(eq(userSpecs.id, spec.specId));
      } catch (error) {
        console.error("Error updating spec activation:", error);
      }
    }
  }

  // Send notification to user (placeholder for real implementation)
  private async notifyUser(userId: string, alert: InsertIntelligentAlert): Promise<void> {
    // TODO: Implement real-time notifications
    // - In-app notification via WebSocket
    // - Email notification via SendGrid
    // - Push notification for mobile
    
    console.log(`📧 Notification sent to user ${userId}: ${alert.title}`);
  }

  // Get recent automatic alerts for user
  async getRecentAutoAlerts(userId: string, hours: number = 24): Promise<Array<{
    id: string;
    title: string;
    createdAt: Date;
    priority: string;
  }>> {
    const cutoff = new Date(Date.now() - hours * 60 * 60 * 1000);
    
    const alerts = await db
      .select({
        id: intelligentAlerts.id,
        title: intelligentAlerts.title,
        createdAt: intelligentAlerts.createdAt,
        priority: intelligentAlerts.priority
      })
      .from(intelligentAlerts)
      .where(and(
        eq(intelligentAlerts.userId, userId),
        gte(intelligentAlerts.createdAt, cutoff)
      ))
      .orderBy(desc(intelligentAlerts.createdAt));

    return alerts.map(alert => ({
      ...alert,
      createdAt: alert.createdAt || new Date()
    }));
  }
}

export const autoAlertTriggerService = new AutoAlertTriggerService();