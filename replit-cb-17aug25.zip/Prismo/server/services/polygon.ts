import fetch from 'node-fetch';

export interface StockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  high: number;
  low: number;
  previousClose: number;
  lastUpdated: string;
}

interface PolygonTickerDetails {
  ticker: string;
  name: string;
  market_cap?: number;
  description?: string;
}

interface PolygonAggregateBar {
  T: string; // ticker
  v: number; // volume
  vw: number; // volume weighted average price
  o: number; // open
  c: number; // close
  h: number; // high
  l: number; // low
  t: number; // timestamp
  n: number; // number of transactions
}

interface PolygonPreviousClose {
  T: string; // ticker
  v: number; // volume
  vw: number; // volume weighted average price
  o: number; // open
  c: number; // close
  h: number; // high
  l: number; // low
  t: number; // timestamp
}

class PolygonService {
  private apiKey: string;
  private baseUrl = 'https://api.polygon.io';
  private cache = new Map<string, { data: StockQuote; timestamp: number }>();
  private searchCache = new Map<string, { data: any; timestamp: number }>();
  private cacheTtl = 5 * 60 * 1000; // 5 minutes cache for real-time data
  private searchCacheTtl = 30 * 60 * 1000; // 30 minutes cache for search results
  private lastSearchTime = 0;
  private minSearchInterval = 100; // Minimum 100ms between searches

  constructor() {
    this.apiKey = process.env.POLYGON_API_KEY || '';
    if (!this.apiKey) {
      console.warn('[POLYGON] API key not found. Stock market features will be disabled.');
    }
  }

  private async makeRequest(endpoint: string): Promise<any> {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url);
    
    if (!response.ok) {
      if (response.status === 429) {
        console.warn('[POLYGON] Rate limit exceeded');
        throw new Error('Rate limit exceeded');
      }
      throw new Error(`Polygon API error: ${response.status} ${response.statusText}`);
    }
    
    return response.json();
  }

  async getTickerDetails(symbol: string): Promise<{ name: string; marketCap?: number }> {
    try {
      const data = await this.makeRequest(`/v3/reference/tickers/${symbol}?apikey=${this.apiKey}`);
      return {
        name: data.results?.name || symbol,
        marketCap: data.results?.market_cap
      };
    } catch (error) {
      console.warn(`[POLYGON] Could not fetch details for ${symbol}:`, error);
      return { name: symbol };
    }
  }

  async getPreviousClose(symbol: string): Promise<PolygonPreviousClose | null> {
    try {
      const data = await this.makeRequest(`/v2/aggs/ticker/${symbol}/prev?adjusted=true&apikey=${this.apiKey}`);
      return data.results?.[0] || null;
    } catch (error) {
      console.warn(`[POLYGON] Could not fetch previous close for ${symbol}:`, error);
      return null;
    }
  }

  async getCurrentPrice(symbol: string): Promise<{ price: number; timestamp: number } | null> {
    try {
      // Get last trade
      const data = await this.makeRequest(`/v2/last/trade/${symbol}?apikey=${this.apiKey}`);
      if (data.results?.price) {
        return {
          price: data.results.price,
          timestamp: data.results.timeframe || Date.now()
        };
      }
      return null;
    } catch (error) {
      console.warn(`[POLYGON] Could not fetch current price for ${symbol}:`, error);
      return null;
    }
  }

  async getQuote(symbol: string): Promise<StockQuote | null> {
    if (!this.apiKey) {
      console.warn('[POLYGON] API key not configured');
      return null;
    }

    // Check cache first
    const cached = this.cache.get(symbol);
    if (cached && Date.now() - cached.timestamp < this.cacheTtl) {
      console.log(`[POLYGON] Serving cached data for ${symbol}`);
      return cached.data;
    }

    try {
      console.log(`[POLYGON] Fetching fresh data for ${symbol}`);
      
      // Get ticker details for name and market cap
      const details = await this.getTickerDetails(symbol);
      
      // Get previous close for baseline
      const prevClose = await this.getPreviousClose(symbol);
      if (!prevClose) {
        console.warn(`[POLYGON] No previous close data for ${symbol}`);
        return null;
      }

      // Get current price (fallback to previous close if not available)
      const current = await this.getCurrentPrice(symbol);
      const currentPrice = current?.price || prevClose.c;
      
      // Calculate changes
      const change = currentPrice - prevClose.c;
      const changePercent = (change / prevClose.c) * 100;

      const quote: StockQuote = {
        symbol,
        name: details.name,
        price: currentPrice,
        change,
        changePercent,
        volume: prevClose.v,
        marketCap: details.marketCap || 0,
        high: prevClose.h,
        low: prevClose.l,
        previousClose: prevClose.c,
        lastUpdated: new Date().toISOString().split('T')[0]
      };

      // Cache the result
      this.cache.set(symbol, {
        data: quote,
        timestamp: Date.now()
      });

      return quote;
    } catch (error) {
      console.error(`[POLYGON] Error fetching quote for ${symbol}:`, error);
      return null;
    }
  }

  async getQuotes(symbols: string[]): Promise<StockQuote[]> {
    if (!this.apiKey) {
      console.warn('[POLYGON] API key not configured');
      return [];
    }

    console.log(`[POLYGON] Fetching quotes for: ${symbols.join(', ')}`);
    const startTime = Date.now();
    
    // Process symbols in parallel for better performance
    const promises = symbols.map(symbol => this.getQuote(symbol));
    const results = await Promise.allSettled(promises);
    
    const quotes = results
      .filter((result): result is PromiseFulfilledResult<StockQuote | null> => 
        result.status === 'fulfilled' && result.value !== null)
      .map(result => result.value as StockQuote);

    const duration = Date.now() - startTime;
    console.log(`[POLYGON] Retrieved ${quotes.length}/${symbols.length} quotes in ${duration}ms`);
    
    return quotes;
  }

  // Search for tickers by company name or symbol
  async searchTickers(query: string, limit: number = 10): Promise<Array<{symbol: string, name: string, market?: string}>> {
    if (!this.apiKey) {
      console.warn('[POLYGON] API key not available for ticker search');
      return [];
    }

    const cacheKey = `search:${query.toLowerCase()}:${limit}`;
    const cached = this.searchCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.searchCacheTtl) {
      console.log(`[POLYGON] Using cached search results for: "${query}"`);
      return cached.data;
    }

    // Rate limiting: ensure minimum interval between searches
    const now = Date.now();
    const timeSinceLastSearch = now - this.lastSearchTime;
    if (timeSinceLastSearch < this.minSearchInterval) {
      const waitTime = this.minSearchInterval - timeSinceLastSearch;
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    this.lastSearchTime = Date.now();

    try {
      const url = `https://api.polygon.io/v3/reference/tickers?search=${encodeURIComponent(query)}&limit=${limit}&apikey=${this.apiKey}`;
      console.log(`[POLYGON] Searching tickers for: "${query}"`);
      
      const response = await fetch(url);
      if (!response.ok) {
        if (response.status === 429) {
          console.warn('[POLYGON] Rate limit exceeded for search, checking fallback');
          return this.getFallbackSearchResults(query);
        }
        throw new Error(`Polygon API error: ${response.status} ${response.statusText}`);
      }

      const data: any = await response.json();
      
      if (data.status !== 'OK' || !data.results) {
        console.warn('[POLYGON] No results found for search:', query);
        return [];
      }

      const results = data.results
        .filter((ticker: any) => ticker.market === 'stocks' && ticker.active === true)
        .map((ticker: any) => ({
          symbol: ticker.ticker,
          name: ticker.name,
          market: ticker.market
        }))
        .slice(0, limit);

      // Cache the search results
      this.searchCache.set(cacheKey, {
        data: results,
        timestamp: Date.now()
      });
      
      console.log(`[POLYGON] Found ${results.length} tickers for "${query}"`);
      return results;
    } catch (error) {
      console.error('[POLYGON] Error searching tickers:', error);
      return this.getFallbackSearchResults(query);
    }
  }

  // Fallback search results for common companies when API is rate limited
  private getFallbackSearchResults(query: string): Array<{symbol: string, name: string, market?: string}> {
    const fallbackStocks = [
      // Major US Tech Companies
      { symbol: 'AAPL', name: 'Apple Inc.' },
      { symbol: 'MSFT', name: 'Microsoft Corporation' },
      { symbol: 'GOOGL', name: 'Alphabet Inc.' },
      { symbol: 'AMZN', name: 'Amazon.com Inc.' },
      { symbol: 'TSLA', name: 'Tesla Inc.' },
      { symbol: 'META', name: 'Meta Platforms Inc.' },
      { symbol: 'NVDA', name: 'NVIDIA Corporation' },
      { symbol: 'NFLX', name: 'Netflix Inc.' },
      { symbol: 'CRM', name: 'Salesforce Inc.' },
      { symbol: 'ORCL', name: 'Oracle Corporation' },
      { symbol: 'INTC', name: 'Intel Corporation' },
      { symbol: 'AMD', name: 'Advanced Micro Devices Inc.' },
      { symbol: 'UBER', name: 'Uber Technologies Inc.' },
      { symbol: 'LYFT', name: 'Lyft Inc.' },
      { symbol: 'SNAP', name: 'Snap Inc.' },
      { symbol: 'SQ', name: 'Block Inc.' },
      { symbol: 'PYPL', name: 'PayPal Holdings Inc.' },
      
      // Major International Companies
      { symbol: 'TSM', name: 'Taiwan Semiconductor Manufacturing Company' },
      { symbol: 'ASML', name: 'ASML Holding N.V.' },
      { symbol: 'NVO', name: 'Novo Nordisk A/S' },
      { symbol: 'TM', name: 'Toyota Motor Corporation' },
      { symbol: 'SAP', name: 'SAP SE' },
      { symbol: 'BABA', name: 'Alibaba Group Holding Limited' },
      { symbol: 'JD', name: 'JD.com Inc.' },
      { symbol: 'NIO', name: 'NIO Inc.' },
      { symbol: 'LI', name: 'Li Auto Inc.' },
      { symbol: 'XPEV', name: 'XPeng Inc.' },
      { symbol: 'BIDU', name: 'Baidu Inc.' },
      
      // Financial & Traditional Companies  
      { symbol: 'JPM', name: 'JPMorgan Chase & Co.' },
      { symbol: 'BAC', name: 'Bank of America Corporation' },
      { symbol: 'WFC', name: 'Wells Fargo & Company' },
      { symbol: 'GS', name: 'The Goldman Sachs Group Inc.' },
      { symbol: 'MS', name: 'Morgan Stanley' },
      { symbol: 'V', name: 'Visa Inc.' },
      { symbol: 'MA', name: 'Mastercard Incorporated' },
      { symbol: 'JNJ', name: 'Johnson & Johnson' },
      { symbol: 'PG', name: 'The Procter & Gamble Company' },
      { symbol: 'KO', name: 'The Coca-Cola Company' }
    ];

    const queryLower = query.toLowerCase();
    const results = fallbackStocks.filter(stock => 
      stock.symbol.toLowerCase().includes(queryLower) ||
      stock.name.toLowerCase().includes(queryLower) ||
      // Handle common variations and partial matches
      (queryLower.includes('microsoft') && stock.symbol === 'MSFT') ||
      (queryLower.includes('apple') && stock.symbol === 'AAPL') ||
      (queryLower.includes('google') && stock.symbol === 'GOOGL') ||
      (queryLower.includes('amazon') && stock.symbol === 'AMZN') ||
      (queryLower.includes('tesla') && stock.symbol === 'TSLA') ||
      (queryLower.includes('facebook') && stock.symbol === 'META') ||
      (queryLower.includes('meta') && stock.symbol === 'META') ||
      (queryLower.includes('nvidia') && stock.symbol === 'NVDA') ||
      (queryLower.includes('netflix') && stock.symbol === 'NFLX') ||
      // International companies
      (queryLower.includes('taiwan semi') && stock.symbol === 'TSM') ||
      (queryLower.includes('tsmc') && stock.symbol === 'TSM') ||
      (queryLower.includes('asml') && stock.symbol === 'ASML') ||
      (queryLower.includes('toyota') && stock.symbol === 'TM') ||
      (queryLower.includes('alibaba') && stock.symbol === 'BABA') ||
      (queryLower.includes('baidu') && stock.symbol === 'BIDU') ||
      (queryLower.includes('nio') && stock.symbol === 'NIO') ||
      // Financial companies
      (queryLower.includes('jpmorgan') && stock.symbol === 'JPM') ||
      (queryLower.includes('jp morgan') && stock.symbol === 'JPM') ||
      (queryLower.includes('bank of america') && stock.symbol === 'BAC') ||
      (queryLower.includes('wells fargo') && stock.symbol === 'WFC') ||
      (queryLower.includes('goldman') && stock.symbol === 'GS') ||
      (queryLower.includes('morgan stanley') && stock.symbol === 'MS') ||
      (queryLower.includes('visa') && stock.symbol === 'V') ||
      (queryLower.includes('mastercard') && stock.symbol === 'MA') ||
      (queryLower.includes('johnson') && stock.symbol === 'JNJ') ||
      (queryLower.includes('coca cola') && stock.symbol === 'KO') ||
      (queryLower.includes('coca-cola') && stock.symbol === 'KO')
    );

    if (results.length > 0) {
      console.log(`[POLYGON] Using fallback results for "${query}": found ${results.length} matches`);
    }

    return results.map(stock => ({...stock, market: 'stocks'}));
  }

  // Clear cache if needed
  clearCache(): void {
    this.cache.clear();
    this.searchCache.clear();
    console.log('[POLYGON] Cache cleared');
  }

  // Get cache stats
  getCacheStats(): { size: number; keys: string[]; searchSize: number; searchKeys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys()),
      searchSize: this.searchCache.size,
      searchKeys: Array.from(this.searchCache.keys())
    };
  }
}

export const polygonService = new PolygonService();