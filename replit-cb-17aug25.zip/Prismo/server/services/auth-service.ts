import * as argon2 from 'argon2';
import { randomBytes } from 'crypto';
import { db } from '../db';
import { 
  users, 
  rateLimitAttempts, 
  securityAuditLog, 
  emailVerificationQueue,
  type User, 
  type InsertUser,
  type InsertRateLimitAttempts,
  type InsertSecurityAuditLog,
  type InsertEmailVerificationQueue
} from '@shared/schema';
import { eq, and, gte, lt } from 'drizzle-orm';

export interface SignupData {
  username: string;
  email: string;
  password: string;
  name?: string;
}

export interface LoginData {
  username: string;
  password: string;
}

export interface AuthContext {
  ipAddress: string;
  userAgent: string;
  sessionId?: string;
}

export interface RateLimitResult {
  allowed: boolean;
  resetTime?: Date;
  attemptsRemaining?: number;
  blockReason?: string;
}

export class AuthService {
  // Argon2 configuration for maximum security
  private readonly argonConfig = {
    type: argon2.argon2id,
    memoryCost: 2 ** 16, // 64 MB
    timeCost: 3,
    parallelism: 1,
  };

  // Rate limiting thresholds
  private readonly rateLimits = {
    signup: { maxAttempts: 3, windowMinutes: 60 }, // 3 signups per hour per IP/email
    login: { maxAttempts: 5, windowMinutes: 15 }, // 5 failed logins per 15 min
    passwordReset: { maxAttempts: 3, windowMinutes: 60 },
    emailVerification: { maxAttempts: 5, windowMinutes: 60 },
  };

  // Account lockout configuration
  private readonly lockoutConfig = {
    maxFailedAttempts: 5,
    lockoutDurationMinutes: 30,
    escalatingLockout: true, // Double lockout time on repeated failures
  };

  /**
   * Hash password using Argon2id
   */
  async hashPassword(password: string): Promise<string> {
    try {
      return await argon2.hash(password, this.argonConfig);
    } catch (error) {
      console.error('Password hashing failed:', error);
      throw new Error('Password processing failed');
    }
  }

  /**
   * Verify password against hash
   */
  async verifyPassword(hash: string, password: string): Promise<boolean> {
    try {
      return await argon2.verify(hash, password);
    } catch (error) {
      console.error('Password verification failed:', error);
      return false;
    }
  }

  /**
   * Generate secure random token
   */
  generateSecureToken(length: number = 32): string {
    return randomBytes(length).toString('hex');
  }

  /**
   * Check rate limiting for IP address or email
   */
  async checkRateLimit(
    identifier: string,
    identifierType: 'ip' | 'email',
    attemptType: 'signup' | 'login' | 'password_reset' | 'email_verification'
  ): Promise<RateLimitResult> {
    // Map password_reset to passwordReset for internal lookup
    const limitKey = attemptType === 'password_reset' ? 'passwordReset' : 
                     attemptType === 'email_verification' ? 'emailVerification' : attemptType;
    const limit = this.rateLimits[limitKey as keyof typeof this.rateLimits];
    const windowStart = new Date(Date.now() - limit.windowMinutes * 60 * 1000);

    // Get current rate limit record
    const [rateLimitRecord] = await db
      .select()
      .from(rateLimitAttempts)
      .where(
        and(
          eq(rateLimitAttempts.identifier, identifier),
          eq(rateLimitAttempts.identifierType, identifierType),
          eq(rateLimitAttempts.attemptType, attemptType),
          gte(rateLimitAttempts.resetAt, new Date())
        )
      )
      .limit(1);

    if (rateLimitRecord) {
      if (rateLimitRecord.blocked) {
        return {
          allowed: false,
          resetTime: rateLimitRecord.resetAt,
          blockReason: rateLimitRecord.blockReason || 'Rate limit exceeded',
        };
      }

      if ((rateLimitRecord.attemptCount || 0) >= limit.maxAttempts) {
        // Block the identifier
        await db
          .update(rateLimitAttempts)
          .set({
            blocked: true,
            blockReason: `Exceeded ${limit.maxAttempts} ${attemptType} attempts in ${limit.windowMinutes} minutes`,
            updatedAt: new Date(),
          })
          .where(eq(rateLimitAttempts.id, rateLimitRecord.id));

        return {
          allowed: false,
          resetTime: rateLimitRecord.resetAt,
          blockReason: `Rate limit exceeded: ${limit.maxAttempts} attempts in ${limit.windowMinutes} minutes`,
        };
      }

      return {
        allowed: true,
        attemptsRemaining: limit.maxAttempts - (rateLimitRecord.attemptCount || 0),
        resetTime: rateLimitRecord.resetAt,
      };
    }

    return {
      allowed: true,
      attemptsRemaining: limit.maxAttempts,
    };
  }

  /**
   * Record rate limit attempt
   */
  async recordRateLimit(
    identifier: string,
    identifierType: 'ip' | 'email',
    attemptType: 'signup' | 'login' | 'password_reset' | 'email_verification'
  ): Promise<void> {
    // Map password_reset to passwordReset for internal lookup
    const limitKey = attemptType === 'password_reset' ? 'passwordReset' : 
                     attemptType === 'email_verification' ? 'emailVerification' : attemptType;
    const limit = this.rateLimits[limitKey as keyof typeof this.rateLimits];
    const resetAt = new Date(Date.now() + limit.windowMinutes * 60 * 1000);

    // Try to update existing record first
    const [existingRecord] = await db
      .select()
      .from(rateLimitAttempts)
      .where(
        and(
          eq(rateLimitAttempts.identifier, identifier),
          eq(rateLimitAttempts.identifierType, identifierType),
          eq(rateLimitAttempts.attemptType, attemptType),
          gte(rateLimitAttempts.resetAt, new Date())
        )
      )
      .limit(1);

    if (existingRecord) {
      await db
        .update(rateLimitAttempts)
        .set({
          attemptCount: (existingRecord.attemptCount || 0) + 1,
          lastAttemptAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(rateLimitAttempts.id, existingRecord.id));
    } else {
      const rateLimitData: InsertRateLimitAttempts = {
        identifier,
        identifierType,
        attemptType,
        attemptCount: 1,
        lastAttemptAt: new Date(),
        resetAt,
      };
      await db.insert(rateLimitAttempts).values(rateLimitData);
    }
  }

  /**
   * Log security event
   */
  async logSecurityEvent(
    action: string,
    context: AuthContext,
    success: boolean,
    userId?: string,
    failureReason?: string,
    metadata?: any
  ): Promise<void> {
    const riskScore = this.calculateRiskScore(action, success, context, metadata);
    
    const auditData: InsertSecurityAuditLog = {
      userId,
      action,
      ipAddress: context.ipAddress,
      userAgent: context.userAgent,
      success,
      failureReason,
      sessionId: context.sessionId,
      metadata,
      riskScore,
      blocked: riskScore > 80, // Block high-risk events
    };

    await db.insert(securityAuditLog).values(auditData);
  }

  /**
   * Calculate risk score for security events
   */
  private calculateRiskScore(action: string, success: boolean, context: AuthContext, metadata?: any): number {
    let score = 0;

    // Base scores by action
    if (!success) score += 30; // Failed attempts are risky
    if (action === 'login' && !success) score += 20;
    if (action === 'signup') score += 10; // New signups have base risk

    // IP-based risk factors
    if (!context.ipAddress || context.ipAddress === '127.0.0.1') score += 15;
    
    // User agent risk factors
    if (!context.userAgent) score += 20;
    if (context.userAgent && (
      context.userAgent.includes('bot') || 
      context.userAgent.includes('crawler') ||
      context.userAgent.length < 20
    )) score += 25;

    // Metadata-based risk factors
    if (metadata?.suspiciousActivity) score += 40;
    if (metadata?.multipleFailedAttempts) score += 30;

    return Math.min(100, score);
  }

  /**
   * Check if user account is locked out
   */
  async isAccountLocked(userId: string): Promise<{ locked: boolean; unlockTime?: Date }> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user || !user.lockoutUntil) {
      return { locked: false };
    }

    if (user.lockoutUntil > new Date()) {
      return { locked: true, unlockTime: user.lockoutUntil };
    }

    // Lockout expired, clear it
    await db
      .update(users)
      .set({
        loginAttempts: 0,
        lockoutUntil: null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    return { locked: false };
  }

  /**
   * Handle failed login attempt
   */
  async handleFailedLogin(userId: string, context: AuthContext): Promise<void> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user) return;

    const newAttempts = (user.loginAttempts || 0) + 1;
    let lockoutUntil: Date | null = null;

    if (newAttempts >= this.lockoutConfig.maxFailedAttempts) {
      const lockoutMinutes = this.lockoutConfig.escalatingLockout && user.lockoutUntil
        ? this.lockoutConfig.lockoutDurationMinutes * 2 // Escalating lockout
        : this.lockoutConfig.lockoutDurationMinutes;
      
      lockoutUntil = new Date(Date.now() + lockoutMinutes * 60 * 1000);
    }

    await db
      .update(users)
      .set({
        loginAttempts: newAttempts,
        lockoutUntil,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    // Log security event
    await this.logSecurityEvent(
      'failed_login_attempt',
      context,
      false,
      userId,
      lockoutUntil ? 'Account locked due to multiple failed attempts' : 'Invalid credentials',
      { attemptCount: newAttempts, lockedOut: !!lockoutUntil }
    );
  }

  /**
   * Clear failed login attempts on successful login
   */
  async clearFailedAttempts(userId: string): Promise<void> {
    await db
      .update(users)
      .set({
        loginAttempts: 0,
        lockoutUntil: null,
        lastLoginAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  /**
   * Register user with email verification
   */
  async registerUser(signupData: SignupData, context: AuthContext): Promise<{ user: User; verificationToken: string }> {
    // Check rate limits
    const ipRateLimit = await this.checkRateLimit(context.ipAddress, 'ip', 'signup');
    const emailRateLimit = await this.checkRateLimit(signupData.email, 'email', 'signup');

    if (!ipRateLimit.allowed) {
      throw new Error(`IP rate limit exceeded. Try again after ${ipRateLimit.resetTime?.toLocaleString()}`);
    }

    if (!emailRateLimit.allowed) {
      throw new Error(`Email rate limit exceeded. Try again after ${emailRateLimit.resetTime?.toLocaleString()}`);
    }

    try {
      // Hash password
      const hashedPassword = await this.hashPassword(signupData.password);
      
      // Generate verification token
      const verificationToken = this.generateSecureToken();
      const verificationExpires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

      // Create user
      const userData: InsertUser = {
        username: signupData.username,
        email: signupData.email,
        password: hashedPassword,
        name: signupData.name,
        emailVerificationToken: verificationToken,
        emailVerificationExpires: verificationExpires,
        emailVerified: false,
      };

      const [user] = await db.insert(users).values(userData).returning();

      // Queue email verification
      const emailQueueData: InsertEmailVerificationQueue = {
        userId: user.id,
        email: user.email,
        token: verificationToken,
        expiresAt: verificationExpires,
        priority: 'normal',
      };
      await db.insert(emailVerificationQueue).values(emailQueueData);

      // Record rate limits
      await this.recordRateLimit(context.ipAddress, 'ip', 'signup');
      await this.recordRateLimit(signupData.email, 'email', 'signup');

      // Log security event
      await this.logSecurityEvent('signup', context, true, user.id, undefined, {
        email: signupData.email,
        username: signupData.username,
      });

      return { user, verificationToken };
    } catch (error) {
      // Log failed signup
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      await this.logSecurityEvent('signup', context, false, undefined, errorMessage, {
        email: signupData.email,
        username: signupData.username,
      });
      throw error;
    }
  }

  /**
   * Authenticate user login
   */
  async authenticateUser(loginData: LoginData, context: AuthContext): Promise<User> {
    // Check rate limits
    const ipRateLimit = await this.checkRateLimit(context.ipAddress, 'ip', 'login');
    
    if (!ipRateLimit.allowed) {
      throw new Error(`IP rate limit exceeded. Try again after ${ipRateLimit.resetTime?.toLocaleString()}`);
    }

    // Find user
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, loginData.username))
      .limit(1);

    if (!user) {
      await this.recordRateLimit(context.ipAddress, 'ip', 'login');
      await this.logSecurityEvent('login', context, false, undefined, 'User not found', {
        username: loginData.username,
      });
      throw new Error('Invalid credentials');
    }

    // Check account lockout
    const lockoutStatus = await this.isAccountLocked(user.id);
    if (lockoutStatus.locked) {
      throw new Error(`Account locked until ${lockoutStatus.unlockTime?.toLocaleString()}`);
    }

    // Verify password
    const passwordValid = await this.verifyPassword(user.password, loginData.password);
    
    if (!passwordValid) {
      await this.recordRateLimit(context.ipAddress, 'ip', 'login');
      await this.handleFailedLogin(user.id, context);
      throw new Error('Invalid credentials');
    }

    // Check email verification
    if (!user.emailVerified) {
      await this.logSecurityEvent('login', context, false, user.id, 'Email not verified');
      throw new Error('Email verification required. Please check your email.');
    }

    // Success - clear failed attempts and update login time
    await this.clearFailedAttempts(user.id);
    
    await this.logSecurityEvent('login', context, true, user.id, undefined, {
      username: user.username,
    });

    return user;
  }

  /**
   * Verify email with token
   */
  async verifyEmail(token: string, context: AuthContext): Promise<User> {
    // Find verification record
    const [verificationRecord] = await db
      .select()
      .from(emailVerificationQueue)
      .where(eq(emailVerificationQueue.token, token))
      .limit(1);

    if (!verificationRecord) {
      await this.logSecurityEvent('email_verification', context, false, undefined, 'Invalid token');
      throw new Error('Invalid verification token');
    }

    if (verificationRecord.expiresAt < new Date()) {
      await this.logSecurityEvent('email_verification', context, false, verificationRecord.userId, 'Token expired');
      throw new Error('Verification token expired');
    }

    // Update user as verified
    const [user] = await db
      .update(users)
      .set({
        emailVerified: true,
        emailVerificationToken: null,
        emailVerificationExpires: null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, verificationRecord.userId))
      .returning();

    // Update verification queue status
    await db
      .update(emailVerificationQueue)
      .set({
        status: 'delivered',
        updatedAt: new Date(),
      })
      .where(eq(emailVerificationQueue.id, verificationRecord.id));

    await this.logSecurityEvent('email_verification', context, true, user.id);

    return user;
  }
}

export const authService = new AuthService();