// Cost Optimization Service
// Implements strategies to minimize AI costs while maintaining functionality

import { persistentCostTracker } from './persistentCostTracking';

interface CostTracker {
  dailyAiCalls: number;
  dailyAiCost: number;
  ruleBasedOperations: number;
  lastReset: string;
}

class CostOptimizationService {
  private costTracker: CostTracker;
  private readonly MAX_DAILY_AI_CALLS = 500; // Configurable limit
  private readonly MAX_DAILY_COST = 5.00; // $5 daily limit

  constructor() {
    this.costTracker = this.loadCostTracker();
  }

  private loadCostTracker(): CostTracker {
    const today = new Date().toDateString();
    // In a real app, load from database
    return {
      dailyAiCalls: 0,
      dailyAiCost: 0,
      ruleBasedOperations: 0,
      lastReset: today
    };
  }

  private resetDailyTrackerIfNeeded(): void {
    const today = new Date().toDateString();
    if (this.costTracker.lastReset !== today) {
      this.costTracker = {
        dailyAiCalls: 0,
        dailyAiCost: 0,
        ruleBasedOperations: 0,
        lastReset: today
      };
    }
  }

  // Check if we should use AI or fall back to rule-based processing
  shouldUseAI(estimatedCost: number): boolean {
    this.resetDailyTrackerIfNeeded();
    
    if (this.costTracker.dailyAiCalls >= this.MAX_DAILY_AI_CALLS) {
      console.log(`Daily AI call limit reached (${this.MAX_DAILY_AI_CALLS})`);
      return false;
    }
    
    if (this.costTracker.dailyAiCost + estimatedCost > this.MAX_DAILY_COST) {
      console.log(`Daily cost limit would be exceeded ($${this.MAX_DAILY_COST})`);
      return false;
    }
    
    return true;
  }

  // Track AI usage
  trackAIUsage(actualCost: number): void {
    this.resetDailyTrackerIfNeeded();
    this.costTracker.dailyAiCalls++;
    this.costTracker.dailyAiCost += actualCost;
  }

  // Track rule-based operations (free)
  trackRuleBasedOperation(): void {
    this.resetDailyTrackerIfNeeded();
    this.costTracker.ruleBasedOperations++;
  }

  // Get current cost statistics
  getCostStats() {
    this.resetDailyTrackerIfNeeded();
    return {
      dailyAiCalls: this.costTracker.dailyAiCalls,
      dailyAiCost: this.costTracker.dailyAiCost,
      ruleBasedOperations: this.costTracker.ruleBasedOperations,
      remainingBudget: this.MAX_DAILY_COST - this.costTracker.dailyAiCost,
      remainingCalls: this.MAX_DAILY_AI_CALLS - this.costTracker.dailyAiCalls,
      costSavings: this.costTracker.ruleBasedOperations * 0.0001 // Estimated savings
    };
  }
}

export const costOptimizer = new CostOptimizationService();

// Cost estimation functions for different AI operations
export const AI_COSTS = {
  SENTIMENT_ANALYSIS: 0.0001,
  SUMMARIZATION: 0.0002, 
  CATEGORIZATION: 0.00005,
  ENTITY_EXTRACTION: 0.001,
  BRIEFING_GENERATION: 0.005
};

// Priority-based processing rules
export function shouldProcessWithAI(priority: string, operation: string): boolean {
  const estimatedCost = AI_COSTS[operation as keyof typeof AI_COSTS] || 0.0001;
  
  // Always use AI for critical items within budget
  if (priority === 'critical' && costOptimizer.shouldUseAI(estimatedCost)) {
    return true;
  }
  
  // Use AI for high priority items if we have budget
  if (priority === 'high' && costOptimizer.shouldUseAI(estimatedCost)) {
    return true;
  }
  
  // Skip AI for medium/low priority if we're running low on budget
  const stats = costOptimizer.getCostStats();
  if (stats.remainingBudget < 1.0) { // Save last $1 for critical items
    return false;
  }
  
  return costOptimizer.shouldUseAI(estimatedCost);
}

// Batch processing optimization
export function optimizeBatchSize(totalItems: number, priority: string): number {
  const stats = costOptimizer.getCostStats();
  
  // If we're low on budget, process smaller batches
  if (stats.remainingBudget < 2.0) {
    return Math.min(totalItems, 5);
  }
  
  // For critical priority, process larger batches
  if (priority === 'critical') {
    return Math.min(totalItems, 20);
  }
  
  return Math.min(totalItems, 10);
}