import { db } from "../db";
import { userSpecs, userInteractions, insights } from "@shared/schema";
import { eq, and, desc, sql, gte, inArray } from "drizzle-orm";
import type { InsertUserSpec, InsertUserInteraction } from "@shared/schema";

export class SpecsLearningService {
  // Track user interaction to learn preferences
  async trackInteraction(interaction: InsertUserInteraction): Promise<void> {
    try {
      await db.insert(userInteractions).values(interaction);
      
      // Analyze interaction to potentially update or create specs
      await this.analyzeInteractionForSpecs(interaction);
    } catch (error) {
      console.error("Error tracking user interaction:", error);
    }
  }

  // Analyze interaction and update/create specs accordingly
  private async analyzeInteractionForSpecs(interaction: InsertUserInteraction): Promise<void> {
    // Only learn from positive interactions (view, read, save, positive feedback)
    const positiveInteractions = ['view', 'read', 'save', 'share', 'feedback_positive'];
    if (!positiveInteractions.includes(interaction.interactionType)) {
      return;
    }

    // Extract learning signals from the interaction
    const learningSignals = this.extractLearningSignals(interaction);
    
    for (const signal of learningSignals) {
      await this.updateOrCreateSpec(interaction.userId, signal);
    }
  }

  // Extract potential specs from interaction data
  private extractLearningSignals(interaction: InsertUserInteraction): Array<{
    specType: string;
    specKey: string;
    displayName: string;
    keywords: string[];
    strength: number;
  }> {
    const signals: Array<{
      specType: string;
      specKey: string;
      displayName: string;
      keywords: string[];
      strength: number;
    }> = [];

    // Category interest
    if (interaction.category) {
      signals.push({
        specType: 'industry_focus',
        specKey: interaction.category.toLowerCase(),
        displayName: this.formatDisplayName(interaction.category),
        keywords: [interaction.category.toLowerCase()],
        strength: this.calculateInteractionStrength(interaction)
      });
    }

    // Keyword interests
    if (interaction.extractedKeywords && interaction.extractedKeywords.length > 0) {
      for (const keyword of interaction.extractedKeywords) {
        if (keyword.length > 3) { // Avoid short words
          signals.push({
            specType: 'technology_interest',
            specKey: keyword.toLowerCase(),
            displayName: this.formatDisplayName(keyword),
            keywords: [keyword.toLowerCase()],
            strength: this.calculateInteractionStrength(interaction) * 0.8 // Slightly lower for keywords
          });
        }
      }
    }

    // Entity interests (companies, people, organizations)
    if (interaction.extractedEntities && interaction.extractedEntities.length > 0) {
      for (const entity of interaction.extractedEntities) {
        signals.push({
          specType: 'company_tracking',
          specKey: entity.toLowerCase(),
          displayName: entity,
          keywords: [entity.toLowerCase()],
          strength: this.calculateInteractionStrength(interaction)
        });
      }
    }

    return signals;
  }

  // Calculate strength based on interaction type and dwell time
  private calculateInteractionStrength(interaction: InsertUserInteraction): number {
    let baseStrength = 0.3;

    switch (interaction.interactionType) {
      case 'view':
        baseStrength = 0.2;
        break;
      case 'read':
        baseStrength = 0.5;
        break;
      case 'save':
        baseStrength = 0.8;
        break;
      case 'share':
        baseStrength = 0.9;
        break;
      case 'feedback_positive':
        baseStrength = 1.0;
        break;
    }

    // Boost strength for high-priority content
    if (interaction.priority === 'high') {
      baseStrength *= 1.3;
    } else if (interaction.priority === 'critical') {
      baseStrength *= 1.5;
    }

    // Factor in dwell time for view interactions
    if (interaction.dwellTime && interaction.dwellTime > 30) {
      const dwellBoost = Math.min(interaction.dwellTime / 120, 2); // Max 2x boost for 2+ minutes
      baseStrength *= dwellBoost;
    }

    return Math.min(baseStrength, 1.0);
  }

  // Update existing spec or create new one
  private async updateOrCreateSpec(userId: string, signal: {
    specType: string;
    specKey: string;
    displayName: string;
    keywords: string[];
    strength: number;
  }): Promise<void> {
    try {
      // Check if spec already exists
      const existingSpec = await db
        .select()
        .from(userSpecs)
        .where(and(
          eq(userSpecs.userId, userId),
          eq(userSpecs.specType, signal.specType),
          eq(userSpecs.specKey, signal.specKey)
        ))
        .limit(1);

      if (existingSpec.length > 0) {
        // Update existing spec
        const spec = existingSpec[0];
        const newInteractionCount = spec.interactionCount + 1;
        const newStrength = Math.min(
          (spec.strength * spec.interactionCount + signal.strength) / newInteractionCount,
          1.0
        );
        const newConfidence = Math.min(spec.confidence + 0.1, 1.0);

        await db
          .update(userSpecs)
          .set({
            strength: newStrength,
            confidence: newConfidence,
            interactionCount: newInteractionCount,
            lastReinforced: new Date(),
            updatedAt: new Date(),
            // Merge keywords
            keywords: Array.from(new Set([
              ...(spec.keywords || []),
              ...signal.keywords
            ]))
          })
          .where(eq(userSpecs.id, spec.id));
      } else {
        // Create new spec
        const newSpec: InsertUserSpec = {
          userId,
          specType: signal.specType as any,
          specKey: signal.specKey,
          displayName: signal.displayName,
          strength: signal.strength,
          confidence: 0.5, // Start with medium confidence
          learnedFrom: 'interaction',
          interactionCount: 1,
          keywords: signal.keywords,
          isActive: true,
          showInProfile: signal.strength > 0.4, // Only show strong preferences in profile
        };

        await db.insert(userSpecs).values(newSpec);
      }
    } catch (error) {
      console.error("Error updating/creating spec:", error);
    }
  }

  // Format display name for profile tags
  private formatDisplayName(text: string): string {
    return text
      .split(/[-_\s]+/)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  // Get user's current specs for matching
  async getUserSpecs(userId: string): Promise<Array<{
    id: string;
    specType: string;
    specKey: string;
    displayName: string;
    strength: number;
    keywords: string[];
  }>> {
    const specs = await db
      .select()
      .from(userSpecs)
      .where(and(
        eq(userSpecs.userId, userId),
        eq(userSpecs.isActive, true)
      ))
      .orderBy(desc(userSpecs.strength));

    return specs.map(spec => ({
      id: spec.id,
      specType: spec.specType,
      specKey: spec.specKey,
      displayName: spec.displayName,
      strength: spec.strength,
      keywords: spec.keywords || []
    }));
  }

  // Check if insight matches user specs (for automatic alert triggering)
  async checkInsightMatchesSpecs(userId: string, insight: {
    id: string;
    title: string;
    content: string;
    category?: string;
    tags?: string[];
    priority: string;
  }): Promise<{
    matches: boolean;
    matchedSpecs: Array<{
      specId: string;
      specType: string;
      displayName: string;
      matchStrength: number;
    }>;
    overallRelevance: number;
  }> {
    const userSpecsList = await this.getUserSpecs(userId);
    const matchedSpecs: Array<{
      specId: string;
      specType: string;
      displayName: string;
      matchStrength: number;
    }> = [];

    for (const spec of userSpecsList) {
      const matchStrength = this.calculateSpecMatch(spec, insight);
      
      if (matchStrength > 0.3) { // Threshold for match
        matchedSpecs.push({
          specId: spec.id,
          specType: spec.specType,
          displayName: spec.displayName,
          matchStrength
        });
      }
    }

    const overallRelevance = matchedSpecs.length > 0 
      ? matchedSpecs.reduce((sum, match) => sum + match.matchStrength, 0) / matchedSpecs.length
      : 0;

    return {
      matches: matchedSpecs.length > 0 && overallRelevance > 0.4,
      matchedSpecs,
      overallRelevance
    };
  }

  // Calculate how well an insight matches a spec
  private calculateSpecMatch(spec: {
    specKey: string;
    keywords: string[];
    strength: number;
  }, insight: {
    title: string;
    content: string;
    category?: string;
    tags?: string[];
  }): number {
    const searchText = `${insight.title} ${insight.content} ${insight.category || ''} ${(insight.tags || []).join(' ')}`.toLowerCase();
    
    let matchScore = 0;
    
    // Direct spec key match
    if (searchText.includes(spec.specKey.toLowerCase())) {
      matchScore += 0.8 * spec.strength;
    }
    
    // Keyword matches
    const keywordMatches = (spec.keywords || []).filter(keyword => 
      searchText.includes(keyword.toLowerCase())
    );
    
    if (keywordMatches.length > 0) {
      matchScore += (keywordMatches.length / (spec.keywords?.length || 1)) * 0.6 * spec.strength;
    }
    
    return Math.min(matchScore, 1.0);
  }

  // Get profile tags for user display
  async getProfileTags(userId: string): Promise<Array<{
    id: string;
    displayName: string;
    specType: string;
    strength: number;
  }>> {
    const specs = await db
      .select({
        id: userSpecs.id,
        displayName: userSpecs.displayName,
        specType: userSpecs.specType,
        strength: userSpecs.strength
      })
      .from(userSpecs)
      .where(and(
        eq(userSpecs.userId, userId),
        eq(userSpecs.isActive, true),
        eq(userSpecs.showInProfile, true)
      ))
      .orderBy(desc(userSpecs.strength))
      .limit(10); // Show top 10 specs as profile tags

    return specs;
  }
}

export const specsLearningService = new SpecsLearningService();