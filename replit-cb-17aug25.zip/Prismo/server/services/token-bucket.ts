import { db } from "../db";
import { sql } from "drizzle-orm";

interface TokenBucketConfig {
  capacity: number;
  refillRate: number; // tokens per second
  refillInterval: number; // milliseconds
}

interface BucketState {
  tokens: number;
  lastRefill: number;
}

interface RateLimitConfig {
  // Per-tenant limits
  tenantApiCalls: TokenBucketConfig;
  tenantDataIngestion: TokenBucketConfig;
  tenantEmailSending: TokenBucketConfig;
  
  // Global system limits
  globalCriticalOps: TokenBucketConfig;
  globalNonCriticalOps: TokenBucketConfig;
  
  // Per-IP limits
  perIpAuth: TokenBucketConfig;
  perIpGeneral: TokenBucketConfig;
}

// Optimized rate limit configurations for high-performance systems
const RATE_LIMITS: RateLimitConfig = {
  // Tenant-specific limits (per team/user)
  tenantApiCalls: {
    capacity: 1000,     // 1000 requests burst
    refillRate: 10,     // 10 req/sec sustained
    refillInterval: 100 // refill every 100ms
  },
  tenantDataIngestion: {
    capacity: 100,      // 100 RSS feeds burst
    refillRate: 2,      // 2 feeds/sec sustained
    refillInterval: 500 // refill every 500ms
  },
  tenantEmailSending: {
    capacity: 50,       // 50 emails burst
    refillRate: 0.1,    // 1 email per 10 seconds
    refillInterval: 10000 // refill every 10s
  },
  
  // Global system protection
  globalCriticalOps: {
    capacity: 5000,     // High capacity for critical ops
    refillRate: 100,    // 100 ops/sec
    refillInterval: 100
  },
  globalNonCriticalOps: {
    capacity: 1000,     // Lower capacity for non-critical
    refillRate: 20,     // 20 ops/sec
    refillInterval: 100
  },
  
  // IP-based protection
  perIpAuth: {
    capacity: 20,       // 20 auth attempts burst
    refillRate: 0.2,    // 1 attempt per 5 seconds
    refillInterval: 5000
  },
  perIpGeneral: {
    capacity: 200,      // 200 requests burst
    refillRate: 5,      // 5 req/sec sustained
    refillInterval: 200
  }
};

export class TokenBucketRateLimiter {
  private buckets = new Map<string, BucketState>();
  private config: RateLimitConfig;

  constructor() {
    this.config = RATE_LIMITS;
    
    // Clean up old buckets every 5 minutes
    setInterval(() => this.cleanupOldBuckets(), 5 * 60 * 1000);
  }

  /**
   * Check if operation is allowed and consume tokens
   * @param key - Unique identifier (tenant:operation, ip:operation, global:operation)
   * @param operation - Type of operation for rate limit lookup
   * @param tokens - Number of tokens to consume (default: 1)
   * @returns {allowed: boolean, retryAfter?: number, remaining?: number}
   */
  async checkRateLimit(
    key: string, 
    operation: keyof RateLimitConfig, 
    tokens: number = 1
  ): Promise<{
    allowed: boolean;
    retryAfter?: number;
    remaining?: number;
    resetTime?: number;
  }> {
    const config = this.config[operation];
    if (!config) {
      throw new Error(`Unknown operation: ${operation}`);
    }

    const bucket = this.getBucket(key, config);
    const now = Date.now();

    // Refill tokens based on time elapsed
    this.refillBucket(bucket, config, now);

    // Check if enough tokens available
    if (bucket.tokens >= tokens) {
      bucket.tokens -= tokens;
      
      return {
        allowed: true,
        remaining: Math.floor(bucket.tokens),
        resetTime: now + (config.capacity - bucket.tokens) * (config.refillInterval / config.refillRate)
      };
    }

    // Calculate retry-after in seconds
    const tokensNeeded = tokens - bucket.tokens;
    const retryAfterMs = tokensNeeded * (config.refillInterval / config.refillRate);
    
    return {
      allowed: false,
      retryAfter: Math.ceil(retryAfterMs / 1000),
      remaining: Math.floor(bucket.tokens),
      resetTime: now + retryAfterMs
    };
  }

  /**
   * Get current bucket state without consuming tokens
   */
  getBucketStatus(key: string, operation: keyof RateLimitConfig): {
    tokens: number;
    capacity: number;
    refillRate: number;
    nextRefill: number;
  } {
    const config = this.config[operation];
    const bucket = this.getBucket(key, config);
    const now = Date.now();
    
    this.refillBucket(bucket, config, now);
    
    return {
      tokens: Math.floor(bucket.tokens),
      capacity: config.capacity,
      refillRate: config.refillRate,
      nextRefill: bucket.lastRefill + config.refillInterval
    };
  }

  /**
   * Reset bucket for testing or emergency situations
   */
  resetBucket(key: string): void {
    this.buckets.delete(key);
  }

  private getBucket(key: string, config: TokenBucketConfig): BucketState {
    let bucket = this.buckets.get(key);
    
    if (!bucket) {
      bucket = {
        tokens: config.capacity,
        lastRefill: Date.now()
      };
      this.buckets.set(key, bucket);
    }
    
    return bucket;
  }

  private refillBucket(bucket: BucketState, config: TokenBucketConfig, now: number): void {
    const timeSinceLastRefill = now - bucket.lastRefill;
    
    if (timeSinceLastRefill >= config.refillInterval) {
      const intervalsElapsed = Math.floor(timeSinceLastRefill / config.refillInterval);
      const tokensToAdd = intervalsElapsed * config.refillRate;
      
      bucket.tokens = Math.min(config.capacity, bucket.tokens + tokensToAdd);
      bucket.lastRefill = now;
    }
  }

  private cleanupOldBuckets(): void {
    const now = Date.now();
    const maxAge = 30 * 60 * 1000; // 30 minutes
    
    Array.from(this.buckets.entries()).forEach(([key, bucket]) => {
      if (now - bucket.lastRefill > maxAge) {
        this.buckets.delete(key);
      }
    });
  }

  /**
   * Get metrics for monitoring
   */
  getMetrics(): {
    totalBuckets: number;
    bucketsPerOperation: Record<string, number>;
    memoryUsage: number;
  } {
    return this.getStats();
  }

  /**
   * Get detailed statistics for monitoring
   */
  getStats(): {
    totalBuckets: number;
    bucketsPerOperation: Record<string, number>;
    memoryUsage: number;
  } {
    const bucketsPerOperation: Record<string, number> = {};
    
    Array.from(this.buckets.keys()).forEach(key => {
      const operation = key.split(':')[1] || 'unknown';
      bucketsPerOperation[operation] = (bucketsPerOperation[operation] || 0) + 1;
    });
    
    return {
      totalBuckets: this.buckets.size,
      bucketsPerOperation,
      memoryUsage: this.buckets.size * 64 // approximate bytes per bucket
    };
  }
}

// Singleton instance
export const rateLimiter = new TokenBucketRateLimiter();

/**
 * Helper function to generate rate limit keys
 */
export const RateLimitKeys = {
  // Tenant-based keys
  tenantApi: (tenantId: string) => `tenant:${tenantId}:api`,
  tenantIngestion: (tenantId: string) => `tenant:${tenantId}:ingestion`,
  tenantEmail: (tenantId: string) => `tenant:${tenantId}:email`,
  
  // IP-based keys
  ipAuth: (ip: string) => `ip:${ip}:auth`,
  ipGeneral: (ip: string) => `ip:${ip}:general`,
  
  // Global keys
  globalCritical: () => 'global:critical',
  globalNonCritical: () => 'global:non-critical',
  
  // User-based keys (fallback when no tenant)
  userApi: (userId: string) => `user:${userId}:api`,
  userIngestion: (userId: string) => `user:${userId}:ingestion`,
  userEmail: (userId: string) => `user:${userId}:email`
};