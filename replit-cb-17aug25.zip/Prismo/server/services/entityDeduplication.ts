/**
 * Entity Deduplication Service
 * 
 * Handles entity deduplication using canonical names and identifiers.
 * Implements intelligent merging and conflict resolution.
 */

import { db } from '../db';
import { entities, entityIdentifiers, type Entity, type EntityIdentifier as DbEntityIdentifier } from '../../shared/schema';
import { EntityCanonicalizationService, IdentifierScheme, type EntityIdentifier } from './entityCanonicalization';
import { sql, eq, and, or } from 'drizzle-orm';
import { logger } from '../observability/logger';

export interface EntityMatchResult {
  entity: Entity;
  matchType: 'exact' | 'canonical' | 'identifier' | 'fuzzy';
  confidence: number;
  matchedBy?: {
    field?: string;
    value?: string;
    scheme?: IdentifierScheme;
  };
}

export interface EntityUpsertOptions {
  allowMerge?: boolean;
  confidenceThreshold?: number;
  identifiers?: EntityIdentifier[];
}

export class EntityDeduplicationService {
  private canonicalizationService: EntityCanonicalizationService;
  
  constructor() {
    this.canonicalizationService = new EntityCanonicalizationService();
  }
  
  /**
   * Find existing entities that match the given name and identifiers
   */
  async findMatches(
    name: string, 
    identifiers: EntityIdentifier[] = []
  ): Promise<EntityMatchResult[]> {
    const canonicalized = this.canonicalizationService.canonicalizeName(name);
    const matches: EntityMatchResult[] = [];
    
    // 1. Exact name match
    const exactMatches = await db.select()
      .from(entities)
      .where(eq(entities.name, name))
      .limit(5);
    
    for (const entity of exactMatches) {
      matches.push({
        entity,
        matchType: 'exact',
        confidence: 1.0,
        matchedBy: { field: 'name', value: name }
      });
    }
    
    // 2. Canonical name match
    if (matches.length === 0) {
      const canonicalMatches = await db.select()
        .from(entities)
        .where(eq(entities.canonicalName, canonicalized.canonicalName))
        .limit(5);
      
      for (const entity of canonicalMatches) {
        matches.push({
          entity,
          matchType: 'canonical',
          confidence: 0.95,
          matchedBy: { field: 'canonicalName', value: canonicalized.canonicalName }
        });
      }
    }
    
    // 3. Identifier matches
    if (identifiers.length > 0) {
      const identifierMatches = await this.findByIdentifiers(identifiers);
      matches.push(...identifierMatches);
    }
    
    // 4. Fuzzy matching using trigram similarity (if no strong matches)
    if (matches.length === 0) {
      const fuzzyMatches = await this.findFuzzyMatches(canonicalized.canonicalName);
      matches.push(...fuzzyMatches);
    }
    
    // Deduplicate and sort by confidence
    const uniqueMatches = this.deduplicateMatches(matches);
    return uniqueMatches.sort((a, b) => b.confidence - a.confidence);
  }
  
  /**
   * Find entities by identifiers
   */
  private async findByIdentifiers(identifiers: EntityIdentifier[]): Promise<EntityMatchResult[]> {
    const matches: EntityMatchResult[] = [];
    
    for (const identifier of identifiers) {
      const normalized = this.canonicalizationService.normalizeIdentifier(
        identifier.scheme, 
        identifier.value
      );
      
      const identifierEntities = await db.select({
        entity: entities,
        identifier: entityIdentifiers
      })
      .from(entityIdentifiers)
      .innerJoin(entities, eq(entityIdentifiers.entityId, entities.id))
      .where(and(
        eq(entityIdentifiers.scheme, identifier.scheme),
        eq(entityIdentifiers.value, normalized)
      ))
      .limit(5);
      
      for (const result of identifierEntities) {
        matches.push({
          entity: result.entity,
          matchType: 'identifier',
          confidence: identifier.confidence,
          matchedBy: {
            scheme: identifier.scheme,
            value: identifier.value
          }
        });
      }
    }
    
    return matches;
  }
  
  /**
   * Find fuzzy matches using trigram similarity
   */
  private async findFuzzyMatches(canonicalName: string): Promise<EntityMatchResult[]> {
    if (canonicalName.length < 3) {
      return [];
    }
    
    try {
      // Use pg_trgm for fuzzy matching with similarity threshold
      const results = await db.execute(sql`
        SELECT *, similarity(canonical_name, ${canonicalName}) as sim_score
        FROM entities 
        WHERE canonical_name % ${canonicalName}
          AND similarity(canonical_name, ${canonicalName}) > 0.3
        ORDER BY sim_score DESC
        LIMIT 5
      `);
      
      const matches: EntityMatchResult[] = [];
      for (const row of results.rows as any[]) {
        matches.push({
          entity: {
            id: row.id,
            type: row.type,
            name: row.name,
            canonicalName: row.canonical_name,
            description: row.description,
            status: row.status,
            confidence: row.confidence,
            source: row.source,
            createdAt: row.created_at,
            updatedAt: row.updated_at
          },
          matchType: 'fuzzy',
          confidence: parseFloat(row.sim_score) * 0.8, // Reduce confidence for fuzzy matches
          matchedBy: { field: 'canonicalName', value: canonicalName }
        });
      }
      
      return matches;
    } catch (error) {
      logger.error('Fuzzy matching failed', { error, canonicalName });
      return [];
    }
  }
  
  /**
   * Remove duplicate matches based on entity ID
   */
  private deduplicateMatches(matches: EntityMatchResult[]): EntityMatchResult[] {
    const seen = new Set<string>();
    const unique: EntityMatchResult[] = [];
    
    for (const match of matches) {
      if (!seen.has(match.entity.id)) {
        seen.add(match.entity.id);
        unique.push(match);
      }
    }
    
    return unique;
  }
  
  /**
   * Upsert an entity with deduplication logic
   */
  async upsertEntity(
    name: string,
    type: string,
    description?: string,
    options: EntityUpsertOptions = {}
  ): Promise<{ entity: Entity; wasCreated: boolean; mergedFrom?: string[] }> {
    const {
      allowMerge = true,
      confidenceThreshold = 0.8,
      identifiers = []
    } = options;
    
    const canonicalized = this.canonicalizationService.canonicalizeName(name);
    
    // Find potential matches
    const matches = await this.findMatches(name, identifiers);
    
    // Check for high-confidence matches
    const strongMatch = matches.find(m => m.confidence >= confidenceThreshold);
    
    if (strongMatch && allowMerge) {
      // Update existing entity
      const updatedEntity = await this.updateEntity(
        strongMatch.entity.id,
        { name, description },
        identifiers
      );
      
      logger.info('Entity deduplicated (updated existing)', {
        message: 'Entity deduplicated by updating existing record',
        entityId: updatedEntity.id,
        matchType: strongMatch.matchType,
        confidence: strongMatch.confidence
      });
      
      return { entity: updatedEntity, wasCreated: false };
    }
    
    // Create new entity
    const newEntity = await this.createEntity(
      name,
      type,
      canonicalized.canonicalName,
      description,
      identifiers
    );
    
    logger.info('Entity created (no strong match found)', {
      message: 'New entity created - no strong match found',
      entityId: newEntity.id,
      canonicalName: canonicalized.canonicalName,
      matchesFound: matches.length
    });
    
    return { entity: newEntity, wasCreated: true };
  }
  
  /**
   * Create a new entity with identifiers
   */
  private async createEntity(
    name: string,
    type: string,
    canonicalName: string,
    description?: string,
    identifiers: EntityIdentifier[] = []
  ): Promise<Entity> {
    const [entity] = await db.insert(entities).values({
      type,
      name,
      canonicalName,
      description,
      status: 'active',
      confidence: 1.0,
      source: 'system'
    }).returning();
    
    // Add identifiers
    if (identifiers.length > 0) {
      await this.addIdentifiers(entity.id, identifiers);
    }
    
    return entity;
  }
  
  /**
   * Update an existing entity
   */
  private async updateEntity(
    entityId: string,
    updates: { name?: string; description?: string },
    identifiers: EntityIdentifier[] = []
  ): Promise<Entity> {
    const updateData: any = { updatedAt: new Date() };
    
    if (updates.name) {
      const canonicalized = this.canonicalizationService.canonicalizeName(updates.name);
      updateData.name = updates.name;
      updateData.canonicalName = canonicalized.canonicalName;
    }
    
    if (updates.description) {
      updateData.description = updates.description;
    }
    
    const [entity] = await db.update(entities)
      .set(updateData)
      .where(eq(entities.id, entityId))
      .returning();
    
    // Add new identifiers (will be deduplicated by unique constraint)
    if (identifiers.length > 0) {
      await this.addIdentifiers(entityId, identifiers);
    }
    
    return entity;
  }
  
  /**
   * Add identifiers to an entity
   */
  async addIdentifiers(entityId: string, identifiers: EntityIdentifier[]): Promise<void> {
    const validIdentifiers = identifiers.filter(id => 
      this.canonicalizationService.validateIdentifier(id.scheme, id.value)
    );
    
    if (validIdentifiers.length === 0) {
      return;
    }
    
    const identifierRows = validIdentifiers.map(id => ({
      entityId,
      scheme: id.scheme,
      value: this.canonicalizationService.normalizeIdentifier(id.scheme, id.value),
      originalValue: id.value,
      confidence: id.confidence,
      source: 'system'
    }));
    
    try {
      // Insert identifiers one by one to handle conflicts gracefully
      for (const row of identifierRows) {
        try {
          await db.insert(entityIdentifiers).values({
            entityId: row.entityId,
            scheme: row.scheme,
            value: row.value,
            originalValue: row.originalValue,
            confidence: row.confidence,
            source: row.source,
            // Set type for backward compatibility
            type: row.scheme
          }).onConflictDoNothing({
            target: [entityIdentifiers.scheme, entityIdentifiers.value]
          });
        } catch (insertError) {
          // Log but continue with other identifiers
          logger.debug('Individual identifier insert failed', {
            entityId: row.entityId,
            scheme: row.scheme,
            error: insertError.message
          });
        }
      }
      
      logger.debug('Identifiers added', { 
        message: 'Entity identifiers added successfully',
        entityId, 
        count: identifierRows.length 
      });
    } catch (error) {
      logger.error('Failed to add identifiers', { 
        message: 'Failed to add entity identifiers',
        error: error.message, 
        entityId, 
        identifierCount: identifierRows.length 
      });
    }
  }
  
  /**
   * Merge multiple entities into one (for manual deduplication)
   */
  async mergeEntities(targetEntityId: string, sourceEntityIds: string[]): Promise<Entity> {
    return await db.transaction(async (tx) => {
      // Move all identifiers to target entity
      for (const sourceId of sourceEntityIds) {
        await tx.update(entityIdentifiers)
          .set({ entityId: targetEntityId })
          .where(eq(entityIdentifiers.entityId, sourceId));
      }
      
      // TODO: Move other related data (attributes, embeddings, edges, events)
      
      // Delete source entities
      await tx.delete(entities)
        .where(sql`${entities.id} = ANY(${sourceEntityIds})`);
      
      // Return updated target entity
      const [targetEntity] = await tx.select()
        .from(entities)
        .where(eq(entities.id, targetEntityId));
      
      logger.info('Entities merged', { 
        message: 'Multiple entities merged successfully',
        targetEntityId, 
        sourceEntityIds, 
        count: sourceEntityIds.length 
      });
      
      return targetEntity;
    });
  }
}