/**
 * Intelligent OpenAI Model Router
 * Automatically selects the optimal OpenAI model based on task requirements, cost considerations, and complexity
 */
import OpenAI from "openai";
import { persistentCostTracker } from "./persistentCostTracking";

// Model configurations with pricing (per 1M tokens) and capabilities - Updated August 14, 2025
export interface ModelConfig {
  name: string;
  inputPrice: number;   // Price per 1M input tokens
  outputPrice: number;  // Price per 1M output tokens
  contextWindow: number;
  capabilities: {
    reasoning: number;    // 1-10 scale
    speed: number;        // 1-10 scale (10 = fastest)
    multimodal: boolean;
    longContext: boolean;
    costEfficient: number; // 1-10 scale (10 = most efficient)
    coding: number;       // 1-10 scale for coding tasks
  };
  bestFor: string[];
  releaseDate: string;
}

export const OPENAI_MODELS: Record<string, ModelConfig> = {
  // NEW GPT-5 Series - Released August 7, 2025 (Latest flagship models)
  "gpt-5": {
    name: "gpt-5",
    inputPrice: 1.25,
    outputPrice: 10.00,
    contextWindow: 128000,
    capabilities: {
      reasoning: 10,
      speed: 6,
      multimodal: true,
      longContext: false,
      costEfficient: 4,
      coding: 10
    },
    bestFor: ["coding", "agentic_tasks", "complex_reasoning", "frontend_development", "advanced_analysis"],
    releaseDate: "2025-08-07"
  },

  "gpt-5-mini": {
    name: "gpt-5-mini",
    inputPrice: 0.25,
    outputPrice: 2.00,
    contextWindow: 128000,
    capabilities: {
      reasoning: 8,
      speed: 8,
      multimodal: true,
      longContext: false,
      costEfficient: 8,
      coding: 9
    },
    bestFor: ["coding", "balanced_performance", "content_analysis", "moderate_complexity_tasks"],
    releaseDate: "2025-08-07"
  },

  "gpt-5-nano": {
    name: "gpt-5-nano",
    inputPrice: 0.05,
    outputPrice: 0.40,
    contextWindow: 128000,
    capabilities: {
      reasoning: 6,
      speed: 10,
      multimodal: false,
      longContext: false,
      costEfficient: 10,
      coding: 7
    },
    bestFor: ["simple_tasks", "classification", "high_volume_processing", "cost_optimization"],
    releaseDate: "2025-08-07"
  },

  // Enhanced Reasoning Models - Latest releases
  "o4-mini": {
    name: "o4-mini",
    inputPrice: 0.80, // Estimated based on positioning
    outputPrice: 4.00,
    contextWindow: 200000,
    capabilities: {
      reasoning: 10,
      speed: 7,
      multimodal: true,
      longContext: true,
      costEfficient: 7,
      coding: 8
    },
    bestFor: ["fast_reasoning", "cost_efficient_analysis", "multimodal_reasoning", "tool_access"],
    releaseDate: "2025-08-14"
  },

  "o3": {
    name: "o3",
    inputPrice: 0.40,
    outputPrice: 1.60,
    contextWindow: 200000,
    capabilities: {
      reasoning: 10,
      speed: 5,
      multimodal: true,
      longContext: true,
      costEfficient: 8,
      coding: 9
    },
    bestFor: ["deep_reasoning", "step_by_step_logic", "competitive_analysis", "market_intelligence"],
    releaseDate: "2025-08-14"
  },

  // GPT-4.1 Series - Coding-focused models (April 2025)
  "gpt-4.1": {
    name: "gpt-4.1",
    inputPrice: 2.00,
    outputPrice: 8.00,
    contextWindow: 1000000,
    capabilities: {
      reasoning: 8,
      speed: 6,
      multimodal: false,
      longContext: true,
      costEfficient: 5,
      coding: 9
    },
    bestFor: ["advanced_coding", "instruction_following", "long_context_analysis", "large_codebases"],
    releaseDate: "2025-04-14"
  },

  "gpt-4.1-mini": {
    name: "gpt-4.1-mini",
    inputPrice: 0.40,
    outputPrice: 1.60,
    contextWindow: 1000000,
    capabilities: {
      reasoning: 8,
      speed: 8,
      multimodal: false,
      longContext: true,
      costEfficient: 9,
      coding: 8
    },
    bestFor: ["coding", "content_analysis", "entity_extraction", "cost_efficient_reasoning"],
    releaseDate: "2025-04-14"
  },

  "gpt-4.1-nano": {
    name: "gpt-4.1-nano",
    inputPrice: 0.10,
    outputPrice: 0.40,
    contextWindow: 1000000,
    capabilities: {
      reasoning: 6,
      speed: 10,
      multimodal: false,
      longContext: true,
      costEfficient: 10,
      coding: 7
    },
    bestFor: ["simple_coding", "classification", "autocompletion", "high_volume_tasks"],
    releaseDate: "2025-04-14"
  },

  // Legacy models (still available but not recommended for new implementations)
  "gpt-4o": {
    name: "gpt-4o",
    inputPrice: 0.15,
    outputPrice: 0.60,
    contextWindow: 128000,
    capabilities: {
      reasoning: 7,
      speed: 7,
      multimodal: true,
      longContext: false,
      costEfficient: 7,
      coding: 6
    },
    bestFor: ["legacy_support", "multimodal_basic", "general_purpose"],
    releaseDate: "2024-05-13"
  },

  "gpt-4o-mini": {
    name: "gpt-4o-mini",
    inputPrice: 0.25,
    outputPrice: 1.25,
    contextWindow: 128000,
    capabilities: {
      reasoning: 6,
      speed: 9,
      multimodal: true,
      longContext: false,
      costEfficient: 8,
      coding: 5
    },
    bestFor: ["legacy_support", "basic_multimodal", "simple_classification"],
    releaseDate: "2024-07-18"
  },

  // Older reasoning models (kept for compatibility)
  "o1-mini": {
    name: "o1-mini",
    inputPrice: 3.00,
    outputPrice: 15.00,
    contextWindow: 128000,
    capabilities: {
      reasoning: 9,
      speed: 4,
      multimodal: false,
      longContext: false,
      costEfficient: 3,
      coding: 7
    },
    bestFor: ["legacy_reasoning", "complex_analysis", "research"],
    releaseDate: "2024-09-12"
  }
};

// Embedding models for vector operations - Updated August 2025
export const EMBEDDING_MODELS = {
  "text-embedding-3-small": {
    name: "text-embedding-3-small",
    price: 0.02, // per 1M tokens
    dimensions: 1536,
    bestFor: ["general_embedding", "similarity", "clustering", "cost_efficient"],
    releaseDate: "2024-01-25"
  },
  "text-embedding-3-large": {
    name: "text-embedding-3-large", 
    price: 0.13,
    dimensions: 3072,
    bestFor: ["high_accuracy_embedding", "multilingual", "complex_semantic_search"],
    releaseDate: "2024-01-25"
  }
};

// Task complexity definitions
export enum TaskType {
  // Simple tasks (rule-based preferred)
  SIMPLE_CLASSIFICATION = "simple_classification",
  KEYWORD_EXTRACTION = "keyword_extraction",
  BASIC_SENTIMENT = "basic_sentiment",
  
  // Medium complexity tasks
  CATEGORIZATION = "categorization", 
  SENTIMENT_ANALYSIS = "sentiment_analysis",
  SUMMARIZATION = "summarization",
  CONTENT_ANALYSIS = "content_analysis",
  
  // Complex tasks requiring reasoning
  ENTITY_EXTRACTION = "entity_extraction",
  STRATEGIC_ANALYSIS = "strategic_analysis", 
  COMPETITIVE_INTELLIGENCE = "competitive_intelligence",
  BRIEFING_GENERATION = "briefing_generation",
  DEEP_RESEARCH = "deep_research",
  
  // Specialized tasks
  EMBEDDING_GENERATION = "embedding_generation",
  MULTIMODAL_ANALYSIS = "multimodal_analysis",
  LONG_CONTEXT_ANALYSIS = "long_context_analysis",
  
  // New task types for GPT-5 series
  CODING_TASKS = "coding_tasks",
  AGENTIC_TASKS = "agentic_tasks",
  FRONTEND_DEVELOPMENT = "frontend_development",
  TOOL_USAGE = "tool_usage"
}

export interface TaskContext {
  type: TaskType;
  priority: "low" | "medium" | "high" | "critical";
  contentLength: number;
  budgetConstraint: "strict" | "moderate" | "flexible";
  qualityRequirement: "basic" | "good" | "high" | "premium";
  timeConstraint: "urgent" | "normal" | "flexible";
  isMultimodal?: boolean;
  requiresReasoning?: boolean;
}

export class ModelRouter {
  private openai: OpenAI;
  private dailyBudget: number;
  private currentSpend: number;

  constructor(apiKey: string, dailyBudget: number = 5.0) {
    this.openai = new OpenAI({ apiKey });
    this.dailyBudget = dailyBudget;
    this.currentSpend = 0;
  }

  /**
   * Select the optimal model based on task context and constraints
   */
  selectOptimalModel(context: TaskContext): ModelConfig {
    const remainingBudget = this.dailyBudget - this.currentSpend;
    const budgetRatio = remainingBudget / this.dailyBudget;
    
    // Filter models based on context requirements
    let candidateModels = Object.values(OPENAI_MODELS).filter(model => {
      // Check if model supports required capabilities
      if (context.isMultimodal && !model.capabilities.multimodal) return false;
      if (context.contentLength > model.contextWindow) return false;
      if (context.requiresReasoning && model.capabilities.reasoning < 7) return false;
      
      return true;
    });

    // Score models based on context
    const scoredModels = candidateModels.map(model => {
      let score = 0;
      
      // Task type alignment - Enhanced for new GPT-5 capabilities
      if (model.bestFor.includes(context.type) || 
          model.bestFor.some(use => context.type.includes(use))) {
        score += 30;
      }

      // Special scoring for coding and agentic tasks (GPT-5 series advantage)
      if ([TaskType.CODING_TASKS, TaskType.AGENTIC_TASKS, TaskType.FRONTEND_DEVELOPMENT].includes(context.type)) {
        score += model.capabilities.coding * 3;
      }

      // Budget constraint scoring
      if (context.budgetConstraint === "strict") {
        score += model.capabilities.costEfficient * 3;
      } else if (context.budgetConstraint === "moderate") {
        score += model.capabilities.costEfficient * 2;
      }

      // Quality requirement scoring
      if (context.qualityRequirement === "premium") {
        score += model.capabilities.reasoning * 2;
        // Boost new models for premium quality
        if (model.releaseDate >= "2025-04-01") {
          score += 15;
        }
      } else if (context.qualityRequirement === "high") {
        score += model.capabilities.reasoning * 1.5;
        // Slight boost for newer models
        if (model.releaseDate >= "2025-04-01") {
          score += 10;
        }
      }

      // Time constraint scoring
      if (context.timeConstraint === "urgent") {
        score += model.capabilities.speed * 2;
      }

      // Priority-based adjustments
      if (context.priority === "critical") {
        if (model.capabilities.reasoning >= 9) {
          score += 25;
        }
        // Prefer latest models for critical tasks
        if (model.releaseDate >= "2025-08-01") {
          score += 20;
        }
      } else if (context.priority === "low" && model.capabilities.costEfficient >= 8) {
        score += 15;
        // Prefer nano models for low priority
        if (model.name.includes("nano")) {
          score += 10;
        }
      }

      // Budget pressure adjustments
      if (budgetRatio < 0.2) { // Less than 20% budget remaining
        score += model.capabilities.costEfficient * 4;
        // Heavily favor nano models when budget is tight
        if (model.name.includes("nano")) {
          score += 20;
        }
      } else if (budgetRatio < 0.5) { // Less than 50% budget remaining  
        score += model.capabilities.costEfficient * 2;
        // Favor mini models for moderate budget pressure
        if (model.name.includes("mini")) {
          score += 10;
        }
      }

      // Penalize legacy models unless specifically needed
      if (model.releaseDate < "2025-01-01" && context.qualityRequirement !== "basic") {
        score -= 10;
      }

      return { model, score };
    });

    // Select the highest scoring model
    const bestModel = scoredModels.sort((a, b) => b.score - a.score)[0];
    
    if (!bestModel) {
      // Fallback to most cost-efficient new model
      return OPENAI_MODELS["gpt-5-nano"];
    }

    return bestModel.model;
  }

  /**
   * Select optimal embedding model
   */
  selectEmbeddingModel(context: { accuracy: "basic" | "high", budgetConstraint: "strict" | "flexible" }) {
    if (context.accuracy === "high" && context.budgetConstraint === "flexible") {
      return EMBEDDING_MODELS["text-embedding-3-large"];
    }
    return EMBEDDING_MODELS["text-embedding-3-small"];
  }

  /**
   * Estimate cost for a task
   */
  estimateCost(model: ModelConfig, inputTokens: number, outputTokens: number): number {
    return (inputTokens * model.inputPrice / 1000000) + (outputTokens * model.outputPrice / 1000000);
  }

  /**
   * Check if task should use AI or fall back to rule-based processing
   */
  shouldUseAI(context: TaskContext): { useAI: boolean, reason: string } {
    const remainingBudget = this.dailyBudget - this.currentSpend;
    
    // Always use AI for critical priority tasks
    if (context.priority === "critical") {
      return { useAI: true, reason: "Critical priority task - using latest AI models" };
    }

    // Always use AI for coding and agentic tasks (GPT-5 strength)
    if ([TaskType.CODING_TASKS, TaskType.AGENTIC_TASKS, TaskType.FRONTEND_DEVELOPMENT].includes(context.type)) {
      return { useAI: true, reason: "Coding/agentic task - leveraging GPT-5 capabilities" };
    }

    // Use rule-based for simple tasks when budget is tight, but with lower thresholds due to GPT-5-nano pricing
    if (remainingBudget < 0.5 && ["simple_classification", "basic_sentiment", "keyword_extraction"].includes(context.type)) {
      return { useAI: false, reason: "Low budget + simple task = rule-based processing" };
    }

    // Use rule-based for low priority tasks when budget is very tight
    if (remainingBudget < 0.25 && context.priority === "low") {
      return { useAI: false, reason: "Very low budget + low priority = rule-based processing" };
    }

    // Use AI more liberally due to improved cost efficiency of new models
    if (context.requiresReasoning || context.qualityRequirement === "premium") {
      return { useAI: true, reason: "Complex reasoning - using advanced models (o3/o4-mini/GPT-5)" };
    }

    // Lower budget threshold for AI usage due to GPT-5-nano cost efficiency
    if (remainingBudget > 0.5 && ["medium", "high"].includes(context.priority)) {
      return { useAI: true, reason: "Cost-efficient AI processing with latest models" };
    }

    // Even with tight budget, consider AI for medium-complexity tasks due to nano pricing
    if (remainingBudget > 0.25 && context.type !== "simple_classification") {
      return { useAI: true, reason: "GPT-5-nano cost efficiency enables AI for more tasks" };
    }

    return { useAI: false, reason: "Budget optimization - using rule-based processing" };
  }

  /**
   * Make an optimized API call with the best model for the task
   */
  async makeOptimizedCall(
    context: TaskContext,
    messages: any[],
    maxTokens: number = 500,
    temperature: number = 0.1
  ): Promise<{ response: any, model: string, cost: number }> {
    
    // Check if we should use AI at all
    const aiDecision = this.shouldUseAI(context);
    if (!aiDecision.useAI) {
      throw new Error(`Rule-based processing recommended: ${aiDecision.reason}`);
    }

    const model = this.selectOptimalModel(context);
    
    try {
      // Use max_completion_tokens for newer models (2025+), max_tokens for legacy models
      const modelDate = new Date(model.releaseDate);
      const cutoffDate = new Date("2025-01-01");
      const isNewerModel = modelDate >= cutoffDate;
      const tokenParam = isNewerModel ? "max_completion_tokens" : "max_tokens";
      
      // Some models only support default temperature (1.0)
      const supportsCustomTemperature = !["gpt-5-nano", "o3", "o4-mini", "gpt-4.1-mini", "gpt-4.1-nano"].includes(model.name);
      
      const requestParams: any = {
        model: model.name,
        messages,
        [tokenParam]: maxTokens,
        response_format: messages.some(m => m.content?.includes("JSON")) ? { type: "json_object" } : undefined,
      };
      
      // Only set custom temperature for models that support it
      if (supportsCustomTemperature) {
        requestParams.temperature = temperature;
      }

      const response = await this.openai.chat.completions.create(requestParams);

      // Estimate cost
      const inputTokens = messages.reduce((total, msg) => total + (msg.content?.length || 0) / 4, 0); // Rough token estimate
      const outputTokens = response.choices[0]?.message?.content?.length || 0 / 4;
      const cost = this.estimateCost(model, inputTokens, outputTokens);
      
      // Update spend tracking
      this.currentSpend += cost;

      // Record cost in persistent tracking
      await persistentCostTracker.recordCost({
        modelName: model.name,
        operation: context.type,
        inputTokens: Math.round(inputTokens),
        outputTokens: Math.round(outputTokens),
        cost,
        priority: context.priority,
        success: true,
        metadata: {
          budgetConstraint: context.budgetConstraint,
          qualityRequirement: context.qualityRequirement,
          reason: aiDecision.reason
        }
      });

      console.log(`Used ${model.name} (cost: ~$${cost.toFixed(6)}) - ${aiDecision.reason}`);

      return {
        response,
        model: model.name,
        cost
      };

    } catch (error) {
      console.error(`Failed to call ${model.name}:`, error);
      throw error;
    }
  }

  /**
   * Generate embeddings with optimal model selection
   */
  async generateEmbeddings(
    texts: string[],
    context: { accuracy: "basic" | "high", budgetConstraint: "strict" | "flexible" }
  ): Promise<{ embeddings: number[][], model: string, cost: number }> {
    
    const model = this.selectEmbeddingModel(context);
    
    try {
      const response = await this.openai.embeddings.create({
        input: texts,
        model: model.name,
        dimensions: context.accuracy === "basic" ? 1536 : undefined // Use full dimensions for high accuracy
      });

      const totalTokens = texts.reduce((sum, text) => sum + text.length / 4, 0);
      const cost = totalTokens * model.price / 1000000;
      this.currentSpend += cost;

      // Record embedding cost in persistent tracking
      await persistentCostTracker.recordCost({
        modelName: model.name,
        operation: "embedding_generation",
        inputTokens: Math.round(totalTokens),
        outputTokens: 0,
        cost,
        priority: context.budgetConstraint === "strict" ? "low" : "medium",
        success: true,
        metadata: {
          accuracy: context.accuracy,
          budgetConstraint: context.budgetConstraint,
          textCount: texts.length
        }
      });

      console.log(`Generated embeddings with ${model.name} (cost: ~$${cost.toFixed(6)})`);

      return {
        embeddings: response.data.map(d => d.embedding),
        model: model.name,
        cost
      };

    } catch (error) {
      console.error(`Failed to generate embeddings with ${model.name}:`, error);
      throw error;
    }
  }

  /**
   * Update current spend (called from cost tracking)
   */
  updateCurrentSpend(spend: number) {
    this.currentSpend = spend;
  }

  /**
   * Get model recommendation for a task without making the call
   */
  getModelRecommendation(context: TaskContext): {
    model: ModelConfig;
    shouldUseAI: boolean;
    estimatedCost: number;
    reasoning: string;
  } {
    const aiDecision = this.shouldUseAI(context);
    const model = this.selectOptimalModel(context);
    const estimatedTokens = Math.min(context.contentLength / 4, 1000); // Rough estimate
    const estimatedCost = this.estimateCost(model, estimatedTokens, 150);

    return {
      model,
      shouldUseAI: aiDecision.useAI,
      estimatedCost,
      reasoning: `${aiDecision.reason} | Selected ${model.name} for optimal balance of cost, quality, and speed.`
    };
  }
}

// Export singleton instance
let modelRouter: ModelRouter | null = null;

export function getModelRouter(): ModelRouter {
  if (!modelRouter) {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error("OPENAI_API_KEY environment variable is required");
    }
    modelRouter = new ModelRouter(process.env.OPENAI_API_KEY, 5.0); // $5 daily budget
  }
  return modelRouter;
}

// Helper function to create task context
export function createTaskContext(
  type: TaskType,
  options: Partial<TaskContext> = {}
): TaskContext {
  return {
    type,
    priority: options.priority || "medium",
    contentLength: options.contentLength || 500,
    budgetConstraint: options.budgetConstraint || "moderate",
    qualityRequirement: options.qualityRequirement || "good",
    timeConstraint: options.timeConstraint || "normal",
    isMultimodal: options.isMultimodal || false,
    requiresReasoning: options.requiresReasoning || false,
    ...options
  };
}