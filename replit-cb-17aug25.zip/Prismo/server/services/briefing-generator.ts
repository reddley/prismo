// Briefing generation service for creating AI-powered summaries
import { storage } from '../storage';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function generateBriefing(timeframe: string = '24h', filters?: {
  categories?: string[];
  priorities?: string[];
  sources?: string[];
}): Promise<{
  briefingId: string;
  insights: number;
  keyTrends: string[];
  summary: string;
}> {
  console.log(`[BRIEFING] Generating briefing for ${timeframe} with filters:`, filters);

  try {
    // Get insights for the timeframe
    const insights = await getInsightsForBriefing(timeframe, filters);
    
    if (insights.length === 0) {
      throw new Error('No insights found for briefing generation');
    }

    // Generate AI-powered briefing
    const briefingContent = await generateBriefingWithAI(insights, timeframe);
    
    // Save briefing to database
    const briefing = await storage.createBriefing({
      title: `${timeframe} Intelligence Briefing`,
      content: briefingContent.content,
      summary: briefingContent.summary,
      keyTrends: briefingContent.keyTrends,
      timeframe: timeframe,
      insightCount: insights.length,
      generatedAt: new Date(),
      filters: filters || {},
    });

    console.log(`[BRIEFING] Generated briefing ${briefing.id} with ${insights.length} insights`);
    
    return {
      briefingId: briefing.id,
      insights: insights.length,
      keyTrends: briefingContent.keyTrends,
      summary: briefingContent.summary,
    };

  } catch (error) {
    console.error('[BRIEFING] Failed to generate briefing:', error);
    throw error;
  }
}

async function getInsightsForBriefing(timeframe: string, filters?: any): Promise<any[]> {
  // Calculate time range
  const now = new Date();
  let startDate: Date;
  
  switch (timeframe) {
    case '1h':
      startDate = new Date(now.getTime() - 60 * 60 * 1000);
      break;
    case '6h':
      startDate = new Date(now.getTime() - 6 * 60 * 60 * 1000);
      break;
    case '24h':
      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      break;
    case '7d':
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      break;
    default:
      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  }

  // Get insights from storage
  return await storage.getInsightsForTimeframe(startDate, now, filters);
}

async function generateBriefingWithAI(insights: any[], timeframe: string): Promise<{
  content: string;
  summary: string;
  keyTrends: string[];
}> {
  // Prepare insights for AI analysis
  const insightSummaries = insights.slice(0, 50).map(insight => ({
    title: insight.title,
    category: insight.category,
    sentiment: insight.sentiment,
    priority: insight.priority,
    summary: insight.summary || insight.content.substring(0, 200),
  }));

  const prompt = `Generate an intelligence briefing based on these ${insights.length} insights from the last ${timeframe}:

${JSON.stringify(insightSummaries, null, 2)}

Provide:
1. Executive summary (2-3 sentences)
2. Key trends (3-5 bullet points)  
3. Detailed briefing content (organized by category, 3-4 paragraphs)

Focus on:
- Most important developments
- Emerging patterns and trends
- High-priority items
- Market implications

Format as JSON with keys: summary, keyTrends (array), content`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 1500,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      content: result.content || generateFallbackBriefing(insights, timeframe),
      summary: result.summary || `Intelligence briefing covering ${insights.length} insights from the last ${timeframe}.`,
      keyTrends: Array.isArray(result.keyTrends) ? result.keyTrends : [],
    };

  } catch (error) {
    console.error('[BRIEFING] AI generation failed, using fallback:', error);
    
    // Fallback briefing generation
    return {
      content: generateFallbackBriefing(insights, timeframe),
      summary: `Intelligence briefing covering ${insights.length} insights from the last ${timeframe}.`,
      keyTrends: extractKeyTrendsFromInsights(insights),
    };
  }
}

function generateFallbackBriefing(insights: any[], timeframe: string): string {
  const categories = groupInsightsByCategory(insights);
  
  let content = `# Intelligence Briefing - Last ${timeframe}\n\n`;
  content += `This briefing covers ${insights.length} insights collected over the past ${timeframe}.\n\n`;
  
  // Summary by category
  for (const [category, categoryInsights] of Object.entries(categories)) {
    if (Array.isArray(categoryInsights) && categoryInsights.length > 0) {
      content += `## ${category} (${categoryInsights.length} insights)\n\n`;
      
      // High priority items first
      const highPriority = categoryInsights.filter(i => i.priority === 'high' || i.priority === 'critical');
      if (highPriority.length > 0) {
        content += `**High Priority Items:**\n`;
        highPriority.slice(0, 3).forEach(insight => {
          content += `- ${insight.title}\n`;
        });
        content += '\n';
      }
      
      // Sentiment overview
      const positive = categoryInsights.filter(i => i.sentiment === 'positive').length;
      const negative = categoryInsights.filter(i => i.sentiment === 'negative').length;
      content += `Sentiment: ${positive} positive, ${negative} negative, ${categoryInsights.length - positive - negative} neutral\n\n`;
    }
  }
  
  return content;
}

function groupInsightsByCategory(insights: any[]): Record<string, any[]> {
  return insights.reduce((groups, insight) => {
    const category = insight.category || 'Other';
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(insight);
    return groups;
  }, {} as Record<string, any[]>);
}

function extractKeyTrendsFromInsights(insights: any[]): string[] {
  const categories = groupInsightsByCategory(insights);
  const trends: string[] = [];
  
  // Most active category
  const sortedCategories = Object.entries(categories)
    .sort(([,a], [,b]) => b.length - a.length);
  
  if (sortedCategories.length > 0) {
    trends.push(`${sortedCategories[0][0]} showing highest activity with ${sortedCategories[0][1].length} insights`);
  }
  
  // Sentiment trend
  const totalPositive = insights.filter(i => i.sentiment === 'positive').length;
  const totalNegative = insights.filter(i => i.sentiment === 'negative').length;
  
  if (totalPositive > totalNegative * 1.5) {
    trends.push('Overall positive sentiment trend');
  } else if (totalNegative > totalPositive * 1.5) {
    trends.push('Overall negative sentiment trend');
  }
  
  // High priority items
  const highPriority = insights.filter(i => i.priority === 'high' || i.priority === 'critical').length;
  if (highPriority > 0) {
    trends.push(`${highPriority} high-priority developments identified`);
  }
  
  return trends.slice(0, 5);
}