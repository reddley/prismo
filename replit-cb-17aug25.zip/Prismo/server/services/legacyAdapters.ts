/**
 * Legacy Service Adapters
 * Provides backward compatibility while transitioning to unified services
 */

import { 
  getDataIntelligenceService, 
  getUserIntelligenceService, 
  getCostIntelligenceService,
  serviceContainer
} from './serviceRegistry';

// Legacy EntityService compatibility
export class EntityService {
  private getDataIntelligence() {
    return serviceContainer.get('dataIntelligence');
  }

  async processInsightForEntities(insight: any) {
    return this.getDataIntelligence().processInsightForEntities(insight);
  }

  async extractEntitiesFromContent(content: string) {
    return this.getDataIntelligence().extractEntitiesFromContent(content);
  }

  async createOrUpdateEntity(entityData: any) {
    return this.getDataIntelligence().createOrUpdateEntity(entityData);
  }
}

// Legacy DataEnrichmentService compatibility
export class DataEnrichmentService {
  private getDataIntelligence() {
    return serviceContainer.get('dataIntelligence');
  }

  async enrichCompanyData(companyName: string) {
    return this.getDataIntelligence().enrichCompanyData(companyName);
  }

  async enrichPersonData(personName: string) {
    return this.getDataIntelligence().enrichPersonData(personName);
  }

  async cropImageToSquare(imageUrl: string) {
    return this.getDataIntelligence().cropImageToSquare(imageUrl);
  }
}

// Legacy IntelligentAlertsService compatibility
export class IntelligentAlertsService {
  private getUserIntelligence() {
    return serviceContainer.get('userIntelligence');
  }

  async getUserAlerts(userId: string, includeRead: boolean = false) {
    // Simplified implementation for backward compatibility
    return [];
  }

  async generateIntelligentAlerts(userId: string) {
    // Simplified implementation for backward compatibility
    return;
  }

  async markAlertRead(alertId: string, userId: string, feedback?: any) {
    // Simplified implementation for backward compatibility
    return;
  }
}

// Legacy SpecsLearningService compatibility
export class SpecsLearningService {
  private getUserIntelligence() {
    return serviceContainer.get('userIntelligence');
  }

  async trackInteraction(interaction: any) {
    return this.getUserIntelligence().trackInteraction(interaction);
  }

  async checkInsightMatchesSpecs(userId: string, insight: any) {
    return this.getUserIntelligence().checkInsightMatchesSpecs(userId, insight);
  }
}

// Legacy AutoAlertTriggerService compatibility
export class AutoAlertTriggerService {
  private getUserIntelligence() {
    return serviceContainer.get('userIntelligence');
  }

  async processInsightForAlerts(insightId: string) {
    return this.getUserIntelligence().processInsightForAlerts(insightId);
  }
}

// Legacy cost tracking services
export class PersistentCostTrackingService {
  private getCostIntelligence() {
    return serviceContainer.get('costIntelligence');
  }

  async recordCost(operation: any) {
    return this.getCostIntelligence().recordCost(operation);
  }

  async recordRuleBasedOperation(operation: string, savings?: number) {
    return this.getCostIntelligence().recordRuleBasedOperation(operation, savings);
  }

  async getDailyCostStats() {
    return this.getCostIntelligence().getDailyCostStats();
  }
}

// Export singletons for backward compatibility
export const entityService = new EntityService();
export const dataEnrichmentService = new DataEnrichmentService();
export const intelligentAlertsService = new IntelligentAlertsService();
export const specsLearningService = new SpecsLearningService();
export const autoAlertTriggerService = new AutoAlertTriggerService();
export const persistentCostTrackingService = new PersistentCostTrackingService();