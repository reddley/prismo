// Content analysis service for extracting insights and monitoring keywords
import { storage } from '../storage';

export async function analyzeContent(content: string, options?: {
  insightId?: string;
  title?: string;
  url?: string;
}): Promise<{
  keywordMatches: string[];
  monitorAlerts: string[];
  score: number;
}> {
  console.log(`[CONTENT-ANALYZER] Analyzing content: ${options?.title || 'Unknown'}`);

  try {
    // Get active monitors for keyword matching
    const monitors = await storage.getActiveMonitors();
    
    const keywordMatches: string[] = [];
    const monitorAlerts: string[] = [];
    let score = 0;

    // Analyze content against monitors
    for (const monitor of monitors) {
      const matches = checkKeywordMatch(content, monitor.keywords);
      
      if (matches.length > 0) {
        keywordMatches.push(...matches);
        
        // Create alert if threshold met
        if (matches.length >= (monitor.threshold || 1)) {
          monitorAlerts.push(monitor.id);
          
          // Create notification/alert
          await createMonitorAlert(monitor, {
            content,
            matches,
            insightId: options?.insightId,
            title: options?.title,
            url: options?.url,
          });
        }
        
        // Increase score based on priority
        const priorityWeight = {
          critical: 10,
          high: 5,
          medium: 3,
          low: 1,
          normal: 2,
        };
        score += (priorityWeight[monitor.priority as keyof typeof priorityWeight] || 2) * matches.length;
      }
    }

    console.log(`[CONTENT-ANALYZER] Analysis complete: ${keywordMatches.length} matches, ${monitorAlerts.length} alerts, score: ${score}`);
    
    return {
      keywordMatches,
      monitorAlerts,
      score,
    };

  } catch (error) {
    console.error('[CONTENT-ANALYZER] Analysis failed:', error);
    throw error;
  }
}

function checkKeywordMatch(content: string, keywords: string[]): string[] {
  const lowerContent = content.toLowerCase();
  const matches: string[] = [];
  
  for (const keyword of keywords) {
    if (lowerContent.includes(keyword.toLowerCase())) {
      matches.push(keyword);
    }
  }
  
  return matches;
}

async function createMonitorAlert(monitor: any, context: {
  content: string;
  matches: string[];
  insightId?: string;
  title?: string;
  url?: string;
}): Promise<void> {
  try {
    // Create alert record
    const alert = await storage.createAlert({
      monitorId: monitor.id,
      type: 'keyword_match',
      title: `Monitor "${monitor.name}" triggered`,
      message: `Found keywords: ${context.matches.join(', ')}`,
      priority: monitor.priority,
      insightId: context.insightId,
      metadata: {
        keywords: context.matches,
        contentTitle: context.title,
        contentUrl: context.url,
      },
    });

    // Create notification for users
    await storage.createNotification({
      userId: monitor.userId,
      type: 'monitor_alert',
      title: `Monitor Alert: ${monitor.name}`,
      message: `Keywords "${context.matches.join(', ')}" detected in: ${context.title || 'content'}`,
      priority: monitor.priority,
      alertId: alert.id,
    });

    console.log(`[CONTENT-ANALYZER] Created alert for monitor: ${monitor.name}`);

  } catch (error) {
    console.error('[CONTENT-ANALYZER] Failed to create alert:', error);
  }
}