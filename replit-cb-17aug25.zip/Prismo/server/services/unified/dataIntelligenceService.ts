/**
 * Unified Data Intelligence Service
 * Consolidates entity processing and data enrichment into a single service
 */

import { IDataEnrichmentService, IEntityProcessingService, withErrorPolicy } from '../serviceContainer';
import { logger } from '../../observability/logger';

interface EnrichmentData {
  logoUrl?: string;
  description?: string;
  industry?: string;
  website?: string;
  location?: string;
  employeeCount?: number;
}

interface EntityMention {
  name: string;
  type: 'COMPANY' | 'PERSON' | 'ORGANIZATION';
  context: string;
  relevance: number;
  startPos?: number;
  endPos?: number;
}

interface EntityRelationshipData {
  sourceEntityId: string;
  targetEntityId: string;
  relationshipType: string;
  strength: number;
  context: string;
}

export class DataIntelligenceService implements IDataEnrichmentService, IEntityProcessingService {
  private aiService: any;
  private storage: any;

  constructor(aiService: any, storage: any) {
    this.aiService = aiService;
    this.storage = storage;
  }

  // Entity Processing Methods
  async processInsightForEntities(insight: any): Promise<{ mentions: EntityMention[]; relationships: EntityRelationshipData[]; }> {
    try {
      // Extract entities using unified AI service
      const extractedEntities = await this.aiService.extractEntities(insight.content);
      
      const mentions: EntityMention[] = [];
      const relationships: EntityRelationshipData[] = [];
      
      // Process extracted entities
      for (const entity of extractedEntities) {
        if (entity.relevance > 0.3) { // Only process relevant entities
          // Create or update entity
          const entityRecord = await this.createOrUpdateEntity({
            name: entity.name,
            type: entity.type,
            description: entity.context
          });
          
          // Create mention record
          const mention: EntityMention = {
            name: entity.name,
            type: entity.type,
            context: entity.context,
            relevance: entity.relevance
          };
          mentions.push(mention);
          
          // Enrich entity data if it's a company or high-relevance entity
          if (entity.type === 'COMPANY' && entity.relevance > 0.7) {
            await this.enrichEntityData(entityRecord.id, entity.name, entity.type);
          }
        }
      }
      
      // Extract relationships between entities
      if (mentions.length > 1) {
        const relationshipData = await this.extractEntityRelationships(insight.content, mentions);
        relationships.push(...relationshipData);
      }
      
      logger.info('Processed insight for entities', {
        insightId: insight.id,
        entitiesFound: mentions.length,
        relationshipsFound: relationships.length
      });
      
      return { mentions, relationships };
    } catch (error) {
      logger.error('Failed to process insight for entities', {
        insightId: insight.id,
        error: error.message
      });
      return { mentions: [], relationships: [] };
    }
  }

  async extractEntitiesFromContent(content: string): Promise<any[]> {
    return await this.aiService.extractEntities(content);
  }

  async createOrUpdateEntity(entityData: any): Promise<any> {
    try {
      // Check if entity already exists
      const existing = await this.storage.findEntityByName(entityData.name, entityData.type);
      
      if (existing) {
        // Update existing entity
        return await this.storage.updateEntity(existing.id, {
          ...entityData,
          lastSeenAt: new Date(),
          mentionCount: existing.mentionCount + 1
        });
      } else {
        // Create new entity
        return await this.storage.createEntity({
          ...entityData,
          createdAt: new Date(),
          lastSeenAt: new Date(),
          mentionCount: 1
        });
      }
    } catch (error) {
      logger.error('Failed to create/update entity', {
        entityName: entityData.name,
        error: error.message
      });
      throw error;
    }
  }

  // Data Enrichment Methods
  async enrichCompanyData(companyName: string): Promise<EnrichmentData | null> {
    try {
      logger.info('Enriching company data', { companyName });
      
      // Try multiple enrichment sources in order of preference
      const sources = [
        () => this.fetchClearbitLogo(companyName),
        () => this.fetchCompanyWebsiteLogo(companyName),
        () => this.fetchWikipediaData(companyName, 'company'),
        () => this.generateBasicCompanyProfile(companyName)
      ];

      for (const source of sources) {
        try {
          const data = await source();
          if (data && (data.logoUrl || data.description)) {
            return data;
          }
        } catch (error) {
          logger.debug('Enrichment source failed, trying next', {
            companyName,
            error: error.message
          });
        }
      }

      return null;
    } catch (error) {
      logger.error('Failed to enrich company data', {
        companyName,
        error: error.message
      });
      return null;
    }
  }

  async enrichPersonData(personName: string): Promise<any | null> {
    try {
      // Try multiple sources for person data
      const sources = [
        () => this.fetchWikipediaData(personName, 'person'),
        () => this.generateBasicPersonProfile(personName)
      ];

      for (const source of sources) {
        try {
          const data = await source();
          if (data) {
            return data;
          }
        } catch (error) {
          logger.debug('Person enrichment source failed, trying next', {
            personName,
            error: error.message
          });
        }
      }

      return null;
    } catch (error) {
      logger.error('Failed to enrich person data', {
        personName,
        error: error.message
      });
      return null;
    }
  }

  async cropImageToSquare(imageUrl: string): Promise<string | null> {
    try {
      const sharp = (await import('sharp')).default;
      const fetch = (await import('node-fetch')).default;
      const fs = await import('fs');
      const path = await import('path');
      const crypto = await import('crypto');

      // Create uploads directory if it doesn't exist
      const uploadsDir = path.join(process.cwd(), 'uploads');
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      // Download the image
      const response = await fetch(imageUrl);
      if (!response.ok) return null;

      const buffer = await response.buffer();
      
      // Generate unique filename
      const hash = crypto.createHash('md5').update(imageUrl).digest('hex');
      const filename = `cropped_${hash}.png`;
      const filepath = path.join(uploadsDir, filename);

      // Skip if already exists
      if (fs.existsSync(filepath)) {
        return `/uploads/${filename}`;
      }

      // Crop to square and resize to 200x200
      await sharp(buffer)
        .resize(200, 200, {
          fit: 'cover',
          position: 'center'
        })
        .png()
        .toFile(filepath);

      return `/uploads/${filename}`;
    } catch (error) {
      logger.warn('Image cropping failed, returning original URL', {
        imageUrl,
        error: error.message
      });
      return imageUrl; // Return original if cropping fails
    }
  }

  // Private helper methods
  private async enrichEntityData(entityId: string, entityName: string, entityType: string): Promise<void> {
    try {
      let enrichmentData = null;
      
      if (entityType === 'COMPANY') {
        enrichmentData = await this.enrichCompanyData(entityName);
      } else if (entityType === 'PERSON') {
        enrichmentData = await this.enrichPersonData(entityName);
      }
      
      if (enrichmentData) {
        await this.storage.updateEntityEnrichment(entityId, enrichmentData);
        logger.info('Entity enriched successfully', { entityId, entityName });
      }
    } catch (error) {
      logger.warn('Failed to enrich entity data', {
        entityId,
        entityName,
        error: error.message
      });
    }
  }

  private async extractEntityRelationships(content: string, mentions: EntityMention[]): Promise<EntityRelationshipData[]> {
    // Simplified relationship extraction logic
    const relationships: EntityRelationshipData[] = [];
    
    // Look for common relationship patterns in content
    const relationshipPatterns = [
      { pattern: /(.+?)\s+acquire[sd]?\s+(.+?)/, type: 'ACQUISITION' },
      { pattern: /(.+?)\s+partner[s]?\s+with\s+(.+?)/, type: 'PARTNERSHIP' },
      { pattern: /(.+?)\s+invest[s]?\s+in\s+(.+?)/, type: 'INVESTMENT' },
      { pattern: /(.+?)\s+compete[s]?\s+with\s+(.+?)/, type: 'COMPETITION' }
    ];
    
    for (const pattern of relationshipPatterns) {
      const matches = content.match(pattern.pattern);
      if (matches && mentions.length >= 2) {
        // Find entities that match the relationship pattern
        const sourceEntity = mentions.find(m => matches[1].toLowerCase().includes(m.name.toLowerCase()));
        const targetEntity = mentions.find(m => matches[2].toLowerCase().includes(m.name.toLowerCase()));
        
        if (sourceEntity && targetEntity && sourceEntity !== targetEntity) {
          relationships.push({
            sourceEntityId: sourceEntity.name, // In real implementation, use actual IDs
            targetEntityId: targetEntity.name,
            relationshipType: pattern.type,
            strength: 0.8,
            context: matches[0]
          });
        }
      }
    }
    
    return relationships;
  }

  // Enrichment source methods (simplified versions)
  private async fetchClearbitLogo(companyName: string): Promise<EnrichmentData | null> {
    // Mock implementation - in real version, integrate with Clearbit API
    return null;
  }

  private async fetchCompanyWebsiteLogo(companyName: string): Promise<EnrichmentData | null> {
    // Mock implementation - in real version, try to find company website and extract logo
    return null;
  }

  private async fetchWikipediaData(name: string, type: 'company' | 'person'): Promise<EnrichmentData | null> {
    // Mock implementation - in real version, integrate with Wikipedia API
    return null;
  }

  private async generateBasicCompanyProfile(companyName: string): Promise<EnrichmentData | null> {
    // Use AI service to generate basic profile
    try {
      const description = await this.aiService.summarizeContent(`Generate a brief company profile for ${companyName}`);
      return {
        description,
        industry: 'Unknown'
      };
    } catch {
      return null;
    }
  }

  private async generateBasicPersonProfile(personName: string): Promise<any> {
    try {
      const description = await this.aiService.summarizeContent(`Generate a brief professional profile for ${personName}`);
      return {
        description,
        title: 'Professional'
      };
    } catch {
      return null;
    }
  }
}