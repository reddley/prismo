/**
 * Unified AI Intelligence Service
 * Consolidates OpenAI operations, model routing, and AI-powered analysis
 */

import { IAiIntelligenceService, withErrorPolicy } from '../serviceContainer';
import { logger } from '../../observability/logger';

interface TaskContext {
  type: string;
  contentLength: number;
  budgetConstraint: 'strict' | 'moderate' | 'flexible';
  qualityRequirement: 'basic' | 'high' | 'premium';
  timeConstraint: 'urgent' | 'normal' | 'batch';
  isMultimodal?: boolean;
  requiresReasoning?: boolean;
}

export class AiIntelligenceService implements IAiIntelligenceService {
  private modelRouter: any;
  private costTracker: any;

  constructor(modelRouter: any, costTracker: any) {
    this.modelRouter = modelRouter;
    this.costTracker = costTracker;
  }

  async analyzeSentiment(text: string): Promise<{ sentiment: string; confidence: number; priority: string; }> {
    // Rule-based pre-filtering for cost optimization
    const ruleBasedResult = this.getRuleBasedSentimentAndPriority(text);
    if (ruleBasedResult.confidence > 0.8) {
      await this.costTracker.recordRuleBasedOperation('sentiment_analysis', 0.001);
      return ruleBasedResult;
    }

    // Use AI for uncertain cases
    const context: TaskContext = {
      type: 'sentiment_analysis',
      contentLength: text.length,
      budgetConstraint: 'strict',
      qualityRequirement: 'basic',
      timeConstraint: 'normal'
    };

    const model = this.modelRouter.selectOptimalModel(context);
    
    try {
      const response = await this.modelRouter.chatCompletion({
        model: model.id,
        messages: [
          {
            role: 'system',
            content: 'Analyze sentiment and assign priority. Respond with JSON: {"sentiment": "positive/negative/neutral", "confidence": 0.0-1.0, "priority": "low/medium/high/critical"}'
          },
          { role: 'user', content: text }
        ],
        response_format: { type: 'json_object' },
        max_tokens: 100
      });

      const result = JSON.parse(response.choices[0].message.content);
      
      await this.costTracker.recordCost({
        modelName: model.id,
        operation: 'sentiment_analysis',
        inputTokens: response.usage.prompt_tokens,
        outputTokens: response.usage.completion_tokens,
        cost: this.modelRouter.calculateCost(model.id, response.usage),
        priority: 'medium',
        success: true
      });

      return {
        sentiment: result.sentiment,
        confidence: Math.max(0, Math.min(1, result.confidence)),
        priority: result.priority
      };
    } catch (error) {
      logger.error('AI sentiment analysis failed', { error: error.message });
      return ruleBasedResult; // Fallback to rule-based
    }
  }

  async summarizeContent(text: string): Promise<string> {
    if (text.length < 200) {
      await this.costTracker.recordRuleBasedOperation('summarization', 0.002);
      return text.substring(0, 150) + '...';
    }

    const context: TaskContext = {
      type: 'summarization',
      contentLength: text.length,
      budgetConstraint: 'moderate',
      qualityRequirement: 'high',
      timeConstraint: 'normal'
    };

    const model = this.modelRouter.selectOptimalModel(context);
    
    const response = await this.modelRouter.chatCompletion({
      model: model.id,
      messages: [
        {
          role: 'system',
          content: 'Provide a concise, informative summary in 2-3 sentences focusing on key business impact and implications.'
        },
        { role: 'user', content: `Summarize: ${text}` }
      ],
      max_tokens: 150
    });

    await this.costTracker.recordCost({
      modelName: model.id,
      operation: 'summarization',
      inputTokens: response.usage.prompt_tokens,
      outputTokens: response.usage.completion_tokens,
      cost: this.modelRouter.calculateCost(model.id, response.usage),
      priority: 'medium',
      success: true
    });

    return response.choices[0].message.content.trim();
  }

  async categorizeContent(text: string): Promise<string> {
    // Rule-based categorization for common patterns
    const ruleBasedCategory = this.getRuleBasedCategory(text);
    if (ruleBasedCategory) {
      await this.costTracker.recordRuleBasedOperation('categorization', 0.001);
      return ruleBasedCategory;
    }

    const context: TaskContext = {
      type: 'categorization',
      contentLength: text.length,
      budgetConstraint: 'strict',
      qualityRequirement: 'basic',
      timeConstraint: 'normal'
    };

    const model = this.modelRouter.selectOptimalModel(context);
    
    const response = await this.modelRouter.chatCompletion({
      model: model.id,
      messages: [
        {
          role: 'system',
          content: 'Categorize this content into one of: Technology, Finance, Healthcare, Energy, Retail, Manufacturing, Transportation, Media, Government, Other'
        },
        { role: 'user', content: text.substring(0, 500) }
      ],
      max_tokens: 20
    });

    await this.costTracker.recordCost({
      modelName: model.id,
      operation: 'categorization',
      inputTokens: response.usage.prompt_tokens,
      outputTokens: response.usage.completion_tokens,
      cost: this.modelRouter.calculateCost(model.id, response.usage),
      priority: 'low',
      success: true
    });

    return response.choices[0].message.content.trim();
  }

  async extractEntities(text: string): Promise<any[]> {
    // Use rule-based entity extraction for cost efficiency and speed
    const entities = this.extractEntitiesRuleBased(text);
    await this.costTracker.recordRuleBasedOperation('entity_extraction', 0.005);
    return entities;
  }

  selectOptimalModel(context: TaskContext): any {
    return this.modelRouter.selectOptimalModel(context);
  }

  // Private helper methods
  private extractEntitiesRuleBased(text: string): any[] {
    const entities: any[] = [];
    const words = text.split(/\s+/);
    
    // Simple entity patterns
    for (let i = 0; i < words.length; i++) {
      const word = words[i];
      
      // Company indicators
      if (word.match(/^[A-Z][a-z]+$/)) {
        if (i + 1 < words.length && words[i + 1].match(/^(Inc|Corp|Ltd|LLC|Co)\.?$/)) {
          entities.push({
            name: `${word} ${words[i + 1]}`,
            type: 'COMPANY',
            relevance: 0.8
          });
        }
      }
      
      // Well-known companies (case insensitive)
      const lowerWord = word.toLowerCase().replace(/[^\w]/g, '');
      const knownCompanies = ['apple', 'microsoft', 'google', 'amazon', 'tesla', 'meta', 'netflix'];
      if (knownCompanies.includes(lowerWord)) {
        entities.push({
          name: word,
          type: 'COMPANY',
          relevance: 0.9
        });
      }
      
      // Person names (simple heuristic)
      if (word.match(/^[A-Z][a-z]+$/) && i + 1 < words.length && words[i + 1].match(/^[A-Z][a-z]+$/)) {
        entities.push({
          name: `${word} ${words[i + 1]}`,
          type: 'PERSON',
          relevance: 0.7
        });
      }
    }
    
    return entities;
  }

  private getRuleBasedSentimentAndPriority(text: string): { sentiment: string; confidence: number; priority: string; } {
    const lowerText = text.toLowerCase();
    
    // Critical priority indicators
    const criticalNegative = ['bankruptcy', 'hack', 'breach', 'lawsuit', 'fraud', 'scandal'];
    const criticalPositive = ['acquisition', 'merger', 'ipo'];
    
    // High priority indicators
    const highNegative = ['loss', 'decline', 'drop', 'fall', 'crash', 'layoffs'];
    const highPositive = ['growth', 'profit', 'rise', 'increase', 'funding', 'investment'];
    
    if (criticalNegative.some(word => lowerText.includes(word))) {
      return { sentiment: 'negative', confidence: 0.9, priority: 'critical' };
    }
    if (criticalPositive.some(word => lowerText.includes(word))) {
      return { sentiment: 'positive', confidence: 0.9, priority: 'critical' };
    }
    if (highNegative.some(word => lowerText.includes(word))) {
      return { sentiment: 'negative', confidence: 0.8, priority: 'high' };
    }
    if (highPositive.some(word => lowerText.includes(word))) {
      return { sentiment: 'positive', confidence: 0.8, priority: 'high' };
    }
    
    return { sentiment: 'neutral', confidence: 0.6, priority: 'medium' };
  }

  private getRuleBasedCategory(text: string): string | null {
    const lowerText = text.toLowerCase();
    
    const categoryKeywords = {
      'Technology': ['software', 'ai', 'artificial intelligence', 'cloud', 'cybersecurity', 'tech'],
      'Finance': ['bank', 'financial', 'investment', 'trading', 'cryptocurrency', 'fintech'],
      'Healthcare': ['medical', 'pharmaceutical', 'biotech', 'health', 'drug', 'clinical'],
      'Energy': ['oil', 'gas', 'renewable', 'solar', 'wind', 'energy', 'electric'],
      'Retail': ['retail', 'e-commerce', 'shopping', 'consumer', 'store', 'marketplace']
    };
    
    for (const [category, keywords] of Object.entries(categoryKeywords)) {
      if (keywords.some(keyword => lowerText.includes(keyword))) {
        return category;
      }
    }
    
    return null;
  }
}