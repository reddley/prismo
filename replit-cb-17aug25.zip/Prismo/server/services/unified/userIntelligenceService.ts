/**
 * Unified User Intelligence Service
 * Consolidates user interaction tracking, specs learning, and alert generation
 */

import { IUserIntelligenceService, withErrorPolicy } from '../serviceContainer';
import { logger } from '../../observability/logger';
import { db } from '../../db';
import { userInteractions, userSpecs, notifications } from '../../../shared/schema';
import { eq, desc } from 'drizzle-orm';

interface UserInteraction {
  userId: string;
  interactionType: string;
  insightId?: string;
  category?: string;
  extractedKeywords?: string[];
  sessionId?: string;
  metadata?: Record<string, any>;
}

interface UserSpec {
  userId: string;
  specType: string;
  specKey: string;
  displayName: string;
  keywords: string[];
  strength: number;
  isActive: boolean;
}

interface MatchResult {
  matches: boolean;
  overallRelevance: number;
  matchedSpecs: UserSpec[];
  reasons: string[];
}

export class UserIntelligenceService implements IUserIntelligenceService {
  private storage: any;

  constructor(storage: any) {
    this.storage = storage;
  }

  async trackInteraction(interaction: UserInteraction): Promise<void> {
    try {
      // Store interaction in database
      await db.insert(userInteractions).values({
        userId: interaction.userId,
        interactionType: interaction.interactionType,
        insightId: interaction.insightId,
        category: interaction.category,
        extractedKeywords: interaction.extractedKeywords,
        sessionId: interaction.sessionId,
        metadata: interaction.metadata,
        timestamp: new Date()
      });

      // Analyze interaction for learning opportunities
      await this.analyzeInteractionForSpecs(interaction);
      
      logger.info('User interaction tracked successfully', {
        userId: interaction.userId,
        interactionType: interaction.interactionType
      });
    } catch (error) {
      logger.error('Failed to track user interaction', {
        userId: interaction.userId,
        error: error.message
      });
      throw error;
    }
  }

  async checkInsightMatchesSpecs(userId: string, insight: any): Promise<MatchResult> {
    try {
      // Get active user specs
      const activeSpecs = await db
        .select()
        .from(userSpecs)
        .where(eq(userSpecs.userId, userId))
        .where(eq(userSpecs.isActive, true));

      if (activeSpecs.length === 0) {
        return {
          matches: false,
          overallRelevance: 0,
          matchedSpecs: [],
          reasons: ['No active user specifications found']
        };
      }

      const matchedSpecs: UserSpec[] = [];
      const reasons: string[] = [];
      let totalRelevance = 0;

      // Check each spec against the insight
      for (const spec of activeSpecs) {
        const matchStrength = this.calculateSpecMatchStrength(spec, insight);
        
        if (matchStrength > 0.3) { // Threshold for considering a match
          matchedSpecs.push(spec);
          totalRelevance += matchStrength * spec.strength;
          reasons.push(`Matches ${spec.displayName} (strength: ${matchStrength.toFixed(2)})`);
        }
      }

      // Calculate overall relevance (weighted average)
      const overallRelevance = matchedSpecs.length > 0 
        ? totalRelevance / matchedSpecs.reduce((sum, spec) => sum + spec.strength, 0)
        : 0;

      return {
        matches: matchedSpecs.length > 0,
        overallRelevance,
        matchedSpecs,
        reasons
      };
    } catch (error) {
      logger.error('Failed to check insight against specs', {
        userId,
        insightId: insight.id,
        error: error.message
      });
      return {
        matches: false,
        overallRelevance: 0,
        matchedSpecs: [],
        reasons: ['Error checking specifications']
      };
    }
  }

  async processInsightForAlerts(insightId: string): Promise<void> {
    try {
      // Get the insight
      const insight = await this.storage.getInsightById(insightId);
      if (!insight) {
        logger.warn('Insight not found for alert processing', { insightId });
        return;
      }

      // Only process high-priority insights
      if (insight.priority !== 'high' && insight.priority !== 'critical') {
        return;
      }

      logger.info('Processing insight for potential alerts', {
        insightId,
        title: insight.title,
        priority: insight.priority
      });

      // Get all users with active specs (simplified to default user for now)
      const userId = "default-user";
      
      // Check if insight matches user specs
      const matchResult = await this.checkInsightMatchesSpecs(userId, insight);

      if (matchResult.matches && matchResult.overallRelevance > 0.5) {
        logger.info('Insight matches user specs, generating alert', {
          insightId,
          relevance: matchResult.overallRelevance,
          matchedSpecs: matchResult.matchedSpecs.length
        });
        
        await this.generateAlert(userId, insight, matchResult);
      }
    } catch (error) {
      logger.error('Failed to process insight for alerts', {
        insightId,
        error: error.message
      });
    }
  }

  async generateAlert(userId: string, insight: any, matchResult: MatchResult): Promise<void> {
    try {
      // Create notification/alert
      await db.insert(notifications).values({
        userId,
        title: `High Priority Alert: ${insight.category || 'Update'}`,
        message: this.generateAlertMessage(insight, matchResult),
        type: insight.priority === 'critical' ? 'error' : 'warning',
        priority: insight.priority,
        insightId: insight.id,
        metadata: {
          relevance: matchResult.overallRelevance,
          matchedSpecs: matchResult.matchedSpecs.map(s => s.displayName),
          reasons: matchResult.reasons
        },
        isRead: false,
        createdAt: new Date()
      });

      logger.info('Alert generated successfully', {
        userId,
        insightId: insight.id,
        relevance: matchResult.overallRelevance
      });
    } catch (error) {
      logger.error('Failed to generate alert', {
        userId,
        insightId: insight.id,
        error: error.message
      });
      throw error;
    }
  }

  // Private helper methods
  private async analyzeInteractionForSpecs(interaction: UserInteraction): Promise<void> {
    // Only learn from positive interactions
    const positiveInteractions = ['view', 'read', 'save', 'share', 'feedback_positive'];
    if (!positiveInteractions.includes(interaction.interactionType)) {
      return;
    }

    const learningSignals = this.extractLearningSignals(interaction);
    
    for (const signal of learningSignals) {
      await this.updateOrCreateSpec(interaction.userId, signal);
    }
  }

  private extractLearningSignals(interaction: UserInteraction): Array<{
    specType: string;
    specKey: string;
    displayName: string;
    keywords: string[];
    strength: number;
  }> {
    const signals: Array<{
      specType: string;
      specKey: string;
      displayName: string;
      keywords: string[];
      strength: number;
    }> = [];

    // Category interest
    if (interaction.category) {
      signals.push({
        specType: 'industry_focus',
        specKey: interaction.category.toLowerCase(),
        displayName: this.formatDisplayName(interaction.category),
        keywords: [interaction.category.toLowerCase()],
        strength: this.calculateInteractionStrength(interaction)
      });
    }

    // Keyword interests
    if (interaction.extractedKeywords && interaction.extractedKeywords.length > 0) {
      for (const keyword of interaction.extractedKeywords) {
        if (keyword.length > 3) { // Avoid short words
          signals.push({
            specType: 'technology_interest',
            specKey: keyword.toLowerCase(),
            displayName: this.formatDisplayName(keyword),
            keywords: [keyword.toLowerCase()],
            strength: this.calculateInteractionStrength(interaction) * 0.8
          });
        }
      }
    }

    return signals;
  }

  private async updateOrCreateSpec(userId: string, signal: {
    specType: string;
    specKey: string;
    displayName: string;
    keywords: string[];
    strength: number;
  }): Promise<void> {
    try {
      // Check if spec already exists
      const [existingSpec] = await db
        .select()
        .from(userSpecs)
        .where(eq(userSpecs.userId, userId))
        .where(eq(userSpecs.specKey, signal.specKey))
        .limit(1);

      if (existingSpec) {
        // Update existing spec strength
        const newStrength = Math.min(1.0, existingSpec.strength + signal.strength * 0.1);
        await db
          .update(userSpecs)
          .set({
            strength: newStrength,
            lastActivatedAt: new Date(),
            updatedAt: new Date()
          })
          .where(eq(userSpecs.id, existingSpec.id));
      } else {
        // Create new spec
        await db.insert(userSpecs).values({
          userId,
          specType: signal.specType,
          specKey: signal.specKey,
          displayName: signal.displayName,
          keywords: signal.keywords,
          strength: signal.strength,
          isActive: true,
          source: 'learned',
          confidence: 0.7,
          createdAt: new Date(),
          updatedAt: new Date()
        });
      }
    } catch (error) {
      logger.error('Failed to update/create user spec', {
        userId,
        specKey: signal.specKey,
        error: error.message
      });
    }
  }

  private calculateSpecMatchStrength(spec: UserSpec, insight: any): number {
    let matchStrength = 0;

    // Check category match
    if (spec.specType === 'industry_focus' && insight.category) {
      if (spec.specKey === insight.category.toLowerCase()) {
        matchStrength += 0.8;
      }
    }

    // Check keyword matches
    if (spec.keywords && spec.keywords.length > 0) {
      const insightText = `${insight.title} ${insight.content}`.toLowerCase();
      const keywordMatches = spec.keywords.filter(keyword => 
        insightText.includes(keyword.toLowerCase())
      );
      matchStrength += (keywordMatches.length / spec.keywords.length) * 0.6;
    }

    // Check priority alignment
    if (insight.priority === 'critical' || insight.priority === 'high') {
      matchStrength += 0.2;
    }

    return Math.min(1.0, matchStrength);
  }

  private generateAlertMessage(insight: any, matchResult: MatchResult): string {
    const relevancePercent = Math.round(matchResult.overallRelevance * 100);
    const specNames = matchResult.matchedSpecs.map(s => s.displayName).join(', ');
    
    return `New ${insight.priority} priority insight: "${insight.title}" - ` +
           `${relevancePercent}% match with your interests (${specNames})`;
  }

  private calculateInteractionStrength(interaction: UserInteraction): number {
    const strengthMap: Record<string, number> = {
      'view': 0.1,
      'read': 0.3,
      'save': 0.7,
      'share': 0.8,
      'feedback_positive': 0.9
    };
    
    return strengthMap[interaction.interactionType] || 0.1;
  }

  private formatDisplayName(name: string): string {
    return name.charAt(0).toUpperCase() + name.slice(1).replace(/_/g, ' ');
  }
}