/**
 * Unified Cost Intelligence Service
 * Consolidates cost tracking, optimization, and budget management
 */

import { ICostTrackingService, withErrorPolicy } from '../serviceContainer';
import { logger } from '../../observability/logger';
import { db } from '../../db';
import { costEntries, costSummaries } from '../../../shared/schema';
import { eq, sql } from 'drizzle-orm';

interface CostEntry {
  modelName: string;
  operation: string;
  inputTokens: number;
  outputTokens: number;
  cost: number;
  priority: string;
  success?: boolean;
  metadata?: Record<string, any>;
}

interface DailyCostStats {
  totalCost: number;
  totalCalls: number;
  ruleBasedOperations: number;
  costSavings: number;
  budgetRemaining: number;
  topModels: Array<{ model: string; cost: number; calls: number; }>;
  topOperations: Array<{ operation: string; cost: number; calls: number; }>;
}

export class CostIntelligenceService implements ICostTrackingService {
  private readonly MAX_DAILY_COST = 5.00;
  private readonly MAX_DAILY_CALLS = 500;
  private budgetCache = new Map<string, { spent: number; timestamp: number }>();
  private readonly CACHE_TTL = 60000; // 1 minute cache

  constructor() {
    this.initializeTodaySummary();
  }

  async recordCost(operation: CostEntry): Promise<void> {
    try {
      // Insert detailed cost entry
      await db.insert(costEntries).values({
        modelName: operation.modelName,
        operation: operation.operation,
        inputTokens: operation.inputTokens,
        outputTokens: operation.outputTokens,
        cost: operation.cost.toString(),
        priority: operation.priority,
        success: operation.success ?? true,
        metadata: operation.metadata || {},
        timestamp: new Date()
      });

      // Update daily summary
      await this.updateDailySummary(operation.cost, 1);
      
      // Invalidate cache
      this.invalidateBudgetCache();
      
      logger.info('Cost recorded successfully', {
        operation: operation.operation,
        model: operation.modelName,
        cost: operation.cost,
        tokens: operation.inputTokens + operation.outputTokens
      });
    } catch (error) {
      logger.error('Failed to record cost entry', {
        operation: operation.operation,
        error: error.message
      });
      throw error;
    }
  }

  async recordRuleBasedOperation(operation: string, estimatedSavings: number = 0.001): Promise<void> {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      await db
        .update(costSummaries)
        .set({
          ruleBasedOperations: sql`${costSummaries.ruleBasedOperations} + 1`,
          costSavings: sql`${costSummaries.costSavings} + ${estimatedSavings}`,
          updatedAt: new Date(),
        })
        .where(eq(costSummaries.date, today));

      logger.debug('Rule-based operation recorded', {
        operation,
        estimatedSavings
      });
    } catch (error) {
      logger.error('Failed to record rule-based operation', {
        operation,
        error: error.message
      });
    }
  }

  async getDailyCostStats(): Promise<DailyCostStats> {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      // Get daily summary
      const [summary] = await db
        .select()
        .from(costSummaries)
        .where(eq(costSummaries.date, today))
        .limit(1);

      if (!summary) {
        return this.getDefaultCostStats();
      }

      // Get top models and operations for today
      const topModels = await this.getTopModelsByUsage(today);
      const topOperations = await this.getTopOperationsByUsage(today);

      return {
        totalCost: parseFloat(summary.totalCost),
        totalCalls: summary.totalCalls,
        ruleBasedOperations: summary.ruleBasedOperations,
        costSavings: parseFloat(summary.costSavings),
        budgetRemaining: Math.max(0, this.MAX_DAILY_COST - parseFloat(summary.totalCost)),
        topModels,
        topOperations
      };
    } catch (error) {
      logger.error('Failed to get daily cost stats', { error: error.message });
      return this.getDefaultCostStats();
    }
  }

  async checkBudgetConstraints(): Promise<boolean> {
    try {
      // Check cache first
      const today = new Date().toISOString().split('T')[0];
      const cached = this.budgetCache.get(today);
      
      if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
        return cached.spent < this.MAX_DAILY_COST;
      }

      // Get current spending
      const stats = await this.getDailyCostStats();
      
      // Update cache
      this.budgetCache.set(today, {
        spent: stats.totalCost,
        timestamp: Date.now()
      });

      const withinBudget = stats.totalCost < this.MAX_DAILY_COST && stats.totalCalls < this.MAX_DAILY_CALLS;
      
      if (!withinBudget) {
        logger.warn('Daily budget constraints exceeded', {
          totalCost: stats.totalCost,
          maxCost: this.MAX_DAILY_COST,
          totalCalls: stats.totalCalls,
          maxCalls: this.MAX_DAILY_CALLS
        });
      }

      return withinBudget;
    } catch (error) {
      logger.error('Failed to check budget constraints', { error: error.message });
      return false; // Fail safe - assume budget exceeded
    }
  }

  // Budget analysis and optimization methods
  async getOptimizationRecommendations(): Promise<Array<{
    type: string;
    priority: 'high' | 'medium' | 'low';
    description: string;
    potentialSavings: number;
  }>> {
    try {
      const stats = await this.getDailyCostStats();
      const recommendations = [];

      // High-cost model recommendations
      const expensiveModels = stats.topModels.filter(m => m.cost > 1.0);
      if (expensiveModels.length > 0) {
        recommendations.push({
          type: 'model-optimization',
          priority: 'high' as const,
          description: `Consider using more cost-efficient models for ${expensiveModels.map(m => m.model).join(', ')}`,
          potentialSavings: expensiveModels.reduce((sum, m) => sum + m.cost, 0) * 0.3
        });
      }

      // High-frequency operation recommendations
      const frequentOps = stats.topOperations.filter(op => op.calls > 50);
      if (frequentOps.length > 0) {
        recommendations.push({
          type: 'operation-optimization',
          priority: 'medium' as const,
          description: `Implement rule-based pre-filtering for frequent operations: ${frequentOps.map(op => op.operation).join(', ')}`,
          potentialSavings: frequentOps.reduce((sum, op) => sum + op.cost, 0) * 0.5
        });
      }

      // Budget utilization recommendations
      if (stats.totalCost > this.MAX_DAILY_COST * 0.8) {
        recommendations.push({
          type: 'budget-alert',
          priority: 'high' as const,
          description: 'Daily budget utilization exceeds 80%, consider implementing stricter cost controls',
          potentialSavings: 0
        });
      }

      return recommendations;
    } catch (error) {
      logger.error('Failed to generate optimization recommendations', { error: error.message });
      return [];
    }
  }

  // Private helper methods
  private async initializeTodaySummary(): Promise<void> {
    const today = new Date().toISOString().split('T')[0];
    
    try {
      const [existingSummary] = await db
        .select()
        .from(costSummaries)
        .where(eq(costSummaries.date, today))
        .limit(1);

      if (!existingSummary) {
        await db.insert(costSummaries).values({
          date: today,
          totalCost: "0",
          totalCalls: 0,
          ruleBasedOperations: 0,
          costSavings: "0",
          topModels: [],
          topOperations: [],
          createdAt: new Date(),
          updatedAt: new Date()
        });
        
        logger.info('Initialized daily cost summary', { date: today });
      }
    } catch (error) {
      logger.error('Failed to initialize daily cost summary', {
        date: today,
        error: error.message
      });
    }
  }

  private async updateDailySummary(cost: number, callCount: number): Promise<void> {
    const today = new Date().toISOString().split('T')[0];
    
    try {
      await db
        .update(costSummaries)
        .set({
          totalCost: sql`${costSummaries.totalCost} + ${cost}`,
          totalCalls: sql`${costSummaries.totalCalls} + ${callCount}`,
          updatedAt: new Date(),
        })
        .where(eq(costSummaries.date, today));
    } catch (error) {
      logger.error('Failed to update daily summary', {
        date: today,
        cost,
        callCount,
        error: error.message
      });
    }
  }

  private async getTopModelsByUsage(date: string): Promise<Array<{ model: string; cost: number; calls: number; }>> {
    try {
      const results = await db
        .select({
          model: costEntries.modelName,
          totalCost: sql<number>`SUM(CAST(${costEntries.cost} AS DECIMAL))`,
          totalCalls: sql<number>`COUNT(*)`
        })
        .from(costEntries)
        .where(sql`DATE(${costEntries.timestamp}) = ${date}`)
        .groupBy(costEntries.modelName)
        .orderBy(sql`SUM(CAST(${costEntries.cost} AS DECIMAL)) DESC`)
        .limit(5);

      return results.map(r => ({
        model: r.model,
        cost: Number(r.totalCost),
        calls: Number(r.totalCalls)
      }));
    } catch (error) {
      logger.error('Failed to get top models by usage', { error: error.message });
      return [];
    }
  }

  private async getTopOperationsByUsage(date: string): Promise<Array<{ operation: string; cost: number; calls: number; }>> {
    try {
      const results = await db
        .select({
          operation: costEntries.operation,
          totalCost: sql<number>`SUM(CAST(${costEntries.cost} AS DECIMAL))`,
          totalCalls: sql<number>`COUNT(*)`
        })
        .from(costEntries)
        .where(sql`DATE(${costEntries.timestamp}) = ${date}`)
        .groupBy(costEntries.operation)
        .orderBy(sql`SUM(CAST(${costEntries.cost} AS DECIMAL)) DESC`)
        .limit(5);

      return results.map(r => ({
        operation: r.operation,
        cost: Number(r.totalCost),
        calls: Number(r.totalCalls)
      }));
    } catch (error) {
      logger.error('Failed to get top operations by usage', { error: error.message });
      return [];
    }
  }

  private getDefaultCostStats(): DailyCostStats {
    return {
      totalCost: 0,
      totalCalls: 0,
      ruleBasedOperations: 0,
      costSavings: 0,
      budgetRemaining: this.MAX_DAILY_COST,
      topModels: [],
      topOperations: []
    };
  }

  private invalidateBudgetCache(): void {
    this.budgetCache.clear();
  }
}