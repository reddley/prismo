import Anthropic from '@anthropic-ai/sdk';

const DEFAULT_MODEL_STR = "claude-sonnet-4-20250514";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

interface EnrichmentData {
  name: string;
  description?: string;
  imageUrl?: string;
  logoUrl?: string;
  website?: string;
  founded?: string;
  headquarters?: string;
  industry?: string;
  keyPeople?: string[];
  revenue?: string;
  employees?: string;
  wikipediaUrl?: string;
  verified: boolean;
  source: string;
  lastUpdated: Date;
}

export class DataEnrichmentService {
  /**
   * Crop and resize image to square format
   */
  private async cropImageToSquare(imageUrl: string): Promise<string | null> {
    try {
      const sharp = (await import('sharp')).default;
      const fetch = (await import('node-fetch')).default;
      const fs = await import('fs');
      const path = await import('path');
      const crypto = await import('crypto');

      // Create uploads directory if it doesn't exist
      const uploadsDir = path.join(process.cwd(), 'uploads');
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      // Download the image
      const response = await fetch(imageUrl);
      if (!response.ok) return null;

      const buffer = await response.buffer();
      
      // Generate unique filename
      const hash = crypto.createHash('md5').update(imageUrl).digest('hex');
      const filename = `cropped_${hash}.png`;
      const filepath = path.join(uploadsDir, filename);

      // Skip if already exists
      if (fs.existsSync(filepath)) {
        return `/uploads/${filename}`;
      }

      // Crop to square and resize to 200x200
      await sharp(buffer)
        .resize(200, 200, {
          fit: 'cover',
          position: 'center'
        })
        .png()
        .toFile(filepath);

      // Return local path that can be served
      return `/uploads/${filename}`;
    } catch (error) {
      console.error('Error cropping image:', error);
      return imageUrl; // Return original if cropping fails
    }
  }

  /**
   * Enrich company data with multiple high-quality sources
   */
  async enrichCompanyData(companyName: string): Promise<EnrichmentData | null> {
    try {
      console.log(`Enriching data for company: ${companyName}`);
      
      // Try multiple sources in order of preference
      const sources = [
        () => this.fetchClearbitLogo(companyName),
        () => this.fetchCompanyWebsiteLogo(companyName),
        () => this.fetchWikipediaData(companyName, 'company')
      ];

      for (const source of sources) {
        try {
          const data = await source();
          if (data && data.logoUrl) {
            return data;
          }
        } catch (error) {
          console.log(`Source failed for ${companyName}, trying next source`);
        }
      }

      // Fallback: Use AI to generate basic company profile
      return await this.generateBasicCompanyProfile(companyName);
    } catch (error) {
      console.error(`Error enriching company data for ${companyName}:`, error);
      return null;
    }
  }

  /**
   * Enrich person data with multiple high-quality sources
   */
  async enrichPersonData(personName: string): Promise<EnrichmentData | null> {
    try {
      console.log(`Enriching data for person: ${personName}`);
      
      // Try multiple sources in order of preference
      const sources = [
        () => this.fetchLinkedInPhoto(personName),
        () => this.fetchWikipediaData(personName, 'person'),
        () => this.fetchCrunchbasePhoto(personName)
      ];

      for (const source of sources) {
        try {
          const data = await source();
          if (data && data.imageUrl) {
            return data;
          }
        } catch (error) {
          console.log(`Source failed for ${personName}, trying next source`);
        }
      }

      // Fallback: Use AI to generate basic person profile
      return await this.generateBasicPersonProfile(personName);
    } catch (error) {
      console.error(`Error enriching person data for ${personName}:`, error);
      return null;
    }
  }

  /**
   * Enrich organization data with information from Wikipedia and other sources
   */
  async enrichOrganizationData(orgName: string): Promise<EnrichmentData | null> {
    try {
      console.log(`Enriching data for organization: ${orgName}`);
      
      // First try Wikipedia
      const wikipediaData = await this.fetchWikipediaData(orgName, 'organization');
      if (wikipediaData) {
        return wikipediaData;
      }

      // Fallback: Use AI to generate basic organization profile
      return await this.generateBasicOrganizationProfile(orgName);
    } catch (error) {
      console.error(`Error enriching organization data for ${orgName}:`, error);
      return null;
    }
  }

  /**
   * Fetch data from Wikipedia API
   */
  private async fetchWikipediaData(entityName: string, entityType: 'company' | 'person' | 'organization'): Promise<EnrichmentData | null> {
    try {
      console.log(`Fetching Wikipedia data for ${entityName} (${entityType})`);
      
      // First try direct page lookup
      const searchUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(entityName)}`;
      
      const response = await fetch(searchUrl, {
        headers: {
          'User-Agent': 'Prismo Intelligence Platform/1.0 (competitive-intelligence@example.com)'
        }
      });

      if (!response.ok) {
        console.log(`Wikipedia direct search failed for ${entityName}: ${response.status}`);
        // Try search API if direct lookup fails
        return await this.searchWikipedia(entityName, entityType);
      }

      const data = await response.json();
      
      if (data.type === 'disambiguation') {
        console.log(`Wikipedia disambiguation page found for ${entityName}, trying search`);
        return await this.searchWikipedia(entityName, entityType);
      }

      console.log(`Wikipedia data found for ${entityName}:`, {
        title: data.title,
        hasImage: !!data.thumbnail,
        hasOriginalImage: !!data.originalimage
      });

      // Extract image URL with higher resolution preference
      let imageUrl = null;
      if (data.originalimage?.source) {
        imageUrl = data.originalimage.source;
      } else if (data.thumbnail?.source) {
        // Try to get higher resolution version
        imageUrl = data.thumbnail.source.replace(/\/\d+px-/, '/400px-');
      }

      // Crop image to square format if available
      let croppedImageUrl = null;
      if (imageUrl) {
        croppedImageUrl = await this.cropImageToSquare(imageUrl);
      }
      
      const enrichmentData = {
        name: data.title || entityName,
        description: data.extract || undefined,
        imageUrl: entityType === 'person' ? (croppedImageUrl || imageUrl) : undefined,
        logoUrl: (entityType === 'company' || entityType === 'organization') ? (croppedImageUrl || imageUrl) : undefined,
        website: data.content_urls?.desktop?.page || undefined,
        wikipediaUrl: data.content_urls?.desktop?.page || undefined,
        verified: true,
        source: 'Wikipedia',
        lastUpdated: new Date()
      };

      console.log(`Enrichment data for ${entityName}:`, {
        hasDescription: !!enrichmentData.description,
        hasImage: !!(enrichmentData.imageUrl || enrichmentData.logoUrl),
        imageUrl: enrichmentData.imageUrl || enrichmentData.logoUrl
      });

      return enrichmentData;
    } catch (error) {
      console.error(`Error fetching Wikipedia data for ${entityName}:`, error);
      return null;
    }
  }

  /**
   * Search Wikipedia when direct lookup fails
   */
  private async searchWikipedia(entityName: string, entityType: 'company' | 'person' | 'organization'): Promise<EnrichmentData | null> {
    try {
      // Add search terms to improve accuracy
      let searchTerm = entityName;
      if (entityType === 'company') {
        // For companies, add common identifiers
        if (entityName.toLowerCase() === 'tesla') {
          searchTerm = 'Tesla Inc';
        } else if (!entityName.includes('Inc') && !entityName.includes('Corp') && !entityName.includes('Company')) {
          searchTerm = `${entityName} company`;
        }
      }
      
      const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(searchTerm)}&srlimit=5`;
      
      const response = await fetch(searchUrl, {
        headers: {
          'User-Agent': 'Prismo Intelligence Platform/1.0 (competitive-intelligence@example.com)'
        }
      });

      if (!response.ok) {
        return null;
      }

      const data = await response.json();
      const searchResults = data.query?.search || [];
      
      if (searchResults.length === 0) {
        console.log(`No Wikipedia search results for ${entityName}`);
        return null;
      }

      // For companies, try to find the most relevant result
      let bestResult = searchResults[0];
      if (entityType === 'company') {
        const companyResult = searchResults.find((result: any) => 
          result.title.toLowerCase().includes('inc') || 
          result.title.toLowerCase().includes('corp') ||
          result.title.toLowerCase().includes('company') ||
          result.title.toLowerCase().includes('ltd')
        );
        if (companyResult) {
          bestResult = companyResult;
        }
      }

      console.log(`Using search result: ${bestResult.title} for ${entityName}`);
      return await this.fetchWikipediaData(bestResult.title, entityType);
    } catch (error) {
      console.error(`Error searching Wikipedia for ${entityName}:`, error);
      return null;
    }
  }

  /**
   * Generate basic company profile using AI when Wikipedia fails
   */
  private async generateBasicCompanyProfile(companyName: string): Promise<EnrichmentData> {
    try {
      const prompt = `Generate a concise business profile for the company "${companyName}". Based on your knowledge, provide:

1. A brief 2-3 sentence description of what the company does
2. Industry classification
3. Approximate founding year (if known)
4. Notable information about the company

Return ONLY a JSON object in this format:
{
  "description": "Brief company description",
  "industry": "Industry name",
  "founded": "Year or 'Unknown'",
  "keyFacts": ["Fact 1", "Fact 2"]
}

If you don't have reliable information about this company, return null.`;

      const response = await anthropic.messages.create({
        model: DEFAULT_MODEL_STR,
        max_tokens: 500,
        system: "You are a business intelligence researcher. Provide only verified, factual information about companies. If uncertain, indicate so clearly.",
        messages: [{ role: 'user', content: prompt }],
      });

      const content = (response.content[0] as any).text.trim();
      
      if (content === 'null' || content.toLowerCase().includes('don\'t have reliable information')) {
        throw new Error('No reliable data available');
      }

      const cleanContent = content
        .replace(/```json\s*/g, '')
        .replace(/```\s*/g, '')
        .trim();

      const aiData = JSON.parse(cleanContent);

      return {
        name: companyName,
        description: aiData.description,
        industry: aiData.industry,
        founded: aiData.founded !== 'Unknown' ? aiData.founded : undefined,
        verified: false,
        source: 'AI Analysis',
        lastUpdated: new Date()
      };
    } catch (error) {
      console.error(`Error generating AI company profile for ${companyName}:`, error);
      return {
        name: companyName,
        description: `Automatically detected company from intelligence analysis`,
        verified: false,
        source: 'Auto-detected',
        lastUpdated: new Date()
      };
    }
  }

  /**
   * Generate basic person profile using AI when Wikipedia fails
   */
  private async generateBasicPersonProfile(personName: string): Promise<EnrichmentData> {
    try {
      const prompt = `Generate a concise professional profile for the person "${personName}". Based on your knowledge, provide:

1. A brief 2-3 sentence description of their professional role/significance
2. Current or most notable position
3. Key achievements or notable facts

Return ONLY a JSON object in this format:
{
  "description": "Brief professional description",
  "position": "Current/notable position",
  "keyFacts": ["Achievement 1", "Achievement 2"]
}

If you don't have reliable information about this person, return null.`;

      const response = await anthropic.messages.create({
        model: DEFAULT_MODEL_STR,
        max_tokens: 500,
        system: "You are a professional researcher. Provide only verified, factual information about public figures. If uncertain, indicate so clearly.",
        messages: [{ role: 'user', content: prompt }],
      });

      const content = (response.content[0] as any).text.trim();
      
      if (content === 'null' || content.toLowerCase().includes('don\'t have reliable information')) {
        throw new Error('No reliable data available');
      }

      const cleanContent = content
        .replace(/```json\s*/g, '')
        .replace(/```\s*/g, '')
        .trim();

      const aiData = JSON.parse(cleanContent);

      return {
        name: personName,
        description: aiData.description,
        verified: false,
        source: 'AI Analysis',
        lastUpdated: new Date()
      };
    } catch (error) {
      console.error(`Error generating AI person profile for ${personName}:`, error);
      return {
        name: personName,
        description: `Automatically detected person from intelligence analysis`,
        verified: false,
        source: 'Auto-detected',
        lastUpdated: new Date()
      };
    }
  }

  /**
   * Fetch company logo from Clearbit API (free tier available)
   */
  private async fetchClearbitLogo(companyName: string): Promise<EnrichmentData | null> {
    try {
      // Clearbit provides free logo API
      const domain = await this.guessDomainFromCompany(companyName);
      if (!domain) return null;

      const logoUrl = `https://logo.clearbit.com/${domain}`;
      
      // Test if the logo exists
      const response = await fetch(logoUrl, { method: 'HEAD' });
      if (!response.ok) return null;

      console.log(`Found Clearbit logo for ${companyName}: ${logoUrl}`);
      
      // Crop the logo to square format
      const croppedUrl = await this.cropImageToSquare(logoUrl);

      return {
        name: companyName,
        logoUrl: croppedUrl || logoUrl,
        source: 'Clearbit Logo API',
        verified: true,
        lastUpdated: new Date()
      };
    } catch (error) {
      console.log(`Clearbit logo fetch failed for ${companyName}`);
      return null;
    }
  }

  /**
   * Fetch company logo from their website's favicon/logo
   */
  private async fetchCompanyWebsiteLogo(companyName: string): Promise<EnrichmentData | null> {
    try {
      const domain = await this.guessDomainFromCompany(companyName);
      if (!domain) return null;

      // Try common logo paths
      const logoPaths = [
        `https://${domain}/logo.png`,
        `https://${domain}/logo.svg`,
        `https://${domain}/assets/logo.png`,
        `https://${domain}/static/logo.png`,
        `https://${domain}/images/logo.png`,
        `https://${domain}/favicon.ico`
      ];

      for (const logoPath of logoPaths) {
        try {
          const response = await fetch(logoPath, { method: 'HEAD' });
          if (response.ok && response.headers.get('content-type')?.startsWith('image/')) {
            // Crop the logo to square format
            const croppedUrl = await this.cropImageToSquare(logoPath);
            
            return {
              name: companyName,
              logoUrl: croppedUrl || logoPath,
              website: `https://${domain}`,
              source: 'Company Website',
              verified: true,
              lastUpdated: new Date()
            };
          }
        } catch {
          continue;
        }
      }

      return null;
    } catch (error) {
      console.log(`Website logo fetch failed for ${companyName}`);
      return null;
    }
  }

  /**
   * Try to guess company domain from name (enhanced with common mappings)
   */
  private async guessDomainFromCompany(companyName: string): Promise<string | null> {
    const name = companyName.toLowerCase()
      .replace(/\s+(inc|corp|corporation|llc|ltd|limited|company|co)\.?$/i, '')
      .trim();

    // Common company domain mappings
    const domainMappings: { [key: string]: string } = {
      'tesla': 'tesla.com',
      'apple': 'apple.com',
      'microsoft': 'microsoft.com',
      'google': 'google.com',
      'alphabet': 'abc.xyz',
      'amazon': 'amazon.com',
      'meta': 'meta.com',
      'facebook': 'facebook.com',
      'nvidia': 'nvidia.com',
      'intel': 'intel.com',
      'amd': 'amd.com',
      'samsung': 'samsung.com',
      'sony': 'sony.com',
      'netflix': 'netflix.com',
      'spotify': 'spotify.com',
      'uber': 'uber.com',
      'lyft': 'lyft.com',
      'airbnb': 'airbnb.com',
      'twitter': 'twitter.com',
      'linkedin': 'linkedin.com',
      'tiktok': 'tiktok.com',
      'snapchat': 'snap.com',
      'zoom': 'zoom.us',
      'slack': 'slack.com',
      'salesforce': 'salesforce.com',
      'oracle': 'oracle.com',
      'ibm': 'ibm.com',
      'cisco': 'cisco.com',
      'paypal': 'paypal.com',
      'stripe': 'stripe.com',
      'shopify': 'shopify.com',
      'square': 'squareup.com',
      'dropbox': 'dropbox.com',
      'adobe': 'adobe.com'
    };

    if (domainMappings[name]) {
      return domainMappings[name];
    }

    // Fallback: generate likely domain
    return `${name.replace(/\s+/g, '')}.com`;
  }

  /**
   * Fetch LinkedIn profile photo (placeholder - would need LinkedIn API)
   */
  private async fetchLinkedInPhoto(personName: string): Promise<EnrichmentData | null> {
    // LinkedIn API requires authentication and business relationship
    // For now, return null to fallback to other sources
    return null;
  }

  /**
   * Fetch Crunchbase profile photo (placeholder - would need Crunchbase API)
   */
  private async fetchCrunchbasePhoto(personName: string): Promise<EnrichmentData | null> {
    // Crunchbase API requires paid subscription
    // For now, return null to fallback to other sources
    return null;
  }

  /**
   * Generate basic organization profile using AI when Wikipedia fails
   */
  private async generateBasicOrganizationProfile(orgName: string): Promise<EnrichmentData> {
    try {
      const prompt = `Generate a concise organizational profile for "${orgName}". Based on your knowledge, provide:

1. A brief 2-3 sentence description of what the organization does
2. Type of organization (non-profit, government agency, trade association, etc.)
3. Key focus areas or missions

Return ONLY a JSON object in this format:
{
  "description": "Brief organization description",
  "type": "Organization type",
  "keyFacts": ["Focus area 1", "Focus area 2"]
}

If you don't have reliable information about this organization, return null.`;

      const response = await anthropic.messages.create({
        model: DEFAULT_MODEL_STR,
        max_tokens: 500,
        system: "You are an organizational researcher. Provide only verified, factual information about organizations. If uncertain, indicate so clearly.",
        messages: [{ role: 'user', content: prompt }],
      });

      const content = (response.content[0] as any).text.trim();
      
      if (content === 'null' || content.toLowerCase().includes('don\'t have reliable information')) {
        throw new Error('No reliable data available');
      }

      const cleanContent = content
        .replace(/```json\s*/g, '')
        .replace(/```\s*/g, '')
        .trim();

      const aiData = JSON.parse(cleanContent);

      return {
        name: orgName,
        description: aiData.description,
        verified: false,
        source: 'AI Analysis',
        lastUpdated: new Date()
      };
    } catch (error) {
      console.error(`Error generating AI organization profile for ${orgName}:`, error);
      return {
        name: orgName,
        description: `Automatically detected organization from intelligence analysis`,
        verified: false,
        source: 'Auto-detected',
        lastUpdated: new Date()
      };
    }
  }
}