import { db } from "../db";
import { 
  intelligentAlerts, 
  userSpecs, 
  userBehaviors, 
  savedInsights, 
  alertPatterns,
  insights,
  entityMentions,
  companies,
  people,
  organizations,
  type IntelligentAlert,
  type InsertIntelligentAlert,
  type UserSpec,
  type InsertUserSpec,
  type UserBehavior,
  type InsertUserBehavior
} from "@shared/schema";
import { eq, and, desc, gte, sql, inArray } from "drizzle-orm";
import { ModelRouter } from "./modelRouter";
import { TaskType, createTaskContext } from "./modelRouter";

const modelRouter = new ModelRouter(process.env.OPENAI_API_KEY!);
import { persistentCostTracker } from "./persistentCostTracking";

export class IntelligentAlertsService {
  // Learn user preferences from their behavior patterns
  async learnUserPreferences(userId: string, sessionId?: string): Promise<void> {
    console.log(`Learning preferences for user ${userId}`);
    
    // Analyze recent user behaviors to infer preferences
    const recentBehaviors = await db
      .select()
      .from(userBehaviors)
      .where(eq(userBehaviors.userId, userId))
      .orderBy(desc(userBehaviors.timestamp))
      .limit(50);

    // For now, use simplified preference learning since we're transitioning to specs-based system
    console.log("Preference learning has been replaced by automatic specs learning system");

    // Note: This method is deprecated in favor of automatic specs learning
    return;
    
    // Update learned preferences in database
    for (const pattern of preferencePatterns) {
      await this.upsertUserPreference(userId, pattern);
    }
  }

  private analyzePreferencePatterns(behaviors: UserBehavior[], savedData: any[]): InsertUserPreference[] {
    const patterns: InsertUserPreference[] = [];
    
    // Analyze saved insights for category preferences
    const categoryFreq: Record<string, number> = {};
    savedData.forEach(item => {
      if (item.insight.category) {
        categoryFreq[item.insight.category] = (categoryFreq[item.insight.category] || 0) + 1;
      }
    });

    // Create category preferences
    Object.entries(categoryFreq).forEach(([category, count]) => {
      if (count >= 2) { // Minimum threshold for learning
        patterns.push({
          userId: behaviors[0]?.userId || '',
          preferenceType: 'category_interest',
          preferenceKey: category,
          weight: Math.min(count / 10, 1.0), // Normalize weight
          source: 'learned',
          confidence: count >= 5 ? 0.8 : 0.6,
          metadata: { learnedFromSaves: count }
        });
      }
    });

    // Analyze entity interactions
    const entityFreq: Record<string, number> = {};
    savedData.forEach(item => {
      if (item.mentions) {
        const key = `${item.mentions.entityType}:${item.mentions.entityId}`;
        entityFreq[key] = (entityFreq[key] || 0) + 1;
      }
    });

    // Create entity preferences
    Object.entries(entityFreq).forEach(([entityKey, count]) => {
      if (count >= 2) {
        patterns.push({
          userId: behaviors[0]?.userId || '',
          preferenceType: 'entity_follow',
          preferenceKey: entityKey,
          weight: Math.min(count / 8, 1.0),
          source: 'learned', 
          confidence: count >= 3 ? 0.9 : 0.7,
          metadata: { learnedFromSaves: count }
        });
      }
    });

    return patterns;
  }

  private async upsertUserPreference(userId: string, preference: InsertUserPreference): Promise<void> {
    // Check if preference already exists
    const existing = await db
      .select()
      .from(userPreferences)
      .where(and(
        eq(userPreferences.userId, userId),
        eq(userPreferences.preferenceType, preference.preferenceType),
        eq(userPreferences.preferenceKey, preference.preferenceKey)
      ))
      .limit(1);

    if (existing.length > 0) {
      // Update existing preference - reinforce learning
      await db
        .update(userPreferences)
        .set({
          weight: Math.min((existing[0].weight || 0) + (preference.weight || 0) * 0.3, 1.0),
          confidence: Math.min((existing[0].confidence || 0) + 0.1, 1.0),
          lastReinforced: new Date(),
          updatedAt: new Date()
        })
        .where(eq(userPreferences.id, existing[0].id));
    } else {
      // Create new preference
      await db.insert(userPreferences).values(preference);
    }
  }

  // Track user behavior for learning
  async trackUserBehavior(behavior: InsertUserBehavior): Promise<void> {
    await db.insert(userBehaviors).values(behavior);
    
    // Periodically learn from accumulated behaviors
    const behaviorCount = await db
      .select({ count: sql<number>`count(*)` })
      .from(userBehaviors)
      .where(eq(userBehaviors.userId, behavior.userId))
      .then(rows => rows[0]?.count || 0);

    // Re-learn preferences every 10 behaviors
    if (behaviorCount % 10 === 0) {
      await this.learnUserPreferences(behavior.userId, behavior.sessionId || undefined);
    }
  }

  // Get user preferences for alert generation
  async getUserPreferences(userId: string): Promise<UserPreference[]> {
    return await db
      .select()
      .from(userPreferences)
      .where(and(
        eq(userPreferences.userId, userId),
        eq(userPreferences.isActive, true)
      ))
      .orderBy(desc(userPreferences.weight));
  }

  // Generate alerts by synthesizing insights based on user preferences
  async generateIntelligentAlerts(userId: string): Promise<void> {
    console.log(`Generating intelligent alerts for user ${userId}`);
    
    // Get user preferences
    let preferences = await this.getUserPreferences(userId);
    
    // If no preferences exist, create some default ones based on recent high-priority insights
    if (preferences.length === 0) {
      console.log('No user preferences found, creating default preferences based on recent insights');
      await this.createDefaultPreferences(userId);
      preferences = await this.getUserPreferences(userId);
    }

    // Find high-impact insights from the last 24 hours that match user preferences
    const recentInsights = await this.getRelevantInsights(userId, preferences);
    
    if (recentInsights.length < 2) {
      console.log('Insufficient matching insights, getting broader set for synthesis');
      const broaderInsights = await this.getBroaderInsights();
      if (broaderInsights.length >= 2) {
        const synthesisGroups = await this.identifySynthesisOpportunities(broaderInsights, preferences);
        await this.processSynthesisGroups(userId, synthesisGroups, preferences);
      }
      return;
    }

    // Group insights by potential synthesis patterns
    const synthesisGroups = await this.identifySynthesisOpportunities(recentInsights, preferences);
    
    // Process synthesis groups and generate alerts
    await this.processSynthesisGroups(userId, synthesisGroups, preferences);
    
    // Generate alerts for each synthesis opportunity
    for (const group of synthesisGroups) {
      const alert = await this.synthesizeAlert(userId, group, preferences);
      if (alert && alert.relevanceScore >= 0.7) { // Only create high-relevance alerts
        await this.createAlert(alert);
      }
    }
  }

  private async getRelevantInsights(userId: string, preferences: UserPreference[]) {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    // Get entity preferences for filtering
    const entityPreferences = preferences
      .filter(p => p.preferenceType === 'entity_follow')
      .map(p => p.preferenceKey);
    
    // Get category preferences
    const categoryPreferences = preferences
      .filter(p => p.preferenceType === 'category_interest')
      .map(p => p.preferenceKey);

    // Build query conditions
    const baseConditions = [
      gte(insights.createdAt, oneDayAgo),
      inArray(insights.priority, ['high', 'critical'])
    ];

    // Add category filter if user has category preferences
    if (categoryPreferences.length > 0) {
      baseConditions.push(inArray(insights.category, categoryPreferences));
    }

    // Query insights with entity mentions matching user preferences
    const results = await db
      .select({
        insight: insights,
        mention: entityMentions
      })
      .from(insights)
      .leftJoin(entityMentions, eq(insights.id, entityMentions.insightId))
      .where(and(...baseConditions))
      .limit(50);
    
    // Filter by entity preferences
    return results.filter(item => {
      if (!item.mention) return true; // Include insights without entity mentions
      const entityKey = `${item.mention.entityType}:${item.mention.entityId}`;
      return entityPreferences.includes(entityKey);
    });
  }

  private async identifySynthesisOpportunities(insights: any[], preferences: UserPreference[]) {
    const groups: Array<{
      type: string,
      insights: any[],
      pattern: string,
      strength: number
    }> = [];

    // Group by common entities
    const entityGroups: Record<string, any[]> = {};
    insights.forEach(item => {
      if (item.mention) {
        const key = `${item.mention.entityType}:${item.mention.entityId}`;
        if (!entityGroups[key]) entityGroups[key] = [];
        entityGroups[key].push(item);
      }
    });

    // Create synthesis groups for entities with multiple mentions
    Object.entries(entityGroups).forEach(([entityKey, items]) => {
      if (items.length >= 2) {
        groups.push({
          type: 'entity_correlation',
          insights: items,
          pattern: `Multiple developments around ${entityKey}`,
          strength: Math.min(items.length / 5, 1.0)
        });
      }
    });

    // Group by categories for trend analysis
    const categoryGroups: Record<string, any[]> = {};
    insights.forEach(item => {
      if (item.insight.category) {
        if (!categoryGroups[item.insight.category]) categoryGroups[item.insight.category] = [];
        categoryGroups[item.insight.category].push(item);
      }
    });

    // Create synthesis groups for trending categories
    Object.entries(categoryGroups).forEach(([category, items]) => {
      if (items.length >= 3) {
        groups.push({
          type: 'trend_shift',
          insights: items,
          pattern: `Emerging trend in ${category}`,
          strength: Math.min(items.length / 8, 1.0)
        });
      }
    });

    return groups.filter(g => g.strength >= 0.4);
  }

  // Create default preferences based on recent high-priority insights
  private async createDefaultPreferences(userId: string): Promise<void> {
    const recentHighPriorityInsights = await db
      .select()
      .from(insights)
      .where(inArray(insights.priority, ['high', 'critical']))
      .orderBy(desc(insights.createdAt))
      .limit(50);

    const categoryFreq: Record<string, number> = {};
    recentHighPriorityInsights.forEach(insight => {
      if (insight.category) {
        categoryFreq[insight.category] = (categoryFreq[insight.category] || 0) + 1;
      }
    });

    // Create preferences for top categories
    const topCategories = Object.entries(categoryFreq)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5);

    for (const [category, count] of topCategories) {
      await this.upsertUserPreference(userId, {
        userId,
        preferenceType: 'category_interest',
        preferenceKey: category,
        weight: Math.min(count / 10, 0.8),
        source: 'default',
        confidence: 0.6,
        metadata: { createdFromDefaults: true, insightCount: count }
      });
    }
  }

  // Get broader insights when user preferences don't match enough data
  private async getBroaderInsights() {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    return await db
      .select({
        insight: insights,
        mention: entityMentions
      })
      .from(insights)
      .leftJoin(entityMentions, eq(insights.id, entityMentions.insightId))
      .where(and(
        gte(insights.createdAt, oneDayAgo),
        inArray(insights.priority, ['high', 'critical'])
      ))
      .orderBy(desc(insights.priority), desc(insights.createdAt))
      .limit(20);
  }

  // Process synthesis groups and generate alerts
  private async processSynthesisGroups(userId: string, synthesisGroups: any[], preferences: UserPreference[]): Promise<void> {
    for (const group of synthesisGroups) {
      const alert = await this.synthesizeAlert(userId, group, preferences);
      if (alert) {
        await db.insert(intelligentAlerts).values(alert);
        console.log(`Generated alert: ${alert.title}`);
      }
    }
  }

  private async synthesizeAlert(userId: string, group: any, preferences: UserPreference[]): Promise<InsertIntelligentAlert | null> {
    try {
      // Prepare context for AI synthesis
      const insightSummaries = group.insights.map((item: any) => ({
        title: item.insight.title,
        summary: item.insight.summary,
        category: item.insight.category,
        sentiment: item.insight.sentiment,
        priority: item.insight.priority,
        source: item.insight.source
      }));

      const context = createTaskContext(TaskType.COMPETITIVE_INTELLIGENCE, {
        priority: 'high',
        contentLength: JSON.stringify(insightSummaries).length,
        budgetConstraint: 'moderate',
        qualityRequirement: 'premium',
        timeConstraint: 'normal'
      });

      // Generate synthesized insight using AI
      const { response, cost } = await modelRouter.makeOptimizedCall(
        context,
        [
          {
            role: "system",
            content: `You are a world-class industry analyst. Your task is to synthesize multiple data points into a single, actionable intelligence alert.

CRITICAL: This is NOT a notification or summary. This is synthesized intelligence that "connects the dots" using deeper context.

Requirements:
- Title: Clear, analyst-quality title (max 80 chars)
- Insight: The synthesized intelligence - what patterns/connections emerge when you analyze these data points together? What does this really mean? (2-3 sentences)
- Actionability: Specific action the user should consider based on this intelligence (1-2 sentences)
- Market Context: Brief broader market/industry context (1 sentence)

Pattern type: ${group.pattern}
Respond in JSON format with keys: title, insight, actionability, marketContext, confidence`
          },
          {
            role: "user",
            content: `Synthesize these related insights into actionable intelligence:

${insightSummaries.map((s: any, i: number) => 
  `${i + 1}. ${s.title} (${s.category}, ${s.sentiment} sentiment, ${s.priority} priority)
   Summary: ${s.summary}
   Source: ${s.source}`
).join('\n\n')}`
          }
        ],
        500
      );

      // Track the synthesis cost
      await persistentCostTracker.recordCost({
        operation: 'alert_synthesis', 
        modelName: 'gpt-4o-mini',
        inputTokens: 0,
        outputTokens: 0,
        cost: cost,
        priority: 'high',
        success: true,
        metadata: { synthesisType: group.type, insightCount: group.insights.length }
      });

      const synthesis = JSON.parse(response.choices[0].message.content || '{}');
      
      // Calculate relevance score based on user preferences
      const relevanceScore = this.calculateRelevanceScore(group, preferences);
      
      return {
        userId,
        title: synthesis.title || 'Market Intelligence Alert',
        insight: synthesis.insight || 'Multiple data points suggest emerging patterns requiring attention.',
        actionability: synthesis.actionability || 'Monitor developments and assess strategic implications.',
        priority: group.strength >= 0.8 ? 'critical' : group.strength >= 0.6 ? 'high' : 'medium',
        confidence: synthesis.confidence || 0.7,
        relevanceScore,
        triggerEntities: group.insights
          .filter((i: any) => i.mention)
          .map((i: any) => ({
            type: i.mention.entityType,
            id: i.mention.entityId
          })),
        relatedInsights: group.insights.map((i: any) => i.insight.id),
        trendAnalysis: {
          patternType: group.type,
          strength: group.strength,
          dataPoints: group.insights.length
        },
        marketContext: synthesis.marketContext || ''
      };
    } catch (error) {
      console.error('Failed to synthesize alert:', error);
      return null;
    }
  }

  private calculateRelevanceScore(group: any, preferences: UserPreference[]): number {
    let score = 0.0;
    let maxWeight = 0.0;

    // Check entity relevance
    group.insights.forEach((item: any) => {
      if (item.mention) {
        const entityKey = `${item.mention.entityType}:${item.mention.entityId}`;
        const preference = preferences.find(p => 
          p.preferenceType === 'entity_follow' && p.preferenceKey === entityKey
        );
        if (preference) {
          score += (preference.weight || 0) * (preference.confidence || 0);
          maxWeight += preference.weight || 0;
        }
      }
    });

    // Check category relevance
    const categories = Array.from(new Set(group.insights.map((i: any) => i.insight.category)));
    categories.forEach(category => {
      const preference = preferences.find(p => 
        p.preferenceType === 'category_interest' && p.preferenceKey === category
      );
      if (preference) {
        score += (preference.weight || 0) * (preference.confidence || 0);
        maxWeight += preference.weight || 0;
      }
    });

    return maxWeight > 0 ? Math.min(score / maxWeight, 1.0) : 0.5;
  }

  private async createAlert(alert: InsertIntelligentAlert): Promise<void> {
    await db.insert(intelligentAlerts).values(alert);
    console.log(`Created intelligent alert: ${alert.title}`);
  }

  // Get alerts for a user
  async getUserAlerts(userId: string, includeRead: boolean = false): Promise<IntelligentAlert[]> {
    let query = db
      .select()
      .from(intelligentAlerts)
      .where(eq(intelligentAlerts.userId, userId));

    if (!includeRead) {
      return await db
        .select()
        .from(intelligentAlerts)
        .where(and(
          eq(intelligentAlerts.userId, userId),
          eq(intelligentAlerts.isRead, false),
          eq(intelligentAlerts.isArchived, false)
        ))
        .orderBy(desc(intelligentAlerts.createdAt))
        .limit(20);
    }

    return await query
      .orderBy(desc(intelligentAlerts.createdAt))
      .limit(20);
  }

  // Mark alert as read and collect feedback
  async markAlertRead(alertId: string, userId: string, feedback?: string): Promise<void> {
    await db
      .update(intelligentAlerts)
      .set({ 
        isRead: true,
        userFeedback: feedback
      })
      .where(and(
        eq(intelligentAlerts.id, alertId),
        eq(intelligentAlerts.userId, userId)
      ));
  }

  // Archive alert
  async archiveAlert(alertId: string, userId: string): Promise<void> {
    await db
      .update(intelligentAlerts)
      .set({ isArchived: true })
      .where(and(
        eq(intelligentAlerts.id, alertId),
        eq(intelligentAlerts.userId, userId)
      ));
  }
}

export const intelligentAlertsService = new IntelligentAlertsService();