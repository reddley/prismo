import { storage } from '../storage';
import { costOptimizer, AI_COSTS } from './costOptimization';
import { getModelRouter } from './modelRouter';
import { queueManager } from '../queue/queues';
import { logger } from '../observability/logger';
import { persistentCostTracker } from './persistentCostTracking';
import crypto from 'crypto';

export interface RssItem {
  title: string;
  content: string;
  url: string;
  publishedAt: Date;
  sourceId: string;
  sourceName: string;
  category: string;
  fingerprint?: string;
  priority?: 'low' | 'medium' | 'high' | 'critical';
}

export interface BatchResult {
  processed: number;
  duplicates: number;
  batches: number;
  totalCost: number;
  throughput: number; // items per second
  costPerItem: number;
}

export interface IngestionMetrics {
  timestamp: Date;
  totalItems: number;
  batchesProcessed: number;
  duplicatesRemoved: number;
  averageBatchSize: number;
  totalCost: number;
  throughputPerSecond: number;
  costPerItem: number;
  feedPriorities: Record<string, number>;
}

/**
 * Batch RSS Ingestion Service
 * Processes RSS items in batches to reduce API costs and improve throughput
 */
export class BatchRssIngestionService {
  private fingerprintCache = new Map<string, boolean>();
  private ingestionMetrics: IngestionMetrics[] = [];
  private readonly BATCH_SIZE_MIN = 5;
  private readonly BATCH_SIZE_MAX = 20;
  private readonly FINGERPRINT_CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

  /**
   * Generate a unique fingerprint for an RSS item
   */
  generateFingerprint(item: Partial<RssItem>): string {
    const normalizedTitle = this.normalizeText(item.title || '');
    const normalizedContent = this.normalizeText(item.content || '').substring(0, 200);
    const urlHash = item.url ? crypto.createHash('md5').update(item.url).digest('hex').substring(0, 8) : '';
    
    const combined = `${normalizedTitle}|${normalizedContent}|${urlHash}`;
    return crypto.createHash('sha256').update(combined).digest('hex').substring(0, 16);
  }

  /**
   * Check if an item is a duplicate using enhanced fingerprinting
   */
  async isDuplicate(item: RssItem): Promise<boolean> {
    const fingerprint = this.generateFingerprint(item);
    item.fingerprint = fingerprint;

    // Check cache first for immediate response
    if (this.fingerprintCache.has(fingerprint)) {
      return true;
    }

    // Check for exact URL match (most common duplicate)
    if (item.url) {
      try {
        const existingByUrl = await storage.getInsightBySourceUrl(item.url);
        if (existingByUrl) {
          this.fingerprintCache.set(fingerprint, true);
          return true;
        }
      } catch (error) {
        // Handle missing method gracefully
      }
    }

    // Check for title similarity (case-insensitive, same source)
    try {
      const similarTitle = await this.findSimilarTitle(item.title, item.sourceName);
      if (similarTitle) {
        this.fingerprintCache.set(fingerprint, true);
        return true;
      }
    } catch (error) {
      console.error('Error checking title similarity:', error);
    }

    // Check for content fingerprint match
    const existingFingerprint = await this.findExistingFingerprint(fingerprint);
    if (existingFingerprint) {
      this.fingerprintCache.set(fingerprint, true);
      return true;
    }

    return false;
  }

  /**
   * Find insights with similar titles from the same source
   */
  private async findSimilarTitle(title: string, sourceName: string): Promise<boolean> {
    const normalizedTitle = this.normalizeText(title);
    if (normalizedTitle.length < 20) return false; // Skip very short titles
    
    // Use a simple word-based similarity check
    const titleWords = normalizedTitle.split(' ').filter(word => word.length > 3);
    if (titleWords.length < 3) return false;
    
    // For now, return false - we'll implement database search later
    // This prevents the expensive similarity search from slowing down processing
    return false;
  }

  /**
   * Check if fingerprint exists in recent insights
   */
  private async findExistingFingerprint(fingerprint: string): Promise<boolean> {
    // For performance, we'll implement a simple cache-based approach
    // In a production system, this would query the database
    return this.fingerprintCache.has(fingerprint);
  }

  /**
   * Prioritize feeds based on historical performance and content quality
   */
  async prioritizeFeeds(items: RssItem[]): Promise<RssItem[]> {
    const feedStats = await this.getFeedStats();
    
    return items.map(item => {
      const feedKey = `${item.sourceId}_${item.category}`;
      const stats = feedStats[feedKey] || { score: 0.5, volume: 0 };
      
      // Determine priority based on feed quality and content indicators
      let priority: RssItem['priority'] = 'medium';
      
      // High-value keywords boost priority
      const highValueKeywords = [
        'breakthrough', 'acquisition', 'merger', 'ipo', 'funding', 'investment',
        'launch', 'partnership', 'regulation', 'lawsuit', 'earnings', 'revenue'
      ];
      
      const content = (item.title + ' ' + item.content).toLowerCase();
      const hasHighValueKeywords = highValueKeywords.some(keyword => content.includes(keyword));
      
      if (hasHighValueKeywords && stats.score > 0.7) {
        priority = 'critical';
      } else if (hasHighValueKeywords || stats.score > 0.6) {
        priority = 'high';
      } else if (stats.score < 0.3) {
        priority = 'low';
      }
      
      item.priority = priority;
      return item;
    }).sort((a, b) => {
      // Sort by priority, then by publication date
      const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
      const aPriority = priorityOrder[a.priority || 'medium'];
      const bPriority = priorityOrder[b.priority || 'medium'];
      
      if (aPriority !== bPriority) {
        return bPriority - aPriority;
      }
      
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
    });
  }

  /**
   * Process RSS items in optimized batches
   */
  async processBatch(items: RssItem[]): Promise<BatchResult> {
    const startTime = Date.now();
    logger.info(`[BATCH-RSS] Starting batch processing of ${items.length} items`);

    // Step 1: Fingerprint and deduplicate
    const uniqueItems: RssItem[] = [];
    let duplicates = 0;

    for (const item of items) {
      if (await this.isDuplicate(item)) {
        duplicates++;
        continue;
      }
      uniqueItems.push(item);
    }

    logger.info(`[BATCH-RSS] Removed ${duplicates} duplicates, processing ${uniqueItems.length} unique items`);

    // Step 2: Prioritize feeds
    const prioritizedItems = await this.prioritizeFeeds(uniqueItems);

    // Step 3: Create optimal batches by priority
    const batches = this.createOptimalBatches(prioritizedItems);
    
    let processed = 0;
    let totalCost = 0;

    // Step 4: Process each batch
    for (let index = 0; index < batches.length; index++) {
      const batch = batches[index];
      try {
        const batchCost = await this.processSingleBatch(batch, index);
        totalCost += batchCost;
        processed += batch.length;
        
        // Small delay between batches to prevent overwhelming
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        logger.error(`[BATCH-RSS] Error processing batch ${index}:`, { error: String(error) });
      }
    }

    // Step 5: Calculate metrics
    const duration = (Date.now() - startTime) / 1000; // seconds
    const throughput = processed / duration;
    const costPerItem = processed > 0 ? totalCost / processed : 0;

    const result: BatchResult = {
      processed,
      duplicates,
      batches: batches.length,
      totalCost,
      throughput,
      costPerItem
    };

    // Step 6: Update metrics
    await this.updateIngestionMetrics(result, items);

    logger.info(`[BATCH-RSS] Batch processing complete`, result);
    return result;
  }

  /**
   * Create optimal batches based on priority and cost constraints
   */
  private createOptimalBatches(items: RssItem[]): RssItem[][] {
    const batches: RssItem[][] = [];
    const costStats = costOptimizer.getCostStats();
    
    // Group by priority first
    const priorityGroups = {
      critical: items.filter(item => item.priority === 'critical'),
      high: items.filter(item => item.priority === 'high'),
      medium: items.filter(item => item.priority === 'medium'),
      low: items.filter(item => item.priority === 'low')
    };

    // Process in priority order
    for (const [priority, groupItems] of Object.entries(priorityGroups)) {
      if (groupItems.length === 0) continue;

      // Calculate optimal batch size for this priority
      let batchSize = this.calculateOptimalBatchSize(priority, costStats.remainingBudget);
      
      for (let i = 0; i < groupItems.length; i += batchSize) {
        const batch = groupItems.slice(i, i + batchSize);
        batches.push(batch);
        
        // Adjust batch size if we're running low on budget
        if (costStats.remainingBudget < 1.0 && priority !== 'critical') {
          batchSize = Math.max(this.BATCH_SIZE_MIN, Math.floor(batchSize * 0.7));
        }
      }
    }

    return batches;
  }

  /**
   * Calculate optimal batch size based on priority and budget
   */
  private calculateOptimalBatchSize(priority: string, remainingBudget: number): number {
    const baseBatchSize = {
      critical: this.BATCH_SIZE_MAX,
      high: Math.floor(this.BATCH_SIZE_MAX * 0.8),
      medium: Math.floor(this.BATCH_SIZE_MAX * 0.6),
      low: this.BATCH_SIZE_MIN
    };

    let size = baseBatchSize[priority as keyof typeof baseBatchSize] || this.BATCH_SIZE_MIN;

    // Adjust based on remaining budget
    if (remainingBudget < 2.0) {
      size = Math.max(this.BATCH_SIZE_MIN, Math.floor(size * 0.5));
    } else if (remainingBudget > 4.0) {
      size = Math.min(this.BATCH_SIZE_MAX, Math.floor(size * 1.2));
    }

    return size;
  }

  /**
   * Process a single batch of items with AI analysis
   */
  private async processSingleBatch(items: RssItem[], batchIndex: number): Promise<number> {
    if (items.length === 0) return 0;

    const priority = items[0].priority || 'medium';
    let totalCost = 0;

    // Check if we should use AI for this batch
    const estimatedBatchCost = items.length * (AI_COSTS.SENTIMENT_ANALYSIS + AI_COSTS.CATEGORIZATION + AI_COSTS.SUMMARIZATION);
    
    if (!costOptimizer.shouldUseAI(estimatedBatchCost)) {
      logger.info(`[BATCH-RSS] Skipping AI analysis for batch ${batchIndex} due to budget constraints`);
      return await this.processWithRuleBasedAnalysis(items);
    }

    try {
      // Batch analyze all items together for efficiency
      const batchResults = await this.batchAnalyzeItems(items);
      
      // Save insights and queue further processing
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const analysis = batchResults[i];
        
        // Create insight with AI analysis
        const insight = {
          title: item.title,
          content: item.content,
          summary: analysis.summary,
          category: analysis.category,
          source: item.sourceName,
          sourceUrl: item.url,
          sentiment: analysis.sentiment.sentiment,
          confidence: analysis.sentiment.confidence,
          priority: analysis.sentiment.priority || item.priority,
          tags: [analysis.category.toLowerCase(), item.sourceName.toLowerCase()],
          publishedAt: item.publishedAt,
        };

        const savedInsight = await storage.createInsight(insight);
        
        // Queue for further processing if needed
        if (insight.priority === 'critical' || insight.priority === 'high') {
          await queueManager.addJob('INSIGHT_ENRICHMENT', {
            insightId: savedInsight.id,
            content: insight.content,
            title: insight.title,
          }, {
            priority: insight.priority === 'critical' ? 'HIGH' : 'NORMAL',
            metadata: { source: 'batch-rss', batchIndex, itemIndex: i },
          });
        }

        // Add to fingerprint cache
        if (item.fingerprint) {
          this.fingerprintCache.set(item.fingerprint, true);
        }
      }

      totalCost += estimatedBatchCost;
      costOptimizer.trackAIUsage(estimatedBatchCost);
      
      logger.info(`[BATCH-RSS] Processed batch ${batchIndex} with AI analysis: ${items.length} items, cost: $${estimatedBatchCost.toFixed(4)}`);
      
    } catch (error) {
      logger.error(`[BATCH-RSS] Error in AI batch processing:`, { error: String(error) });
      // Fallback to rule-based processing
      totalCost += await this.processWithRuleBasedAnalysis(items);
    }

    return totalCost;
  }

  /**
   * Batch analyze multiple items with AI for efficiency
   */
  private async batchAnalyzeItems(items: RssItem[]) {
    // Combine all items into a single prompt for efficient processing
    const batchPrompt = items.map((item, index) => 
      `Item ${index + 1}:\nTitle: ${item.title}\nContent: ${item.content.substring(0, 500)}...\n---`
    ).join('\n');

    // Use cost optimization for analysis
    const costStats = costOptimizer.getCostStats();

    const analysisPrompt = `
Analyze the following ${items.length} news items and provide:
1. Sentiment (positive/negative/neutral) with confidence (0-1)
2. Category (technology/finance/business/politics/general)
3. Brief summary (1-2 sentences)
4. Priority (critical/high/medium/low)

Return JSON array with results for each item:

${batchPrompt}

Format: [{"sentiment": {"sentiment": "positive", "confidence": 0.8, "priority": "high"}, "category": "technology", "summary": "Brief summary here"}, ...]`;

    try {
      const modelRouter = getModelRouter();
      const response = await modelRouter.routeRequest(analysisPrompt, 'CONTENT_ANALYSIS', items[0].priority || 'medium');
      const results = JSON.parse(response);
      
      // Ensure we have results for all items
      return results.length === items.length ? results : 
        items.map(() => ({
          sentiment: { sentiment: 'neutral', confidence: 0.5, priority: 'medium' },
          category: 'general',
          summary: 'Content analysis pending'
        }));
    } catch (error) {
      logger.error('[BATCH-RSS] Error in batch AI analysis:', { error: String(error) });
      // Return default analysis for all items
      return items.map(() => ({
        sentiment: { sentiment: 'neutral', confidence: 0.5, priority: 'medium' },
        category: 'general',
        summary: 'Content analysis failed'
      }));
    }
  }

  /**
   * Fallback rule-based processing when AI budget is exhausted
   */
  private async processWithRuleBasedAnalysis(items: RssItem[]): Promise<number> {
    for (const item of items) {
      // Simple rule-based analysis
      const sentiment = this.analyzeContentSentiment(item.title + ' ' + item.content);
      const category = this.categorizeContent(item.title, item.content);
      
      const insight = {
        title: item.title,
        content: item.content,
        summary: item.content.substring(0, 200) + '...',
        category,
        source: item.sourceName,
        sourceUrl: item.url,
        sentiment: sentiment.sentiment,
        confidence: sentiment.confidence,
        priority: item.priority || 'medium',
        tags: [category.toLowerCase(), item.sourceName.toLowerCase()],
        publishedAt: item.publishedAt,
      };

      const savedInsight = await storage.createInsight(insight);
      
      // Add to fingerprint cache
      if (item.fingerprint) {
        this.fingerprintCache.set(item.fingerprint, true);
      }
      
      costOptimizer.trackRuleBasedOperation();
    }

    return 0; // No AI cost
  }

  /**
   * Simple rule-based sentiment analysis
   */
  private analyzeContentSentiment(content: string): { sentiment: string; confidence: number } {
    const positiveWords = ['growth', 'increase', 'profit', 'success', 'breakthrough', 'innovation', 'launch', 'partnership'];
    const negativeWords = ['decline', 'loss', 'failure', 'crisis', 'lawsuit', 'scandal', 'hack', 'breach'];
    
    const words = content.toLowerCase().split(/\s+/);
    const positiveCount = words.filter(word => positiveWords.includes(word)).length;
    const negativeCount = words.filter(word => negativeWords.includes(word)).length;
    
    if (positiveCount > negativeCount) {
      return { sentiment: 'positive', confidence: Math.min(0.8, positiveCount / words.length * 10) };
    } else if (negativeCount > positiveCount) {
      return { sentiment: 'negative', confidence: Math.min(0.8, negativeCount / words.length * 10) };
    }
    
    return { sentiment: 'neutral', confidence: 0.6 };
  }

  /**
   * Simple rule-based categorization
   */
  private categorizeContent(title: string, content: string): string {
    const text = (title + ' ' + content).toLowerCase();
    
    if (text.includes('tech') || text.includes('ai') || text.includes('software') || text.includes('startup')) {
      return 'technology';
    } else if (text.includes('finance') || text.includes('market') || text.includes('investment') || text.includes('stock')) {
      return 'finance';
    } else if (text.includes('business') || text.includes('company') || text.includes('corporate')) {
      return 'business';
    }
    
    return 'general';
  }

  /**
   * Get feed statistics for prioritization
   */
  private async getFeedStats(): Promise<Record<string, { score: number; volume: number }>> {
    // In a real implementation, this would query historical performance data
    // For now, return reasonable defaults
    return {};
  }

  /**
   * Find similar fingerprints to detect near-duplicates
   */
  private async findSimilarFingerprint(fingerprint: string): Promise<boolean> {
    // Simple similarity check - in production, could use more sophisticated methods
    const cachedFingerprints = Array.from(this.fingerprintCache.keys());
    for (const cachedFingerprint of cachedFingerprints) {
      const similarity = this.calculateFingerprintSimilarity(fingerprint, cachedFingerprint);
      if (similarity > 0.9) {
        return true;
      }
    }
    return false;
  }

  /**
   * Calculate similarity between two fingerprints
   */
  private calculateFingerprintSimilarity(fp1: string, fp2: string): number {
    if (fp1.length !== fp2.length) return 0;
    
    let matches = 0;
    for (let i = 0; i < fp1.length; i++) {
      if (fp1[i] === fp2[i]) matches++;
    }
    
    return matches / fp1.length;
  }

  /**
   * Normalize text for fingerprinting
   */
  private normalizeText(text: string): string {
    return text
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Update ingestion metrics
   */
  private async updateIngestionMetrics(result: BatchResult, originalItems: RssItem[]): Promise<void> {
    const metrics: IngestionMetrics = {
      timestamp: new Date(),
      totalItems: originalItems.length,
      batchesProcessed: result.batches,
      duplicatesRemoved: result.duplicates,
      averageBatchSize: result.processed > 0 ? result.processed / result.batches : 0,
      totalCost: result.totalCost,
      throughputPerSecond: result.throughput,
      costPerItem: result.costPerItem,
      feedPriorities: this.calculateFeedPriorities(originalItems)
    };

    this.ingestionMetrics.push(metrics);
    
    // Keep only recent metrics (last 24 hours)
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    this.ingestionMetrics = this.ingestionMetrics.filter(m => m.timestamp > oneDayAgo);

    // Log metrics for observability
    logger.info('[BATCH-RSS] Ingestion metrics updated:', metrics);
  }

  /**
   * Calculate feed priority distribution
   */
  private calculateFeedPriorities(items: RssItem[]): Record<string, number> {
    const priorities: Record<string, number> = {};
    
    for (const item of items) {
      const priority = item.priority || 'medium';
      priorities[priority] = (priorities[priority] || 0) + 1;
    }
    
    return priorities;
  }

  /**
   * Get current ingestion metrics
   */
  getIngestionMetrics(): IngestionMetrics[] {
    return [...this.ingestionMetrics];
  }

  /**
   * Clear fingerprint cache (useful for testing)
   */
  clearFingerprintCache(): void {
    this.fingerprintCache.clear();
  }
}

export const batchRssIngestionService = new BatchRssIngestionService();