// RSS processing service for queue-based ingestion
import Parser from 'rss-parser';
import { storage } from '../storage';
import { queueManager } from '../queue/queues';
// Job types are handled as strings in the queue system
import { featureFlagService } from './feature-flags';
import { batchRssIngestionService, type RssItem } from './batch-rss-ingestion';
import { logger } from '../observability/logger';

const parser = new Parser({
  timeout: 10000,
  headers: {
    'User-Agent': 'Prismo/1.0 (+https://prismo.ai)',
  },
});

export async function processRssFeed(sourceId: string, feedUrl: string): Promise<{
  processed: number;
  errors: number;
  newInsights: number;
}> {
  try {
    // Check if data ingestion is paused
    console.log(`[RSS-DEBUG] About to check if data ingestion is paused`);
    if (await featureFlagService.isDataIngestionPaused()) {
      console.log('⏸️  Data ingestion is paused - skipping RSS feed processing');
      return { processed: 0, errors: 0, newInsights: 0 };
    }
  } catch (error) {
    console.error(`[RSS-DEBUG] Error checking data ingestion pause:`, error);
    // Continue processing if the check fails
  }

  console.log(`[RSS] Processing feed: ${feedUrl} (source: ${sourceId})`);
  
  let processed = 0;
  let errors = 0;
  let newInsights = 0;

  try {
    // Get data source details
    const dataSource = await storage.getDataSource(sourceId);
    if (!dataSource) {
      throw new Error(`Data source not found: ${sourceId}`);
    }

    // Parse RSS feed
    const feed = await parser.parseURL(feedUrl);
    console.log(`[RSS] Found ${feed.items.length} items in feed: ${dataSource.name}`);

    // Get max insights per batch from feature flags
    let maxInsightsPerBatch = 50;
    try {
      console.log(`[RSS-DEBUG] About to call getFlag for MAX_INSIGHTS_PER_BATCH`);
      maxInsightsPerBatch = await featureFlagService.getFlag('MAX_INSIGHTS_PER_BATCH', 50) as number;
      console.log(`[RSS] Using feature flag MAX_INSIGHTS_PER_BATCH: ${maxInsightsPerBatch}`);
    } catch (error) {
      console.error(`[RSS] Failed to get feature flag MAX_INSIGHTS_PER_BATCH:`, error);
      console.error(`[RSS] Error details:`, {
        errorMessage: error instanceof Error ? error.message : 'Unknown error',
        errorStack: error instanceof Error ? error.stack : undefined,
        errorType: typeof error
      });
      console.log(`[RSS] Using default value: ${maxInsightsPerBatch}`);
    }
    const itemsToProcess = feed.items.slice(0, maxInsightsPerBatch);
    
    if (feed.items.length > maxInsightsPerBatch) {
      console.log(`[RSS] Limiting processing to ${maxInsightsPerBatch} items due to feature flag`);
    }

    // Convert RSS items to batch format
    const rssItems: RssItem[] = itemsToProcess.map(item => ({
      title: item.title || 'Untitled',
      content: item.contentSnippet || item.description || '',
      url: item.link || '',
      publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
      sourceId: sourceId,
      sourceName: dataSource.name,
      category: dataSource.category || 'general',
    }));

    // Use batch processing for improved throughput and cost efficiency
    logger.info(`[RSS] Starting batch processing for ${rssItems.length} items from ${dataSource.name}`);
    
    try {
      const batchResult = await batchRssIngestionService.processBatch(rssItems);
      
      processed = batchResult.processed;
      errors = itemsToProcess.length - batchResult.processed - batchResult.duplicates;
      newInsights = batchResult.processed;
      
      logger.info(`[RSS] Batch processing complete`, {
        source: dataSource.name,
        totalItems: itemsToProcess.length,
        processed: batchResult.processed,
        duplicates: batchResult.duplicates,
        batches: batchResult.batches,
        throughput: batchResult.throughput.toFixed(2),
        costPerItem: batchResult.costPerItem.toFixed(6),
        totalCost: batchResult.totalCost.toFixed(4)
      });
      
    } catch (error) {
      logger.error(`[RSS] Batch processing failed for ${dataSource.name}:`, { error: String(error) });
      // Fallback to individual processing if batch fails
      for (const item of itemsToProcess) {
        try {
          await processRssItem(item, dataSource, sourceId);
          processed++;
        } catch (itemError) {
          logger.error(`[RSS] Error processing item ${item.guid}:`, { error: String(itemError) });
          errors++;
        }
      }
    }

    // Update data source status
    await storage.updateDataSourceStatus(sourceId, {
      lastFetchAt: new Date(),
      status: 'active',
      errorMessage: null,
    });

    console.log(`[RSS] Feed processing complete. Processed: ${processed}, Errors: ${errors}, New insights: ${newInsights}`);
    
    return { processed, errors, newInsights };

  } catch (error) {
    console.error(`[RSS] Failed to process feed ${feedUrl}:`, error);
    
    // Update data source with error status
    await storage.updateDataSourceStatus(sourceId, {
      lastFetchAt: new Date(),
      status: 'error',
      errorMessage: error instanceof Error ? error.message : String(error),
    });

    throw error;
  }
}

async function processRssItem(item: any, dataSource: any, sourceId: string): Promise<void> {
  // Create insight from RSS item
  const insight = {
    title: item.title || 'Untitled',
    content: item.contentSnippet || item.description || '',
    url: item.link || '',
    publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
    sourceId: sourceId,
    sourceName: dataSource.name,
    category: dataSource.category || 'General',
    sentiment: 'neutral' as const,
    priority: 'normal' as const,
    sourceUrl: item.link || '',
  };

  try {
    // Check if insight already exists by URL
    const existingInsight = await storage.getInsightByGuid(insight.sourceUrl);
    if (existingInsight) {
      console.log(`[RSS] Insight already exists: ${insight.sourceUrl}`);
      return;
    }

    // Save insight to database
    const savedInsight = await storage.createInsight(insight);
    console.log(`[RSS] Created insight: ${savedInsight.id}`);

    // Queue for AI enrichment if content is substantial
    if (insight.content.length > 100) {
      await queueManager.addJob(JOB_TYPES.AI_ENRICHMENT, {
        insightId: savedInsight.id,
        content: insight.content,
        title: insight.title,
      }, {
        priority: JobPriority.NORMAL,
        metadata: {
          source: 'rss',
          sourceId: sourceId,
        },
      });
    }

    // Queue for content analysis
    await queueManager.addJob(JOB_TYPES.CONTENT_ANALYSIS, {
      insightId: savedInsight.id,
      content: insight.content,
      title: insight.title,
      url: insight.url,
    }, {
      priority: JobPriority.NORMAL,
      metadata: {
        source: 'rss',
        sourceId: sourceId,
      },
    });

  } catch (error) {
    console.error(`[RSS] Error saving insight:`, error);
    throw error;
  }
}

// Batch RSS processing for multiple sources
export async function batchProcessRssFeeds(sourceIds?: string[]): Promise<{
  total: number;
  processed: number;
  failed: number;
  queuedJobs: number;
}> {
  console.log('[RSS] Starting batch RSS feed processing...');

  try {
    // Get active data sources
    let dataSources;
    if (sourceIds && sourceIds.length > 0) {
      dataSources = await Promise.all(
        sourceIds.map(id => storage.getDataSource(id))
      );
      dataSources = dataSources.filter(Boolean);
    } else {
      dataSources = await storage.getActiveDataSources();
    }

    const total = dataSources.length;
    let processed = 0;
    let failed = 0;
    let queuedJobs = 0;

    console.log(`[RSS] Processing ${total} data sources`);

    // Queue RSS processing jobs with different priorities
    for (const source of dataSources) {
      try {
        // Determine priority based on source importance
        let priority = 'NORMAL';
        if (source.priority === 'high') {
          priority = 'HIGH';
        } else if (source.priority === 'critical') {
          priority = 'CRITICAL';
        }

        const job = await queueManager.addJob('RSS_FETCH', {
          sourceId: source.id,
          feedUrl: source.url,
        }, {
          priority,
          metadata: {
            sourceName: source.name,
            category: source.category,
          },
        });

        if (job) {
          queuedJobs++;
          console.log(`[RSS] Queued RSS fetch job for: ${source?.name || 'Unknown source'}`);
        }
        
        processed++;
      } catch (error) {
        console.error(`[RSS] Failed to queue job for source ${source?.id || 'Unknown'}:`, error);
        failed++;
      }
    }

    console.log(`[RSS] Batch processing complete. Queued: ${queuedJobs}, Failed: ${failed}`);
    
    return { total, processed, failed, queuedJobs };

  } catch (error) {
    console.error('[RSS] Batch RSS processing failed:', error);
    throw error;
  }
}