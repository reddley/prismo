-- Critical database indexes for optimal performance
-- Run these indexes to achieve 5x-10x faster query performance

-- Insights table - most frequently queried
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_created_at ON insights(created_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_priority ON insights(priority);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_category ON insights(category);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_sentiment ON insights(sentiment);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_source ON insights(source);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_published_at ON insights(published_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_composite_main ON insights(created_at DESC, priority, category);

-- Full text search indexes for content
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_title_gin ON insights USING gin(to_tsvector('english', title));
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_content_gin ON insights USING gin(to_tsvector('english', content));
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_insights_summary_gin ON insights USING gin(to_tsvector('english', summary));

-- Data sources table
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_data_sources_active ON data_sources(is_active);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_data_sources_created_at ON data_sources(created_at);

-- Entity-related indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_mentions_entity ON entity_mentions(entity_type, entity_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_mentions_insight ON entity_mentions(insight_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entity_mentions_created_at ON entity_mentions(created_at DESC);

-- Company/Person/Organization indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_companies_updated_at ON companies(updated_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_companies_name ON companies(name);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_people_updated_at ON people(updated_at DESC);  
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_people_name ON people(name);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_organizations_updated_at ON organizations(updated_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_organizations_name ON organizations(name);

-- Notifications and alerts
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_notifications_read ON notifications(is_read);

-- Briefings
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_briefings_date ON briefings(date DESC);

-- Board-related indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_boards_user_id ON boards(user_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_board_entities_board_id ON board_entities(board_id);

-- System monitoring indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_cost_tracking_date ON cost_tracking(date DESC);

-- Deck mentions
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_deck_mentions_entity ON deck_mentions(entity_type, entity_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_deck_mentions_published_at ON deck_mentions(published_at DESC);

-- Dashboard performance optimization indexes
-- These are specifically designed for the optimized dashboard endpoint
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_companies_dashboard ON companies(mention_count DESC, last_mentioned DESC) WHERE priority IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_people_dashboard ON people(mention_count DESC, last_mentioned DESC) WHERE priority IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_organizations_dashboard ON organizations(mention_count DESC, last_mentioned DESC) WHERE priority IS NOT NULL;

-- Priority-based sorting optimization
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_companies_priority_mentions ON companies(priority, mention_count DESC, last_mentioned DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_people_priority_mentions ON people(priority, mention_count DESC, last_mentioned DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_organizations_priority_mentions ON organizations(priority, mention_count DESC, last_mentioned DESC);