// Pool monitoring and performance metrics
import { getPoolHealth } from './db';

interface PoolMetrics {
  timestamp: number;
  activeConnections: number;
  totalConnections: number;
  p95Latency: number;
  queryThroughput: number;
}

class PoolMonitor {
  private metrics: PoolMetrics[] = [];
  private lastQueryCount = 0;
  private monitoringInterval: NodeJS.Timeout | null = null;

  start() {
    if (this.monitoringInterval) {
      return; // Already monitoring
    }

    console.log('[POOL-MONITOR] Starting connection pool monitoring...');
    
    this.monitoringInterval = setInterval(() => {
      this.collectMetrics();
    }, 10000); // Collect metrics every 10 seconds
  }

  stop() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
      console.log('[POOL-MONITOR] Pool monitoring stopped');
    }
  }

  private collectMetrics() {
    try {
      const health = getPoolHealth();
      const now = Date.now();
      
      // Calculate query throughput (queries per second)
      const queryThroughput = health.totalQueries - this.lastQueryCount;
      this.lastQueryCount = health.totalQueries;
      
      const metrics: PoolMetrics = {
        timestamp: now,
        activeConnections: health.activeConnections,
        totalConnections: health.totalConnections,
        p95Latency: health.p95Latency,
        queryThroughput: queryThroughput / 10, // Per second
      };
      
      this.metrics.push(metrics);
      
      // Keep only last 100 metrics (16 minutes of data)
      if (this.metrics.length > 100) {
        this.metrics = this.metrics.slice(-100);
      }
      
      // Alert on performance issues
      this.checkAlerts(metrics, health);
      
    } catch (error) {
      console.error('[POOL-MONITOR] Error collecting metrics:', error);
    }
  }

  private checkAlerts(metrics: PoolMetrics, health: any) {
    // Alert on high P95 latency (reduced frequency)
    if (metrics.p95Latency > 250 && Math.random() < 0.1) { // Only 10% of the time
      console.warn(`[POOL-ALERT] High P95 latency: ${metrics.p95Latency}ms (target: 250ms)`);
    }
    
    // Alert on connection pool exhaustion (reduced frequency)
    const connectionUtilization = metrics.activeConnections / health.poolConfig.maxConnections;
    if (connectionUtilization > 0.95 && Math.random() < 0.05) { // Only 5% of the time at 95%+ utilization
      console.warn(`[POOL-ALERT] High connection utilization: ${Math.round(connectionUtilization * 100)}%`);
    }
    
    // Alert on connection spikes (reduced frequency)
    if (metrics.activeConnections > health.poolConfig.maxConnections * 0.9 && Math.random() < 0.05) {
      console.warn(`[POOL-ALERT] Connection spike detected: ${metrics.activeConnections} active connections`);
    }
  }

  getRecentMetrics(minutes: number = 10): PoolMetrics[] {
    const cutoff = Date.now() - (minutes * 60 * 1000);
    return this.metrics.filter(m => m.timestamp > cutoff);
  }

  getPerformanceSummary() {
    if (this.metrics.length === 0) {
      return null;
    }

    const recent = this.getRecentMetrics(5); // Last 5 minutes
    if (recent.length === 0) {
      return null;
    }

    const avgP95 = recent.reduce((sum, m) => sum + m.p95Latency, 0) / recent.length;
    const maxConnections = Math.max(...recent.map(m => m.activeConnections));
    const avgThroughput = recent.reduce((sum, m) => sum + m.queryThroughput, 0) / recent.length;

    return {
      avgP95Latency: Math.round(avgP95),
      maxActiveConnections: maxConnections,
      avgQueryThroughput: Math.round(avgThroughput * 10) / 10,
      sampleSize: recent.length,
      timeRange: '5 minutes',
    };
  }
}

export const poolMonitor = new PoolMonitor();