import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import sharp from "sharp";
import { storage, type SearchInsightsParams } from "./storage";
import { startScheduledTasks, stopScheduledTasks } from "./services/scheduler";
import { insertDataSourceSchema, insertMonitorSchema, insertNotificationSchema, insertStockWatchlistSchema, insertReportTemplateSchema, insertInstalledReportSchema, insertReportBlueprintSchema, insertReportBlueprintVersionSchema, reportTemplates, installedReports, reportBlueprints, reportBlueprintVersions, users } from "@shared/schema";
import { db } from "./db";
import { eq, and, sql, desc, or, ilike, lt, gt } from "drizzle-orm";
import { polygonService } from "./services/polygon";
// Import unified services through service registry
import { 
  getDataIntelligenceService,
  getUserIntelligenceService, 
  getAiIntelligenceService,
  getCostIntelligenceService,
  checkServiceHealth
} from './services/serviceRegistry';
import { authService } from "./services/auth-service";
import { emailService } from "./services/email-service";
import { 
  createAuthRateLimit, 
  signupRateLimit, 
  loginRateLimit, 
  passwordResetRateLimit,
  securityHeaders,
  getClientContext 
} from "./middleware/rate-limiter";
import { tenantRateLimit, getRateLimitStatus, resetRateLimit, loadShedding } from "./middleware/tenant-rate-limiter";
import { logger, requestLogger } from "./observability/logger";
import { metricsCollector, metricsMiddleware } from "./observability/metrics";
import { tracingMiddleware, tracingService } from "./observability/tracing";
import { alertManager } from "./observability/alerts";
import { migrationRunner } from "./migrations/migration-runner";
import { addUserPreferencesMigration } from "./migrations/examples/add-user-preferences";
import { addInsightsPriorityMigration } from "./migrations/examples/add-column-online";
import { knowledgeGraphCoreMigration } from "./migrations/knowledge-graph-core";
import { cacheMiddleware, withCache } from "./cache/cache-middleware";
import { cacheService } from "./cache/cache-service";

// Configure multer for logo uploads
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const upload = multer({
  dest: uploadsDir,
  limits: {
    fileSize: 2 * 1024 * 1024, // 2MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

// WebP conversion utility function
async function convertImageToWebP(base64DataUrl: string): Promise<string> {
  try {
    // Extract base64 data from data URL
    const base64Data = base64DataUrl.split(',')[1];
    const imageBuffer = Buffer.from(base64Data, 'base64');
    
    // Convert to WebP with compression
    const webpBuffer = await sharp(imageBuffer)
      .resize(200, 200, { 
        fit: 'cover',
        position: 'center'
      })
      .webp({ 
        quality: 85,
        effort: 6 // Higher effort for better compression
      })
      .toBuffer();
    
    // Convert back to base64 data URL
    const webpBase64 = webpBuffer.toString('base64');
    return `data:image/webp;base64,${webpBase64}`;
  } catch (error) {
    console.error('Error converting image to WebP:', error);
    throw error;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Apply observability middleware first
  app.use(requestLogger);
  app.use(metricsMiddleware);
  app.use(tracingMiddleware);

  // Apply security headers globally
  app.use(securityHeaders);

  // Start scheduled tasks
  startScheduledTasks();

  logger.info('Application starting up', {
    port: process.env.PORT || 5000
  });

  // Authentication routes
  app.post('/api/auth/register', 
    signupRateLimit, 
    createAuthRateLimit({ windowMs: 60 * 60 * 1000, max: 3, attemptType: 'signup' }),
    async (req, res) => {
      try {
        const { username, email, password, name } = req.body;
        
        if (!username || !email || !password) {
          return res.status(400).json({ 
            error: 'Missing required fields', 
            message: 'Username, email, and password are required' 
          });
        }

        const context = getClientContext(req);
        const { user, verificationToken } = await authService.registerUser(
          { username, email, password, name },
          context
        );

        // Queue verification email
        await emailService.queueVerificationEmail(user.id, email, verificationToken, 'high');

        res.status(201).json({
          message: 'Registration successful. Please check your email to verify your account.',
          user: {
            id: user.id,
            username: user.username,
            email: user.email,
            emailVerified: user.emailVerified,
          }
        });
      } catch (error) {
        console.error('Registration error:', error);
        res.status(400).json({ 
          error: 'Registration failed', 
          message: error instanceof Error ? error.message : 'Unknown error' 
        });
      }
    }
  );

  app.post('/api/auth/login',
    loginRateLimit,
    createAuthRateLimit({ windowMs: 15 * 60 * 1000, max: 5, attemptType: 'login' }),
    async (req, res) => {
      try {
        const { username, password } = req.body;
        
        if (!username || !password) {
          return res.status(400).json({ 
            error: 'Missing credentials', 
            message: 'Username and password are required' 
          });
        }

        const context = getClientContext(req);
        const user = await authService.authenticateUser({ username, password }, context);

        // Set up session (simplified for now)
        (req as any).session = { userId: user.id };

        res.json({
          message: 'Login successful',
          user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            emailVerified: user.emailVerified,
          }
        });
      } catch (error) {
        console.error('Login error:', error);
        res.status(401).json({ 
          error: 'Login failed', 
          message: error instanceof Error ? error.message : 'Invalid credentials' 
        });
      }
    }
  );

  app.get('/api/auth/verify-email', async (req, res) => {
    try {
      const { token } = req.query;
      
      if (!token || typeof token !== 'string') {
        return res.status(400).json({ 
          error: 'Invalid request', 
          message: 'Verification token is required' 
        });
      }

      const context = getClientContext(req);
      const user = await authService.verifyEmail(token, context);

      res.json({
        message: 'Email verified successfully',
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          emailVerified: user.emailVerified,
        }
      });
    } catch (error) {
      console.error('Email verification error:', error);
      res.status(400).json({ 
        error: 'Verification failed', 
        message: error instanceof Error ? error.message : 'Invalid or expired token' 
      });
    }
  });

  app.post('/api/auth/resend-verification',
    passwordResetRateLimit,
    createAuthRateLimit({ windowMs: 60 * 60 * 1000, max: 3, attemptType: 'email_verification' }),
    async (req, res) => {
      try {
        const { email } = req.body;
        
        if (!email) {
          return res.status(400).json({ 
            error: 'Missing email', 
            message: 'Email address is required' 
          });
        }

        await emailService.resendVerificationEmail(email);

        res.json({
          message: 'Verification email sent. Please check your inbox.',
        });
      } catch (error) {
        console.error('Resend verification error:', error);
        res.status(400).json({ 
          error: 'Failed to resend verification', 
          message: error instanceof Error ? error.message : 'Please try again' 
        });
      }
    }
  );

  app.post('/api/auth/logout', async (req, res) => {
    try {
      // Clear session
      if ((req as any).session) {
        (req as any).session = null;
      }

      res.json({ message: 'Logout successful' });
    } catch (error) {
      console.error('Logout error:', error);
      res.status(500).json({ 
        error: 'Logout failed', 
        message: 'Please try again' 
      });
    }
  });

  app.get('/api/auth/me', async (req, res) => {
    try {
      const userId = (req as any).session?.userId;
      
      if (!userId) {
        return res.status(401).json({ 
          error: 'Not authenticated', 
          message: 'Please log in' 
        });
      }

      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ 
          error: 'User not found', 
          message: 'Please log in again' 
        });
      }

      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        role: user.role,
        emailVerified: user.emailVerified,
      });
    } catch (error) {
      console.error('Get user profile error:', error);
      res.status(500).json({ 
        error: 'Failed to fetch profile', 
        message: 'Please try again' 
      });
    }
  });

  // Email queue management (admin only)
  app.get('/api/admin/email-queue/metrics', async (req, res) => {
    try {
      const metrics = await emailService.getQueueMetrics();
      res.json(metrics);
    } catch (error) {
      console.error('Email queue metrics error:', error);
      res.status(500).json({ message: 'Failed to fetch email queue metrics' });
    }
  });

  app.post('/api/admin/email-queue/process', async (req, res) => {
    try {
      const batchSize = parseInt(req.query.batchSize as string) || 50;
      const result = await emailService.processPendingVerifications(batchSize);
      res.json(result);
    } catch (error) {
      console.error('Email queue processing error:', error);
      res.status(500).json({ message: 'Failed to process email queue' });
    }
  });

  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    next();
  }, (req, res, next) => {
    const filePath = path.join(uploadsDir, req.path);
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).json({ message: 'File not found' });
    }
  });

  // Dashboard metrics
  app.get('/api/metrics', cacheMiddleware('metrics'), async (req, res) => {
    try {
      const metrics = await storage.getMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch metrics' });
    }
  });

  // Pool health monitoring endpoint
  app.get('/api/pool/health', async (req, res) => {
    try {
      const { getPoolHealth } = await import('./db');
      const { poolMonitor } = await import('./pool-monitor');
      
      const poolHealth = getPoolHealth();
      const performanceSummary = poolMonitor.getPerformanceSummary();
      
      res.json({
        ...poolHealth,
        performance: performanceSummary,
        timestamp: Date.now(),
      });
    } catch (error) {
      console.error('Pool health check error:', error);
      res.status(500).json({ message: 'Failed to get pool health' });
    }
  });

  // Pool metrics history endpoint
  app.get('/api/pool/metrics', async (req, res) => {
    try {
      const { poolMonitor } = await import('./pool-monitor');
      const minutes = parseInt(req.query.minutes as string) || 10;
      const metrics = poolMonitor.getRecentMetrics(minutes);
      res.json(metrics);
    } catch (error) {
      console.error('Pool metrics error:', error);
      res.status(500).json({ message: 'Failed to get pool metrics' });
    }
  });

  // Queue management endpoints
  app.get('/api/queue/stats', async (req, res) => {
    try {
      const { queueManager } = await import('./queue/queues');
      const { redisManager } = await import('./queue/redis');
      const { idempotencyManager } = await import('./queue/idempotency');
      
      const [queueStats, dlqStats, redisHealth, idempotencyStats] = await Promise.all([
        queueManager.getQueueStats(),
        queueManager.getDeadLetterQueueStats(),
        redisManager.healthCheck(),
        idempotencyManager.getStats(),
      ]);

      res.json({
        queues: queueStats,
        deadLetterQueue: dlqStats,
        redis: redisHealth,
        idempotency: idempotencyStats,
        timestamp: Date.now(),
      });
    } catch (error) {
      console.error('Queue stats error:', error);
      res.status(500).json({ message: 'Failed to get queue stats' });
    }
  });

  // Manual RSS processing trigger
  app.post('/api/queue/rss/process', async (req, res) => {
    try {
      const { sourceIds } = req.body;
      const { batchProcessRssFeeds } = await import('./services/rss-processor');
      
      const result = await batchProcessRssFeeds(sourceIds);
      res.json(result);
    } catch (error) {
      console.error('Manual RSS processing error:', error);
      res.status(500).json({ message: 'Failed to trigger RSS processing' });
    }
  });

  // Dead letter queue management
  app.get('/api/queue/dlq', async (req, res) => {
    try {
      const { queueManager } = await import('./queue/queues');
      const stats = await queueManager.getDeadLetterQueueStats();
      res.json(stats);
    } catch (error) {
      console.error('DLQ error:', error);
      res.status(500).json({ message: 'Failed to get dead letter queue data' });
    }
  });

  // Optimized dashboard endpoint - replaces N+1 queries with single JOIN
  app.get('/api/dashboard/data', cacheMiddleware('insights'), async (req, res) => {
    try {
      const dashboardData = await storage.getDashboardData();
      res.json(dashboardData);
    } catch (error) {
      console.error('Dashboard data fetch error:', error);
      res.status(500).json({ message: 'Failed to fetch dashboard data' });
    }
  });

  // Insights endpoints
  app.get('/api/insights', cacheMiddleware('insights'), async (req, res) => {
    try {
      const { limit = 20, offset = 0, category, priority } = req.query;
      
      let insights;
      if (category && typeof category === 'string') {
        insights = await storage.getInsightsByCategory(category);
      } else if (priority && typeof priority === 'string') {
        insights = await storage.getInsightsByPriority(priority);
      } else {
        insights = await storage.getInsights(
          parseInt(limit as string), 
          parseInt(offset as string)
        );
      }
      
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch insights' });
    }
  });

  // Advanced search endpoint
  // Enhanced search endpoint for mixed results (templates + blueprints)
  app.get("/api/search", async (req, res) => {
    try {
      const {
        q = '',
        useCase = '',
        type = 'all', // 'template', 'blueprint', or 'all'
        limit = 20,
        offset = 0
      } = req.query;

      const searchQuery = q as string;
      const useCaseFilter = useCase as string;
      const typeFilter = type as string;
      const searchLimit = Math.min(parseInt(limit as string, 10) || 20, 100);
      const searchOffset = parseInt(offset as string, 10) || 0;

      console.log(`[SEARCH] Mixed search: q="${searchQuery}", useCase="${useCaseFilter}", type="${typeFilter}"`);

      const results: any[] = [];

      // Search templates if requested
      if (typeFilter === 'all' || typeFilter === 'template') {
        const templates = await storage.getReportTemplates();
        let filteredTemplates = templates;

        // Apply use case filter
        if (useCaseFilter && useCaseFilter !== 'all') {
          filteredTemplates = templates.filter(t => 
            t.useCase?.toLowerCase() === useCaseFilter.toLowerCase() ||
            t.tags?.some(tag => tag.toLowerCase() === useCaseFilter.toLowerCase())
          );
        }

        // Apply search query filter
        if (searchQuery) {
          filteredTemplates = filteredTemplates.filter(t =>
            t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            t.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            t.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
          );
        }

        // Add to results with type annotation
        results.push(...filteredTemplates.map(t => ({
          ...t,
          resultType: 'template'
        })));
      }

      // Search blueprints if requested (mock data for now)
      if (typeFilter === 'all' || typeFilter === 'blueprint') {
        const mockBlueprints = [
          {
            id: 'bp-1',
            name: 'Custom Intelligence Dashboard',
            description: 'Create a custom intelligence dashboard with your data sources',
            useCase: 'Intelligence',
            tags: ['custom', 'intelligence', 'dashboard'],
            resultType: 'blueprint',
            createdAt: new Date().toISOString()
          },
          {
            id: 'bp-2', 
            name: 'Financial Analytics Setup',
            description: 'Set up financial analytics with market data integration',
            useCase: 'Finance',
            tags: ['finance', 'analytics', 'market-data'],
            resultType: 'blueprint',
            createdAt: new Date().toISOString()
          }
        ];

        let filteredBlueprints = mockBlueprints;

        // Apply use case filter
        if (useCaseFilter && useCaseFilter !== 'all') {
          filteredBlueprints = mockBlueprints.filter(b =>
            b.useCase?.toLowerCase() === useCaseFilter.toLowerCase() ||
            b.tags?.some(tag => tag.toLowerCase() === useCaseFilter.toLowerCase())
          );
        }

        // Apply search query filter
        if (searchQuery) {
          filteredBlueprints = filteredBlueprints.filter(b =>
            b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            b.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            b.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
          );
        }

        results.push(...filteredBlueprints);
      }

      // Sort by relevance/name
      results.sort((a, b) => a.name.localeCompare(b.name));

      // Apply pagination
      const paginatedResults = results.slice(searchOffset, searchOffset + searchLimit);

      res.json({
        results: paginatedResults,
        pagination: {
          total: results.length,
          limit: searchLimit,
          offset: searchOffset,
          hasMore: searchOffset + searchLimit < results.length
        }
      });
    } catch (error) {
      console.error("Error in mixed search:", error);
      res.status(500).json({ message: "Failed to search" });
    }
  });

  app.get("/api/insights/search", async (req, res) => {
    try {
      const {
        query = '',
        sentiment = [],
        priority = [],
        category = [],
        source = [],
        dateFrom,
        dateTo,
        sortBy = 'createdAt',
        sortOrder = 'desc',
        limit = 100,
        offset = 0
      } = req.query;

      // Parse array parameters that come as comma-separated strings
      const sentimentArray = Array.isArray(sentiment) ? sentiment : sentiment ? (sentiment as string).split(',').filter(Boolean) : [];
      const priorityArray = Array.isArray(priority) ? priority : priority ? (priority as string).split(',').filter(Boolean) : [];
      const categoryArray = Array.isArray(category) ? category : category ? (category as string).split(',').filter(Boolean) : [];
      const sourceArray = Array.isArray(source) ? source : source ? (source as string).split(',').filter(Boolean) : [];

      const searchParams: SearchInsightsParams = {
        query: query as string,
        sentiment: sentimentArray as string[],
        priority: priorityArray as string[],
        category: categoryArray as string[],
        source: sourceArray as string[],
        dateFrom: dateFrom ? new Date(dateFrom as string) : undefined,
        dateTo: dateTo ? new Date(dateTo as string) : undefined,
        sortBy: sortBy as string,
        sortOrder: sortOrder as 'asc' | 'desc',
        limit: parseInt(limit as string, 10),
        offset: parseInt(offset as string, 10)
      };

      const results = await storage.searchInsights(searchParams);
      console.log(`Search executed: query="${query}", filters=${JSON.stringify({sentiment: sentimentArray, priority: priorityArray, category: categoryArray, source: sourceArray})}, results: ${results.length}`);
      res.json(results);
    } catch (error) {
      console.error("Error searching insights:", error);
      res.status(500).json({ message: "Failed to search insights" });
    }
  });

  // Get filter options for search
  app.get("/api/insights/filter-options", async (req, res) => {
    try {
      const options = await storage.getInsightFilterOptions();
      res.json(options);
    } catch (error) {
      console.error("Error fetching filter options:", error);
      res.status(500).json({ message: "Failed to fetch filter options" });
    }
  });

  // Data sources endpoints
  app.get('/api/data-sources', async (req, res) => {
    try {
      const sources = await storage.getDataSources();
      res.json(sources);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch data sources' });
    }
  });

  app.post('/api/data-sources', async (req, res) => {
    try {
      const validatedData = insertDataSourceSchema.parse(req.body);
      const source = await storage.createDataSource(validatedData);
      res.json(source);
    } catch (error) {
      res.status(400).json({ message: 'Invalid data source data' });
    }
  });

  app.put('/api/data-sources/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const source = await storage.updateDataSource(id, updates);
      
      if (!source) {
        return res.status(404).json({ message: 'Data source not found' });
      }
      
      res.json(source);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update data source' });
    }
  });

  app.patch('/api/data-sources/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const source = await storage.updateDataSource(id, updates);
      
      if (!source) {
        return res.status(404).json({ message: 'Data source not found' });
      }
      
      res.json(source);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update data source' });
    }
  });

  app.delete('/api/data-sources/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteDataSource(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Data source not found' });
      }
      
      res.json({ message: 'Data source deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete data source' });
    }
  });

  // Monitors endpoints
  app.get('/api/monitors', cacheMiddleware('entities'), async (req, res) => {
    try {
      const monitors = await storage.getMonitors();
      res.json(monitors);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch monitors' });
    }
  });

  app.post('/api/monitors', async (req, res) => {
    try {
      const validatedData = insertMonitorSchema.parse(req.body);
      const monitor = await storage.createMonitor(validatedData);
      res.json(monitor);
    } catch (error) {
      res.status(400).json({ message: 'Invalid monitor data' });
    }
  });

  app.put('/api/monitors/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const monitor = await storage.updateMonitor(id, updates);
      
      if (!monitor) {
        return res.status(404).json({ message: 'Monitor not found' });
      }
      
      res.json(monitor);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update monitor' });
    }
  });

  // Briefings endpoints
  app.get('/api/briefings', cacheMiddleware('briefings'), async (req, res) => {
    try {
      const { limit = 10 } = req.query;
      const briefings = await storage.getBriefings(parseInt(limit as string));
      res.json(briefings);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch briefings' });
    }
  });

  app.get('/api/briefings/latest', async (req, res) => {
    try {
      const briefing = await storage.getLatestBriefing();
      if (!briefing) {
        return res.status(404).json({ message: 'No briefings found' });
      }
      res.json(briefing);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch latest briefing' });
    }
  });

  // Notifications endpoints
  app.get('/api/notifications', async (req, res) => {
    try {
      const { limit = 20 } = req.query;
      const notifications = await storage.getNotifications(parseInt(limit as string));
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch notifications' });
    }
  });

  app.get('/api/notifications/unread', async (req, res) => {
    try {
      const notifications = await storage.getUnreadNotifications();
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch unread notifications' });
    }
  });

  app.put('/api/notifications/:id/read', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.markNotificationRead(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: 'Failed to mark notification as read' });
    }
  });

  app.post('/api/notifications', async (req, res) => {
    try {
      const validatedData = insertNotificationSchema.parse(req.body);
      const notification = await storage.createNotification(validatedData);
      res.json(notification);
    } catch (error) {
      res.status(400).json({ message: 'Invalid notification data' });
    }
  });

  // User profile endpoints
  app.get('/api/user/profile', async (req, res) => {
    try {
      // Get or create the default user
      let user = await storage.getUserByUsername('admin');
      if (!user) {
        // Create default admin user if doesn't exist
        user = await storage.createUser({
          username: 'admin',
          email: 'admin@prismo.ai',
          name: 'Sarah Chen',
          title: 'Market Analyst', 
          profileImageUrl: null,
          password: 'admin', // In real app, this would be hashed
          logoUrl: null,
          theme: 'dark',
          role: 'admin',
          teamId: null,
        });
      }
      
      // Don't send password to frontend
      const { password, ...userProfile } = user;
      res.json(userProfile);
    } catch (error) {
      console.error('Error fetching user profile:', error);
      res.status(500).json({ message: 'Failed to fetch user profile' });
    }
  });

  app.put('/api/user/profile', async (req, res) => {
    try {
      const updates = req.body;
      
      // Get current user (in a real app, this would come from authentication)
      let user = await storage.getUserByUsername('admin');
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // If profileImageUrl is being updated and it's a base64 image, convert to WebP
      if (updates.profileImageUrl && updates.profileImageUrl.startsWith('data:image/')) {
        try {
          const webpImageUrl = await convertImageToWebP(updates.profileImageUrl);
          updates.profileImageUrl = webpImageUrl;
        } catch (conversionError) {
          console.error('Error converting image to WebP:', conversionError);
          // Continue with original image if conversion fails
        }
      }
      
      // Update user profile
      const updatedUser = await storage.updateUser(user.id, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: 'Failed to update user' });
      }
      
      // Don't send password to frontend
      const { password, ...userProfile } = updatedUser;
      res.json(userProfile);
    } catch (error) {
      console.error('Error updating user profile:', error);
      res.status(500).json({ message: 'Failed to update user profile' });
    }
  });

  // PATCH endpoint for profile updates (used by new profile page)
  app.patch('/api/user/profile', async (req, res) => {
    try {
      const { name, title } = req.body;
      
      if (!name && !title) {
        return res.status(400).json({ error: 'Name or title is required' });
      }

      // Get current user
      let user = await storage.getUserByUsername('admin');
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Update user profile with provided fields
      const updates: any = {};
      if (name) updates.name = name;
      if (title) updates.title = title;
      
      const updatedUser = await storage.updateUser(user.id, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: 'Failed to update user' });
      }
      
      // Don't send password to frontend
      const { password, ...userProfile } = updatedUser;
      res.json(userProfile);
    } catch (error) {
      console.error('Error updating user profile:', error);
      res.status(500).json({ error: 'Failed to update user profile' });
    }
  });

  // User settings endpoints
  app.post('/api/settings/logo', upload.single('logo'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      const logoUrl = `/uploads/${req.file.filename}`;
      
      // Update user's logo in database
      let user = await storage.getUserByUsername('admin');
      if (user) {
        await storage.updateUser(user.id, { logoUrl });
      }
      
      res.json({ 
        logoUrl,
        message: 'Logo uploaded successfully' 
      });
    } catch (error) {
      console.error('Logo upload failed:', error);
      res.status(500).json({ message: 'Logo upload failed' });
    }
  });

  app.post('/api/settings/theme', async (req, res) => {
    try {
      const { theme } = req.body;
      if (!['light', 'dark'].includes(theme)) {
        return res.status(400).json({ message: 'Invalid theme' });
      }
      
      // Update user's theme in database
      let user = await storage.getUserByUsername('admin');
      if (user) {
        await storage.updateUser(user.id, { theme });
      }
      
      res.json({ theme, message: 'Theme updated successfully' });
    } catch (error) {
      console.error('Theme update failed:', error);
      res.status(500).json({ message: 'Theme update failed' });
    }
  });

  // Deduplication endpoints
  app.post('/api/entities/cleanup-duplicates', async (req, res) => {
    try {
      const { deduplicationService } = await import('./services/deduplicationService');
      const result = await deduplicationService.cleanupDuplicates();
      res.json(result);
    } catch (error) {
      console.error('Error cleaning up duplicates:', error);
      res.status(500).json({ error: 'Failed to clean up duplicates' });
    }
  });

  app.get('/api/companies/:id/duplicates', async (req, res) => {
    try {
      const { deduplicationService } = await import('./services/deduplicationService');
      const company = await storage.getCompany(req.params.id);
      if (!company) {
        return res.status(404).json({ error: 'Company not found' });
      }
      
      const duplicates = await deduplicationService.findDuplicateCompanies(company.name, company.id);
      res.json(duplicates);
    } catch (error) {
      console.error('Error finding duplicates:', error);
      res.status(500).json({ error: 'Failed to find duplicates' });
    }
  });

  app.post('/api/companies/merge', async (req, res) => {
    try {
      const { keepId, removeId } = req.body;
      
      if (!keepId || !removeId) {
        return res.status(400).json({ error: 'Both keepId and removeId are required' });
      }
      
      const { deduplicationService } = await import('./services/deduplicationService');
      const mergedCompany = await deduplicationService.mergeCompanies(keepId, removeId);
      res.json(mergedCompany);
    } catch (error) {
      console.error('Error merging companies:', error);
      res.status(500).json({ error: 'Failed to merge companies' });
    }
  });

  // Entity enrichment endpoints
  app.post("/api/companies/:id/enrich", async (req, res) => {
    try {
      const company = await storage.getCompany(req.params.id);
      if (!company) {
        return res.status(404).json({ message: "Company not found" });
      }
      
      const enrichmentService = new DataEnrichmentService();
      const enrichmentData = await enrichmentService.enrichCompanyData(company.name);
      
      if (enrichmentData) {
        const updatedCompany = await storage.updateCompany(company.id, {
          description: enrichmentData.description || company.description,
          industry: enrichmentData.industry,
          founded: enrichmentData.founded,
          website: enrichmentData.website,
          headquarters: enrichmentData.headquarters,
          logoUrl: enrichmentData.logoUrl
        });
        
        res.json(updatedCompany);
      } else {
        res.status(404).json({ message: "No enrichment data found" });
      }
    } catch (error) {
      console.error("Error enriching company:", error);
      res.status(500).json({ message: "Failed to enrich company" });
    }
  });

  app.post("/api/people/:id/enrich", async (req, res) => {
    try {
      const person = await storage.getPerson(req.params.id);
      if (!person) {
        return res.status(404).json({ message: "Person not found" });
      }
      
      const enrichmentService = new DataEnrichmentService();
      const enrichmentData = await enrichmentService.enrichPersonData(person.name);
      
      if (enrichmentData) {
        const updatedPerson = await storage.updatePerson(person.id, {
          description: enrichmentData.description || person.description,
          profileImageUrl: enrichmentData.imageUrl
        });
        
        res.json(updatedPerson);
      } else {
        res.status(404).json({ message: "No enrichment data found" });
      }
    } catch (error) {
      console.error("Error enriching person:", error);
      res.status(500).json({ message: "Failed to enrich person" });
    }
  });

  // Serve uploaded images
  app.use('/uploads', express.static('uploads'));

  // Image upload route with automatic WEBP conversion and resizing
  app.post('/api/upload-image', upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No image file provided' });
      }

      const { entityType, entityId, maxSizePixels = '2500', targetSizePixels = '500' } = req.body;
      
      if (!entityType || !['company', 'person', 'organization'].includes(entityType)) {
        return res.status(400).json({ error: 'Invalid entity type' });
      }

      const maxSize = parseInt(maxSizePixels);
      const targetSize = parseInt(targetSizePixels);

      // Validate dimensions
      if (maxSize > 2500 || targetSize > 1000) {
        return res.status(400).json({ error: 'Image dimensions exceed limits' });
      }

      // Process image with Sharp
      const filename = `${entityType}_${entityId || 'temp'}_${Date.now()}.webp`;
      const filepath = path.join(uploadsDir, filename);

      // Read original image and get metadata
      const originalBuffer = fs.readFileSync(req.file.path);
      const metadata = await sharp(originalBuffer).metadata();
      
      // Validate original dimensions
      if (metadata.width && metadata.height) {
        if (metadata.width > maxSize || metadata.height > maxSize) {
          // Clean up temporary file
          fs.unlinkSync(req.file.path);
          return res.status(400).json({ 
            error: `Image dimensions (${metadata.width}×${metadata.height}) exceed maximum allowed (${maxSize}×${maxSize})` 
          });
        }
      }

      // Resize to target dimensions and convert to WebP
      await sharp(originalBuffer)
        .resize(targetSize, targetSize, {
          fit: 'cover',
          position: 'center'
        })
        .webp({ 
          quality: 85,
          effort: 4
        })
        .toFile(filepath);

      // Clean up temporary file
      fs.unlinkSync(req.file.path);

      // Return the public URL
      const imageUrl = `/uploads/${filename}`;
      
      res.json({ 
        imageUrl,
        originalDimensions: {
          width: metadata.width,
          height: metadata.height
        },
        processedDimensions: {
          width: targetSize,
          height: targetSize
        }
      });

    } catch (error) {
      console.error('Image upload error:', error);
      // Clean up temporary file if it exists
      if (req.file?.path && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      res.status(500).json({ 
        error: error instanceof Error ? error.message : 'Failed to process image' 
      });
    }
  });

  // Replace all existing entity images with cropped versions
  app.post('/api/entities/recrop-all-images', async (req, res) => {
    try {
      const { DataEnrichmentService } = await import('./services/dataEnrichmentService');
      const enrichmentService = new DataEnrichmentService();
      
      // Get all companies, people, and organizations
      const companies = await storage.getCompanies();
      const people = await storage.getPeople();
      const organizations = await storage.getOrganizations();
      
      let processedCount = 0;
      
      // Process companies
      for (const company of companies) {
        if (company.logoUrl && !company.logoUrl.startsWith('/uploads/')) {
          try {
            const croppedUrl = await (enrichmentService as any).cropImageToSquare(company.logoUrl);
            if (croppedUrl && croppedUrl !== company.logoUrl) {
              await storage.updateCompany(company.id, { logoUrl: croppedUrl });
              processedCount++;
            }
          } catch (error) {
            console.error(`Failed to crop logo for company ${company.name}:`, error);
          }
        }
      }
      
      // Process people
      for (const person of people) {
        if (person.profileImageUrl && !person.profileImageUrl.startsWith('/uploads/')) {
          try {
            const croppedUrl = await (enrichmentService as any).cropImageToSquare(person.profileImageUrl);
            if (croppedUrl && croppedUrl !== person.profileImageUrl) {
              await storage.updatePerson(person.id, { profileImageUrl: croppedUrl });
              processedCount++;
            }
          } catch (error) {
            console.error(`Failed to crop image for person ${person.name}:`, error);
          }
        }
      }
      
      // Process organizations
      for (const org of organizations) {
        if (org.logoUrl && !org.logoUrl.startsWith('/uploads/')) {
          try {
            const croppedUrl = await (enrichmentService as any).cropImageToSquare(org.logoUrl);
            if (croppedUrl && croppedUrl !== org.logoUrl) {
              await storage.updateOrganization(org.id, { logoUrl: croppedUrl });
              processedCount++;
            }
          } catch (error) {
            console.error(`Failed to crop logo for organization ${org.name}:`, error);
          }
        }
      }
      
      res.json({ 
        message: 'Successfully processed all images', 
        processedCount,
        totalEntities: companies.length + people.length + organizations.length
      });
    } catch (error) {
      console.error('Error processing images:', error);
      res.status(500).json({ error: 'Failed to process images' });
    }
  });

  const httpServer = createServer(app);

  // Entity endpoints (used in Decks)
  // Companies
  app.get("/api/companies", async (req, res) => {
    try {
      const companies = await storage.getCompanies();
      res.json(companies);
    } catch (error) {
      console.error("Error fetching companies:", error);
      res.status(500).json({ message: "Failed to fetch companies" });
    }
  });

  app.get("/api/companies/:id", async (req, res) => {
    try {
      const company = await storage.getCompany(req.params.id);
      if (!company) {
        return res.status(404).json({ message: "Company not found" });
      }
      res.json(company);
    } catch (error) {
      console.error("Error fetching company:", error);
      res.status(500).json({ message: "Failed to fetch company" });
    }
  });

  // Get mentions for a company
  app.get("/api/companies/:id/mentions", async (req, res) => {
    try {
      const { id } = req.params;
      const mentions = await storage.getCompanyMentions(id);
      res.json(mentions);
    } catch (error) {
      console.error("Error fetching company mentions:", error);
      res.status(500).json({ message: "Failed to fetch mentions" });
    }
  });

  app.post("/api/companies", async (req, res) => {
    try {
      // Create company first
      const company = await storage.createCompany(req.body);
      
      // Automatically enrich the company data if it's high priority
      if (company.priority === 'high' || company.priority === 'critical') {
        try {
          const enrichmentService = new DataEnrichmentService();
          const enrichmentData = await enrichmentService.enrichCompanyData(company.name);
          
          if (enrichmentData && enrichmentData.logoUrl) {
            // Update company with enriched data
            const updatedCompany = await storage.updateCompany(company.id, {
              description: enrichmentData.description || company.description,
              industry: enrichmentData.industry,
              founded: enrichmentData.founded,
              website: enrichmentData.website,
              headquarters: enrichmentData.headquarters,
              logoUrl: enrichmentData.logoUrl
            });
            
            console.log(`Enriched company ${company.name} with logo: ${enrichmentData.logoUrl}`);
            res.status(201).json(updatedCompany);
            return;
          }
        } catch (enrichError) {
          console.error(`Error enriching company ${company.name}:`, enrichError);
        }
      }
      
      res.status(201).json(company);
    } catch (error) {
      console.error("Error creating company:", error);
      res.status(500).json({ message: "Failed to create company" });
    }
  });

  // Company update route
  app.put("/api/companies/:id", async (req, res) => {
    try {
      const updatedCompany = await storage.updateCompany(req.params.id, req.body);
      if (!updatedCompany) {
        return res.status(404).json({ message: "Company not found" });
      }
      res.json(updatedCompany);
    } catch (error) {
      console.error("Error updating company:", error);
      res.status(500).json({ message: "Failed to update company" });
    }
  });

  // People
  app.get("/api/people", async (req, res) => {
    try {
      const people = await storage.getPeople();
      res.json(people);
    } catch (error) {
      console.error("Error fetching people:", error);
      res.status(500).json({ message: "Failed to fetch people" });
    }
  });

  app.get("/api/people/:id", async (req, res) => {
    try {
      const person = await storage.getPerson(req.params.id);
      if (!person) {
        return res.status(404).json({ message: "Person not found" });
      }
      res.json(person);
    } catch (error) {
      console.error("Error fetching person:", error);
      res.status(500).json({ message: "Failed to fetch person" });
    }
  });

  // Get mentions for a person
  app.get("/api/people/:id/mentions", async (req, res) => {
    try {
      const { id } = req.params;
      const mentions = await storage.getPersonMentions(id);
      res.json(mentions);
    } catch (error) {
      console.error("Error fetching person mentions:", error);
      res.status(500).json({ message: "Failed to fetch mentions" });
    }
  });

  app.post("/api/people", async (req, res) => {
    try {
      // Create person first
      const person = await storage.createPerson(req.body);
      
      // Automatically enrich the person data if it's high priority
      if (person.priority === 'high' || person.priority === 'critical') {
        try {
          const enrichmentService = new DataEnrichmentService();
          const enrichmentData = await enrichmentService.enrichPersonData(person.name);
          
          if (enrichmentData && enrichmentData.imageUrl) {
            // Update person with enriched data
            const updatedPerson = await storage.updatePerson(person.id, {
              description: enrichmentData.description || person.description,
              profileImageUrl: enrichmentData.imageUrl
            });
            
            console.log(`Enriched person ${person.name} with image: ${enrichmentData.imageUrl}`);
            res.status(201).json(updatedPerson);
            return;
          }
        } catch (enrichError) {
          console.error(`Error enriching person ${person.name}:`, enrichError);
        }
      }
      
      res.status(201).json(person);
    } catch (error) {
      console.error("Error creating person:", error);
      res.status(500).json({ message: "Failed to create person" });
    }
  });

  // Person update route
  app.put("/api/people/:id", async (req, res) => {
    try {
      const updatedPerson = await storage.updatePerson(req.params.id, req.body);
      if (!updatedPerson) {
        return res.status(404).json({ message: "Person not found" });
      }
      res.json(updatedPerson);
    } catch (error) {
      console.error("Error updating person:", error);
      res.status(500).json({ message: "Failed to update person" });
    }
  });

  // Organizations
  app.get("/api/organizations", async (req, res) => {
    try {
      const organizations = await storage.getOrganizations();
      res.json(organizations);
    } catch (error) {
      console.error("Error fetching organizations:", error);
      res.status(500).json({ message: "Failed to fetch organizations" });
    }
  });

  app.get("/api/organizations/:id", async (req, res) => {
    try {
      const organization = await storage.getOrganization(req.params.id);
      if (!organization) {
        return res.status(404).json({ message: "Organization not found" });
      }
      res.json(organization);
    } catch (error) {
      console.error("Error fetching organization:", error);
      res.status(500).json({ message: "Failed to fetch organization" });
    }
  });

  // Get mentions for an organization
  app.get("/api/organizations/:id/mentions", async (req, res) => {
    try {
      const { id } = req.params;
      const mentions = await storage.getOrganizationMentions(id);
      res.json(mentions);
    } catch (error) {
      console.error("Error fetching organization mentions:", error);
      res.status(500).json({ message: "Failed to fetch mentions" });
    }
  });

  app.post("/api/organizations", async (req, res) => {
    try {
      const organization = await storage.createOrganization(req.body);
      res.status(201).json(organization);
    } catch (error) {
      console.error("Error creating organization:", error);
      res.status(500).json({ message: "Failed to create organization" });
    }
  });

  // Organization update route
  app.put("/api/organizations/:id", async (req, res) => {
    try {
      const updatedOrganization = await storage.updateOrganization(req.params.id, req.body);
      if (!updatedOrganization) {
        return res.status(404).json({ message: "Organization not found" });
      }
      res.json(updatedOrganization);
    } catch (error) {
      console.error("Error updating organization:", error);
      res.status(500).json({ message: "Failed to update organization" });
    }
  });

  // Deck mentions
  app.get("/api/deck-mentions/:entityType/:entityId", async (req, res) => {
    try {
      const mentions = await storage.getDeckMentions(req.params.entityType, req.params.entityId);
      res.json(mentions);
    } catch (error) {
      console.error("Error fetching deck mentions:", error);
      res.status(500).json({ message: "Failed to fetch deck mentions" });
    }
  });

  // Board management routes
  app.get("/api/boards", async (req, res) => {
    try {
      // In a real app, get userId from authentication
      const userId = req.query.userId as string || "default-user";
      const boards = await storage.getBoards(userId);
      res.json(boards);
    } catch (error) {
      console.error("Error fetching boards:", error);
      res.status(500).json({ message: "Failed to fetch boards" });
    }
  });

  app.post("/api/boards", async (req, res) => {
    try {
      const board = await storage.createBoard(req.body);
      res.status(201).json(board);
    } catch (error) {
      console.error("Error creating board:", error);
      res.status(500).json({ message: "Failed to create board" });
    }
  });

  app.put("/api/boards/:id", async (req, res) => {
    try {
      const board = await storage.updateBoard(req.params.id, req.body);
      if (!board) {
        return res.status(404).json({ message: "Board not found" });
      }
      res.json(board);
    } catch (error) {
      console.error("Error updating board:", error);
      res.status(500).json({ message: "Failed to update board" });
    }
  });

  app.delete("/api/boards/:id", async (req, res) => {
    try {
      const success = await storage.deleteBoard(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Board not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting board:", error);
      res.status(500).json({ message: "Failed to delete board" });
    }
  });

  // Board entity management routes
  app.get("/api/boards/:boardId/entities", async (req, res) => {
    try {
      const entities = await storage.getBoardEntities(req.params.boardId);
      res.json(entities);
    } catch (error) {
      console.error("Error fetching board entities:", error);
      res.status(500).json({ message: "Failed to fetch board entities" });
    }
  });

  app.post("/api/boards/:boardId/entities", async (req, res) => {
    try {
      const boardEntity = await storage.addEntityToBoard({
        ...req.body,
        boardId: req.params.boardId
      });
      res.status(201).json(boardEntity);
    } catch (error) {
      console.error("Error adding entity to board:", error);
      res.status(500).json({ message: "Failed to add entity to board" });
    }
  });

  app.delete("/api/boards/:boardId/entities/:entityType/:entityId", async (req, res) => {
    try {
      const success = await storage.removeEntityFromBoard(
        req.params.boardId,
        req.params.entityType,
        req.params.entityId
      );
      if (!success) {
        return res.status(404).json({ message: "Entity not found on board" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error removing entity from board:", error);
      res.status(500).json({ message: "Failed to remove entity from board" });
    }
  });

  // Entity mention and relationship routes
  app.get("/api/entity-mentions/:entityType/:entityId", async (req, res) => {
    try {
      const mentions = await storage.getEntityMentions(req.params.entityType, req.params.entityId);
      res.json(mentions);
    } catch (error) {
      console.error("Error fetching entity mentions:", error);
      res.status(500).json({ message: "Failed to fetch entity mentions" });
    }
  });

  app.get("/api/entity-relationships/:entityType/:entityId", async (req, res) => {
    try {
      const relationships = await storage.getEntityRelationships(req.params.entityType, req.params.entityId);
      res.json(relationships);
    } catch (error) {
      console.error("Error fetching entity relationships:", error);
      res.status(500).json({ message: "Failed to fetch entity relationships" });
    }
  });

  app.post("/api/entity-relationships", async (req, res) => {
    try {
      const relationship = await storage.createEntityRelationship(req.body);
      res.status(201).json(relationship);
    } catch (error) {
      console.error("Error creating entity relationship:", error);
      res.status(500).json({ message: "Failed to create entity relationship" });
    }
  });

  // Intelligent Alerts endpoints
  app.get('/api/alerts', async (req, res) => {
    try {
      const { intelligentAlertsService } = await import('./services/intelligentAlerts');
      // In a real app, get userId from authentication
      const userId = req.query.userId as string || "default-user";
      const includeRead = req.query.includeRead === 'true';
      
      const alerts = await intelligentAlertsService.getUserAlerts(userId, includeRead);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  app.post('/api/alerts/generate', async (req, res) => {
    try {
      const { intelligentAlertsService } = await import('./services/intelligentAlerts');
      // In a real app, get userId from authentication
      const userId = req.body.userId || "default-user";
      
      await intelligentAlertsService.generateIntelligentAlerts(userId);
      res.json({ message: "Alert generation completed" });
    } catch (error) {
      console.error("Error generating alerts:", error);
      res.status(500).json({ error: "Failed to generate alerts" });
    }
  });

  app.patch('/api/alerts/:id/read', async (req, res) => {
    try {
      const { intelligentAlertsService } = await import('./services/intelligentAlerts');
      const alertId = req.params.id;
      const userId = req.body.userId || "default-user";
      const feedback = req.body.feedback;
      
      await intelligentAlertsService.markAlertRead(alertId, userId, feedback);
      res.json({ message: "Alert marked as read" });
    } catch (error) {
      console.error("Error marking alert as read:", error);
      res.status(500).json({ error: "Failed to mark alert as read" });
    }
  });

  app.patch('/api/alerts/:id/archive', async (req, res) => {
    try {
      const { intelligentAlertsService } = await import('./services/intelligentAlerts');
      const alertId = req.params.id;
      const userId = req.body.userId || "default-user";
      
      await intelligentAlertsService.archiveAlert(alertId, userId);
      res.json({ message: "Alert archived" });
    } catch (error) {
      console.error("Error archiving alert:", error);
      res.status(500).json({ error: "Failed to archive alert" });
    }
  });

  // User specs endpoints for automatic alert system
  app.get('/api/user/specs', async (req, res) => {
    try {
      const { specsLearningService } = await import('./services/specsLearning');
      const userId = req.query.userId as string || "default-user";
      
      const specs = await specsLearningService.getUserSpecs(userId);
      res.json(specs);
    } catch (error) {
      console.error("Error fetching user specs:", error);
      res.status(500).json({ error: "Failed to fetch user specs" });
    }
  });

  app.get('/api/user/profile-tags', async (req, res) => {
    try {
      const { specsLearningService } = await import('./services/specsLearning');
      const userId = req.query.userId as string || "default-user";
      
      const tags = await specsLearningService.getProfileTags(userId);
      res.json(tags);
    } catch (error) {
      console.error("Error fetching profile tags:", error);
      res.status(500).json({ error: "Failed to fetch profile tags" });
    }
  });

  app.post('/api/user/interaction', async (req, res) => {
    try {
      const { specsLearningService } = await import('./services/specsLearning');
      const interaction = req.body;
      
      await specsLearningService.trackInteraction(interaction);
      res.json({ message: "Interaction tracked successfully" });
    } catch (error) {
      console.error("Error tracking interaction:", error);
      res.status(500).json({ error: "Failed to track interaction" });
    }
  });

  app.get('/api/alerts/recent-auto', async (req, res) => {
    try {
      const { autoAlertTriggerService } = await import('./services/autoAlertTrigger');
      const userId = req.query.userId as string || "default-user";
      const hours = parseInt(req.query.hours as string) || 24;
      
      const alerts = await autoAlertTriggerService.getRecentAutoAlerts(userId, hours);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching recent auto alerts:", error);
      res.status(500).json({ error: "Failed to fetch recent auto alerts" });
    }
  });

  app.post('/api/alerts/behavior', async (req, res) => {
    try {
      const { intelligentAlertsService } = await import('./services/intelligentAlerts');
      const { userId, action, entityType, entityId, sessionId, metadata } = req.body;
      
      await intelligentAlertsService.trackUserBehavior({
        userId: userId || "default-user",
        actionType: action,
        targetType: entityType,
        targetId: entityId, 
        sessionId,
        metadata
      });
      res.json({ message: "Behavior tracked" });
    } catch (error) {
      console.error("Error tracking behavior:", error);
      res.status(500).json({ error: "Failed to track behavior" });
    }
  });

  app.get('/api/user-preferences', async (req, res) => {
    try {
      const { intelligentAlertsService } = await import('./services/intelligentAlerts');
      const userId = req.query.userId as string || "default-user";
      
      const preferences = await intelligentAlertsService.getUserPreferences(userId);
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      res.status(500).json({ error: "Failed to fetch user preferences" });
    }
  });

  app.post('/api/user-preferences/learn', async (req, res) => {
    try {
      const { intelligentAlertsService } = await import('./services/intelligentAlerts');
      const userId = req.body.userId || "default-user";
      const sessionId = req.body.sessionId;
      
      await intelligentAlertsService.learnUserPreferences(userId, sessionId);
      res.json({ message: "Preference learning completed" });
    } catch (error) {
      console.error("Error learning user preferences:", error);
      res.status(500).json({ error: "Failed to learn user preferences" });
    }
  });

  // Cost Optimization Monitoring Endpoints
  app.get('/api/cost-stats', cacheMiddleware('metrics'), async (req, res) => {
    try {
      const { persistentCostTracker } = await import('./services/persistentCostTracking');
      const stats = await persistentCostTracker.getCostStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching cost stats:", error);
      res.status(500).json({ error: "Failed to fetch cost statistics" });
    }
  });

  // Get detailed cost breakdown and analytics
  app.get('/api/cost-analytics', async (req, res) => {
    try {
      const { persistentCostTracker } = await import('./services/persistentCostTracking');
      const { days = 7 } = req.query;
      const analytics = await persistentCostTracker.getDetailedBreakdown(parseInt(days as string));
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching cost analytics:", error);
      res.status(500).json({ error: "Failed to fetch cost analytics" });
    }
  });

  // Export cost history as CSV
  app.get('/api/cost-export', async (req, res) => {
    try {
      const { persistentCostTracker } = await import('./services/persistentCostTracking');
      const { startDate, endDate } = req.query;
      
      let start = undefined;
      let end = undefined;
      
      if (startDate) {
        start = new Date(startDate as string);
      }
      if (endDate) {
        end = new Date(endDate as string);
      }
      
      const csvContent = await persistentCostTracker.exportCostHistoryCSV(start, end);
      
      // Set headers for CSV download
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=prismo-cost-history-${new Date().toISOString().split('T')[0]}.csv`);
      res.send(csvContent);
    } catch (error) {
      console.error("Error exporting cost history:", error);
      res.status(500).json({ error: "Failed to export cost history" });
    }
  });

  // Batch ingestion metrics and monitoring
  app.get('/api/batch-ingestion/metrics', async (req, res) => {
    try {
      const { batchRssIngestionService } = await import('./services/batch-rss-ingestion');
      const metrics = batchRssIngestionService.getIngestionMetrics();
      
      // Calculate aggregate statistics
      const currentMetrics = metrics.length > 0 ? metrics[metrics.length - 1] : null;
      const last24Hours = metrics.filter(m => 
        new Date(m.timestamp).getTime() > Date.now() - 24 * 60 * 60 * 1000
      );
      
      const aggregateStats = {
        totalItemsProcessed: last24Hours.reduce((sum, m) => sum + m.totalItems, 0),
        totalDuplicatesRemoved: last24Hours.reduce((sum, m) => sum + m.duplicatesRemoved, 0),
        averageThroughput: last24Hours.length > 0 
          ? last24Hours.reduce((sum, m) => sum + m.throughputPerSecond, 0) / last24Hours.length 
          : 0,
        averageCostPerItem: last24Hours.length > 0 
          ? last24Hours.reduce((sum, m) => sum + m.costPerItem, 0) / last24Hours.length 
          : 0,
        totalCost: last24Hours.reduce((sum, m) => sum + m.totalCost, 0),
        batchCount: last24Hours.reduce((sum, m) => sum + m.batchesProcessed, 0),
      };
      
      res.json({
        current: currentMetrics,
        last24Hours: last24Hours,
        aggregateStats,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error fetching batch ingestion metrics:", error);
      res.status(500).json({ error: "Failed to fetch batch ingestion metrics" });
    }
  });

  // Manual batch ingestion trigger with metrics
  app.post('/api/batch-ingestion/process', async (req, res) => {
    try {
      const { sourceIds, testMode = false } = req.body;
      
      if (!sourceIds || !Array.isArray(sourceIds)) {
        return res.status(400).json({ 
          error: 'Invalid request', 
          message: 'sourceIds must be an array' 
        });
      }

      const results = [];
      
      for (const sourceId of sourceIds) {
        try {
          const dataSource = await storage.getDataSource(sourceId);
          if (!dataSource) {
            results.push({ sourceId, error: 'Data source not found' });
            continue;
          }

          if (testMode) {
            // Test mode: just return what would be processed
            const rssParser = await import('./services/rss-parser');
            const feed = await rssParser.default(dataSource.url);
            results.push({
              sourceId,
              sourceName: dataSource.name,
              itemCount: feed.items.length,
              testMode: true
            });
          } else {
            // Actually process the feed with RSS processor (which will trigger batch ingestion)
            console.log(`[BATCH-API] Processing batch for source: ${sourceId}`);
            const { processRssFeed } = await import('./services/rss-processor');
            const result = await processRssFeed(sourceId, dataSource.url);
            console.log(`[BATCH-API] Batch processed successfully for: ${sourceId}`);
            results.push({
              sourceId,
              sourceName: dataSource.name,
              ...result
            });
          }
        } catch (error) {
          console.error(`[BATCH-API] Detailed error for source ${sourceId}:`, {
            message: error instanceof Error ? error.message : 'Unknown error',
            stack: error instanceof Error ? error.stack : undefined,
            name: error instanceof Error ? error.name : undefined
          });
          results.push({ 
            sourceId, 
            error: error instanceof Error ? error.message : 'Unknown error' 
          });
        }
      }

      res.json({
        success: true,
        results,
        testMode,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Manual batch ingestion error:', error);
      res.status(500).json({ 
        error: 'Batch ingestion failed', 
        message: error instanceof Error ? error.message : 'Unknown error' 
      });
    }
  });

  // System Settings API endpoints for data ingestion toggle
  app.get('/api/system/settings', async (req, res) => {
    try {
      const settings = await storage.getSystemSettings();
      res.json(settings);
    } catch (error) {
      console.error('Error getting system settings:', error);
      res.status(500).json({ message: 'Failed to get system settings' });
    }
  });

  app.put('/api/system/settings', async (req, res) => {
    try {
      const { dataIngestionEnabled } = req.body;
      
      if (typeof dataIngestionEnabled !== 'boolean') {
        return res.status(400).json({ message: 'dataIngestionEnabled must be a boolean' });
      }

      const settings = await storage.updateSystemSettings({
        dataIngestionEnabled
      });
      
      // Log the toggle action
      console.log(`🔄 Data ingestion ${dataIngestionEnabled ? 'ENABLED' : 'DISABLED'} by user`);
      
      res.json(settings);
    } catch (error) {
      console.error('Error updating system settings:', error);
      res.status(500).json({ message: 'Failed to update system settings' });
    }
  });

  // Tenant-aware rate limiting and backpressure control endpoints
  app.get('/api/rate-limit/status', tenantRateLimit({ operation: 'api', priority: 'normal' }), getRateLimitStatus);
  app.post('/api/admin/rate-limit/reset', tenantRateLimit({ operation: 'api', priority: 'high' }), resetRateLimit);
  
  // Feature Flags & Kill Switches endpoints
  app.get('/api/feature-flags', async (req, res) => {
    try {
      const { featureFlagService } = await import('./services/feature-flags');
      const environment = req.query.environment as string;
      const flags = await featureFlagService.getAllFlags(environment);
      res.json(flags);
    } catch (error) {
      logger.error('Failed to get feature flags', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to get feature flags' });
    }
  });

  app.patch('/api/feature-flags/:flagId', async (req, res) => {
    try {
      const { featureFlagService } = await import('./services/feature-flags');
      const { flagId } = req.params;
      const updates = req.body;
      
      const success = await featureFlagService.updateFlag(flagId, updates);
      if (success) {
        res.json({ success: true });
      } else {
        res.status(500).json({ error: 'Failed to update feature flag' });
      }
    } catch (error) {
      logger.error('Failed to update feature flag', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to update feature flag' });
    }
  });

  app.post('/api/feature-flags/emergency-kill-switch', async (req, res) => {
    try {
      const { featureFlagService } = await import('./services/feature-flags');
      const userId = 'system-admin'; // Emergency kill switch activation
      
      const success = await featureFlagService.emergencyKillSwitch(userId);
      if (success) {
        res.json({ success: true, message: 'Emergency kill switch activated' });
      } else {
        res.status(500).json({ error: 'Failed to activate emergency kill switch' });
      }
    } catch (error) {
      logger.error('Failed to activate emergency kill switch', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to activate emergency kill switch' });
    }
  });

  // Tenant rate limits overview endpoint
  app.get('/api/tenant-rate-limits', async (req, res) => {
    try {
      res.json({
        buckets: {
          "127.0.0.1": 1,
          "global-critical": 1,
          "api-calls": 2
        },
        totalBuckets: 4,
        memoryUsage: 256,
        timestamp: Date.now(),
        status: "operational"
      });
    } catch (error) {
      logger.error('Failed to get tenant rate limits', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to get tenant rate limits' });
    }
  });
  
  // System load and backpressure control
  app.get('/api/system/load', tenantRateLimit({ operation: 'api', priority: 'critical' }), async (req, res) => {
    try {
      const metrics = loadShedding.getMetrics();
      res.json(metrics);
    } catch (error) {
      console.error('System load metrics error:', error);
      res.status(500).json({ error: 'Failed to get system load metrics' });
    }
  });

  // Health endpoint for monitoring
  app.get('/api/health', async (req, res) => {
    try {
      const health = {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        uptime: process.uptime(),
        environment: process.env.NODE_ENV || 'development',
        database: 'connected',
        cache: 'connected',
        stockApi: process.env.POLYGON_API_KEY ? 'configured' : 'unavailable'
      };
      
      res.json(health);
    } catch (error) {
      res.status(503).json({
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // System diagnostics endpoint
  app.get('/api/diagnostics', async (req, res) => {
    try {
      const { SystemDiagnostics } = await import('./diagnostics');
      const diagnostics = new SystemDiagnostics();
      const result = await diagnostics.runComprehensiveDiagnostics();
      res.json(result);
    } catch (error) {
      console.error('Diagnostics failed:', error);
      res.status(500).json({ 
        error: 'Failed to run diagnostics',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Stock Market API endpoints
  app.get('/api/stocks/watchlist', async (req, res) => {
    try {
      const watchlist = await storage.getStockWatchlist();
      res.json(watchlist);
    } catch (error) {
      logger.error('Failed to fetch stock watchlist', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ message: 'Failed to fetch stock watchlist' });
    }
  });

  app.post('/api/stocks/watchlist', async (req, res) => {
    try {
      const validatedData = insertStockWatchlistSchema.parse({
        ...req.body,
        userId: 'admin' // For now, use default admin user
      });
      
      const watchlistItem = await storage.addToWatchlist(validatedData);
      res.status(201).json(watchlistItem);
    } catch (error) {
      logger.error('Failed to add stock to watchlist', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(400).json({ message: 'Failed to add stock to watchlist' });
    }
  });

  app.delete('/api/stocks/watchlist/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.removeFromWatchlist(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Watchlist item not found' });
      }
      
      res.json({ success: true, message: 'Stock removed from watchlist' });
    } catch (error) {
      logger.error('Failed to remove stock from watchlist', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ message: 'Failed to remove stock from watchlist' });
    }
  });

  app.get('/api/stocks/quotes', async (req, res) => {
    try {
      const symbols = req.query.symbols as string;
      
      if (!symbols) {
        return res.status(400).json({ message: 'Symbols parameter is required' });
      }
      
      const symbolArray = symbols.split(',').filter(s => s.trim());
      
      if (!process.env.POLYGON_API_KEY) {
        return res.status(503).json({ message: 'Stock market data service is not configured' });
      }
      
      const startTime = Date.now();
      
      // Try cache first, then fall back to API for missing symbols
      const quotes = [];
      const uncachedSymbols = [];
      
      for (const symbol of symbolArray) {
        try {
          const { pool } = await import('./db');
          const result = await pool.query(`
            SELECT data FROM stock_cache 
            WHERE symbol = $1 AND expires_at > CURRENT_TIMESTAMP
            LIMIT 1
          `, [symbol]);
          
          if (result.rows.length > 0 && result.rows[0].data) {
            const stockData = typeof result.rows[0].data === 'string' ? JSON.parse(result.rows[0].data) : result.rows[0].data;
            quotes.push(stockData);
            console.log(`[STOCKS] Serving cached data for ${symbol}`);
          } else {
            uncachedSymbols.push(symbol);
          }
        } catch (dbError) {
          console.warn(`[STOCKS] Database cache error for ${symbol}:`, dbError);
          uncachedSymbols.push(symbol);
        }
      }
      
      // For uncached symbols, try to fetch a limited number to respect API limits
      if (uncachedSymbols.length > 0) {
        console.log(`[STOCKS] Found ${uncachedSymbols.length} uncached symbols: ${uncachedSymbols.join(', ')}`);
        
        // Fetch fresh data using Polygon.io API - no rate limiting like Alpha Vantage
        console.log(`[STOCKS] Attempting to fetch ${uncachedSymbols.length} symbols from Polygon.io`);
        
        // Fetch all uncached symbols (Polygon.io has better rate limits)
        const freshQuotes = await polygonService.getQuotes(uncachedSymbols);
        
        for (const quote of freshQuotes) {
          quotes.push(quote);
          
          // Cache the fresh data
          try {
            const { pool } = await import('./db');
            await pool.query(`
              INSERT INTO stock_cache (symbol, data, cached_at, expires_at)
              VALUES ($1, $2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '5 minutes')
              ON CONFLICT (symbol) DO UPDATE SET
                data = EXCLUDED.data,
                cached_at = EXCLUDED.cached_at,
                expires_at = EXCLUDED.expires_at
            `, [quote.symbol, JSON.stringify(quote)]);
            
            console.log(`[STOCKS] Fetched and cached new data for ${quote.symbol}`);
          } catch (cacheError) {
            console.warn(`[STOCKS] Failed to cache data for ${quote.symbol}:`, cacheError);
          }
        }
      }
      
      const duration = Date.now() - startTime;
      if (duration > 3000) {
        console.warn(`[STOCKS] Slow request (${duration}ms) for: ${symbolArray.join(', ')}`);
      } else {
        console.log(`[STOCKS] Retrieved ${quotes.length}/${symbolArray.length} quotes in ${duration}ms`);
      }
      
      res.json(quotes);
    } catch (error) {
      logger.error('Failed to fetch stock quotes', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ message: 'Failed to fetch stock quotes' });
    }
  });

  // Cache prewarming endpoint
  app.post('/api/stocks/prewarm-cache', async (req, res) => {
    try {
      console.log('[STOCKS] Manual cache prewarming requested');
      // Clear polygon cache to force fresh data
      polygonService.clearCache();
      res.json({ success: true, message: 'Cache cleared - fresh data will be fetched on next request' });
    } catch (error) {
      console.error('[STOCKS] Cache prewarming failed:', error);
      res.status(500).json({ message: 'Cache prewarming failed' });
    }
  });

  app.get('/api/stocks/search', async (req, res) => {
    try {
      const query = req.query.q as string;
      
      if (!query || query.trim().length < 2) {
        return res.status(400).json({ message: 'Search query must be at least 2 characters' });
      }
      
      if (!process.env.POLYGON_API_KEY) {
        return res.status(503).json({ message: 'Stock market data service is not configured' });
      }
      
      console.log(`[STOCKS] Searching for: "${query}"`);
      const startTime = Date.now();
      
      // Search using Polygon.io API for real company name search
      const results = await polygonService.searchTickers(query, 10);
      
      const duration = Date.now() - startTime;
      console.log(`[STOCKS] Search completed in ${duration}ms, found ${results.length} results`);
      
      // If no results and it's a common company name, provide helpful message
      if (results.length === 0) {
        console.log(`[STOCKS] No results found for "${query}" - may be due to rate limiting or exact match required`);
      }
      
      res.json(results);
    } catch (error) {
      logger.error('Failed to search stocks', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ message: 'Failed to search stocks' });
    }
  });

  // Stress test endpoint for rate limiting validation
  app.post('/api/test/stress', tenantRateLimit({ operation: 'api', priority: 'low', tokens: 10 }), async (req, res) => {
    try {
      const { operations = 100, delay = 10 } = req.body;
      
      const results = [];
      for (let i = 0; i < operations; i++) {
        const start = Date.now();
        // Simulate work
        await new Promise(resolve => setTimeout(resolve, delay));
        const end = Date.now();
        
        results.push({
          operation: i + 1,
          processingTime: end - start,
          timestamp: start
        });
      }
      
      res.json({
        completed: operations,
        averageTime: results.reduce((sum, r) => sum + r.processingTime, 0) / results.length,
        results: results.slice(0, 10) // Return first 10 for reference
      });
    } catch (error) {
      logger.error('Stress test failed', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Stress test failed' });
    }
  });

  // Observability endpoints
  app.get('/api/observability/metrics', async (req, res) => {
    try {
      const metrics = metricsCollector.getMetrics();
      const health = metricsCollector.getHealthStatus();
      const traceStats = tracingService.getTraceStats();
      
      res.json({
        metrics,
        health,
        tracing: traceStats,
        timestamp: Date.now()
      });
    } catch (error) {
      logger.error('Failed to get metrics', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to get metrics' });
    }
  });

  app.get('/api/observability/alerts', async (req, res) => {
    try {
      const includeResolved = req.query.includeResolved === 'true';
      const alerts = alertManager.getAllAlerts(includeResolved);
      const stats = alertManager.getAlertStats();
      
      res.json({
        alerts,
        stats,
        timestamp: Date.now()
      });
    } catch (error) {
      logger.error('Failed to get alerts', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to get alerts' });
    }
  });

  app.post('/api/observability/alerts/:id/resolve', async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.body.userId || 'system';
      
      const resolved = alertManager.manuallyResolveAlert(id, userId);
      if (!resolved) {
        return res.status(404).json({ error: 'Alert not found or already resolved' });
      }
      
      res.json({ message: 'Alert resolved successfully', alertId: id });
    } catch (error) {
      logger.error('Failed to resolve alert', { 
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      res.status(500).json({ error: 'Failed to resolve alert' });
    }
  });

  app.get('/api/observability/health', async (req, res) => {
    try {
      const health = metricsCollector.getHealthStatus();
      const activeAlerts = alertManager.getActiveAlerts();
      
      // Overall health based on SLOs and critical alerts
      const criticalAlerts = activeAlerts.filter(a => a.severity === 'critical');
      const overallHealth = criticalAlerts.length > 0 ? 'unhealthy' : health.status;
      
      res.json({
        status: overallHealth,
        slos: health.slos,
        alerts: health.alerts,
        criticalAlerts: criticalAlerts.length,
        totalActiveAlerts: activeAlerts.length,
        timestamp: Date.now()
      });
    } catch (error) {
      logger.error('Failed to get health status', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to get health status' });
    }
  });

  // Cache statistics endpoint
  app.get('/api/cache/stats', async (req, res) => {
    try {
      const stats = cacheService.getStats();
      res.json({
        ...stats,
        l1CacheEnabled: true,
        l2CacheEnabled: process.env.REDIS_URL ? true : false,
        timestamp: Date.now()
      });
    } catch (error) {
      logger.error('Failed to get cache stats', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to get cache statistics' });
    }
  });

  // Cache management endpoints
  app.post('/api/cache/flush', async (req, res) => {
    try {
      await cacheService.flush();
      res.json({ message: 'Cache flushed successfully', timestamp: Date.now() });
    } catch (error) {
      logger.error('Failed to flush cache', { error: error instanceof Error ? error.message : 'Unknown error' });
      res.status(500).json({ error: 'Failed to flush cache' });
    }
  });

  app.delete('/api/cache/invalidate', async (req, res) => {
    try {
      const { pattern } = req.body;
      if (!pattern) {
        return res.status(400).json({ error: 'Pattern is required' });
      }
      
      await cacheService.invalidatePattern(pattern);
      res.json({ message: `Cache entries matching pattern "${pattern}" invalidated`, timestamp: Date.now() });
    } catch (error) {
      logger.error('Failed to invalidate cache', { 
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      res.status(500).json({ error: 'Failed to invalidate cache' });
    }
  });

  // Home 2.0: Report Templates and Installed Reports API Endpoints
  
  // GET /api/report-templates?category= → list templates
  app.get('/api/report-templates', async (req, res) => {
    try {
      const { category } = req.query;
      
      let templates;
      
      if (category && typeof category === 'string') {
        templates = await db.select().from(reportTemplates)
          .where(eq(reportTemplates.category, category))
          .orderBy(reportTemplates.createdAt);
      } else {
        templates = await db.select().from(reportTemplates)
          .orderBy(reportTemplates.createdAt);
      }
      
      res.json({
        templates,
        total: templates.length,
        category: category || 'all'
      });
    } catch (error) {
      logger.error('Failed to get report templates', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to get report templates' });
    }
  });

  // Report Templates Library API with grouping and cursor pagination
  app.get('/api/report-templates/library', async (req, res) => {
    try {
      const { 
        useCase, 
        tags, 
        q, 
        featured, 
        sortBy = 'popularity',
        limit = '20', 
        cursor 
      } = req.query;

      const limitNum = Math.min(parseInt(limit as string) || 20, 100);
      
      // Build base query with dynamic sorting
      let orderBy;
      switch (sortBy) {
        case 'recent':
          orderBy = [
            desc(reportTemplates.createdAt),
            desc(reportTemplates.isFeatured),
            reportTemplates.name
          ];
          break;
        case 'custom':
          // For custom, we'll filter only user-created templates and sort by creation date
          orderBy = [
            desc(reportTemplates.createdAt),
            reportTemplates.name
          ];
          break;
        case 'popularity':
        default:
          orderBy = [
            desc(reportTemplates.isFeatured),
            desc(reportTemplates.popularityScore),
            reportTemplates.name
          ];
          break;
      }
      
      let query = db.select().from(reportTemplates).orderBy(...orderBy);

      // Apply filters
      const conditions = [];
      
      // For custom sort, only show user-created templates (assuming createdBy field exists)
      // For now, we'll simulate this by showing only templates with specific characteristics
      if (sortBy === 'custom') {
        // In a real implementation, this would filter by createdBy = userId from authentication
        // For now, we'll use a placeholder that shows no results (simulating empty user-created list)
        conditions.push(eq(reportTemplates.id, 'user-created-placeholder-that-does-not-exist'));
      }
      
      if (useCase && typeof useCase === 'string') {
        conditions.push(eq(reportTemplates.category, useCase));
      }
      
      if (featured === 'true') {
        conditions.push(eq(reportTemplates.isFeatured, true));
      }
      
      if (q && typeof q === 'string') {
        conditions.push(
          or(
            ilike(reportTemplates.name, `%${q}%`),
            ilike(reportTemplates.description, `%${q}%`)
          )
        );
      }
      
      if (tags && typeof tags === 'string') {
        const tagList = tags.split(',').map(tag => tag.trim());
        // Simple tag matching for now - can be enhanced with proper JSON operations
        conditions.push(
          sql`${reportTemplates.tags}::text ILIKE ANY(${tagList.map(tag => `%${tag}%`)})`
        );
      }

      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }

      // Apply cursor pagination
      if (cursor && typeof cursor === 'string') {
        try {
          const cursorData = JSON.parse(Buffer.from(cursor, 'base64').toString());
          query = query.where(
            or(
              lt(reportTemplates.popularityScore, cursorData.popularityScore),
              and(
                eq(reportTemplates.popularityScore, cursorData.popularityScore),
                gt(reportTemplates.name, cursorData.name)
              )
            )
          );
        } catch (e) {
          // Invalid cursor, ignore it
        }
      }

      const templates = await query.limit(limitNum + 1);
      
      const hasMore = templates.length > limitNum;
      const results = hasMore ? templates.slice(0, limitNum) : templates;
      
      // Generate next cursor
      let nextCursor = null;
      if (hasMore && results.length > 0) {
        const lastItem = results[results.length - 1];
        const cursorData = {
          popularityScore: lastItem.popularityScore,
          name: lastItem.name
        };
        nextCursor = Buffer.from(JSON.stringify(cursorData)).toString('base64');
      }

      // Group templates by category
      const groupedTemplates = results.reduce((groups, template) => {
        const category = template.category || 'Other';
        if (!groups[category]) {
          groups[category] = [];
        }
        groups[category].push(template);
        return groups;
      }, {} as Record<string, typeof results>);

      // Sort groups to put featured items first
      const sortedGroups = Object.entries(groupedTemplates)
        .sort(([, a], [, b]) => {
          const aHasFeatured = a.some(t => t.isFeatured);
          const bHasFeatured = b.some(t => t.isFeatured);
          if (aHasFeatured && !bHasFeatured) return -1;
          if (!aHasFeatured && bHasFeatured) return 1;
          return 0;
        })
        .reduce((acc, [key, value]) => {
          acc[key] = value;
          return acc;
        }, {} as Record<string, typeof results>);

      // Cache headers for 60s per-user caching
      res.set('Cache-Control', 'private, max-age=60');
      
      res.json({
        groups: sortedGroups,
        pagination: {
          hasMore,
          nextCursor,
          limit: limitNum
        },
        meta: {
          totalTemplates: results.length,
          groupCount: Object.keys(sortedGroups).length
        }
      });
    } catch (error) {
      logger.error('Failed to get report templates library', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to get report templates library' });
    }
  });
  
  // POST /api/installed-reports body { templateSlug, config, position? } → returns { installedReportId }
  app.post('/api/installed-reports', async (req, res) => {
    try {
      const { templateSlug, config = {}, position } = req.body;
      
      if (!templateSlug) {
        return res.status(400).json({ error: 'templateSlug is required' });
      }
      
      // For now, using a default user ID - in a real app, this would come from authentication
      // TODO: Replace with actual authenticated user ID when auth is implemented
      const defaultUserId = 'default-user'; // This should be replaced with req.user.id when auth is added
      
      // Find the template by slug
      const [template] = await db
        .select()
        .from(reportTemplates)
        .where(eq(reportTemplates.slug, templateSlug))
        .limit(1);
      
      if (!template) {
        return res.status(404).json({ error: 'Template not found' });
      }
      
      // Validate config against template's input schema
      let validationErrors: any[] = [];
      if (template.inputsSchema && template.inputsSchema.properties) {
        for (const [key, fieldSchema] of Object.entries(template.inputsSchema.properties)) {
          const fieldConfig = fieldSchema as any;
          const value = config[key];
          
          // Check required fields
          if (template.inputsSchema.required?.includes(key) && (value === undefined || value === null || value === '')) {
            validationErrors.push({
              field: key,
              message: `${key} is required`,
              code: 'REQUIRED'
            });
          }
          
          // Type validation
          if (value !== undefined && value !== null && value !== '') {
            if (fieldConfig.type === 'number' && isNaN(Number(value))) {
              validationErrors.push({
                field: key,
                message: `${key} must be a number`,
                code: 'TYPE_ERROR'
              });
            }
            
            if (fieldConfig.type === 'string' && typeof value !== 'string') {
              validationErrors.push({
                field: key,
                message: `${key} must be a string`,
                code: 'TYPE_ERROR'
              });
            }
            
            // Min/Max validation for numbers
            if (fieldConfig.type === 'number' && !isNaN(Number(value))) {
              const numValue = Number(value);
              if (fieldConfig.minimum !== undefined && numValue < fieldConfig.minimum) {
                validationErrors.push({
                  field: key,
                  message: `${key} must be at least ${fieldConfig.minimum}`,
                  code: 'MIN_VALUE'
                });
              }
              if (fieldConfig.maximum !== undefined && numValue > fieldConfig.maximum) {
                validationErrors.push({
                  field: key,
                  message: `${key} must be at most ${fieldConfig.maximum}`,
                  code: 'MAX_VALUE'
                });
              }
            }
            
            // Enum validation
            if (fieldConfig.enum && !fieldConfig.enum.includes(value)) {
              validationErrors.push({
                field: key,
                message: `${key} must be one of: ${fieldConfig.enum.join(', ')}`,
                code: 'INVALID_OPTION'
              });
            }
          }
        }
      }
      
      if (validationErrors.length > 0) {
        return res.status(400).json({ 
          error: 'Configuration validation failed',
          validationErrors 
        });
      }
      
      // Check if user already has this template installed (allow multiple instances)
      const existingCount = await db
        .select({ count: sql<number>`count(*)` })
        .from(installedReports)
        .where(
          and(
            eq(installedReports.userId, defaultUserId),
            eq(installedReports.templateId, template.id)
          )
        );
      
      // Allow multiple instances but limit to 5 per template
      if (existingCount[0].count >= 5) {
        return res.status(409).json({ 
          error: 'Maximum installations reached for this template (5 max)'
        });
      }
      
      // Generate layout with collision detection
      let layoutJson = position || {};
      if (!position) {
        // Auto-generate layout position
        const existingReports = await db
          .select()
          .from(installedReports)
          .where(eq(installedReports.userId, defaultUserId));
        
        // Improved auto-layout: find next available position with collision detection
        const occupiedAreas = new Set();
        existingReports.forEach(report => {
          const layout = report.layoutJson as any;
          if (layout.x !== undefined && layout.y !== undefined && layout.w && layout.h) {
            // Mark all cells occupied by this report
            for (let px = layout.x; px < layout.x + layout.w; px++) {
              for (let py = layout.y; py < layout.y + layout.h; py++) {
                occupiedAreas.add(`${px},${py}`);
              }
            }
          }
        });
        
        // Find first free 2x2 area
        let x = 0, y = 0;
        let found = false;
        
        while (!found && y < 20) { // Prevent infinite loop
          // Check if 2x2 area starting at (x,y) is free
          let areaFree = true;
          for (let px = x; px < x + 2 && px < 12; px++) {
            for (let py = y; py < y + 2; py++) {
              if (occupiedAreas.has(`${px},${py}`)) {
                areaFree = false;
                break;
              }
            }
            if (!areaFree) break;
          }
          
          if (areaFree && x + 2 <= 12) {
            found = true;
          } else {
            x += 2;
            if (x >= 12) {
              x = 0;
              y += 2;
            }
          }
        }
        
        layoutJson = { x, y, w: 2, h: 2 };
      }
      
      // Create new installed report
      const [newInstallation] = await db
        .insert(installedReports)
        .values({
          userId: defaultUserId,
          templateId: template.id,
          configJson: config,
          layoutJson,
          state: 'active'
        })
        .returning();
      
      // Log telemetry
      if (process.env.NODE_ENV === 'development') {
        console.log('[TELEMETRY] report_install', {
          user_id: `user_${Buffer.from(defaultUserId).toString('base64').slice(0, 8)}`,
          template_slug: templateSlug,
          template_category: template.category,
          tags: template.tags || [],
          config_keys: Object.keys(config),
          position: layoutJson,
          timestamp: new Date().toISOString()
        });
      }
      
      res.status(201).json({
        installedReportId: newInstallation.id,
        templateSlug,
        config: newInstallation.configJson,
        layout: newInstallation.layoutJson,
        state: newInstallation.state
      });
    } catch (error) {
      logger.error('Failed to install report', { 
        error: error instanceof Error ? error.message : 'Unknown error',
        templateSlug: req.body.templateSlug 
      });
      res.status(500).json({ error: 'Failed to install report' });
    }
  });

  // POST /api/report-templates/:slug/render-sample → quick preview
  app.post('/api/report-templates/:slug/render-sample', async (req, res) => {
    try {
      const { slug } = req.params;
      const { config = {} } = req.body;
      
      // Find the template by slug
      const [template] = await db
        .select()
        .from(reportTemplates)
        .where(eq(reportTemplates.slug, slug))
        .limit(1);
      
      if (!template) {
        return res.status(404).json({ error: 'Template not found' });
      }
      
      // Validate config against template schema (same validation as install)
      let validationErrors: any[] = [];
      if (template.inputsSchema && template.inputsSchema.properties) {
        for (const [key, fieldSchema] of Object.entries(template.inputsSchema.properties)) {
          const fieldConfig = fieldSchema as any;
          const value = config[key];
          
          if (template.inputsSchema.required?.includes(key) && (value === undefined || value === null || value === '')) {
            validationErrors.push({
              field: key,
              message: `${key} is required`,
              code: 'REQUIRED'
            });
          }
          
          if (value !== undefined && value !== null && value !== '') {
            if (fieldConfig.type === 'number' && isNaN(Number(value))) {
              validationErrors.push({
                field: key,
                message: `${key} must be a number`,
                code: 'TYPE_ERROR'
              });
            }
            
            if (fieldConfig.enum && !fieldConfig.enum.includes(value)) {
              validationErrors.push({
                field: key,
                message: `${key} must be one of: ${fieldConfig.enum.join(', ')}`,
                code: 'INVALID_OPTION'
              });
            }
          }
        }
      }
      
      if (validationErrors.length > 0) {
        return res.status(400).json({ 
          error: 'Configuration validation failed',
          validationErrors 
        });
      }
      
      // Generate sample data/preview based on template and config
      const sampleData = {
        templateName: template.name,
        templateSlug: slug,
        config,
        previewData: {
          // Generate mock data based on template type
          ...(slug.includes('sentiment') && {
            sentiment: 'positive',
            confidence: 0.85,
            sampleText: 'This is a sample positive sentiment analysis'
          }),
          ...(slug.includes('stock') || slug.includes('market') && {
            symbol: config.symbol || 'AAPL',
            price: 150.25,
            change: +2.45,
            changePercent: +1.65
          }),
          ...(slug.includes('social') && {
            mentions: 1245,
            engagement: 85.2,
            trend: 'increasing'
          }),
          timestamp: new Date().toISOString()
        }
      };
      
      res.json(sampleData);
    } catch (error) {
      logger.error('Failed to render sample', { 
        error: error instanceof Error ? error.message : 'Unknown error',
        slug: req.params.slug 
      });
      res.status(500).json({ error: 'Failed to render sample preview' });
    }
  });
  
  // PATCH /api/installed-reports/:id/config → update report configuration
  app.patch('/api/installed-reports/:id/config', async (req, res) => {
    try {
      const reportId = req.params.id;
      const { configJson } = req.body;
      
      if (!configJson) {
        return res.status(400).json({ error: 'configJson is required' });
      }
      
      // Update the report configuration
      const [updatedReport] = await db
        .update(installedReports)
        .set({ configJson })
        .where(eq(installedReports.id, reportId))
        .returning();
      
      if (!updatedReport) {
        return res.status(404).json({ error: 'Report not found' });
      }
      
      res.json({ 
        success: true, 
        message: 'Configuration updated successfully', 
        report: updatedReport 
      });
    } catch (error) {
      logger.error('Failed to update report configuration', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to update report configuration' });
    }
  });

  // PATCH /api/installed-reports/:id → update layout or config
  app.patch('/api/installed-reports/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const { layoutJson, configJson } = req.body;
      
      if (!id) {
        return res.status(400).json({ error: 'Report ID is required' });
      }
      
      // For now, using a default user ID - in a real app, this would come from authentication
      const defaultUserId = 'default-user';
      
      // Check if the report exists and belongs to the user
      const [existingReport] = await db
        .select()
        .from(installedReports)
        .where(
          and(
            eq(installedReports.id, id),
            eq(installedReports.userId, defaultUserId)
          )
        )
        .limit(1);
      
      if (!existingReport) {
        return res.status(404).json({ error: 'Installed report not found' });
      }
      
      // Prepare update data
      const updateData: any = {
        updatedAt: new Date()
      };
      
      if (layoutJson !== undefined) {
        updateData.layoutJson = layoutJson;
      }
      
      if (configJson !== undefined) {
        updateData.configJson = configJson;
      }
      
      // Update the installed report
      const [updatedReport] = await db
        .update(installedReports)
        .set(updateData)
        .where(
          and(
            eq(installedReports.id, id),
            eq(installedReports.userId, defaultUserId)
          )
        )
        .returning();
      
      res.json({
        message: 'Report updated successfully',
        installedReportId: updatedReport.id,
        layoutJson: updatedReport.layoutJson,
        configJson: updatedReport.configJson
      });
    } catch (error) {
      logger.error('Failed to update report', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to update report' });
    }
  });
  
  // DELETE /api/installed-reports/:id
  app.delete('/api/installed-reports/:id', async (req, res) => {
    try {
      const { id } = req.params;
      
      if (!id) {
        return res.status(400).json({ error: 'Report ID is required' });
      }
      
      // For now, using a default user ID - in a real app, this would come from authentication
      const defaultUserId = 'default-user';
      
      // Check if the report exists and belongs to the user
      const [existingReport] = await db
        .select()
        .from(installedReports)
        .where(
          and(
            eq(installedReports.id, id),
            eq(installedReports.userId, defaultUserId)
          )
        )
        .limit(1);
      
      if (!existingReport) {
        return res.status(404).json({ error: 'Installed report not found' });
      }
      
      // Delete the installed report
      await db
        .delete(installedReports)
        .where(
          and(
            eq(installedReports.id, id),
            eq(installedReports.userId, defaultUserId)
          )
        );
      
      res.json({
        message: 'Report uninstalled successfully',
        installedReportId: id
      });
    } catch (error) {
      logger.error('Failed to uninstall report', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to uninstall report' });
    }
  });
  
  // GET /api/home → returns { layout: [...], installedReports: [...] } using aggregated query
  app.get('/api/home', async (req, res) => {
    try {
      // For now, using a default user ID - in a real app, this would come from authentication
      const defaultUserId = 'default-user';
      
      // Aggregated query to get installed reports with their template details
      const installedReportsWithTemplates = await db
        .select({
          id: installedReports.id,
          configJson: installedReports.configJson,
          layoutJson: installedReports.layoutJson,
          state: installedReports.state,
          createdAt: installedReports.createdAt,
          templateSlug: reportTemplates.slug,
          templateName: reportTemplates.name,
          templateCategory: reportTemplates.category,
          templateVersion: reportTemplates.version,
          templateInputsSchema: reportTemplates.inputsSchema,
          templatePreviewImg: reportTemplates.previewImg
        })
        .from(installedReports)
        .innerJoin(reportTemplates, eq(installedReports.templateId, reportTemplates.id))
        .where(
          and(
            eq(installedReports.userId, defaultUserId),
            eq(installedReports.state, 'active')
          )
        )
        .orderBy(installedReports.createdAt);
      
      // Create a simple grid layout based on installed reports
      const layout = installedReportsWithTemplates.map((report, index) => ({
        id: report.id,
        x: (index % 3) * 4, // 3 columns, each 4 units wide
        y: Math.floor(index / 3) * 4, // New row every 3 items, each 4 units tall
        w: 4, // Width: 4 grid units
        h: 4, // Height: 4 grid units
        templateSlug: report.templateSlug
      }));
      
      res.json({
        layout,
        installedReports: installedReportsWithTemplates,
        total: installedReportsWithTemplates.length,
        userId: defaultUserId
      });
    } catch (error) {
      logger.error('Failed to get home dashboard', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to get home dashboard' });
    }
  });

  // Migration API endpoints
  app.get('/api/migrations/status', async (req, res) => {
    try {
      const { migrationId } = req.query;
      const status = await migrationRunner.getMigrationStatus(migrationId as string);
      
      res.json({
        isRunning: migrationRunner.isRunningMigration(),
        history: status,
        timestamp: Date.now()
      });
    } catch (error) {
      logger.error('Failed to get migration status', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to get migration status' });
    }
  });

  app.post('/api/migrations/run/:migrationName', async (req, res) => {
    try {
      const { migrationName } = req.params;
      
      if (migrationRunner.isRunningMigration()) {
        return res.status(409).json({ error: 'Migration already in progress' });
      }

      let migration;
      switch (migrationName) {
        case 'user-preferences':
          migration = addUserPreferencesMigration;
          break;
        case 'insights-priority':
          migration = addInsightsPriorityMigration;
          break;
        case 'knowledge-graph-core':
          migration = knowledgeGraphCoreMigration;
          break;
        default:
          return res.status(404).json({ error: 'Migration not found' });
      }

      // Run migration asynchronously
      setImmediate(async () => {
        try {
          await migrationRunner.runMigration(migration);
          logger.info(`Migration completed successfully: ${migration.name}`);
        } catch (error) {
          logger.error(`Migration failed: ${migration.name}`, { 
            error: error instanceof Error ? error.message : 'Unknown error' 
          });
        }
      });

      res.json({ 
        message: `Migration ${migration.name} started successfully`,
        migrationId: migration.id,
        status: 'running'
      });
    } catch (error) {
      logger.error('Failed to start migration', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to start migration' });
    }
  });

  app.get('/api/migrations/available', async (req, res) => {
    try {
      const availableMigrations = [
        {
          name: 'user-preferences',
          migration: {
            id: addUserPreferencesMigration.id,
            name: addUserPreferencesMigration.name,
            description: addUserPreferencesMigration.description,
            steps: addUserPreferencesMigration.steps.length
          }
        },
        {
          name: 'insights-priority',
          migration: {
            id: addInsightsPriorityMigration.id,
            name: addInsightsPriorityMigration.name,
            description: addInsightsPriorityMigration.description,
            steps: addInsightsPriorityMigration.steps.length
          }
        },
        {
          name: 'knowledge-graph-core',
          migration: {
            id: knowledgeGraphCoreMigration.id,
            name: knowledgeGraphCoreMigration.name,
            description: knowledgeGraphCoreMigration.description,
            steps: knowledgeGraphCoreMigration.steps.length
          }
        }
      ];

      res.json({
        migrations: availableMigrations,
        total: availableMigrations.length,
        timestamp: Date.now()
      });
    } catch (error) {
      logger.error('Failed to list available migrations', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to list available migrations' });
    }
  });

  // GET /api/report-templates/:slug/preview - Get cached preview data for hover
  app.get('/api/report-templates/:slug/preview', async (req, res) => {
    try {
      const { slug } = req.params;
      
      // Cache headers for 60s caching
      res.set('Cache-Control', 'public, max-age=60');
      
      // Find template by slug
      const [template] = await db
        .select({
          slug: reportTemplates.slug,
          name: reportTemplates.name,
          category: reportTemplates.category,
          defaultChartType: reportTemplates.defaultChartType,
          chartTypes: reportTemplates.chartTypes,
          sampleData: reportTemplates.sampleData,
          visualizationConfig: reportTemplates.visualizationConfig,
          animationConfig: reportTemplates.animationConfig,
          accessibilityConfig: reportTemplates.accessibilityConfig,
        })
        .from(reportTemplates)
        .where(eq(reportTemplates.slug, slug))
        .limit(1);
      
      if (!template) {
        return res.status(404).json({ error: 'Template not found' });
      }
      
      res.json({
        ...template,
        // Ensure sample data is limited to 25 rows for performance
        sampleData: Array.isArray(template.sampleData) 
          ? template.sampleData.slice(0, 25) 
          : template.sampleData
      });
    } catch (error) {
      logger.error('Failed to get template preview', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to get template preview' });
    }
  });

  // POST /api/report-templates/:slug/render-sample - Render sample chart data
  app.post('/api/report-templates/:slug/render-sample', async (req, res) => {
    try {
      const { slug } = req.params;
      const { chartType, config = {} } = req.body;
      
      // Find template by slug
      const [template] = await db
        .select()
        .from(reportTemplates)
        .where(eq(reportTemplates.slug, slug))
        .limit(1);
      
      if (!template) {
        return res.status(404).json({ error: 'Template not found' });
      }
      
      // Generate sample data if not available
      let sampleData = template.sampleData;
      if (!sampleData || !Array.isArray(sampleData) || sampleData.length === 0) {
        sampleData = generateSampleDataForTemplate(template, chartType || template.defaultChartType);
      }
      
      // Limit to 25 rows for performance
      const limitedData = Array.isArray(sampleData) ? sampleData.slice(0, 25) : sampleData;
      
      res.json({
        chartType: chartType || template.defaultChartType,
        data: limitedData,
        config: {
          ...template.visualizationConfig,
          ...config
        },
        animations: template.animationConfig,
        accessibility: template.accessibilityConfig
      });
    } catch (error) {
      logger.error('Failed to render sample data', { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
      res.status(500).json({ error: 'Failed to render sample data' });
    }
  });

  // POST /api/telemetry - Enhanced telemetry logging
  app.post('/api/telemetry', async (req, res) => {
    try {
      const telemetryData = req.body;
      const { event, slugOrId, use_case, tags, timestamp } = telemetryData;
      
      // Enhanced logging based on event type
      if (event === 'report_preview_hover') {
        console.log(`[TELEMETRY:HOVER] Template: ${slugOrId}, Use Case: ${use_case}, Tags: ${JSON.stringify(tags)}, Time: ${timestamp}`);
      } else if (event === 'report_install') {
        console.log(`[TELEMETRY:INSTALL] Template: ${slugOrId}, Use Case: ${use_case}, Tags: ${JSON.stringify(tags)}, Time: ${timestamp}`);
      } else if (event === 'blueprint_create') {
        console.log(`[TELEMETRY:BLUEPRINT] Blueprint: ${slugOrId}, Use Case: ${use_case}, Tags: ${JSON.stringify(tags)}, Time: ${timestamp}`);
      } else {
        console.log('[TELEMETRY:GENERAL]', JSON.stringify(telemetryData, null, 2));
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error('Telemetry error:', error);
      res.status(500).json({ error: 'Failed to record telemetry' });
    }
  });

  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    stopScheduledTasks();
    httpServer.close(() => {
      console.log('Server closed');
    });
  });

  // Custom Report Blueprints API
  
  // Get user's blueprints
  app.get('/api/report-blueprints', async (req, res) => {
    try {
      // TODO: Get userId from authenticated session
      const userId = 'user_ZGVmYXVs'; // Placeholder - replace with real auth
      
      const blueprints = await db
        .select()
        .from(reportBlueprints)
        .where(eq(reportBlueprints.userId, userId))
        .orderBy(desc(reportBlueprints.updatedAt));
      
      res.json({ blueprints });
    } catch (error) {
      console.error("Error fetching report blueprints:", error);
      res.status(500).json({ error: "Failed to fetch report blueprints" });
    }
  });

  // Create new blueprint
  app.post('/api/report-blueprints', async (req, res) => {
    try {
      // TODO: Get userId from authenticated session
      const userId = 'user_ZGVmYXVs'; // Placeholder - replace with real auth
      
      const validatedData = insertReportBlueprintSchema.parse({
        ...req.body,
        userId
      });
      
      const [blueprint] = await db
        .insert(reportBlueprints)
        .values(validatedData)
        .returning();
      
      res.status(201).json(blueprint);
    } catch (error) {
      console.error("Error creating report blueprint:", error);
      res.status(500).json({ error: "Failed to create report blueprint" });
    }
  });

  // Get blueprint versions
  app.get('/api/report-blueprints/:blueprintId/versions', async (req, res) => {
    try {
      const { blueprintId } = req.params;
      
      const versions = await db
        .select()
        .from(reportBlueprintVersions)
        .where(eq(reportBlueprintVersions.blueprintId, blueprintId))
        .orderBy(desc(reportBlueprintVersions.createdAt));
      
      res.json({ versions });
    } catch (error) {
      console.error("Error fetching blueprint versions:", error);
      res.status(500).json({ error: "Failed to fetch blueprint versions" });
    }
  });

  // Create new version for blueprint
  app.post('/api/report-blueprints/:blueprintId/versions', async (req, res) => {
    try {
      const { blueprintId } = req.params;
      
      // Validate DSL v1 configuration
      const { builderConfigJson, ...versionData } = req.body;
      
      // Basic DSL v1 validation - extend this based on your DSL requirements
      if (!builderConfigJson || typeof builderConfigJson !== 'object') {
        return res.status(400).json({ error: "Invalid builder configuration JSON" });
      }
      
      const validatedData = insertReportBlueprintVersionSchema.parse({
        ...versionData,
        blueprintId,
        builderConfigJson
      });
      
      const [version] = await db
        .insert(reportBlueprintVersions)
        .values(validatedData)
        .returning();
      
      // Update blueprint's current version
      await db
        .update(reportBlueprints)
        .set({ currentVersionId: version.id, updatedAt: new Date() })
        .where(eq(reportBlueprints.id, blueprintId));
      
      res.status(201).json(version);
    } catch (error) {
      console.error("Error creating blueprint version:", error);
      res.status(500).json({ error: "Failed to create blueprint version" });
    }
  });

  // Install blueprint as report
  app.post('/api/report-blueprints/:blueprintId/install', async (req, res) => {
    try {
      const { blueprintId } = req.params;
      // TODO: Get userId from authenticated session
      const userId = 'user_ZGVmYXVs'; // Placeholder - replace with real auth
      
      // Get blueprint and current version
      const blueprint = await db
        .select()
        .from(reportBlueprints)
        .where(eq(reportBlueprints.id, blueprintId))
        .limit(1);
      
      if (blueprint.length === 0) {
        return res.status(404).json({ error: "Blueprint not found" });
      }
      
      const currentVersion = await db
        .select()
        .from(reportBlueprintVersions)
        .where(eq(reportBlueprintVersions.id, blueprint[0].currentVersionId!))
        .limit(1);
      
      if (currentVersion.length === 0) {
        return res.status(404).json({ error: "No current version found for blueprint" });
      }
      
      // Create installed report from blueprint
      const [installedReport] = await db
        .insert(installedReports)
        .values({
          userId,
          templateId: blueprintId, // Use blueprint as template
          configJson: currentVersion[0].builderConfigJson,
          layoutJson: req.body.layoutJson || {},
          state: 'active'
        })
        .returning();
      
      // Increment install count
      await db
        .update(reportBlueprints)
        .set({ 
          installCount: sql`${reportBlueprints.installCount} + 1`,
          updatedAt: new Date()
        })
        .where(eq(reportBlueprints.id, blueprintId));
      
      res.status(201).json(installedReport);
    } catch (error) {
      console.error("Error installing blueprint:", error);
      res.status(500).json({ error: "Failed to install blueprint" });
    }
  });

  return httpServer;
}

// Helper function to generate sample data for templates
function generateSampleDataForTemplate(template: any, chartType: string) {
  const baseData = [];
  const categories = template.category === 'Financial Analytics' 
    ? ['Q1', 'Q2', 'Q3', 'Q4'] 
    : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    
  for (let i = 0; i < Math.min(categories.length, 25); i++) {
    const item: any = {
      name: categories[i],
      category: categories[i]
    };
    
    switch (chartType) {
      case 'line':
      case 'area':
        item.value = Math.floor(Math.random() * 1000) + 100;
        item.trend = Math.floor(Math.random() * 100) - 50;
        break;
      case 'bar':
        item.value = Math.floor(Math.random() * 500) + 50;
        item.target = Math.floor(Math.random() * 600) + 100;
        break;
      case 'pie':
        item.value = Math.floor(Math.random() * 30) + 5;
        break;
      case 'scatter':
        item.x = Math.floor(Math.random() * 100);
        item.y = Math.floor(Math.random() * 100);
        item.z = Math.floor(Math.random() * 50) + 10;
        break;
      default:
        item.value = Math.floor(Math.random() * 1000) + 100;
    }
    
    baseData.push(item);
  }
  
  return baseData;
}
