/**
 * Entity Canonicalization Test Suite
 * 
 * Comprehensive tests for entity name normalization and identifier handling.
 */

import { EntityCanonicalizationService, IdentifierScheme } from './services/entityCanonicalization';
import { EntityDeduplicationService } from './services/entityDeduplication';
import { db } from './db';
import { entities, entityIdentifiers } from '../shared/schema';
import { logger } from './observability/logger';
import { sql } from 'drizzle-orm';

async function testCanonicalNameBuilder() {
  console.log('\n📝 Testing Canonical Name Builder...');
  
  const service = new EntityCanonicalizationService();
  
  const testCases = [
    // Basic corporate suffixes
    { input: 'Apple Inc.', expected: 'Apple' },
    { input: 'Microsoft Corporation', expected: 'Microsoft' },
    { input: 'Google LLC', expected: 'Google' },
    { input: 'Amazon.com, Inc.', expected: 'Amazon.com' },
    
    // Unicode normalization
    { input: 'Café Inc.', expected: 'Cafe' },
    { input: 'Naïve Corp', expected: 'Naive' },
    { input: 'Zürich AG', expected: 'Zurich' },
    
    // Case normalization
    { input: 'TESLA MOTORS INC', expected: 'TESLA MOTORS' },
    { input: 'meta platforms inc.', expected: 'meta platforms' },
    
    // Complex corporate structures
    { input: 'Berkshire Hathaway Inc.', expected: 'Berkshire Hathaway' },
    { input: 'Johnson & Johnson', expected: 'Johnson & Johnson' },
    { input: 'AT&T Inc.', expected: 'AT&T' },
    
    // International formats
    { input: 'ASML Holding N.V.', expected: 'ASML Holding' },
    { input: 'SAP SE', expected: 'SAP' },
    { input: 'Unilever Plc', expected: 'Unilever' },
    
    // Tricky cases
    { input: '3M Company', expected: '3M' },
    { input: 'General Electric Company', expected: 'General Electric' },
    { input: 'The Walt Disney Company', expected: 'The Walt Disney' },
    
    // Edge cases
    { input: '  Extra   Spaces   Inc.  ', expected: 'Extra Spaces' },
    { input: 'Quotes "Company" Ltd.', expected: 'Quotes "Company"' },
    { input: 'Dash-Corp Inc.', expected: 'Dash-Corp' },
  ];
  
  let passed = 0;
  let failed = 0;
  
  for (const testCase of testCases) {
    const result = service.canonicalizeName(testCase.input);
    const success = result.canonicalName === testCase.expected;
    
    if (success) {
      passed++;
      console.log(`   ✅ "${testCase.input}" → "${result.canonicalName}"`);
    } else {
      failed++;
      console.log(`   ❌ "${testCase.input}" → "${result.canonicalName}" (expected: "${testCase.expected}")`);
    }
  }
  
  console.log(`   📊 Results: ${passed} passed, ${failed} failed`);
  return failed === 0;
}

async function testIdentifierNormalization() {
  console.log('\n🆔 Testing Identifier Normalization...');
  
  const service = new EntityCanonicalizationService();
  
  const testCases = [
    // Domain normalization
    { scheme: IdentifierScheme.DOMAIN, input: 'https://www.apple.com/', expected: 'apple.com' },
    { scheme: IdentifierScheme.DOMAIN, input: 'Microsoft.com', expected: 'microsoft.com' },
    { scheme: IdentifierScheme.DOMAIN, input: 'www.google.com', expected: 'google.com' },
    
    // CIK normalization (10 digits, zero-padded)
    { scheme: IdentifierScheme.CIK, input: '320193', expected: '0000320193' },
    { scheme: IdentifierScheme.CIK, input: '0000320193', expected: '0000320193' },
    { scheme: IdentifierScheme.CIK, input: 'CIK-789019', expected: '0000789019' },
    
    // Ticker normalization
    { scheme: IdentifierScheme.TICKER, input: 'aapl', expected: 'AAPL' },
    { scheme: IdentifierScheme.TICKER, input: 'MSFT.NASDAQ', expected: 'MSFT' },
    { scheme: IdentifierScheme.TICKER, input: 'GOOGL:US', expected: 'GOOGL' },
    
    // Wikipedia normalization
    { scheme: IdentifierScheme.WIKIPEDIA, input: 'https://en.wikipedia.org/wiki/Apple_Inc.', expected: 'Apple_Inc.' },
    { scheme: IdentifierScheme.WIKIPEDIA, input: 'Microsoft_Corporation', expected: 'Microsoft_Corporation' },
    
    // Patent normalization
    { scheme: IdentifierScheme.PATENT, input: 'US 10,123,456', expected: 'US10,123,456' },
    { scheme: IdentifierScheme.PATENT, input: 'EP 1234567 A1', expected: 'EP1234567A1' },
    
    // LEI normalization (20 characters, uppercase)
    { scheme: IdentifierScheme.LEI, input: 'hwupkr0mpou5kn0xyg36', expected: 'HWUPKR0MPOU5KN0XYG36' },
    { scheme: IdentifierScheme.LEI, input: 'HWUP KR0M POU5 KN0X YG36', expected: 'HWUPKR0MPOU5KN0XYG36' },
    
    // DUNS normalization (9 digits, zero-padded)
    { scheme: IdentifierScheme.DUNS, input: '4175811', expected: '004175811' },
    { scheme: IdentifierScheme.DUNS, input: '004175811', expected: '004175811' },
  ];
  
  let passed = 0;
  let failed = 0;
  
  for (const testCase of testCases) {
    const result = service.normalizeIdentifier(testCase.scheme, testCase.input);
    const success = result === testCase.expected;
    
    if (success) {
      passed++;
      console.log(`   ✅ ${testCase.scheme}: "${testCase.input}" → "${result}"`);
    } else {
      failed++;
      console.log(`   ❌ ${testCase.scheme}: "${testCase.input}" → "${result}" (expected: "${testCase.expected}")`);
    }
  }
  
  console.log(`   📊 Results: ${passed} passed, ${failed} failed`);
  return failed === 0;
}

async function testIdentifierValidation() {
  console.log('\n✅ Testing Identifier Validation...');
  
  const service = new EntityCanonicalizationService();
  
  const testCases = [
    // Valid cases
    { scheme: IdentifierScheme.CIK, value: '0000320193', expected: true },
    { scheme: IdentifierScheme.DOMAIN, value: 'apple.com', expected: true },
    { scheme: IdentifierScheme.LEI, value: 'HWUPKR0MPOU5KN0XYG36', expected: true },
    { scheme: IdentifierScheme.DUNS, value: '004175811', expected: true },
    { scheme: IdentifierScheme.TICKER, value: 'AAPL', expected: true },
    
    // Invalid cases
    { scheme: IdentifierScheme.CIK, value: '123', expected: false }, // Too short
    { scheme: IdentifierScheme.DOMAIN, value: 'not-a-domain', expected: false },
    { scheme: IdentifierScheme.LEI, value: 'SHORTLEI', expected: false }, // Too short
    { scheme: IdentifierScheme.DUNS, value: '12345678901', expected: false }, // Too long
    { scheme: IdentifierScheme.TICKER, value: 'TOOLONG', expected: false }, // Too long
  ];
  
  let passed = 0;
  let failed = 0;
  
  for (const testCase of testCases) {
    const result = service.validateIdentifier(testCase.scheme, testCase.value);
    const success = result === testCase.expected;
    
    if (success) {
      passed++;
      console.log(`   ✅ ${testCase.scheme}: "${testCase.value}" → ${result}`);
    } else {
      failed++;
      console.log(`   ❌ ${testCase.scheme}: "${testCase.value}" → ${result} (expected: ${testCase.expected})`);
    }
  }
  
  console.log(`   📊 Results: ${passed} passed, ${failed} failed`);
  return failed === 0;
}

async function testEntityDeduplication() {
  console.log('\n🔄 Testing Entity Deduplication...');
  
  const deduplicationService = new EntityDeduplicationService();
  const canonicalizationService = new EntityCanonicalizationService();
  
  // Clean up test data
  await db.delete(entityIdentifiers).where(sql`entity_id LIKE 'test-%'`);
  await db.delete(entities).where(sql`id LIKE 'test-%' OR source = 'test'`);
  
  console.log('   🧪 Test 1: Duplicate insertion by name...');
  
  // Test 1: Insert same entity twice (should deduplicate)
  const result1 = await deduplicationService.upsertEntity(
    'Apple Inc.',
    'company',
    'Technology company'
  );
  
  const result2 = await deduplicationService.upsertEntity(
    'Apple Inc.',
    'company',
    'Technology company'
  );
  
  const exactMatchSuccess = result1.entity.id === result2.entity.id && !result2.wasCreated;
  console.log(`      ${exactMatchSuccess ? '✅' : '❌'} Exact name match: ${result1.entity.id === result2.entity.id}`);
  
  console.log('   🧪 Test 2: Canonical name deduplication...');
  
  // Test 2: Different formats of same company name
  const result3 = await deduplicationService.upsertEntity(
    'Microsoft Corporation',
    'company',
    'Software company'
  );
  
  const result4 = await deduplicationService.upsertEntity(
    'Microsoft Corp.',
    'company',
    'Software company'
  );
  
  const canonicalMatchSuccess = result3.entity.id === result4.entity.id && !result4.wasCreated;
  console.log(`      ${canonicalMatchSuccess ? '✅' : '❌'} Canonical match: ${result3.entity.id === result4.entity.id}`);
  
  console.log('   🧪 Test 3: Identifier-based deduplication...');
  
  // Test 3: Different names, same identifier
  const googleIdentifier = canonicalizationService.createIdentifier(
    IdentifierScheme.CIK, 
    '1652044'
  );
  
  const result5 = await deduplicationService.upsertEntity(
    'Alphabet Inc.',
    'company',
    'Google parent company',
    { identifiers: [googleIdentifier] }
  );
  
  const result6 = await deduplicationService.upsertEntity(
    'Google LLC',
    'company',
    'Search engine company',
    { identifiers: [googleIdentifier] }
  );
  
  const identifierMatchSuccess = result5.entity.id === result6.entity.id && !result6.wasCreated;
  console.log(`      ${identifierMatchSuccess ? '✅' : '❌'} Identifier match: ${result5.entity.id === result6.entity.id}`);
  
  console.log('   🧪 Test 4: Unique identifier constraint...');
  
  // Test 4: Test unique constraint on (scheme, value)
  const teslaIdentifier = canonicalizationService.createIdentifier(
    IdentifierScheme.TICKER, 
    'TSLA'
  );
  
  const result7 = await deduplicationService.upsertEntity(
    'Tesla, Inc.',
    'company',
    'Electric vehicle company',
    { identifiers: [teslaIdentifier] }
  );
  
  // Try to add same ticker to different entity (should fail gracefully)
  const result8 = await deduplicationService.upsertEntity(
    'Tesla Motors',
    'company',
    'Electric vehicle company',
    { identifiers: [teslaIdentifier] }
  );
  
  const uniqueConstraintSuccess = result7.entity.id === result8.entity.id;
  console.log(`      ${uniqueConstraintSuccess ? '✅' : '❌'} Unique constraint enforced: ${result7.entity.id === result8.entity.id}`);
  
  const allTests = [exactMatchSuccess, canonicalMatchSuccess, identifierMatchSuccess, uniqueConstraintSuccess];
  const passedTests = allTests.filter(Boolean).length;
  console.log(`   📊 Results: ${passedTests}/${allTests.length} tests passed`);
  
  return passedTests === allTests.length;
}

async function testSimilarityCalculation() {
  console.log('\n📏 Testing Similarity Calculation...');
  
  const service = new EntityCanonicalizationService();
  
  const testCases = [
    { name1: 'Apple Inc.', name2: 'Apple Inc.', expectedRange: [1.0, 1.0] },
    { name1: 'Apple Inc.', name2: 'Apple Corporation', expectedRange: [0.8, 1.0] },
    { name1: 'Microsoft Corp', name2: 'Microsoft Corporation', expectedRange: [0.9, 1.0] },
    { name1: 'Google LLC', name2: 'Alphabet Inc.', expectedRange: [0.0, 0.3] },
    { name1: 'Tesla Inc.', name2: 'Tesla Motors', expectedRange: [0.7, 0.9] },
  ];
  
  let passed = 0;
  let failed = 0;
  
  for (const testCase of testCases) {
    const similarity = service.calculateSimilarity(testCase.name1, testCase.name2);
    const [minExpected, maxExpected] = testCase.expectedRange;
    const success = similarity >= minExpected && similarity <= maxExpected;
    
    if (success) {
      passed++;
      console.log(`   ✅ "${testCase.name1}" vs "${testCase.name2}" → ${similarity.toFixed(3)}`);
    } else {
      failed++;
      console.log(`   ❌ "${testCase.name1}" vs "${testCase.name2}" → ${similarity.toFixed(3)} (expected: ${minExpected}-${maxExpected})`);
    }
  }
  
  console.log(`   📊 Results: ${passed} passed, ${failed} failed`);
  return failed === 0;
}

export async function runEntityCanonicalizationTests(): Promise<boolean> {
  console.log('🧪 Entity Canonicalization Test Suite');
  console.log('=====================================');
  
  const startTime = Date.now();
  
  const results = await Promise.all([
    testCanonicalNameBuilder(),
    testIdentifierNormalization(), 
    testIdentifierValidation(),
    testEntityDeduplication(),
    testSimilarityCalculation()
  ]);
  
  const allPassed = results.every(Boolean);
  const passedTests = results.filter(Boolean).length;
  const totalTests = results.length;
  const duration = Date.now() - startTime;
  
  console.log('\n📊 Test Suite Summary');
  console.log('====================');
  console.log(`Status: ${allPassed ? '✅ PASSED' : '❌ FAILED'}`);
  console.log(`Tests: ${passedTests}/${totalTests} passed`);
  console.log(`Duration: ${duration}ms`);
  
  if (allPassed) {
    logger.info('Entity canonicalization tests passed', { 
      message: 'All entity canonicalization tests passed successfully',
      duration, 
      totalTests 
    });
  } else {
    logger.error('Entity canonicalization tests failed', { 
      message: 'Some entity canonicalization tests failed',
      duration, 
      passedTests, 
      totalTests 
    });
  }
  
  return allPassed;
}

// Run tests if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runEntityCanonicalizationTests()
    .then(success => {
      process.exit(success ? 0 : 1);
    })
    .catch(error => {
      console.error('Test suite failed:', error);
      process.exit(1);
    });
}