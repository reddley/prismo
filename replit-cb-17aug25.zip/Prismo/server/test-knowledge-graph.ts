/**
 * Knowledge Graph Performance Test Suite
 * 
 * Validates:
 * - Basic CRUD operations work correctly
 * - p95 entity lookups <100ms
 * - ANN queries <200ms on sample data
 * - Schema integrity and relationships
 */

import { db } from './db';
import { sql } from 'drizzle-orm';
import { 
  entities, entityIdentifiers, entityAttributes, entityEmbeddings,
  edges, edgeEvidence, events, eventParticipants
} from '../shared/schema';
import { logger } from './observability/logger';

interface PerformanceMetrics {
  entityLookups: number[];
  annQueries: number[];
  insertOperations: number[];
  graphTraversals: number[];
}

async function testKnowledgeGraphOperations() {
  console.log('\n🧠 Testing Knowledge Graph Data Model\n');
  const metrics: PerformanceMetrics = {
    entityLookups: [],
    annQueries: [],
    insertOperations: [],
    graphTraversals: []
  };

  try {
    // Test 1: Basic CRUD Operations
    console.log('1. Testing Basic CRUD Operations...');
    
    // Create test entity
    const startInsert = Date.now();
    const [testEntity] = await db.insert(entities).values({
      type: 'company',
      name: 'Test Corporation',
      description: 'A test company for performance validation',
      confidence: 0.95,
      source: 'test'
    }).returning();
    metrics.insertOperations.push(Date.now() - startInsert);
    console.log(`   ✅ Entity created: ${testEntity.name} (${Date.now() - startInsert}ms)`);

    // Add identifiers
    await db.insert(entityIdentifiers).values([
      {
        entityId: testEntity.id,
        type: 'name',
        value: 'Test Corporation',
        isPrimary: true,
        confidence: 1.0
      },
      {
        entityId: testEntity.id,
        type: 'ticker',
        value: 'TEST',
        isPrimary: false,
        confidence: 0.9
      }
    ]);

    // Add attributes
    await db.insert(entityAttributes).values([
      {
        entityId: testEntity.id,
        key: 'industry',
        value: 'Technology',
        dataType: 'text',
        confidence: 0.8
      },
      {
        entityId: testEntity.id,
        key: 'founded_year',
        value: '2020',
        dataType: 'number',
        confidence: 0.9
      }
    ]);

    // Test 2: Entity Lookup Performance (<100ms target)
    console.log('\n2. Testing Entity Lookup Performance...');
    
    for (let i = 0; i < 10; i++) {
      const startLookup = Date.now();
      
      // Test entity lookup by type
      await db.select().from(entities).where(sql`type = 'company'`).limit(10);
      
      // Test entity lookup with join
      await db.select({
        entity: entities,
        identifier: entityIdentifiers
      })
      .from(entities)
      .leftJoin(entityIdentifiers, sql`${entities.id} = ${entityIdentifiers.entityId}`)
      .where(sql`${entities.type} = 'company'`)
      .limit(5);
      
      const lookupTime = Date.now() - startLookup;
      metrics.entityLookups.push(lookupTime);
    }
    
    const avgLookup = metrics.entityLookups.reduce((a, b) => a + b, 0) / metrics.entityLookups.length;
    const p95Lookup = metrics.entityLookups.sort((a, b) => a - b)[Math.floor(metrics.entityLookups.length * 0.95)];
    console.log(`   ✅ Entity lookups: avg ${avgLookup.toFixed(1)}ms, p95 ${p95Lookup}ms`);
    console.log(`   ${p95Lookup < 100 ? '✅' : '⚠️'} Performance: ${p95Lookup < 100 ? 'EXCELLENT' : 'NEEDS OPTIMIZATION'} (<100ms target)`);

    // Test 3: Vector Embeddings and ANN Search
    console.log('\n3. Testing Vector Embeddings and ANN Search...');
    
    // Create sample embedding (1536 dimensions for text-embedding-3-small)
    const sampleEmbedding = Array.from({ length: 1536 }, () => Math.random() - 0.5);
    
    await db.insert(entityEmbeddings).values({
      entityId: testEntity.id,
      embeddingType: 'description',
      model: 'text-embedding-3-small',
      embedding: sampleEmbedding,
      metadata: { source: 'test', version: 1 }
    });

    // Test ANN queries (<200ms target)
    for (let i = 0; i < 5; i++) {
      const queryEmbedding = Array.from({ length: 1536 }, () => Math.random() - 0.5);
      const startANN = Date.now();
      
      await db.execute(sql`
        SELECT entity_id, embedding <=> ${JSON.stringify(queryEmbedding)}::vector AS distance
        FROM entity_embeddings
        ORDER BY embedding <=> ${JSON.stringify(queryEmbedding)}::vector
        LIMIT 10
      `);
      
      const annTime = Date.now() - startANN;
      metrics.annQueries.push(annTime);
    }
    
    const avgANN = metrics.annQueries.reduce((a, b) => a + b, 0) / metrics.annQueries.length;
    const p95ANN = metrics.annQueries.sort((a, b) => a - b)[Math.floor(metrics.annQueries.length * 0.95)];
    console.log(`   ✅ ANN queries: avg ${avgANN.toFixed(1)}ms, p95 ${p95ANN}ms`);
    console.log(`   ${p95ANN < 200 ? '✅' : '⚠️'} Performance: ${p95ANN < 200 ? 'EXCELLENT' : 'NEEDS OPTIMIZATION'} (<200ms target)`);

    // Test 4: Edge Relationships and Graph Traversal
    console.log('\n4. Testing Edge Relationships and Graph Traversal...');
    
    // Create second entity for relationship
    const [secondEntity] = await db.insert(entities).values({
      type: 'person',
      name: 'Test Person',
      description: 'A test person for relationship validation',
      confidence: 0.9,
      source: 'test'
    }).returning();

    // Create relationship edge
    const [testEdge] = await db.insert(edges).values({
      fromEntityId: secondEntity.id,
      toEntityId: testEntity.id,
      type: 'works_at',
      direction: 'directed',
      strength: 1.0,
      confidence: 0.85,
      properties: { title: 'CEO', start_date: '2020-01-01' }
    }).returning();

    // Add evidence for the relationship
    await db.insert(edgeEvidence).values({
      edgeId: testEdge.id,
      evidenceType: 'web_scraping',
      sourceUrl: 'https://example.com/about',
      sourceTitle: 'About Our Team',
      excerpt: 'Test Person serves as CEO of Test Corporation',
      confidence: 0.8
    });

    // Test graph traversal performance
    for (let i = 0; i < 5; i++) {
      const startTraversal = Date.now();
      
      // Find all relationships for an entity
      await db.select({
        edge: edges,
        fromEntity: entities,
        evidence: edgeEvidence
      })
      .from(edges)
      .leftJoin(entities, sql`${edges.fromEntityId} = ${entities.id}`)
      .leftJoin(edgeEvidence, sql`${edges.id} = ${edgeEvidence.edgeId}`)
      .where(sql`${edges.toEntityId} = ${testEntity.id}`)
      .limit(10);
      
      const traversalTime = Date.now() - startTraversal;
      metrics.graphTraversals.push(traversalTime);
    }
    
    const avgTraversal = metrics.graphTraversals.reduce((a, b) => a + b, 0) / metrics.graphTraversals.length;
    console.log(`   ✅ Graph traversal: avg ${avgTraversal.toFixed(1)}ms`);

    // Test 5: Event Temporal Knowledge
    console.log('\n5. Testing Event Temporal Knowledge...');
    
    const [testEvent] = await db.insert(events).values({
      type: 'funding_round',
      title: 'Test Corporation Series A',
      description: 'Test Corporation raises $10M Series A funding',
      eventDate: new Date('2021-03-15'),
      location: 'San Francisco, CA',
      importance: 'high',
      confidence: 0.9,
      metadata: { amount: '$10M', round: 'Series A' }
    }).returning();

    // Link entities to event
    await db.insert(eventParticipants).values([
      {
        eventId: testEvent.id,
        entityId: testEntity.id,
        role: 'recipient',
        importance: 'primary'
      },
      {
        eventId: testEvent.id,
        entityId: secondEntity.id,
        role: 'decision_maker',
        importance: 'primary'
      }
    ]);

    // Test temporal queries
    const eventQuery = await db.select({
      event: events,
      participant: eventParticipants,
      entity: entities
    })
    .from(events)
    .leftJoin(eventParticipants, sql`${events.id} = ${eventParticipants.eventId}`)
    .leftJoin(entities, sql`${eventParticipants.entityId} = ${entities.id}`)
    .where(sql`${events.type} = 'funding_round'`)
    .limit(10);

    console.log(`   ✅ Event temporal query: found ${eventQuery.length} results`);

    // Test 6: Schema Integrity Validation
    console.log('\n6. Testing Schema Integrity...');
    
    // Verify foreign key constraints
    try {
      // This should fail due to foreign key constraint
      await db.insert(entityIdentifiers).values({
        entityId: 'non-existent-id',
        type: 'test',
        value: 'should fail'
      });
      console.log('   ❌ Foreign key constraint not working');
    } catch (error) {
      console.log('   ✅ Foreign key constraints working properly');
    }

    // Verify check constraints
    try {
      // This should fail due to confidence check constraint
      await db.insert(entities).values({
        type: 'test',
        name: 'Test',
        confidence: 1.5 // Invalid confidence > 1.0
      });
      console.log('   ❌ Check constraint not working');
    } catch (error) {
      console.log('   ✅ Check constraints working properly');
    }

    // Test 7: Performance Summary
    console.log('\n7. Performance Summary...');
    console.log(`   📊 Entity lookups p95: ${p95Lookup}ms (target: <100ms)`);
    console.log(`   📊 ANN queries p95: ${p95ANN}ms (target: <200ms)`);
    console.log(`   📊 Insert operations avg: ${(metrics.insertOperations.reduce((a, b) => a + b, 0) / metrics.insertOperations.length).toFixed(1)}ms`);
    console.log(`   📊 Graph traversals avg: ${avgTraversal.toFixed(1)}ms`);

    // Cleanup test data
    await db.delete(eventParticipants).where(sql`event_id = ${testEvent.id}`);
    await db.delete(events).where(sql`id = ${testEvent.id}`);
    await db.delete(edgeEvidence).where(sql`edge_id = ${testEdge.id}`);
    await db.delete(edges).where(sql`id = ${testEdge.id}`);
    await db.delete(entityEmbeddings).where(sql`entity_id IN (${testEntity.id}, ${secondEntity.id})`);
    await db.delete(entityAttributes).where(sql`entity_id IN (${testEntity.id}, ${secondEntity.id})`);
    await db.delete(entityIdentifiers).where(sql`entity_id IN (${testEntity.id}, ${secondEntity.id})`);
    await db.delete(entities).where(sql`id IN (${testEntity.id}, ${secondEntity.id})`);

    console.log('\n🎉 Knowledge Graph Test Suite PASSED');
    console.log('📊 Schema Status: OPERATIONAL & OPTIMIZED');
    
    return {
      success: true,
      metrics: {
        entityLookupP95: p95Lookup,
        annQueryP95: p95ANN,
        avgInsert: metrics.insertOperations.reduce((a, b) => a + b, 0) / metrics.insertOperations.length,
        avgTraversal: avgTraversal
      }
    };
    
  } catch (error) {
    console.error('\n❌ Knowledge Graph Test Failed:', error);
    logger.error('Knowledge graph test failed', { 
      error: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    });
    return { success: false, error };
  }
}

// Export for use in other modules
export { testKnowledgeGraphOperations };

// Run tests if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  testKnowledgeGraphOperations().then(result => {
    process.exit(result.success ? 0 : 1);
  });
}