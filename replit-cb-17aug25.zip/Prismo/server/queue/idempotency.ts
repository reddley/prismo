// Idempotency key management for preventing duplicate job execution
import { redisManager } from './redis';
import { QUEUE_CONFIG } from './config';
import crypto from 'crypto';

export class IdempotencyManager {
  private keyPrefix = 'idempotency:';
  private ttlSeconds: number;

  constructor() {
    this.ttlSeconds = QUEUE_CONFIG.idempotency.keyTTL * 3600; // Convert hours to seconds
  }

  // Generate idempotency key from job data
  generateKey(jobType: string, jobData: any): string {
    const dataString = JSON.stringify(jobData, Object.keys(jobData).sort());
    const hash = crypto.createHash('sha256').update(dataString).digest('hex').substring(0, 16);
    return `${this.keyPrefix}${jobType}:${hash}`;
  }

  // Check if job already processed (idempotency check)
  async isJobProcessed(idempotencyKey: string): Promise<boolean> {
    const redis = redisManager.getClient();
    if (!redis) {
      // No Redis available, allow job to proceed
      return false;
    }

    try {
      const exists = await redis.exists(idempotencyKey);
      return exists === 1;
    } catch (error) {
      console.error('[IDEMPOTENCY] Error checking key:', error);
      // On error, allow job to proceed to avoid blocking system
      return false;
    }
  }

  // Mark job as processed
  async markJobProcessed(idempotencyKey: string, result?: any): Promise<void> {
    const redis = redisManager.getClient();
    if (!redis) {
      return;
    }

    try {
      const value = JSON.stringify({
        processed_at: new Date().toISOString(),
        result: result || null,
      });
      
      await redis.setex(idempotencyKey, this.ttlSeconds, value);
    } catch (error) {
      console.error('[IDEMPOTENCY] Error marking job processed:', error);
    }
  }

  // Get result of previously processed job
  async getProcessedResult(idempotencyKey: string): Promise<any> {
    const redis = redisManager.getClient();
    if (!redis) {
      return null;
    }

    try {
      const value = await redis.get(idempotencyKey);
      if (value) {
        const data = JSON.parse(value);
        return data.result;
      }
      return null;
    } catch (error) {
      console.error('[IDEMPOTENCY] Error getting processed result:', error);
      return null;
    }
  }

  // Clean up expired idempotency keys (maintenance task)
  async cleanup(): Promise<number> {
    const redis = redisManager.getClient();
    if (!redis) {
      return 0;
    }

    try {
      // Redis handles TTL automatically, but we can scan for any stuck keys
      const keys = await redis.keys(`${this.keyPrefix}*`);
      let cleanedCount = 0;

      for (const key of keys) {
        const ttl = await redis.ttl(key);
        if (ttl === -1) { // Key without expiration
          await redis.del(key);
          cleanedCount++;
        }
      }

      if (cleanedCount > 0) {
        console.log(`[IDEMPOTENCY] Cleaned up ${cleanedCount} stuck keys`);
      }

      return cleanedCount;
    } catch (error) {
      console.error('[IDEMPOTENCY] Error during cleanup:', error);
      return 0;
    }
  }

  // Get statistics about idempotency keys
  async getStats(): Promise<{
    totalKeys: number;
    expiredKeys: number;
    activeKeys: number;
  }> {
    const redis = redisManager.getClient();
    if (!redis) {
      return { totalKeys: 0, expiredKeys: 0, activeKeys: 0 };
    }

    try {
      const keys = await redis.keys(`${this.keyPrefix}*`);
      let activeKeys = 0;
      let expiredKeys = 0;

      for (const key of keys) {
        const ttl = await redis.ttl(key);
        if (ttl > 0) {
          activeKeys++;
        } else if (ttl === -2) {
          expiredKeys++;
        }
      }

      return {
        totalKeys: keys.length,
        expiredKeys,
        activeKeys,
      };
    } catch (error) {
      console.error('[IDEMPOTENCY] Error getting stats:', error);
      return { totalKeys: 0, expiredKeys: 0, activeKeys: 0 };
    }
  }
}

export const idempotencyManager = new IdempotencyManager();