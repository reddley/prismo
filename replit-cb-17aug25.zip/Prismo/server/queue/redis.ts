// Redis client configuration and connection management
import Redis from 'ioredis';
import { getRedisConnection } from './config';

class RedisManager {
  private static instance: RedisManager;
  private redis: Redis | null = null;
  private isConnected = false;

  private constructor() {}

  static getInstance(): RedisManager {
    if (!RedisManager.instance) {
      RedisManager.instance = new RedisManager();
    }
    return RedisManager.instance;
  }

  async connect(): Promise<Redis> {
    if (this.redis && this.isConnected) {
      return this.redis;
    }

    try {
      const config = getRedisConnection();
      this.redis = new Redis({
        ...config,
        connectTimeout: 5000,
        commandTimeout: 5000,
        retryDelayOnFailover: 100,
        maxRetriesPerRequest: null,
        enableReadyCheck: false,
        maxRetriesPerSecond: 1,
      });

      // Connection event handlers
      this.redis.on('connect', () => {
        this.isConnected = true;
        console.log('[REDIS] Connected successfully');
      });

      this.redis.on('error', (err) => {
        this.isConnected = false;
        // Don't log every connection error
        if (err.code !== 'ECONNREFUSED') {
          console.error('[REDIS] Connection error:', err);
        }
      });

      this.redis.on('close', () => {
        this.isConnected = false;
      });

      // Test connection with timeout
      const connectPromise = Promise.race([
        this.redis.ping(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Connection timeout')), 3000)
        )
      ]);

      await connectPromise;
      console.log('[REDIS] Connection established and tested');

      return this.redis;
    } catch (error) {
      // Clean up failed connection
      if (this.redis) {
        this.redis.disconnect();
        this.redis = null;
      }
      
      this.isConnected = false;
      
      // Fallback mode for development
      if (process.env.NODE_ENV === 'development') {
        console.warn('[REDIS] Using fallback mode for development (Redis not available)');
        return null;
      }
      
      throw error;
    }
  }

  async disconnect(): Promise<void> {
    if (this.redis) {
      await this.redis.quit();
      this.redis = null;
      this.isConnected = false;
      console.log('[REDIS] Disconnected');
    }
  }

  getClient(): Redis | null {
    return this.redis;
  }

  isReady(): boolean {
    return this.isConnected && this.redis !== null;
  }

  // Health check for monitoring
  async healthCheck(): Promise<{
    connected: boolean;
    responseTime: number;
    memoryUsage?: string;
    version?: string;
  }> {
    if (!this.redis || !this.isConnected) {
      return {
        connected: false,
        responseTime: -1,
      };
    }

    try {
      const start = Date.now();
      await this.redis.ping();
      const responseTime = Date.now() - start;

      // Get Redis info
      const info = await this.redis.info('memory');
      const memoryMatch = info.match(/used_memory_human:(.+)\r/);
      const memoryUsage = memoryMatch ? memoryMatch[1] : undefined;

      const serverInfo = await this.redis.info('server');
      const versionMatch = serverInfo.match(/redis_version:(.+)\r/);
      const version = versionMatch ? versionMatch[1] : undefined;

      return {
        connected: true,
        responseTime,
        memoryUsage,
        version,
      };
    } catch (error) {
      console.error('[REDIS] Health check failed:', error);
      return {
        connected: false,
        responseTime: -1,
      };
    }
  }
}

export const redisManager = RedisManager.getInstance();