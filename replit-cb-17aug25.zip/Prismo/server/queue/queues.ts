// BullMQ queue management with dead letter queue and retry logic
import { Queue, Worker, Job, QueueEvents } from 'bullmq';
import { redisManager } from './redis';
import { QUEUE_CONFIG, JOB_TYPES, JobPriority, type JobType } from './config';
import { idempotencyManager } from './idempotency';

interface JobData {
  type: JobType;
  payload: any;
  idempotencyKey?: string;
  priority?: JobPriority;
  metadata?: {
    source?: string;
    userId?: string;
    timestamp?: string;
  };
}

interface QueueStats {
  waiting: number;
  active: number;
  completed: number;
  failed: number;
  delayed: number;
  paused: boolean;
}

class QueueManager {
  private queues: Map<JobType, Queue> = new Map();
  private workers: Map<JobType, Worker> = new Map();
  private queueEvents: Map<JobType, QueueEvents> = new Map();
  private deadLetterQueue: Queue | null = null;
  private isInitialized = false;

  async initialize(): Promise<void> {
    if (this.isInitialized) {
      return;
    }

    try {
      // Try to connect to Redis with timeout
      const connectPromise = Promise.race([
        redisManager.connect(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Redis connection timeout')), 5000)
        )
      ]);
      
      await connectPromise;
      const connection = redisManager.getClient();

      if (!connection) {
        console.warn('[QUEUE] Redis not available, running in fallback mode');
        this.isInitialized = true;
        return;
      }

      // Initialize dead letter queue
      this.deadLetterQueue = new Queue('dead-letter-queue', {
        connection,
        defaultJobOptions: {
          removeOnComplete: 100,
          removeOnFail: false, // Keep failed jobs for analysis
        },
      });

      // Initialize job queues
      for (const jobType of Object.values(JOB_TYPES)) {
        await this.createQueue(jobType);
      }

      this.isInitialized = true;
      console.log('[QUEUE] All queues initialized successfully');

    } catch (error) {
      console.warn('[QUEUE] Failed to initialize queues, running in fallback mode');
      // Don't throw error, allow system to continue without queues
      this.isInitialized = true;
    }
  }

  private async createQueue(jobType: JobType): Promise<void> {
    const connection = redisManager.getClient();
    if (!connection) return;

    // Create main queue
    const queue = new Queue(jobType, {
      connection,
      defaultJobOptions: {
        attempts: QUEUE_CONFIG.retries.maxAttempts,
        backoff: {
          type: QUEUE_CONFIG.retries.backoffType,
          settings: {
            delay: QUEUE_CONFIG.retries.backoffDelay,
            maxDelay: QUEUE_CONFIG.retries.maxBackoffDelay,
          },
        },
        removeOnComplete: 50,
        removeOnFail: 20,
      },
    });

    // Create worker with bounded concurrency
    const concurrency = QUEUE_CONFIG.concurrency[jobType] || 1;
    const worker = new Worker(
      jobType,
      this.createJobProcessor(jobType),
      {
        connection,
        concurrency,
        limiter: {
          max: concurrency,
          duration: 1000, // Per second
        },
      }
    );

    // Create queue events listener
    const queueEvents = new QueueEvents(jobType, { connection });

    // Set up event handlers
    this.setupEventHandlers(jobType, worker, queueEvents);

    // Store references
    this.queues.set(jobType, queue);
    this.workers.set(jobType, worker);
    this.queueEvents.set(jobType, queueEvents);

    console.log(`[QUEUE] Created queue '${jobType}' with concurrency: ${concurrency}`);
  }

  private createJobProcessor(jobType: JobType) {
    return async (job: Job<JobData>) => {
      const { data } = job;
      const startTime = Date.now();

      try {
        // Check idempotency
        if (data.idempotencyKey) {
          const alreadyProcessed = await idempotencyManager.isJobProcessed(data.idempotencyKey);
          if (alreadyProcessed) {
            console.log(`[QUEUE] Job ${job.id} skipped (already processed): ${data.idempotencyKey}`);
            const previousResult = await idempotencyManager.getProcessedResult(data.idempotencyKey);
            return previousResult;
          }
        }

        // Add jitter to prevent thundering herd
        if (job.attemptsMade > 0) {
          const jitter = Math.random() * 1000; // 0-1 second jitter
          await new Promise(resolve => setTimeout(resolve, jitter));
        }

        // Process the job based on type
        const result = await this.processJob(jobType, data, job);

        // Mark as processed for idempotency
        if (data.idempotencyKey) {
          await idempotencyManager.markJobProcessed(data.idempotencyKey, result);
        }

        const duration = Date.now() - startTime;
        console.log(`[QUEUE] Job ${job.id} (${jobType}) completed in ${duration}ms`);

        return result;

      } catch (error) {
        const duration = Date.now() - startTime;
        console.error(`[QUEUE] Job ${job.id} (${jobType}) failed after ${duration}ms:`, error);

        // Check if this is the final attempt
        if (job.attemptsMade >= QUEUE_CONFIG.retries.maxAttempts) {
          await this.moveToDeadLetterQueue(job, error);
        }

        throw error;
      }
    };
  }

  private async processJob(jobType: JobType, data: JobData, job: Job): Promise<any> {
    switch (jobType) {
      case JOB_TYPES.RSS_FETCH:
        return this.processRssFetch(data.payload, job);
      
      case JOB_TYPES.AI_ENRICHMENT:
        return this.processAiEnrichment(data.payload, job);
      
      case JOB_TYPES.CONTENT_ANALYSIS:
        return this.processContentAnalysis(data.payload, job);
      
      case JOB_TYPES.BRIEFING_GENERATION:
        return this.processBriefingGeneration(data.payload, job);
      
      case JOB_TYPES.CLEANUP:
        return this.processCleanup(data.payload, job);
      
      default:
        throw new Error(`Unknown job type: ${jobType}`);
    }
  }

  // Job processing methods (to be implemented)
  private async processRssFetch(payload: any, job: Job): Promise<any> {
    // Import and call RSS processing service
    const { processRssFeed } = await import('../services/rss-processor');
    return processRssFeed(payload.sourceId, payload.feedUrl);
  }

  private async processAiEnrichment(payload: any, job: Job): Promise<any> {
    // Import and call AI enrichment service
    const { enrichContent } = await import('../services/ai-enrichment');
    return enrichContent(payload.insightId, payload.content);
  }

  private async processContentAnalysis(payload: any, job: Job): Promise<any> {
    // Import and call content analysis service
    const { analyzeContent } = await import('../services/content-analyzer');
    return analyzeContent(payload.content, payload.options);
  }

  private async processBriefingGeneration(payload: any, job: Job): Promise<any> {
    // Import and call briefing generation service
    const { generateBriefing } = await import('../services/briefing-generator');
    return generateBriefing(payload.timeframe, payload.filters);
  }

  private async processCleanup(payload: any, job: Job): Promise<any> {
    // Cleanup tasks
    await idempotencyManager.cleanup();
    return { cleaned: true, timestamp: new Date().toISOString() };
  }

  private async moveToDeadLetterQueue(job: Job, error: any): Promise<void> {
    if (!this.deadLetterQueue) return;

    try {
      await this.deadLetterQueue.add('failed-job', {
        originalJobId: job.id,
        originalQueue: job.queueName,
        originalData: job.data,
        error: {
          message: error.message,
          stack: error.stack,
        },
        failedAt: new Date().toISOString(),
        attempts: job.attemptsMade,
      }, {
        priority: JobPriority.LOW,
      });

      console.log(`[QUEUE] Moved job ${job.id} to dead letter queue`);
    } catch (dlqError) {
      console.error('[QUEUE] Failed to move job to dead letter queue:', dlqError);
    }
  }

  private setupEventHandlers(jobType: JobType, worker: Worker, queueEvents: QueueEvents): void {
    worker.on('completed', (job) => {
      console.log(`[QUEUE] Job completed: ${job.id}`);
    });

    worker.on('failed', (job, err) => {
      console.error(`[QUEUE] Job failed: ${job?.id}`, err);
    });

    worker.on('stalled', (jobId) => {
      console.warn(`[QUEUE] Job stalled: ${jobId}`);
    });

    queueEvents.on('waiting', ({ jobId }) => {
      console.log(`[QUEUE] Job waiting: ${jobId}`);
    });

    queueEvents.on('active', ({ jobId }) => {
      console.log(`[QUEUE] Job active: ${jobId}`);
    });
  }

  // Public API methods
  async addJob(jobType: JobType, payload: any, options?: {
    priority?: JobPriority;
    delay?: number;
    idempotencyKey?: string;
    metadata?: any;
  }): Promise<Job<JobData> | null> {
    const queue = this.queues.get(jobType);
    if (!queue) {
      // Fallback: execute job directly if no queue available
      console.warn(`[QUEUE] No queue available for ${jobType}, executing directly`);
      try {
        const jobData: JobData = {
          type: jobType,
          payload,
          idempotencyKey: options?.idempotencyKey || idempotencyManager.generateKey(jobType, payload),
          priority: options?.priority || JobPriority.NORMAL,
          metadata: options?.metadata,
        };
        
        const fakeJob = { id: Date.now().toString(), data: jobData, attemptsMade: 0 } as Job;
        await this.processJob(jobType, jobData, fakeJob);
        return fakeJob as Job<JobData>;
      } catch (error) {
        console.error(`[QUEUE] Direct execution failed for ${jobType}:`, error);
        return null;
      }
    }

    const jobData: JobData = {
      type: jobType,
      payload,
      idempotencyKey: options?.idempotencyKey || idempotencyManager.generateKey(jobType, payload),
      priority: options?.priority || JobPriority.NORMAL,
      metadata: options?.metadata,
    };

    // Check idempotency before adding
    if (jobData.idempotencyKey) {
      const alreadyProcessed = await idempotencyManager.isJobProcessed(jobData.idempotencyKey);
      if (alreadyProcessed) {
        console.log(`[QUEUE] Job skipped (already processed): ${jobData.idempotencyKey}`);
        return null;
      }
    }

    try {
      const job = await queue.add(jobType, jobData, {
        priority: jobData.priority,
        delay: options?.delay,
      });

      console.log(`[QUEUE] Job added: ${job.id} (${jobType})`);
      return job;
    } catch (error) {
      console.error(`[QUEUE] Failed to add job (${jobType}):`, error);
      return null;
    }
  }

  async getQueueStats(jobType?: JobType): Promise<Record<string, QueueStats>> {
    const stats: Record<string, QueueStats> = {};

    if (this.queues.size === 0) {
      // Return default stats for fallback mode
      const types = jobType ? [jobType] : Object.values(JOB_TYPES);
      for (const type of types) {
        stats[type] = {
          waiting: 0,
          active: 0,
          completed: 0,
          failed: 0,
          delayed: 0,
          paused: false,
        };
      }
      return stats;
    }

    const queues = jobType ? [jobType] : Array.from(this.queues.keys());

    for (const type of queues) {
      const queue = this.queues.get(type);
      if (queue) {
        try {
          const [waiting, active, completed, failed, delayed] = await Promise.all([
            queue.getWaiting(),
            queue.getActive(),
            queue.getCompleted(),
            queue.getFailed(),
            queue.getDelayed(),
          ]);

          stats[type] = {
            waiting: waiting.length,
            active: active.length,
            completed: completed.length,
            failed: failed.length,
            delayed: delayed.length,
            paused: await queue.isPaused(),
          };
        } catch (error) {
          console.error(`[QUEUE] Error getting stats for ${type}:`, error);
          stats[type] = {
            waiting: 0,
            active: 0,
            completed: 0,
            failed: 0,
            delayed: 0,
            paused: false,
          };
        }
      }
    }

    return stats;
  }

  async getDeadLetterQueueStats(): Promise<{
    total: number;
    recent: number; // Last 24 hours
    oldestFailure: Date | null;
  }> {
    if (!this.deadLetterQueue) {
      return { total: 0, recent: 0, oldestFailure: null };
    }

    try {
      const failed = await this.deadLetterQueue.getFailed();
      const total = failed.length;
      
      const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
      const recent = failed.filter(job => {
        const jobData = job.data as any;
        return new Date(jobData.failedAt).getTime() > oneDayAgo;
      }).length;

      const oldestFailure = failed.length > 0 
        ? new Date(Math.min(...failed.map(job => new Date((job.data as any).failedAt).getTime())))
        : null;

      return { total, recent, oldestFailure };
    } catch (error) {
      console.error('[QUEUE] Error getting DLQ stats:', error);
      return { total: 0, recent: 0, oldestFailure: null };
    }
  }

  async shutdown(): Promise<void> {
    console.log('[QUEUE] Shutting down queues...');

    // Close workers
    for (const [type, worker] of this.workers) {
      try {
        await worker.close();
        console.log(`[QUEUE] Worker closed: ${type}`);
      } catch (error) {
        console.error(`[QUEUE] Error closing worker ${type}:`, error);
      }
    }

    // Close queue events
    for (const [type, queueEvents] of this.queueEvents) {
      try {
        await queueEvents.close();
        console.log(`[QUEUE] Queue events closed: ${type}`);
      } catch (error) {
        console.error(`[QUEUE] Error closing queue events ${type}:`, error);
      }
    }

    // Close queues
    for (const [type, queue] of this.queues) {
      try {
        await queue.close();
        console.log(`[QUEUE] Queue closed: ${type}`);
      } catch (error) {
        console.error(`[QUEUE] Error closing queue ${type}:`, error);
      }
    }

    // Close dead letter queue
    if (this.deadLetterQueue) {
      try {
        await this.deadLetterQueue.close();
        console.log('[QUEUE] Dead letter queue closed');
      } catch (error) {
        console.error('[QUEUE] Error closing dead letter queue:', error);
      }
    }

    // Disconnect Redis
    await redisManager.disconnect();

    this.isInitialized = false;
    console.log('[QUEUE] All queues shut down');
  }
}

export const queueManager = new QueueManager();