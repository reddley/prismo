// Job queue configuration with Redis backend
import { ConnectionOptions } from 'bullmq';

export interface QueueConfig {
  concurrency: {
    rss_fetch: number;
    ai_enrichment: number;
    content_analysis: number;
    briefing_generation: number;
  };
  retries: {
    maxAttempts: number;
    backoffType: 'exponential' | 'fixed';
    backoffDelay: number;
    maxBackoffDelay: number;
  };
  deadLetterQueue: {
    enabled: boolean;
    maxAge: number; // hours
  };
  idempotency: {
    keyTTL: number; // hours
  };
}

export const QUEUE_CONFIG: QueueConfig = {
  // Bounded concurrency per job type
  concurrency: {
    rss_fetch: 3,        // Max 3 RSS feeds fetching simultaneously
    ai_enrichment: 2,    // Max 2 AI enrichment jobs (cost control)
    content_analysis: 4, // Max 4 content analysis jobs
    briefing_generation: 1, // Single briefing generation at a time
  },
  
  // Exponential backoff with jitter
  retries: {
    maxAttempts: 5,
    backoffType: 'exponential',
    backoffDelay: 2000,      // Start with 2 seconds
    maxBackoffDelay: 300000, // Cap at 5 minutes
  },
  
  // Dead letter queue for failed jobs
  deadLetterQueue: {
    enabled: true,
    maxAge: 24, // Keep failed jobs for 24 hours
  },
  
  // Idempotency protection
  idempotency: {
    keyTTL: 24, // Idempotency keys valid for 24 hours
  },
};

// Redis connection configuration
export const getRedisConnection = (): ConnectionOptions => {
  // Use Redis from environment or local fallback
  const redisUrl = process.env.REDIS_URL || process.env.UPSTASH_REDIS_REST_URL;
  
  if (redisUrl) {
    return {
      host: new URL(redisUrl).hostname,
      port: parseInt(new URL(redisUrl).port) || 6379,
      password: new URL(redisUrl).password || undefined,
      maxRetriesPerRequest: null, // Required by BullMQ
      retryDelayOnFailover: 100,
      lazyConnect: true,
    };
  }
  
  // Local Redis fallback for development
  return {
    host: 'localhost',
    port: 6379,
    maxRetriesPerRequest: null, // Required by BullMQ
    retryDelayOnFailover: 100,
    lazyConnect: true,
  };
};

// Job priorities
export enum JobPriority {
  CRITICAL = 1,    // Immediate processing (alerts, errors)
  HIGH = 5,        // Important but not urgent (new insights)
  NORMAL = 10,     // Regular processing (RSS feeds)
  LOW = 20,        // Background tasks (cleanup, optimization)
}

// Job types with their configurations
export const JOB_TYPES = {
  RSS_FETCH: 'rss_fetch',
  AI_ENRICHMENT: 'ai_enrichment', 
  CONTENT_ANALYSIS: 'content_analysis',
  BRIEFING_GENERATION: 'briefing_generation',
  CLEANUP: 'cleanup',
} as const;

export type JobType = typeof JOB_TYPES[keyof typeof JOB_TYPES];