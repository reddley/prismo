import rateLimit from 'express-rate-limit';
import slowDown from 'express-slow-down';
import { Request, Response, NextFunction } from 'express';
import { authService } from '../services/auth-service';

/**
 * Enhanced rate limiter with IP and user-specific tracking
 */
export function createAuthRateLimit(options: {
  windowMs: number;
  max: number;
  attemptType: 'signup' | 'login' | 'password_reset' | 'email_verification';
}) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
    
    try {
      // Check IP-based rate limiting
      const rateLimitResult = await authService.checkRateLimit(
        clientIp,
        'ip',
        options.attemptType
      );

      if (!rateLimitResult.allowed) {
        return res.status(429).json({
          error: 'Rate limit exceeded',
          message: rateLimitResult.blockReason,
          resetTime: rateLimitResult.resetTime,
        });
      }

      // Add rate limit info to request for later use
      req.rateLimitInfo = rateLimitResult;
      next();
    } catch (error) {
      console.error('Rate limit check failed:', error);
      // Continue on error to avoid blocking legitimate users
      next();
    }
  };
}

/**
 * Standard Express rate limiters for additional protection
 */
export const signupRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // Limit each IP to 3 signups per hour
  message: 'Too many signup attempts, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

export const loginRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 login attempts per 15 minutes
  message: 'Too many login attempts, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

export const passwordResetRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // Limit each IP to 3 password reset attempts per hour
  message: 'Too many password reset attempts, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

/**
 * Speed limiter for suspicious activity
 */
export const suspiciousActivitySlowDown = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 2, // Allow 2 requests per 15 minutes at full speed
  delayMs: () => 500, // Add 500ms delay after delayAfter is reached
  maxDelayMs: 20000, // Maximum delay of 20 seconds
  validate: { delayMs: false }, // Disable warning
});

/**
 * Security headers middleware
 */
export function securityHeaders(req: Request, res: Response, next: NextFunction) {
  // Skip CSP in development to allow Vite HMR and development tools
  if (process.env.NODE_ENV === 'development') {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  } else {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self';");
  }
  next();
}

/**
 * Get client context for security logging
 */
export function getClientContext(req: Request) {
  return {
    ipAddress: req.ip || req.connection.remoteAddress || 'unknown',
    userAgent: req.get('User-Agent') || 'unknown',
    sessionId: (req as any).sessionID || undefined,
  };
}

// Extend Express Request interface
declare global {
  namespace Express {
    interface Request {
      rateLimitInfo?: {
        allowed: boolean;
        resetTime?: Date;
        attemptsRemaining?: number;
        blockReason?: string;
      };
    }
  }
}