import { Request, Response, NextFunction } from "express";
import { rateLimiter, RateLimitKeys } from "../services/token-bucket";

// System load tracking
interface SystemMetrics {
  cpuUsage: number;
  memoryUsage: number;
  activeConnections: number;
  p95Latency: number;
  lastUpdate: number;
}

class LoadShedding {
  private metrics: SystemMetrics = {
    cpuUsage: 0,
    memoryUsage: 0,
    activeConnections: 0,
    p95Latency: 0,
    lastUpdate: Date.now()
  };

  private readonly thresholds = {
    // When to start shedding non-critical work
    highLoad: {
      cpuUsage: 70,
      memoryUsage: 80,
      p95Latency: 250,
      activeConnections: 25
    },
    // When to shed almost everything except critical ops
    criticalLoad: {
      cpuUsage: 85,
      memoryUsage: 90,
      p95Latency: 500,
      activeConnections: 28
    }
  };

  updateMetrics(partial: Partial<SystemMetrics>): void {
    this.metrics = {
      ...this.metrics,
      ...partial,
      lastUpdate: Date.now()
    };
  }

  shouldShedLoad(priority: 'critical' | 'high' | 'normal' | 'low'): boolean {
    const m = this.metrics;
    const high = this.thresholds.highLoad;
    const critical = this.thresholds.criticalLoad;

    // Always allow critical operations
    if (priority === 'critical') return false;

    // Under critical load, only allow critical operations
    if (m.cpuUsage > critical.cpuUsage || 
        m.memoryUsage > critical.memoryUsage ||
        m.p95Latency > critical.p95Latency ||
        m.activeConnections > critical.activeConnections) {
      return true;
    }

    // Under high load, shed low priority operations
    if (priority === 'low' && (
        m.cpuUsage > high.cpuUsage ||
        m.memoryUsage > high.memoryUsage ||
        m.p95Latency > high.p95Latency ||
        m.activeConnections > high.activeConnections)) {
      return true;
    }

    return false;
  }

  getLoadLevel(): 'normal' | 'high' | 'critical' {
    const m = this.metrics;
    const high = this.thresholds.highLoad;
    const critical = this.thresholds.criticalLoad;

    if (m.cpuUsage > critical.cpuUsage || 
        m.memoryUsage > critical.memoryUsage ||
        m.p95Latency > critical.p95Latency) {
      return 'critical';
    }

    if (m.cpuUsage > high.cpuUsage || 
        m.memoryUsage > high.memoryUsage ||
        m.p95Latency > high.p95Latency) {
      return 'high';
    }

    return 'normal';
  }

  getMetrics(): SystemMetrics & { loadLevel: string } {
    return {
      ...this.metrics,
      loadLevel: this.getLoadLevel()
    };
  }
}

// Singleton load shedding instance
export const loadShedding = new LoadShedding();

// Request priority classification
function getRequestPriority(req: Request): 'critical' | 'high' | 'normal' | 'low' {
  const path = req.path;
  const method = req.method;

  // Critical: Core authentication and system health
  if (path.startsWith('/api/auth/') || 
      path === '/api/health' || 
      path === '/api/system/status') {
    return 'critical';
  }

  // High: Core business operations
  if (path.startsWith('/api/insights') ||
      path.startsWith('/api/monitors') ||
      path.startsWith('/api/briefings') ||
      (path.startsWith('/api/rss') && method === 'GET')) {
    return 'high';
  }

  // Normal: Standard operations
  if (path.startsWith('/api/data-sources') ||
      path.startsWith('/api/notifications') ||
      path.startsWith('/api/user')) {
    return 'normal';
  }

  // Low: Administrative and non-essential operations
  if (path.startsWith('/api/admin') ||
      path.startsWith('/api/analytics') ||
      path.startsWith('/api/export') ||
      method === 'DELETE') {
    return 'low';
  }

  return 'normal';
}

// Get tenant ID from request (user/team-based)
function getTenantId(req: Request): string | null {
  // Try to get from authenticated user first
  const user = (req as any).user;
  if (user?.teamId) {
    return user.teamId;
  }
  if (user?.id) {
    return `user:${user.id}`;
  }
  
  // Fallback to API key or header-based tenant identification
  const tenantHeader = req.headers['x-tenant-id'] as string;
  if (tenantHeader) {
    return tenantHeader;
  }

  return null;
}

// Get client IP address
function getClientIP(req: Request): string {
  return (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
         req.connection.remoteAddress ||
         req.socket.remoteAddress ||
         '127.0.0.1';
}

interface RateLimitOptions {
  skipSuccessfulAuth?: boolean;
  requireTenant?: boolean;
  operation?: 'api' | 'ingestion' | 'email' | 'auth' | 'general';
  priority?: 'critical' | 'high' | 'normal' | 'low';
  tokens?: number;
}

/**
 * Advanced tenant-aware rate limiting middleware with load shedding
 */
export function tenantRateLimit(options: RateLimitOptions = {}) {
  const {
    skipSuccessfulAuth = false,
    requireTenant = false,
    operation = 'api',
    priority,
    tokens = 1
  } = options;

  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const startTime = Date.now();
      
      // Determine request priority
      const requestPriority = priority || getRequestPriority(req);
      
      // Check if we should shed this request due to load
      if (loadShedding.shouldShedLoad(requestPriority)) {
        const loadLevel = loadShedding.getLoadLevel();
        res.status(503).json({
          error: 'Service temporarily overloaded',
          message: `System under ${loadLevel} load, shedding ${requestPriority} priority requests`,
          retryAfter: 30,
          priority: requestPriority,
          loadLevel
        });
        return;
      }

      const clientIP = getClientIP(req);
      const tenantId = getTenantId(req);

      // Skip rate limiting for successful auth if configured
      if (skipSuccessfulAuth && req.path.includes('/auth/') && req.method === 'POST') {
        return next();
      }

      // Require tenant for certain operations
      if (requireTenant && !tenantId) {
        res.status(400).json({
          error: 'Tenant identification required',
          message: 'Please provide tenant ID or authenticate with a user account'
        });
        return;
      }

      // Apply multiple rate limiting layers
      const checks: Array<{
        key: string;
        operation: string;
        description: string;
      }> = [];

      // 1. IP-based rate limiting (always applied)
      if (operation === 'auth') {
        checks.push({
          key: RateLimitKeys.ipAuth(clientIP),
          operation: 'perIpAuth',
          description: 'IP authentication'
        });
      } else {
        checks.push({
          key: RateLimitKeys.ipGeneral(clientIP),
          operation: 'perIpGeneral',
          description: 'IP general'
        });
      }

      // 2. Tenant-based rate limiting (if tenant available)
      if (tenantId && operation !== 'auth') {
        switch (operation) {
          case 'api':
            checks.push({
              key: RateLimitKeys.tenantApi(tenantId),
              operation: 'tenantApiCalls',
              description: 'Tenant API'
            });
            break;
          case 'ingestion':
            checks.push({
              key: RateLimitKeys.tenantIngestion(tenantId),
              operation: 'tenantDataIngestion',
              description: 'Tenant ingestion'
            });
            break;
          case 'email':
            checks.push({
              key: RateLimitKeys.tenantEmail(tenantId),
              operation: 'tenantEmailSending',
              description: 'Tenant email'
            });
            break;
        }
      }

      // 3. Global rate limiting based on priority
      if (requestPriority === 'critical') {
        checks.push({
          key: RateLimitKeys.globalCritical(),
          operation: 'globalCriticalOps',
          description: 'Global critical'
        });
      } else {
        checks.push({
          key: RateLimitKeys.globalNonCritical(),
          operation: 'globalNonCriticalOps',
          description: 'Global non-critical'
        });
      }

      // Check all rate limits
      for (const check of checks) {
        const result = await rateLimiter.checkRateLimit(
          check.key,
          check.operation as any,
          tokens
        );

        if (!result.allowed) {
          res.status(429).json({
            error: 'Rate limit exceeded',
            message: `${check.description} rate limit exceeded`,
            retryAfter: result.retryAfter,
            resetTime: result.resetTime,
            remaining: result.remaining,
            limit: check.operation,
            priority: requestPriority
          });
          return;
        }
      }

      // Update system metrics for load shedding
      const processingTime = Date.now() - startTime;
      if (processingTime > 100) { // Only track slower requests
        loadShedding.updateMetrics({
          p95Latency: Math.max(loadShedding.getMetrics().p95Latency * 0.95, processingTime)
        });
      }

      // Add rate limit headers for monitoring
      res.set({
        'X-RateLimit-Priority': requestPriority,
        'X-RateLimit-Tenant': tenantId || 'none',
        'X-System-Load': loadShedding.getLoadLevel()
      });

      next();
    } catch (error) {
      console.error('Rate limiting error:', error);
      // Fail open - don't block requests if rate limiter fails
      next();
    }
  };
}

/**
 * Endpoint to get rate limiting status for monitoring
 */
export async function getRateLimitStatus(req: Request, res: Response) {
  try {
    const clientIP = getClientIP(req);
    const tenantId = getTenantId(req);
    
    const status: any = {
      ip: clientIP,
      tenant: tenantId,
      loadLevel: loadShedding.getLoadLevel(),
      systemMetrics: loadShedding.getMetrics(),
      rateLimiterMetrics: rateLimiter.getMetrics(),
      buckets: {}
    };

    // Get status for various bucket types
    if (tenantId) {
      status.buckets.tenantApi = rateLimiter.getBucketStatus(
        RateLimitKeys.tenantApi(tenantId), 
        'tenantApiCalls'
      );
      status.buckets.tenantIngestion = rateLimiter.getBucketStatus(
        RateLimitKeys.tenantIngestion(tenantId), 
        'tenantDataIngestion'
      );
    }

    status.buckets.ipGeneral = rateLimiter.getBucketStatus(
      RateLimitKeys.ipGeneral(clientIP), 
      'perIpGeneral'
    );
    
    status.buckets.globalCritical = rateLimiter.getBucketStatus(
      RateLimitKeys.globalCritical(), 
      'globalCriticalOps'
    );

    res.json(status);
  } catch (error) {
    console.error('Error getting rate limit status:', error);
    res.status(500).json({ error: 'Failed to get rate limit status' });
  }
}

/**
 * Admin endpoint to reset rate limits
 */
export async function resetRateLimit(req: Request, res: Response) {
  try {
    const { tenantId, ip, bucketKey } = req.body;
    
    if (bucketKey) {
      rateLimiter.resetBucket(bucketKey);
    } else if (tenantId) {
      rateLimiter.resetBucket(RateLimitKeys.tenantApi(tenantId));
      rateLimiter.resetBucket(RateLimitKeys.tenantIngestion(tenantId));
      rateLimiter.resetBucket(RateLimitKeys.tenantEmail(tenantId));
    } else if (ip) {
      rateLimiter.resetBucket(RateLimitKeys.ipAuth(ip));
      rateLimiter.resetBucket(RateLimitKeys.ipGeneral(ip));
    } else {
      return res.status(400).json({ 
        error: 'Must specify tenantId, ip, or bucketKey' 
      });
    }

    res.json({ 
      success: true, 
      message: 'Rate limit reset successfully' 
    });
  } catch (error) {
    console.error('Error resetting rate limit:', error);
    res.status(500).json({ error: 'Failed to reset rate limit' });
  }
}